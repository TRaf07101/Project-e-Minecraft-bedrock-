import { ACTIVITY_TYPES, UNITS } from "../course";
import { dayKey, type State } from "./store";
import { isActivityDone, isCheckpointPassed, levelProgress } from "./progress";

export interface Challenge {
  id: string;
  label: string;
  value: number;
  goal: number;
  icon: "activity" | "correct" | "review" | "stars";
}

/** Três desafios diários (inspirados nas missões diárias do Busuu), calculados a partir do estudo real do dia. */
export function dailyChallenges(s: State): Challenge[] {
  const d = s.days[dayKey()] ?? { xp: 0, minutes: 0, activities: 0 };
  return [
    { id: "activities", label: "Conclua 2 atividades", value: d.activities, goal: 2, icon: "activity" },
    { id: "correct", label: "Acerte 20 respostas", value: d.correct ?? 0, goal: 20, icon: "correct" },
    { id: "stars", label: `Ganhe ${s.settings.dailyGoal} estrelas`, value: d.xp, goal: s.settings.dailyGoal, icon: "stars" },
  ];
}
export const challengesDone = (s: State) => dailyChallenges(s).filter((c) => c.value >= c.goal).length;

/** Semana atual (segunda a domingo). */
export function weekDays(): Date[] {
  const now = new Date();
  const dow = (now.getDay() + 6) % 7; // 0 = segunda
  return Array.from({ length: 7 }, (_, i) => {
    const d = new Date(now);
    d.setDate(now.getDate() - dow + i);
    return d;
  });
}

export function planStats(s: State) {
  const days = weekDays();
  const weekMinutes = days.reduce((n, d) => n + (s.days[dayKey(d)]?.minutes ?? 0), 0);
  const weekGoal = s.plan.minutes * s.plan.days.length;
  const today = new Date();
  const todayMinutes = s.days[dayKey()]?.minutes ?? 0;
  const isStudyDay = s.plan.days.includes(today.getDay());
  const fluency = (levelProgress(s, "A2") + levelProgress(s, "B1")) / 2;

  // tempo restante estimado: ~4 min por atividade, ~6 min por checkpoint
  let remaining = 0;
  for (const u of UNITS) {
    for (const l of u.lessons) for (const t of ACTIVITY_TYPES) if (!isActivityDone(s, l.id, t)) remaining += 4;
    if (!isCheckpointPassed(s, u.id)) remaining += 6;
  }
  const perWeek = Math.max(1, weekGoal);
  const weeks = remaining / perWeek;
  const eta = new Date(Date.now() + weeks * 7 * 864e5);
  return { days, weekMinutes, weekGoal, todayMinutes, isStudyDay, fluency, remainingMinutes: remaining, eta };
}

export const WEEKDAY_SHORT = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];
export const WEEKDAY_LETTER = ["D", "S", "T", "Q", "Q", "S", "S"];
