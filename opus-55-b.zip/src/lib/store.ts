import { useSyncExternalStore } from "react";
import type { ActivityType, Level } from "../course";

export interface ActivityRecord {
  done: boolean;
  best: number; // 0..1
  attempts: number;
  at: number;
}
export interface CheckpointRecord {
  best: number;
  passed: boolean;
  attempts: number;
  at: number;
}
export interface VocabRecord {
  box: number; // 0..5
  due: number;
  correct: number;
  wrong: number;
  last: number;
}
export interface GrammarRecord {
  correct: number;
  wrong: number;
  last: number;
  recent: number[]; // last results 1/0
}
export interface Settings {
  furigana: boolean;
  romaji: boolean;
  autoplay: boolean;
  rate: number;
  sfx: boolean;
  dailyGoal: number;
}
export interface DayStat {
  xp: number;
  minutes: number;
  activities: number;
  correct?: number; // respostas corretas no dia (desafios diários)
  reviewed?: number; // itens revisados no dia (desafios diários)
}
export interface StudyPlan {
  days: number[]; // 0=domingo … 6=sábado
  minutes: number; // minutos por dia
  time: string; // horário preferido HH:MM
}
export interface State {
  version: 1;
  onboarded: boolean;
  name: string;
  createdAt: number;
  activities: Record<string, ActivityRecord>;
  checkpoints: Record<string, CheckpointRecord>;
  testedOut: { A2?: boolean };
  placement?: { score: number; at: number; passed: boolean };
  vocab: Record<string, VocabRecord>;
  grammar: Record<string, GrammarRecord>;
  xp: number;
  days: Record<string, DayStat>;
  streak: { count: number; last: string | null; best: number };
  settings: Settings;
  certificates: Partial<Record<Level, { at: number; score: number }>>;
  lastPath?: string;
  favorites: string[];
  plan: StudyPlan;
}

const KEY = "kotoba-jp-a2b1-v1";

export const defaultState = (): State => ({
  version: 1,
  onboarded: false,
  name: "",
  createdAt: Date.now(),
  activities: {},
  checkpoints: {},
  testedOut: {},
  vocab: {},
  grammar: {},
  xp: 0,
  days: {},
  streak: { count: 0, last: null, best: 0 },
  settings: { furigana: true, romaji: false, autoplay: true, rate: 0.9, sfx: true, dailyGoal: 30 },
  certificates: {},
  favorites: [],
  plan: { days: [1, 2, 3, 4, 5], minutes: 10, time: "19:00" },
});

function load(): State {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return defaultState();
    const parsed = JSON.parse(raw);
    const d = defaultState();
    return {
      ...d,
      ...parsed,
      settings: { ...d.settings, ...(parsed.settings ?? {}) },
      streak: { ...d.streak, ...(parsed.streak ?? {}) },
      plan: { ...d.plan, ...(parsed.plan ?? {}) },
      favorites: Array.isArray(parsed.favorites) ? parsed.favorites : [],
    };
  } catch {
    return defaultState();
  }
}

let state: State = load();
const listeners = new Set<() => void>();

function persist() {
  try {
    localStorage.setItem(KEY, JSON.stringify(state));
  } catch {
    /* storage full / disabled */
  }
}

export function getState() {
  return state;
}

export function setState(fn: (s: State) => State) {
  state = fn(state);
  persist();
  listeners.forEach((l) => l());
}

export function subscribe(l: () => void) {
  listeners.add(l);
  return () => listeners.delete(l);
}

export function useAppState<T>(sel: (s: State) => T): T {
  return useSyncExternalStore(subscribe, () => sel(state), () => sel(state));
}

// sync across tabs
if (typeof window !== "undefined") {
  window.addEventListener("storage", (e) => {
    if (e.key === KEY) {
      state = load();
      listeners.forEach((l) => l());
    }
  });
}

// ───────────────────────── dates
export const dayKey = (d = new Date()) => {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${dd}`;
};
export const yesterdayKey = () => {
  const d = new Date();
  d.setDate(d.getDate() - 1);
  return dayKey(d);
};

export function effectiveStreak(s: State) {
  const today = dayKey();
  if (s.streak.last === today || s.streak.last === yesterdayKey()) return s.streak.count;
  return 0;
}

// ───────────────────────── actions
export const activityKey = (lessonId: string, type: ActivityType) => `${lessonId}:${type}`;

export function addXP(xp: number, minutes: number, countActivity = true) {
  setState((s) => {
    const today = dayKey();
    const day = s.days[today] ?? { xp: 0, minutes: 0, activities: 0 };
    let streak = s.streak;
    if (streak.last !== today) {
      const count = streak.last === yesterdayKey() ? streak.count + 1 : 1;
      streak = { count, last: today, best: Math.max(streak.best, count) };
    }
    return {
      ...s,
      xp: s.xp + xp,
      streak,
      days: {
        ...s.days,
        [today]: { xp: day.xp + xp, minutes: day.minutes + minutes, activities: day.activities + (countActivity ? 1 : 0) },
      },
    };
  });
}

export function completeActivity(lessonId: string, type: ActivityType, score: number) {
  const k = activityKey(lessonId, type);
  setState((s) => {
    const prev = s.activities[k];
    return {
      ...s,
      activities: {
        ...s.activities,
        [k]: { done: true, best: Math.max(prev?.best ?? 0, score), attempts: (prev?.attempts ?? 0) + 1, at: Date.now() },
      },
    };
  });
}

export function recordCheckpoint(unitId: string, score: number, passed: boolean) {
  setState((s) => {
    const prev = s.checkpoints[unitId];
    return {
      ...s,
      checkpoints: {
        ...s.checkpoints,
        [unitId]: {
          best: Math.max(prev?.best ?? 0, score),
          passed: (prev?.passed ?? false) || passed,
          attempts: (prev?.attempts ?? 0) + 1,
          at: Date.now(),
        },
      },
    };
  });
}

export function awardCertificate(level: Level, score: number) {
  setState((s) => (s.certificates[level] ? s : { ...s, certificates: { ...s.certificates, [level]: { at: Date.now(), score } } }));
}

export function recordPlacement(score: number, passed: boolean) {
  setState((s) => ({
    ...s,
    placement: { score, at: Date.now(), passed: passed || (s.placement?.passed ?? false) },
    testedOut: passed ? { ...s.testedOut, A2: true } : s.testedOut,
  }));
}

// Spaced repetition (Leitner boxes)
const HOUR = 3600_000;
const DAY = 24 * HOUR;
const INTERVALS = [0, 4 * HOUR, 1 * DAY, 3 * DAY, 7 * DAY, 16 * DAY];

export function recordVocab(id: string, correct: boolean) {
  setState((s) => {
    const r = s.vocab[id] ?? { box: 0, due: 0, correct: 0, wrong: 0, last: 0 };
    const box = correct ? Math.min(5, r.box + 1) : Math.max(0, r.box - 2);
    const now = Date.now();
    return {
      ...s,
      vocab: {
        ...s.vocab,
        [id]: {
          box,
          due: now + (correct ? INTERVALS[box] : 10 * 60_000),
          correct: r.correct + (correct ? 1 : 0),
          wrong: r.wrong + (correct ? 0 : 1),
          last: now,
        },
      },
    };
  });
}

export function ensureVocab(ids: string[]) {
  setState((s) => {
    const vocab = { ...s.vocab };
    let changed = false;
    for (const id of ids) {
      if (!vocab[id]) {
        vocab[id] = { box: 1, due: Date.now() + INTERVALS[1], correct: 0, wrong: 0, last: Date.now() };
        changed = true;
      }
    }
    return changed ? { ...s, vocab } : s;
  });
}

export function recordGrammar(id: string, correct: boolean) {
  setState((s) => {
    const r = s.grammar[id] ?? { correct: 0, wrong: 0, last: 0, recent: [] };
    return {
      ...s,
      grammar: {
        ...s.grammar,
        [id]: {
          correct: r.correct + (correct ? 1 : 0),
          wrong: r.wrong + (correct ? 0 : 1),
          last: Date.now(),
          recent: [...r.recent, correct ? 1 : 0].slice(-10),
        },
      },
    };
  });
}

export type Strength = "fraca" | "média" | "forte";
/** Força com decaimento: como no Busuu, a força cai quando a palavra fica muito tempo sem revisão. */
export function effectiveBox(r: VocabRecord, now = Date.now()) {
  const overdue = now - r.due;
  if (overdue <= 0) return r.box;
  const step = Math.max(DAY, INTERVALS[r.box] ?? DAY);
  return Math.max(0, r.box - Math.floor(overdue / step));
}
export const vocabStrength = (r?: VocabRecord): Strength => {
  if (!r) return "fraca";
  const b = effectiveBox(r);
  return b <= 1 ? "fraca" : b <= 3 ? "média" : "forte";
};

/** Quatro níveis de domínio da Revisão de Gramática (Precisa praticar, Melhorando, Forte, Dominado). */
export type Mastery = "needs" | "improving" | "strong" | "mastered";
export const MASTERY_LABEL: Record<Mastery, string> = { needs: "Precisa praticar", improving: "Melhorando", strong: "Forte", mastered: "Dominado" };
export const MASTERY_COLOR: Record<Mastery, string> = { needs: "#E5484D", improving: "#F5A623", strong: "#116EEE", mastered: "#1E9E62" };
export function grammarMastery(r?: GrammarRecord): Mastery {
  if (!r || r.recent.length === 0) return "needs";
  const avg = r.recent.reduce((a, b) => a + b, 0) / r.recent.length;
  const days = (Date.now() - r.last) / DAY;
  const score = avg - Math.min(0.3, Math.max(0, days - 3) * 0.02);
  if (score >= 0.9 && r.recent.length >= 8) return "mastered";
  if (score >= 0.75 && r.recent.length >= 4) return "strong";
  if (score >= 0.5) return "improving";
  return "needs";
}

export function toggleFavorite(id: string) {
  setState((s) => ({ ...s, favorites: s.favorites.includes(id) ? s.favorites.filter((f) => f !== id) : [...s.favorites, id] }));
}
export function updatePlan(p: Partial<StudyPlan>) {
  setState((s) => ({ ...s, plan: { ...s.plan, ...p } }));
}
export function trackDay(p: { correct?: number; reviewed?: number }) {
  setState((s) => {
    const today = dayKey();
    const d = s.days[today] ?? { xp: 0, minutes: 0, activities: 0 };
    return {
      ...s,
      days: { ...s.days, [today]: { ...d, correct: (d.correct ?? 0) + (p.correct ?? 0), reviewed: (d.reviewed ?? 0) + (p.reviewed ?? 0) } },
    };
  });
}

export function grammarStrength(r?: GrammarRecord): Strength {
  if (!r || r.recent.length === 0) return "fraca";
  const avg = r.recent.reduce((a, b) => a + b, 0) / r.recent.length;
  return avg >= 0.85 && r.recent.length >= 5 ? "forte" : avg >= 0.6 ? "média" : "fraca";
}

export function updateSettings(p: Partial<Settings>) {
  setState((s) => ({ ...s, settings: { ...s.settings, ...p } }));
}

export function resetAll() {
  state = defaultState();
  persist();
  listeners.forEach((l) => l());
}

export function exportState() {
  return JSON.stringify(state, null, 2);
}

export function importState(json: string): boolean {
  try {
    const parsed = JSON.parse(json);
    if (!parsed || parsed.version !== 1 || typeof parsed.activities !== "object") return false;
    const d = defaultState();
    state = { ...d, ...parsed, settings: { ...d.settings, ...parsed.settings } };
    persist();
    listeners.forEach((l) => l());
    return true;
  } catch {
    return false;
  }
}
