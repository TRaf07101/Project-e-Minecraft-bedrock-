import {
  ALL_GRAMMAR,
  ALL_KANJI,
  ALL_VOCAB,
  unitsOf,
  vocabById,
  grammarById,
  type ActivityType,
  type Dialogue,
  type GapEx,
  type Grammar,
  type Kanji,
  type Lesson,
  type OrderEx,
  type Unit,
  type Vocab,
  type Writing,
} from "../course";
import { plain, reading } from "../course/kana";
import { getState, vocabStrength } from "./store";

export interface McqStep {
  t: "mcq";
  key: string;
  instruction: string;
  promptJp?: string;
  promptPt?: string;
  audio?: string; // text to speak
  listening?: boolean; // hide prompt text, audio only
  context?: string;
  options: string[];
  optionsJp: boolean;
  answer: number;
  exp?: string;
  vocabId?: string;
  grammarId?: string;
}
export type Step =
  | { t: "vocabCard"; key: string; v: Vocab }
  | { t: "kanjiCard"; key: string; k: Kanji }
  | { t: "grammarCard"; key: string; g: Grammar }
  | { t: "dialogue"; key: string; d: Dialogue }
  | McqStep
  | { t: "match"; key: string; pairs: { id: string; left: string; right: string; vocabId?: string }[] }
  | { t: "type"; key: string; v: Vocab }
  | { t: "gap"; key: string; ex: GapEx; grammarId: string }
  | { t: "order"; key: string; ex: OrderEx; grammarId: string }
  | { t: "write"; key: string; w: Writing }
  | { t: "tf"; key: string; v: Vocab; claim: string; truth: boolean }
  | { t: "spell"; key: string; v: Vocab; tiles: string[] }
  | { t: "speak"; key: string; v: Vocab }
  | { t: "flash"; key: string; v: Vocab };

export const isGraded = (s: Step) => !["vocabCard", "kanjiCard", "grammarCard", "dialogue"].includes(s.t);
/** Tipos que voltam ao fim da atividade quando errados (comportamento observado no Busuu). */
export const isRetryable = (s: Step) => ["mcq", "gap", "order", "type", "tf", "spell"].includes(s.t);

export const speechRecognitionAvailable = () =>
  typeof window !== "undefined" && ("SpeechRecognition" in window || "webkitSpeechRecognition" in window);

export interface Session {
  id: string;
  kind: "activity" | "checkpoint" | "placement" | "review";
  title: string;
  subtitle: string;
  steps: Step[];
}

// ───────────────────────── helpers
export function shuffle<T>(a: T[]): T[] {
  const r = [...a];
  for (let i = r.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [r[i], r[j]] = [r[j], r[i]];
  }
  return r;
}
const sample = <T,>(a: T[], n: number) => shuffle(a).slice(0, n);

function distract(answer: string, pool: string[], n: number) {
  const seen = new Set([plain(answer)]);
  const out: string[] = [];
  for (const p of shuffle(pool)) {
    const k = plain(p);
    if (seen.has(k)) continue;
    seen.add(k);
    out.push(p);
    if (out.length >= n) break;
  }
  return out;
}

function mcq(base: Omit<McqStep, "t" | "options" | "answer">, correct: string, wrong: string[]): McqStep {
  const opts = shuffle([correct, ...wrong]);
  return { t: "mcq", ...base, options: opts, answer: opts.indexOf(correct) };
}

function shuffledGap(ex: GapEx): GapEx {
  const correct = ex.options[ex.answer];
  const opts = shuffle(ex.options);
  return { ...ex, options: opts, answer: opts.indexOf(correct) };
}

function lessonVocabPool(v: Vocab) {
  // prefer same unit, then whole course
  const unitPrefix = v.lessonId.split("-").slice(0, 2).join("-");
  const near = ALL_VOCAB.filter((x) => x.lessonId.startsWith(unitPrefix + "-") && x.id !== v.id);
  return near.length >= 6 ? near : ALL_VOCAB.filter((x) => x.id !== v.id);
}

// vocabulary question builders
export function vocabMeaning(v: Vocab, key: string): McqStep {
  const pool = lessonVocabPool(v).map((x) => x.pt);
  return mcq(
    { key, instruction: "Qual é o significado?", promptJp: v.jp, audio: v.kana, optionsJp: false, vocabId: v.id },
    v.pt,
    distract(v.pt, pool, 3)
  );
}
export function vocabReverse(v: Vocab, key: string): McqStep {
  const pool = lessonVocabPool(v).map((x) => x.jp);
  return mcq({ key, instruction: "Como se diz em japonês?", promptPt: v.pt, optionsJp: true, vocabId: v.id }, v.jp, distract(v.jp, pool, 3));
}
export function vocabListening(v: Vocab, key: string): McqStep {
  const pool = lessonVocabPool(v).map((x) => x.jp);
  return mcq(
    { key, instruction: "Ouça e escolha a palavra que você ouviu", audio: v.kana, listening: true, optionsJp: true, vocabId: v.id },
    v.jp,
    distract(v.jp, pool, 3)
  );
}
function vocabInContext(v: Vocab, key: string): McqStep {
  const pool = lessonVocabPool(v).map((x) => x.pt);
  return mcq(
    {
      key,
      instruction: "Ouça a frase. O que significa a palavra destacada?",
      promptJp: v.ex,
      audio: v.ex,
      context: `Palavra: ${plain(v.jp)}`,
      optionsJp: false,
      vocabId: v.id,
    },
    v.pt,
    distract(v.pt, pool, 3)
  );
}

export function vocabTrueFalse(v: Vocab, key: string): Step {
  const truth = Math.random() < 0.5;
  const pool = lessonVocabPool(v).map((x) => x.pt);
  const claim = truth ? v.pt : distract(v.pt, pool, 1)[0] ?? v.pt;
  return { t: "tf", key, v, claim, truth: claim === v.pt };
}

const KANA_POOL = "あいうえおかきくけこさしすせそたちつてとなにぬねのはひふへほまみむめもやゆよらりるれろわをんがぎぐげござじずぜぞだでどばびぶべぼぱぴぷぺぽ";
export function vocabSpell(v: Vocab, key: string): Step | null {
  const chars = [...v.kana.replace(/\s/g, "")];
  if (chars.length < 2 || chars.length > 7 || !/^[\u3041-\u3096]+$/.test(chars.join(""))) return null;
  const extra: string[] = [];
  while (extra.length < Math.min(3, 9 - chars.length)) {
    const c = KANA_POOL[Math.floor(Math.random() * KANA_POOL.length)];
    if (!chars.includes(c) && !extra.includes(c)) extra.push(c);
  }
  return { t: "spell", key, v, tiles: shuffle([...chars, ...extra]) };
}

function kanjiQuestions(k: Kanji, keyBase: string): McqStep[] {
  const others = ALL_KANJI.filter((x) => x.id !== k.id);
  const out: McqStep[] = [
    mcq(
      { key: keyBase + "-m", instruction: "O que significa este kanji?", promptJp: k.char, optionsJp: false },
      k.pt,
      distract(
        k.pt,
        others.map((o) => o.pt),
        3
      )
    ),
  ];
  k.words.forEach((w, i) => {
    const r = reading(w.jp);
    const pool = others.flatMap((o) => o.words.map((x) => reading(x.jp)));
    out.push(
      mcq(
        {
          key: `${keyBase}-r${i}`,
          instruction: "Como se lê esta palavra?",
          promptJp: plain(w.jp),
          context: w.pt,
          optionsJp: true,
        },
        r,
        distract(r, pool, 3)
      )
    );
  });
  return out;
}

function grammarListening(g: Grammar, key: string): McqStep {
  const x = g.examples[Math.floor(Math.random() * g.examples.length)];
  const pool = ALL_GRAMMAR.filter((o) => o.id !== g.id).flatMap((o) => o.examples.map((e) => e.pt));
  const local = g.examples.filter((e) => e !== x).map((e) => e.pt);
  return mcq(
    { key, instruction: "Ouça a frase e escolha a tradução correta", audio: x.jp, listening: true, optionsJp: false, grammarId: g.id },
    x.pt,
    [...distract(x.pt, local, 2), ...distract(x.pt, pool, 3)].slice(0, 3)
  );
}

function dialogueQuestions(l: Lesson): McqStep[] {
  return l.dialogue.questions.map((q) => {
    const correct = q.options[q.answer];
    return mcq({ key: q.id, instruction: "Responda sobre o diálogo", promptPt: q.q, context: `Diálogo: ${l.dialogue.title}`, optionsJp: false }, correct, q.options.filter((_, i) => i !== q.answer));
  });
}

function dialogueLineMatch(l: Lesson, key: string): McqStep {
  const lines = l.dialogue.lines;
  const target = lines[Math.floor(Math.random() * lines.length)];
  return mcq(
    { key, instruction: "Qual fala do diálogo corresponde a esta tradução?", promptPt: `“${target.pt}”`, optionsJp: true },
    target.jp,
    distract(
      target.jp,
      lines.map((x) => x.jp),
      2
    )
  );
}

const gapStep = (ex: GapEx, gid: string, key?: string): Step => ({ t: "gap", key: key ?? ex.id, ex: shuffledGap(ex), grammarId: gid });

// ───────────────────────── activity sessions
export function buildActivity(l: Lesson, type: ActivityType): Session {
  const id = `${l.id}:${type}`;
  const steps: Step[] = [];
  const titleMap: Record<ActivityType, string> = {
    vocab: "Vocabulário",
    kanji: "Kanji",
    grammar: "Gramática",
    dialogue: "Diálogo",
    practice: "Prática final",
  };
  if (type === "vocab") {
    const half = Math.ceil(l.vocab.length / 2);
    const groups = [l.vocab.slice(0, half), l.vocab.slice(half)];
    groups.forEach((grp, gi) => {
      grp.forEach((v) => steps.push({ t: "vocabCard", key: `card-${v.id}`, v }));
      grp.forEach((v, i) => {
        const k = (i + gi) % 3;
        steps.push(k === 0 ? vocabMeaning(v, `m-${v.id}`) : k === 1 ? vocabListening(v, `l-${v.id}`) : vocabReverse(v, `r-${v.id}`));
      });
    });
    steps.push({
      t: "match",
      key: `match-${l.id}`,
      pairs: sample(l.vocab, 5).map((v) => ({ id: v.id, left: v.jp, right: v.pt, vocabId: v.id })),
    });
    const tfWords = sample(l.vocab, 2);
    tfWords.forEach((v) => steps.push(vocabTrueFalse(v, `tf-${v.id}`)));
    const byLen = [...l.vocab].sort((a, b) => a.kana.length - b.kana.length);
    const spellable = byLen.filter((v) => /^[\u3041-\u3096]{3,7}$/.test(v.kana));
    const sv = spellable[Math.floor(Math.random() * spellable.length)];
    const spell = sv ? vocabSpell(sv, `sp-${sv.id}`) : null;
    if (spell) steps.push(spell);
    const typeable = byLen.slice(0, 2);
    typeable.forEach((v) => steps.push({ t: "type", key: `t-${v.id}`, v }));
  } else if (type === "kanji") {
    l.kanji.forEach((k) => {
      steps.push({ t: "kanjiCard", key: `card-${k.id}`, k });
      steps.push(...kanjiQuestions(k, k.id));
    });
    const seenL = new Set<string>();
    const seenR = new Set<string>();
    const kpairs = l.kanji
      .flatMap((k) => k.words.map((w, i) => ({ id: `${k.id}-${i}`, left: w.jp, right: w.pt })))
      .filter((p) => {
        const a = plain(p.left);
        const b = p.right.toLowerCase();
        if (seenL.has(a) || seenR.has(b)) return false;
        seenL.add(a);
        seenR.add(b);
        return true;
      })
      .slice(0, 5);
    if (kpairs.length >= 2) steps.push({ t: "match", key: `kmatch-${l.id}`, pairs: kpairs });
  } else if (type === "grammar") {
    const g = l.grammar;
    steps.push({ t: "grammarCard", key: `card-${g.id}`, g });
    g.exercises.forEach((ex) => (ex.kind === "gap" ? steps.push(gapStep(ex, g.id)) : steps.push({ t: "order", key: ex.id, ex, grammarId: g.id })));
    steps.push(grammarListening(g, `gl-${g.id}`));
  } else if (type === "dialogue") {
    steps.push({ t: "dialogue", key: `dlg-${l.id}`, d: l.dialogue });
    steps.push(...dialogueQuestions(l));
    steps.push(dialogueLineMatch(l, `dline-${l.id}`));
    const v = l.vocab.find((x) => l.dialogue.lines.some((ln) => plain(ln.jp).includes(plain(x.jp).slice(0, 2)))) ?? l.vocab[0];
    steps.push(vocabInContext(v, `ctx-${v.id}`));
  } else {
    const vs = sample(l.vocab, 3);
    steps.push(vocabReverse(vs[0], `p-r-${vs[0].id}`));
    steps.push(vocabListening(vs[1], `p-l-${vs[1].id}`));
    steps.push({ t: "type", key: `p-t-${vs[2].id}`, v: vs[2] });
    const k = l.kanji[Math.floor(Math.random() * l.kanji.length)];
    steps.push(kanjiQuestions(k, `p-${k.id}`)[1]);
    const gaps = sample(
      l.grammar.exercises.filter((e): e is GapEx => e.kind === "gap"),
      2
    );
    gaps.forEach((ex) => steps.push(gapStep(ex, l.grammar.id, `p-${ex.id}`)));
    const ord = l.grammar.exercises.find((e): e is OrderEx => e.kind === "order");
    if (ord) steps.push({ t: "order", key: `p-${ord.id}`, ex: ord, grammarId: l.grammar.id });
    if (speechRecognitionAvailable()) {
      const sv = vs[0];
      steps.push({ t: "speak", key: `p-s-${sv.id}`, v: sv });
    }
    steps.push({ t: "write", key: `w-${l.id}`, w: l.writing });
  }
  return { id, kind: "activity", title: titleMap[type], subtitle: l.title, steps };
}

// ───────────────────────── checkpoint (end of unit)
export function buildCheckpoint(u: Unit): Session {
  const steps: Step[] = [];
  for (const l of u.lessons) {
    const gaps = sample(
      l.grammar.exercises.filter((e): e is GapEx => e.kind === "gap"),
      2
    );
    gaps.forEach((ex) => steps.push(gapStep(ex, l.grammar.id, `cp-${ex.id}`)));
    const v = l.vocab[Math.floor(Math.random() * l.vocab.length)];
    steps.push(Math.random() < 0.5 ? vocabReverse(v, `cp-v-${v.id}`) : vocabListening(v, `cp-v-${v.id}`));
    const qs = dialogueQuestions(l);
    steps.push({ ...qs[Math.floor(Math.random() * qs.length)], key: `cp-q-${l.id}` });
    const k = l.kanji[Math.floor(Math.random() * l.kanji.length)];
    steps.push({ ...kanjiQuestions(k, `cp-${k.id}`)[1] });
  }
  return { id: `cp:${u.id}`, kind: "checkpoint", title: "Checkpoint", subtitle: u.title, steps: shuffle(steps) };
}

// ───────────────────────── placement (A2 → B1)
export function buildPlacement(): Session {
  const lessons = sample(
    unitsOf("A2").flatMap((u) => u.lessons),
    20
  );
  const steps: Step[] = lessons.map((l) => {
    const gaps = l.grammar.exercises.filter((e): e is GapEx => e.kind === "gap");
    const ex = gaps[Math.floor(Math.random() * gaps.length)];
    return gapStep(ex, l.grammar.id, `pl-${ex.id}`);
  });
  return { id: "placement", kind: "placement", title: "Teste de nivelamento", subtitle: "Conteúdo do nível A2", steps };
}

// ───────────────────────── reviews
export function dueVocabIds(limit = 12): string[] {
  const s = getState();
  const now = Date.now();
  return Object.entries(s.vocab)
    .filter(([id, r]) => r.due <= now && vocabById.has(id))
    .sort((a, b) => a[1].box - b[1].box || a[1].due - b[1].due)
    .slice(0, limit)
    .map(([id]) => id);
}

export function weakVocabIds(limit = 12): string[] {
  const s = getState();
  return shuffle(Object.entries(s.vocab).filter(([id, r]) => vocabById.has(id) && vocabStrength(r) !== "forte"))
    .sort((a, b) => a[1].box - b[1].box)
    .slice(0, limit)
    .map(([id]) => id);
}

export function buildVocabReview(ids: string[], title = "Revisão inteligente", mode: "writing" | "flash" = "writing"): Session {
  const steps: Step[] = ids.map((id, i) => {
    const v = vocabById.get(id)!;
    if (mode === "flash") return { t: "flash", key: `rv-f-${id}`, v };
    const k = (i + Math.floor(Math.random() * 5)) % 5;
    if (k === 0) return vocabMeaning(v, `rv-m-${id}`);
    if (k === 1) return vocabReverse(v, `rv-r-${id}`);
    if (k === 2) return vocabListening(v, `rv-l-${id}`);
    if (k === 3) return vocabTrueFalse(v, `rv-tf-${id}`);
    return { t: "type", key: `rv-t-${id}`, v };
  });
  return { id: "review-vocab", kind: "review", title, subtitle: `${ids.length} palavras · ${mode === "flash" ? "Cartões" : "Escrita"}`, steps };
}

export function favoriteVocabIds(limit = 15): string[] {
  return shuffle(getState().favorites.filter((id) => vocabById.has(id))).slice(0, limit);
}

export function buildGrammarReview(grammarIds: string[], title = "Revisão de gramática"): Session {
  const steps: Step[] = [];
  const per = grammarIds.length === 1 ? 6 : Math.max(1, Math.ceil(8 / grammarIds.length));
  for (const gid of grammarIds) {
    const g = grammarById.get(gid);
    if (!g) continue;
    const exs = sample(g.exercises, Math.min(per, g.exercises.length));
    for (const ex of exs) {
      if (ex.kind === "gap") steps.push(gapStep(ex, g.id, `gr-${ex.id}`));
      else steps.push({ t: "order", key: `gr-${ex.id}`, ex, grammarId: g.id });
    }
    if (grammarIds.length === 1) steps.push(grammarListening(g, `gr-l-${g.id}`));
  }
  return { id: "review-grammar", kind: "review", title, subtitle: grammarIds.length === 1 ? grammarById.get(grammarIds[0])?.title ?? "" : `${grammarIds.length} tópicos`, steps: shuffle(steps).slice(0, 10) };
}
