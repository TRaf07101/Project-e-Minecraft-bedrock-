import { useSyncExternalStore } from "react";

const get = () => (window.location.hash.replace(/^#/, "") || "/").split("?")[0];

export function useRoute(): string[] {
  const path = useSyncExternalStore(
    (cb) => {
      window.addEventListener("hashchange", cb);
      return () => window.removeEventListener("hashchange", cb);
    },
    get,
    get
  );
  return path.split("/").filter(Boolean);
}

export function navigate(path: string, replace = false) {
  const target = "#" + path;
  if (replace) window.location.replace(target);
  else window.location.hash = path;
  window.scrollTo({ top: 0 });
}

export function back(fallback = "/") {
  if (window.history.length > 1) window.history.back();
  else navigate(fallback);
}
