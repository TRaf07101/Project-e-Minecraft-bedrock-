import { getState } from "./store";
import { plain } from "../course/kana";

let voice: SpeechSynthesisVoice | null = null;
let voicesLoaded = false;
const hasTTS = typeof window !== "undefined" && "speechSynthesis" in window;

function pickVoice() {
  if (!hasTTS) return;
  const vs = window.speechSynthesis.getVoices();
  if (vs.length) voicesLoaded = true;
  const ja = vs.filter((v) => v.lang.toLowerCase().startsWith("ja"));
  voice =
    ja.find((v) => /google/i.test(v.name)) ||
    ja.find((v) => /kyoko|otoya|haruka|nanami|ayumi|ichiro|sayaka/i.test(v.name)) ||
    ja[0] ||
    null;
}
if (hasTTS) {
  pickVoice();
  window.speechSynthesis.onvoiceschanged = pickVoice;
}

export const ttsAvailable = () => hasTTS;
export const japaneseVoiceAvailable = () => {
  if (!voicesLoaded) pickVoice();
  return !!voice;
};
export const voiceName = () => voice?.name ?? null;

let speakId = 0;
type Listener = (text: string | null) => void;
const speakingListeners = new Set<Listener>();
let current: string | null = null;
function setCurrent(t: string | null) {
  current = t;
  speakingListeners.forEach((l) => l(t));
}
export const onSpeaking = (l: Listener) => {
  speakingListeners.add(l);
  return () => {
    speakingListeners.delete(l);
  };
};
export const currentSpeaking = () => current;

/** Speaks Japanese text (furigana markup is stripped). Resolves when finished. */
export function speak(text: string, opts: { rate?: number; key?: string } = {}): Promise<void> {
  if (!hasTTS) return Promise.resolve();
  const id = ++speakId;
  const clean = plain(text).replace(/[＿]+/g, "、");
  window.speechSynthesis.cancel();
  return new Promise((resolve) => {
    const u = new SpeechSynthesisUtterance(clean);
    u.lang = "ja-JP";
    if (voice) u.voice = voice;
    u.rate = opts.rate ?? getState().settings.rate;
    let done = false;
    const finish = () => {
      if (done) return;
      done = true;
      if (id === speakId) setCurrent(null);
      resolve();
    };
    u.onend = finish;
    u.onerror = finish;
    // safety timeout (some browsers never fire onend)
    setTimeout(finish, 1500 + clean.length * 260);
    setCurrent(opts.key ?? text);
    window.speechSynthesis.speak(u);
  });
}

export function stopSpeaking() {
  speakId++;
  if (hasTTS) window.speechSynthesis.cancel();
  setCurrent(null);
}

// ───────────────────────── sound effects (WebAudio)
let ctx: AudioContext | null = null;
function ac() {
  if (!ctx) {
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AC) return null;
    ctx = new AC();
  }
  if (ctx.state === "suspended") ctx.resume();
  return ctx;
}
function tone(freq: number, start: number, dur: number, vol = 0.12, type: OscillatorType = "sine") {
  const c = ac();
  if (!c) return;
  const t = c.currentTime + start;
  const o = c.createOscillator();
  const g = c.createGain();
  o.type = type;
  o.frequency.value = freq;
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(vol, t + 0.015);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.connect(g);
  g.connect(c.destination);
  o.start(t);
  o.stop(t + dur + 0.05);
}
export function sfx(kind: "correct" | "wrong" | "complete" | "tap") {
  if (!getState().settings.sfx) return;
  try {
    if (kind === "correct") {
      tone(880, 0, 0.12);
      tone(1318.5, 0.09, 0.22);
    } else if (kind === "wrong") {
      tone(220, 0, 0.18, 0.1, "triangle");
      tone(196, 0.12, 0.25, 0.1, "triangle");
    } else if (kind === "complete") {
      [523.25, 659.25, 783.99, 1046.5].forEach((f, i) => tone(f, i * 0.11, 0.3, 0.1));
    } else {
      tone(660, 0, 0.05, 0.05);
    }
  } catch {
    /* ignore */
  }
}
