import { ACTIVITY_TYPES, UNITS, unitsOf, type ActivityType, type Lesson, type Level, type Unit } from "../course";
import { activityKey, type State } from "./store";

export const PASS_CHECKPOINT = 0.7;
export const PASS_PLACEMENT = 0.75;

export const isActivityDone = (s: State, lessonId: string, t: ActivityType) => !!s.activities[activityKey(lessonId, t)]?.done;
export const lessonDoneCount = (s: State, l: Lesson) => ACTIVITY_TYPES.filter((t) => isActivityDone(s, l.id, t)).length;
export const isLessonComplete = (s: State, l: Lesson) => lessonDoneCount(s, l) === ACTIVITY_TYPES.length;
export const isCheckpointPassed = (s: State, unitId: string) => !!s.checkpoints[unitId]?.passed;

const freeA2 = (s: State, level: Level) => level === "A2" && !!s.testedOut.A2;

export function isUnitUnlocked(s: State, u: Unit): boolean {
  if (u.index === 1) return true;
  if (freeA2(s, u.level)) return true;
  if (u.level === "B1" && u.levelIndex === 1 && s.testedOut.A2) return true;
  const prev = UNITS[u.index - 2];
  return isCheckpointPassed(s, prev.id);
}

export function isLessonUnlocked(s: State, l: Lesson): boolean {
  const u = UNITS.find((x) => x.id === l.unitId)!;
  if (!isUnitUnlocked(s, u)) return false;
  if (l.index === 0 || freeA2(s, l.level)) return true;
  return isLessonComplete(s, u.lessons[l.index - 1]);
}

export function isActivityUnlocked(s: State, l: Lesson, t: ActivityType): boolean {
  if (!isLessonUnlocked(s, l)) return false;
  const i = ACTIVITY_TYPES.indexOf(t);
  if (i === 0 || freeA2(s, l.level)) return true;
  return isActivityDone(s, l.id, ACTIVITY_TYPES[i - 1]);
}

export function isCheckpointUnlocked(s: State, u: Unit): boolean {
  if (!isUnitUnlocked(s, u)) return false;
  if (freeA2(s, u.level)) return true;
  return u.lessons.every((l) => isLessonComplete(s, l));
}

export function isLevelUnlocked(s: State, level: Level) {
  return isUnitUnlocked(s, unitsOf(level)[0]);
}

export function unitProgress(s: State, u: Unit) {
  const total = u.lessons.length * ACTIVITY_TYPES.length + 1;
  let done = u.lessons.reduce((n, l) => n + lessonDoneCount(s, l), 0);
  if (isCheckpointPassed(s, u.id)) done++;
  return done / total;
}

export function levelProgress(s: State, level: Level) {
  const us = unitsOf(level);
  return us.reduce((n, u) => n + unitProgress(s, u), 0) / us.length;
}

export function isLevelComplete(s: State, level: Level) {
  return unitsOf(level).every((u) => isCheckpointPassed(s, u.id));
}

export type NextStep =
  | { kind: "activity"; lesson: Lesson; unit: Unit; type: ActivityType }
  | { kind: "checkpoint"; unit: Unit }
  | { kind: "done" };

/** First pending step in course order that is unlocked. */
export function nextStep(s: State, level?: Level): NextStep {
  const units = level ? unitsOf(level) : UNITS;
  for (const u of units) {
    if (!isUnitUnlocked(s, u)) continue;
    for (const l of u.lessons) {
      for (const t of ACTIVITY_TYPES) {
        if (!isActivityDone(s, l.id, t) && isActivityUnlocked(s, l, t)) return { kind: "activity", lesson: l, unit: u, type: t };
      }
    }
    if (!isCheckpointPassed(s, u.id) && isCheckpointUnlocked(s, u)) return { kind: "checkpoint", unit: u };
  }
  return { kind: "done" };
}

/** Step after finishing a given activity. */
export function stepAfter(s: State, lesson: Lesson, type: ActivityType): NextStep {
  const u = UNITS.find((x) => x.id === lesson.unitId)!;
  const i = ACTIVITY_TYPES.indexOf(type);
  for (let j = i + 1; j < ACTIVITY_TYPES.length; j++) {
    const t = ACTIVITY_TYPES[j];
    if (!isActivityDone(s, lesson.id, t) && isActivityUnlocked(s, lesson, t)) return { kind: "activity", lesson, unit: u, type: t };
  }
  return nextStep(s, u.level);
}

export const pathFor = (n: NextStep) =>
  n.kind === "activity" ? `/play/${n.lesson.id}/${n.type}` : n.kind === "checkpoint" ? `/checkpoint/${n.unit.id}` : "/";

export function wordsLearned(s: State) {
  return Object.keys(s.vocab).length;
}
export function lessonsCompleted(s: State) {
  return UNITS.flatMap((u) => u.lessons).filter((l) => isLessonComplete(s, l)).length;
}
export function currentLevel(s: State): Level {
  return isLevelComplete(s, "A2") || s.testedOut.A2 ? "B1" : "A2";
}
