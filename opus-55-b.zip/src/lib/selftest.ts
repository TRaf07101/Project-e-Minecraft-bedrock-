import { ACTIVITY_TYPES, ALL_GRAMMAR, ALL_VOCAB, LESSONS, UNITS, type Issue } from "../course";
import { plain } from "../course/kana";
import { buildActivity, buildCheckpoint, buildGrammarReview, buildPlacement, buildVocabReview, type Session } from "./sessions";
import { defaultState, type State } from "./store";
import { isLevelComplete, isLevelUnlocked, nextStep } from "./progress";

function checkSession(sess: Session, where: string, out: Issue[]) {
  if (!sess.steps.length) out.push({ where, msg: "Sessão vazia" });
  const keys = new Set<string>();
  for (const st of sess.steps) {
    if (keys.has(st.key)) out.push({ where, msg: `Chave de etapa duplicada: ${st.key}` });
    keys.add(st.key);
    if (st.t === "mcq") {
      if (st.options.length < 2) out.push({ where, msg: `Poucas alternativas em ${st.key}` });
      if (st.answer < 0 || st.answer >= st.options.length) out.push({ where, msg: `Resposta inválida em ${st.key}` });
      if (new Set(st.options.map(plain)).size !== st.options.length) out.push({ where, msg: `Alternativas repetidas em ${st.key}` });
    } else if (st.t === "gap") {
      if (st.ex.answer < 0 || st.ex.answer >= st.ex.options.length) out.push({ where, msg: `Lacuna com resposta inválida ${st.key}` });
    } else if (st.t === "match") {
      if (st.pairs.length < 2) out.push({ where, msg: `Pares insuficientes em ${st.key}` });
      if (new Set(st.pairs.map((p) => plain(p.left))).size !== st.pairs.length || new Set(st.pairs.map((p) => p.right)).size !== st.pairs.length)
        out.push({ where, msg: `Pares ambíguos em ${st.key}` });
    } else if (st.t === "spell") {
      const pool = [...st.tiles];
      for (const c of st.v.kana) {
        const i = pool.indexOf(c);
        if (i < 0) out.push({ where, msg: `Soletração impossível em ${st.key}` });
        else pool.splice(i, 1);
      }
    } else if (st.t === "tf") {
      if (!st.claim) out.push({ where, msg: `Verdadeiro/falso sem afirmação ${st.key}` });
      if (st.truth !== (st.claim === st.v.pt)) out.push({ where, msg: `Verdadeiro/falso inconsistente ${st.key}` });
    } else if (st.t === "order") {
      if (st.ex.tiles.length < 3) out.push({ where, msg: `Ordenação curta ${st.key}` });
    }
  }
}

/** Monta todas as sessões do curso e verifica a integridade de cada exercício gerado. */
export function auditSessions(): { issues: Issue[]; sessions: number; steps: number } {
  const out: Issue[] = [];
  let sessions = 0;
  let steps = 0;
  const run = (s: Session, where: string) => {
    sessions++;
    steps += s.steps.length;
    checkSession(s, where, out);
  };
  for (const l of LESSONS) for (const t of ACTIVITY_TYPES) run(buildActivity(l, t), `${l.id}:${t}`);
  for (const u of UNITS) run(buildCheckpoint(u), `checkpoint ${u.id}`);
  run(buildPlacement(), "nivelamento");
  for (const g of ALL_GRAMMAR) run(buildGrammarReview([g.id]), `revisão ${g.id}`);
  for (let i = 0; i < ALL_VOCAB.length; i += 12) {
    const ids = ALL_VOCAB.slice(i, i + 12).map((v) => v.id);
    run(buildVocabReview(ids), `revisão vocab ${i}`);
    run(buildVocabReview(ids, "x", "flash"), `cartões ${i}`);
  }
  return { issues: out, sessions, steps };
}

/** Simula um aluno novo concluindo o curso na ordem e verifica todos os desbloqueios. */
export function simulateProgression(): { issues: Issue[]; steps: number } {
  const out: Issue[] = [];
  let s: State = defaultState();
  if (isLevelUnlocked(s, "B1")) out.push({ where: "início", msg: "B1 não deveria estar desbloqueado" });
  const expected = LESSONS.length * ACTIVITY_TYPES.length + UNITS.length;
  let count = 0;
  for (let guard = 0; guard < expected + 5; guard++) {
    const n = nextStep(s);
    if (n.kind === "done") break;
    count++;
    if (n.kind === "activity") {
      s = { ...s, activities: { ...s.activities, [`${n.lesson.id}:${n.type}`]: { done: true, best: 1, attempts: 1, at: 0 } } };
    } else {
      s = { ...s, checkpoints: { ...s.checkpoints, [n.unit.id]: { best: 1, passed: true, attempts: 1, at: 0 } } };
      if (n.unit.level === "A2" && n.unit.levelIndex === 8 && !isLevelUnlocked(s, "B1")) out.push({ where: n.unit.id, msg: "B1 não desbloqueou após o último checkpoint do A2" });
    }
  }
  if (count !== expected) out.push({ where: "progressão", msg: `Etapas alcançadas: ${count} (esperado ${expected})` });
  if (!isLevelComplete(s, "A2") || !isLevelComplete(s, "B1")) out.push({ where: "progressão", msg: "Níveis não concluídos ao fim da simulação" });
  return { issues: out, steps: count };
}
