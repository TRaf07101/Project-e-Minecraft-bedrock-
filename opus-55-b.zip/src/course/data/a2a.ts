import { g, o, type RawUnit } from "../dsl";

export const A2_PART1: RawUnit[] = [
  // ───────────────────────── Capítulo 1
  {
    t: "Minha rotina",
    d: "Descrever o dia a dia e ações em sequência",
    icon: "⏰",
    color: "#FF8A4C",
    lessons: [
      {
        t: "Começando o dia",
        d: "Ações em sequência com a forma て",
        v: `
起[お]きる|acordar, levantar-se|毎朝[まいあさ]六時[ろくじ]に起[お]きます。|Acordo às seis todas as manhãs.
顔[かお]を洗[あら]う|lavar o rosto|起[お]きて、顔[かお]を洗[あら]います。|Acordo e lavo o rosto.
歯[は]を磨[みが]く|escovar os dentes|朝[あさ]ご飯[はん]の後[あと]で歯[は]を磨[みが]きます。|Escovo os dentes depois do café da manhã.
着替[きが]える|trocar de roupa|急[いそ]いで着替[きが]えました。|Troquei de roupa às pressas.
朝[あさ]ご飯[はん]|café da manhã|朝[あさ]ご飯[はん]にパンを食[た]べます。|No café da manhã como pão.
出[で]かける|sair (de casa)|毎朝[まいあさ]八時[はちじ]に出[で]かけます。|Saio todas as manhãs às oito.`,
        k: `
朝|チョウ|あさ|manhã|朝[あさ]ご飯[はん]=café da manhã;毎朝[まいあさ]=todas as manhãs
起|キ|お(きる)|levantar, despertar|起[お]きる=acordar;起[お]こす=acordar alguém`,
        g: {
          t: "Forma て: ações em sequência",
          e: `Para ligar várias ações na ordem em que acontecem, use a **forma て** do verbo. Somente o último verbo indica o tempo (presente ou passado) e o nível de formalidade.
• Verbos -ru: troque る por て → 起[お]きる → 起[お]きて
• う・つ・る → って: 洗[あら]う → 洗[あら]って
• く → いて: 磨[みが]く → 磨[みが]いて (exceção: 行[い]く → 行[い]って)
• む・ぶ・ぬ → んで: 飲[の]む → 飲[の]んで
• す → して: 話[はな]す → 話[はな]して
• Irregulares: する → して / 来[く]る → 来[き]て
Ex.: 起[お]きて、顔[かお]を洗[あら]って、着替[きが]えます。`,
          x: `
起[お]きて、シャワーを浴[あ]びます。|Acordo e tomo banho.
朝[あさ]ご飯[はん]を食[た]べて、歯[は]を磨[みが]きました。|Tomei café da manhã e escovei os dentes.
着替[きが]えて、八時[はちじ]に出[で]かけます。|Troco de roupa e saio às oito.`,
          q: [
            g("顔[かお]を＿＿、歯[は]を磨[みが]きます。", ["洗[あら]って", "洗[あら]いて", "洗[あら]んで", "洗[あら]た"], 0, "Lavo o rosto e escovo os dentes.", "洗う termina em う → って: 洗って."),
            g("毎朝[まいあさ]コーヒーを＿＿、新聞[しんぶん]を読[よ]みます。", ["飲[の]んで", "飲[の]みて", "飲[の]って", "飲[の]いて"], 0, "Toda manhã tomo café e leio o jornal.", "Verbos terminados em む, ぶ, ぬ formam a forma て com んで: 飲む → 飲んで."),
            g("昨日[きのう]は七時[しちじ]に＿＿、すぐ出[で]かけました。", ["起[お]きて", "起[お]きって", "起[お]いて", "起[お]きた"], 0, "Ontem acordei às sete e saí logo.", "起きる é verbo -ru: tire る e coloque て. O passado fica só no último verbo (出かけました)."),
            g("宿題[しゅくだい]を＿＿、寝[ね]ます。", ["して", "しって", "すて", "しんで"], 0, "Faço a lição de casa e vou dormir.", "する é irregular: して."),
            o("朝[あさ]ご飯[はん]を/食[た]べて/歯[は]を/磨[みが]きます", "Tomo café da manhã e escovo os dentes."),
          ],
        },
        dl: {
          t: "Uma manhã corrida",
          l: `
Ken|おはよう、アナさん。今日[きょう]は早[はや]いね。|Bom dia, Ana. Você chegou cedo hoje.
Ana|うん、五時[ごじ]に起[お]きて、ジョギングをしたの。|Sim, acordei às cinco e fui correr.
Ken|すごい！それから？|Que incrível! E depois?
Ana|シャワーを浴[あ]びて、朝[あさ]ご飯[はん]を食[た]べて、七時[しちじ]に出[で]かけたよ。|Tomei banho, tomei café da manhã e saí às sete.
Ken|僕[ぼく]は八時[はちじ]に起[お]きて、何[なに]も食[た]べないで来[き]たよ。|Eu acordei às oito e vim sem comer nada.
Ana|え、お腹[なか]すいてない？|Hã, você não está com fome?`,
          q: [
            ["A que horas Ana acordou?", ["Às cinco", "Às sete", "Às oito"], 0],
            ["O que Ken comeu antes de sair?", ["Pão", "Nada", "Arroz"], 1],
          ],
        },
        w: ["Descreva sua manhã em uma frase usando a forma て com pelo menos dois verbos.", "七時[しちじ]に起[お]きて、顔[かお]を洗[あら]って、朝[あさ]ご飯[はん]を食[た]べます。", ["forma て=て、|で、|て|で"]],
      },
      {
        t: "Antes e depois",
        d: "～てから e ～前に",
        v: `
仕事[しごと]|trabalho|仕事[しごと]は九時[くじ]からです。|O trabalho começa às nove.
帰[かえ]る|voltar (para casa)|六時[ろくじ]ごろ家[いえ]に帰[かえ]ります。|Volto para casa por volta das seis.
晩[ばん]ご飯[はん]|jantar|晩[ばん]ご飯[はん]を作[つく]りました。|Fiz o jantar.
お風呂[ふろ]に入[はい]る|tomar banho de banheira|毎晩[まいばん]お風呂[ふろ]に入[はい]ります。|Tomo banho de banheira toda noite.
寝[ね]る|dormir, deitar-se|十一時[じゅういちじ]に寝[ね]ます。|Vou dormir às onze.
休[やす]む|descansar; faltar|週末[しゅうまつ]は家[いえ]で休[やす]みます。|No fim de semana descanso em casa.`,
        k: `
前|ゼン|まえ|antes; frente|前[まえ]に=antes de;午前[ごぜん]=manhã (a.m.)
後|ゴ|あと、うし(ろ)|depois; atrás|後[あと]で=depois;午後[ごご]=tarde (p.m.)`,
        g: {
          t: "～てから e ～前に: antes e depois",
          e: `**Verbo (forma て) + から** = “depois de fazer...”. Enfatiza que a primeira ação termina antes de a segunda começar.
• 仕事[しごと]が終[お]わってから、ジムに行[い]きます。
**Verbo (forma de dicionário) + 前[まえ]に** = “antes de fazer...”. O verbo antes de 前に fica sempre no presente, mesmo falando do passado.
• 寝[ね]る前[まえ]に、本[ほん]を読[よ]みました。
Com substantivos: **Substantivo + の前[まえ]に** (食事[しょくじ]の前[まえ]に).`,
          x: `
手[て]を洗[あら]ってから、食[た]べます。|Como depois de lavar as mãos.
寝[ね]る前[まえ]に、お風呂[ふろ]に入[はい]ります。|Antes de dormir, tomo banho de banheira.
仕事[しごと]の前[まえ]に、コーヒーを飲[の]みました。|Antes do trabalho, tomei café.`,
          q: [
            g("晩[ばん]ご飯[はん]を食[た]べて＿＿、テレビを見[み]ます。", ["から", "まえに", "ので", "まで"], 0, "Depois de jantar, assisto TV.", "Forma て + から = depois de."),
            g("寝[ね]る＿＿、歯[は]を磨[みが]きます。", ["前[まえ]に", "から", "後[あと]で", "の前[まえ]に"], 0, "Antes de dormir, escovo os dentes.", "Verbo na forma de dicionário + 前に. の前に é usado só com substantivos."),
            g("会議[かいぎ]＿＿前[まえ]に、資料[しりょう]を読[よ]みます。", ["の", "を", "に", "て"], 0, "Antes da reunião, leio os documentos.", "Com substantivo usa-se の: 会議の前に."),
            g("昨日[きのう]、家[いえ]に＿＿前[まえ]に、スーパーに行[い]きました。", ["帰[かえ]る", "帰[かえ]った", "帰[かえ]って", "帰[かえ]り"], 0, "Ontem, antes de voltar para casa, fui ao supermercado.", "Antes de 前に o verbo fica sempre na forma de dicionário, mesmo no passado."),
            o("仕事[しごと]が/終[お]わってから/ジムに/行[い]きます", "Depois que o trabalho termina, vou à academia."),
          ],
        },
        dl: {
          t: "Depois do trabalho",
          l: `
Tanaka|アナさん、仕事[しごと]の後[あと]で、何[なに]をしますか。|Ana, o que você faz depois do trabalho?
Ana|家[いえ]に帰[かえ]ってから、晩[ばん]ご飯[はん]を作[つく]ります。|Depois de voltar para casa, faço o jantar.
Tanaka|毎日[まいにち]料理[りょうり]するんですか。すごいですね。|Você cozinha todos os dias? Que legal.
Ana|はい。でも、作[つく]る前[まえ]に、少[すこ]し休[やす]みます。|Sim. Mas, antes de cozinhar, descanso um pouco.
Tanaka|私[わたし]は寝[ね]る前[まえ]に、いつもお風呂[ふろ]に入[はい]ります。|Eu sempre tomo banho de banheira antes de dormir.
Ana|日本[にほん]のお風呂[ふろ]、気持[きも]ちいいですよね。|O banho japonês é muito gostoso, né?`,
          q: [
            ["O que Ana faz antes de cozinhar?", ["Descansa um pouco", "Toma banho", "Vai à academia"], 0],
            ["Quando o Sr. Tanaka toma banho de banheira?", ["Depois do trabalho", "Antes de dormir", "De manhã"], 1],
          ],
        },
        w: ["Escreva o que você faz antes de dormir, usando 前に.", "寝[ね]る前[まえ]に、本[ほん]を読[よ]みます。", ["前に=前に|まえに"]],
      },
      {
        t: "Duas coisas ao mesmo tempo",
        d: "Ações simultâneas com ～ながら",
        v: `
音楽[おんがく]|música|音楽[おんがく]を聞[き]くのが好[す]きです。|Gosto de ouvir música.
聞[き]く|ouvir; perguntar|ラジオを聞[き]きます。|Escuto rádio.
歩[ある]く|andar, caminhar|駅[えき]まで歩[ある]きます。|Vou andando até a estação.
運転[うんてん]する|dirigir|父[ちち]は毎日[まいにち]運転[うんてん]します。|Meu pai dirige todos os dias.
スマホ|smartphone|スマホで写真[しゃしん]を撮[と]ります。|Tiro fotos com o smartphone.
電車[でんしゃ]|trem|電車[でんしゃ]で会社[かいしゃ]に行[い]きます。|Vou para a empresa de trem.`,
        k: `
聞|ブン|き(く)|ouvir, perguntar|聞[き]く=ouvir;新聞[しんぶん]=jornal
歩|ホ|ある(く)|andar|歩[ある]く=caminhar;散歩[さんぽ]=passeio`,
        g: {
          t: "～ながら: duas ações simultâneas",
          e: `**Verbo (forma ます sem ます) + ながら** indica que duas ações acontecem ao mesmo tempo, feitas pelo mesmo sujeito.
• 聞[き]きます → 聞[き]きながら
• 食[た]べます → 食[た]べながら
A ação **principal** fica no fim da frase; a ação secundária vem antes de ながら.
• 音楽[おんがく]を聞[き]きながら、勉強[べんきょう]します。 (A ação principal é estudar.)`,
          x: `
音楽[おんがく]を聞[き]きながら、走[はし]ります。|Corro ouvindo música.
テレビを見[み]ながら、晩[ばん]ご飯[はん]を食[た]べました。|Jantei vendo TV.
歩[ある]きながら、スマホを使[つか]わないでください。|Não use o celular enquanto anda.`,
          q: [
            g("コーヒーを＿＿ながら、新聞[しんぶん]を読[よ]みます。", ["飲[の]み", "飲[の]む", "飲[の]んで", "飲[の]んだ"], 0, "Leio o jornal enquanto tomo café.", "ながら junta-se ao radical da forma ます: 飲みます → 飲み."),
            g("歌[うた]を＿＿ながら、料理[りょうり]をします。", ["歌[うた]い", "歌[うた]う", "歌[うた]って", "歌[うた]わ"], 0, "Cozinho cantando.", "歌います → 歌い + ながら."),
            g("運転[うんてん]し＿＿、電話[でんわ]をしてはいけません。", ["ながら", "てから", "まえに", "たり"], 0, "Não se deve telefonar enquanto dirige.", "運転します → 運転し + ながら = enquanto dirige."),
            g("電車[でんしゃ]の中[なか]で、音楽[おんがく]を聞[き]き＿＿本[ほん]を読[よ]みます。", ["ながら", "て", "から", "前[まえ]に"], 0, "No trem, leio um livro ouvindo música.", "Duas ações ao mesmo tempo: 聞きながら."),
            o("テレビを/見[み]ながら/ご飯[はん]を/食[た]べます", "Como vendo TV."),
          ],
        },
        dl: {
          t: "No trem",
          l: `
Ken|アナさん、電車[でんしゃ]の中[なか]で何[なに]をしているの？|Ana, o que você faz no trem?
Ana|いつも音楽[おんがく]を聞[き]きながら、日本語[にほんご]の単語[たんご]を覚[おぼ]えているよ。|Sempre memorizo palavras de japonês ouvindo música.
Ken|へえ、えらいね。僕[ぼく]はゲームをしながら、よく寝[ね]ちゃうんだ。|Nossa, que dedicada. Eu sempre acabo dormindo enquanto jogo.
Ana|ははは。でも、歩[ある]きながらスマホを見[み]るのは危[あぶ]ないよ。|Hahaha. Mas olhar o celular enquanto anda é perigoso.
Ken|そうだね。気[き]をつけるよ。|É verdade. Vou tomar cuidado.`,
          q: [
            ["O que Ana faz no trem?", ["Joga no celular", "Memoriza palavras ouvindo música", "Dorme"], 1],
            ["Segundo Ana, o que é perigoso?", ["Ouvir música alta", "Olhar o celular enquanto anda", "Dormir no trem"], 1],
          ],
        },
        w: ["Escreva uma frase dizendo duas coisas que você faz ao mesmo tempo (use ながら).", "音楽[おんがく]を聞[き]きながら、勉強[べんきょう]します。", ["ながら=ながら"]],
      },
    ],
  },
  // ───────────────────────── Capítulo 2
  {
    t: "Fazendo compras",
    d: "Pedir permissão, comparar produtos e pagar",
    icon: "🛍️",
    color: "#E85D9E",
    lessons: [
      {
        t: "Na loja de roupas",
        d: "Pedir permissão com ～てもいいですか",
        v: `
試着[しちゃく]する|experimentar (roupa)|このシャツを試着[しちゃく]します。|Vou experimentar esta camisa.
サイズ|tamanho|もっと大[おお]きいサイズはありますか。|Tem um tamanho maior?
色[いろ]|cor|どんな色[いろ]が好[す]きですか。|De que cor você gosta?
靴[くつ]|sapato|新[あたら]しい靴[くつ]を買[か]いました。|Comprei sapatos novos.
似合[にあ]う|ficar bem (em alguém)|その服[ふく]、よく似合[にあ]いますね。|Essa roupa fica muito bem em você.
店員[てんいん]|atendente (de loja)|店員[てんいん]に聞[き]きました。|Perguntei ao atendente.`,
        k: `
色|ショク|いろ|cor|色[いろ]=cor;茶色[ちゃいろ]=marrom
服|フク|—|roupa|服[ふく]=roupa;洋服[ようふく]=roupa ocidental`,
        g: {
          t: "～てもいいですか: pedir permissão",
          e: `**Verbo (forma て) + もいいですか** = “Posso...?”
• 試着[しちゃく]してもいいですか。 Posso experimentar?
Para responder:
• Sim: はい、いいですよ。 / どうぞ。
• Não (de forma educada): すみません、ちょっと…。
Sem か, **～てもいいです** concede permissão: 触[さわ]ってもいいです (Pode tocar).`,
          x: `
この靴[くつ]を履[は]いてもいいですか。|Posso calçar estes sapatos?
写真[しゃしん]を撮[と]ってもいいですか。|Posso tirar uma foto?
ここに座[すわ]ってもいいですよ。|Pode se sentar aqui.`,
          q: [
            g("このシャツを試着[しちゃく]＿＿もいいですか。", ["して", "する", "した", "し"], 0, "Posso experimentar esta camisa?", "A forma て de する é して: してもいいですか."),
            g("窓[まど]を＿＿もいいですか。", ["開[あ]けて", "開[あ]ける", "開[あ]けた", "開[あ]け"], 0, "Posso abrir a janela?", "開ける → 開けて + もいいですか."),
            g("A: ここでたばこを吸[す]ってもいいですか。 B: すみません、＿＿。", ["ちょっと…", "どうぞ", "いいですよ", "はい"], 0, "A: Posso fumar aqui? B: Desculpe, é que...", "Em japonês, recusa-se de forma indireta: すみません、ちょっと…."),
            g("A: このペン、使[つか]ってもいいですか。 B: はい、＿＿。", ["どうぞ", "ちょっと", "いけません", "だめでした"], 0, "A: Posso usar esta caneta? B: Sim, fique à vontade.", "どうぞ concede permissão: “à vontade”."),
            o("この/靴[くつ]を/履[は]いても/いいですか", "Posso calçar estes sapatos?"),
          ],
        },
        dl: {
          t: "Experimentando um casaco",
          l: `
Atendente|いらっしゃいませ。|Bem-vinda!
Ana|すみません、このコートを試着[しちゃく]してもいいですか。|Com licença, posso experimentar este casaco?
Atendente|はい、どうぞ。試着室[しちゃくしつ]はあちらです。|Sim, por favor. O provador é ali.
Ana|ちょっと小[ちい]さいです。Ｍサイズはありますか。|Está um pouco pequeno. Tem tamanho M?
Atendente|はい、ございます。色[いろ]は黒[くろ]と白[しろ]がございます。|Sim, temos. As cores são preto e branco.
Ana|じゃ、黒[くろ]をお願[ねが]いします。|Então, o preto, por favor.`,
          q: [
            ["Qual é o problema do primeiro casaco?", ["É caro", "É um pouco pequeno", "A cor é feia"], 1],
            ["Qual cor Ana escolhe?", ["Branco", "Preto", "Azul"], 1],
          ],
        },
        w: ["Peça permissão para tirar uma foto na loja.", "すみません、写真[しゃしん]を撮[と]ってもいいですか。", ["てもいいですか=てもいいですか|でもいいですか|てもいい|でもいい"]],
      },
      {
        t: "Comparando produtos",
        d: "より, ほうが e 一番",
        v: `
高[たか]い|caro; alto|この時計[とけい]は高[たか]いです。|Este relógio é caro.
安[やす]い|barato|あの店[みせ]は安[やす]いです。|Aquela loja é barata.
軽[かる]い|leve|このかばんは軽[かる]いです。|Esta bolsa é leve.
重[おも]い|pesado|荷物[にもつ]が重[おも]いです。|A bagagem está pesada.
便利[べんり]|prático, conveniente|このアプリは便利[べんり]です。|Este aplicativo é prático.
値段[ねだん]|preço|値段[ねだん]を見[み]てください。|Veja o preço.`,
        k: `
高|コウ|たか(い)|alto, caro|高[たか]い=caro;高校[こうこう]=ensino médio
安|アン|やす(い)|barato, tranquilo|安[やす]い=barato;安心[あんしん]=alívio`,
        g: {
          t: "Comparações: より, ほうが e 一番",
          e: `**A は B より + adjetivo** = A é mais ... do que B.
• 東京[とうきょう]は大阪[おおさか]より大[おお]きいです。
**A と B と、どちらが + adjetivo ですか** = Qual é mais ...?
Resposta: **A のほうが + adjetivo です**.
• 電車[でんしゃ]のほうが速[はや]いです。
**(grupo) の中[なか]で ～が一番[いちばん] + adjetivo** = o mais ... de todos.
• 果物[くだもの]の中[なか]で、りんごが一番[いちばん]好[す]きです。`,
          x: `
このかばんはあのかばんより軽[かる]いです。|Esta bolsa é mais leve do que aquela.
コーヒーと紅茶[こうちゃ]と、どちらが好[す]きですか。|Você prefere café ou chá preto?
この店[みせ]で、これが一番[いちばん]安[やす]いです。|Nesta loja, este é o mais barato.`,
          q: [
            g("このパソコンはあのパソコン＿＿軽[かる]いです。", ["より", "ほう", "一番[いちばん]", "どちら"], 0, "Este computador é mais leve do que aquele.", "より marca o item com que se compara: “do que”."),
            g("A: 電車[でんしゃ]とバスと、どちらが速[はや]いですか。 B: 電車[でんしゃ]の＿＿が速[はや]いです。", ["ほう", "より", "中[なか]", "一番[いちばん]"], 0, "A: O que é mais rápido, trem ou ônibus? B: O trem é mais rápido.", "Na resposta usa-se ～のほうが."),
            g("クラスの中[なか]で、ケンさんが＿＿背[せ]が高[たか]いです。", ["一番[いちばん]", "より", "ほう", "どちら"], 0, "Na turma, o Ken é o mais alto.", "一番 = o mais (superlativo)."),
            g("スポーツの中[なか]で、＿＿が一番[いちばん]好[す]きですか。", ["何[なに]", "どちら", "どれと", "いつ"], 0, "Dentre os esportes, de qual você gosta mais?", "Para três ou mais itens, pergunta-se com 何 (ou どれ); どちら é para dois."),
            o("この靴[くつ]は/あの靴[くつ]より/安[やす]いです", "Estes sapatos são mais baratos do que aqueles.", "あの靴[くつ]より/この靴[くつ]は/安[やす]いです"),
          ],
        },
        dl: {
          t: "Qual celular comprar?",
          l: `
Ana|ケンさん、このスマホとあのスマホと、どちらがいいと思[おも]う？|Ken, qual você acha melhor, este celular ou aquele?
Ken|うーん、こっちのほうが軽[かる]いね。|Hmm, este aqui é mais leve.
Ana|でも、あっちのほうがカメラがいいよ。|Mas aquele tem uma câmera melhor.
Ken|値段[ねだん]は？|E o preço?
Ana|あっちは五万円[ごまんえん]で、こっちより一万円[いちまんえん]高[たか]い。|Aquele custa 50 mil ienes, 10 mil a mais que este.
Ken|写真[しゃしん]が好[す]きなら、あっちのほうがいいよ。|Se você gosta de fotos, aquele é melhor.`,
          q: [
            ["Qual é a vantagem do celular “este aqui” (こっち)?", ["É mais leve", "Tem câmera melhor", "É mais caro"], 0],
            ["Quanto custa o celular “aquele” (あっち)?", ["40 mil ienes", "50 mil ienes", "10 mil ienes"], 1],
          ],
        },
        w: ["Compare duas coisas que você usa todos os dias usando より.", "電車[でんしゃ]はバスより速[はや]いです。", ["より=より"]],
      },
      {
        t: "No caixa",
        d: "Decidir com ～にします e pagar",
        v: `
レジ|caixa (de pagamento)|レジはあちらです。|O caixa é ali.
払[はら]う|pagar|カードで払[はら]います。|Pago com cartão.
現金[げんきん]|dinheiro em espécie|現金[げんきん]しか使[つか]えません。|Só aceita dinheiro.
袋[ふくろ]|sacola|袋[ふくろ]はいりますか。|Precisa de sacola?
おつり|troco|おつりは三百円[さんびゃくえん]です。|O troco é de 300 ienes.
決[き]める|decidir|色[いろ]を決[き]めました。|Decidi a cor.`,
        k: `
円|エン|まる(い)|iene; círculo|円[えん]=iene;百円[ひゃくえん]=cem ienes
買|バイ|か(う)|comprar|買[か]う=comprar;買[か]い物[もの]=compras`,
        g: {
          t: "～にします: tomar uma decisão",
          e: `**Substantivo + にします** = “vou ficar com...”, “decido por...”. Muito usado ao escolher algo em lojas e restaurantes.
• これにします。 Vou levar este.
• 飲[の]み物[もの]はコーヒーにします。
Para perguntar a escolha de alguém: **何[なに]にしますか**.
Decisão já tomada: **～にしました**.
O meio de pagamento é marcado com **で**: カードで払[はら]います。`,
          x: `
赤[あか]いのにします。|Vou ficar com o vermelho.
A: 何[なに]にしますか。 B: ラーメンにします。|A: O que vai querer? B: Vou querer ramen.
旅行[りょこう]は京都[きょうと]にしました。|Para a viagem, escolhemos Quioto.`,
          q: [
            g("A: 何[なに]に＿＿か。 B: カレーにします。", ["します", "なります", "あります", "いきます"], 0, "A: O que vai querer? B: Vou querer curry.", "Pergunta-se a escolha com 何にしますか."),
            g("じゃ、この青[あお]いシャツ＿＿します。", ["に", "を", "が", "で"], 0, "Então vou levar esta camisa azul.", "A escolha é marcada com に: ～にします."),
            g("A: お支払[しはら]いはどうしますか。 B: カード＿＿お願[ねが]いします。", ["で", "に", "を", "が"], 0, "A: Como vai pagar? B: No cartão, por favor.", "で indica o meio: カードで (com cartão)."),
            g("誕生日[たんじょうび]のプレゼントは時計[とけい]に＿＿。", ["しました", "なりました", "ありました", "いました"], 0, "Decidi que o presente de aniversário seria um relógio.", "Decisão já tomada: ～にしました."),
            o("飲[の]み物[もの]は/オレンジジュースに/します", "Para beber, vou querer suco de laranja."),
          ],
        },
        dl: {
          t: "No caixa da loja",
          l: `
Atendente|お次[つぎ]の方[かた]、どうぞ。|Próximo, por favor.
Ana|これをお願[ねが]いします。|Isto, por favor.
Atendente|全部[ぜんぶ]で三千五百円[さんぜんごひゃくえん]です。袋[ふくろ]はご利用[りよう]ですか。|Ao todo são 3.500 ienes. Vai usar sacola?
Ana|いいえ、大丈夫[だいじょうぶ]です。カードで払[はら]ってもいいですか。|Não, tudo bem. Posso pagar com cartão?
Atendente|申[もう]し訳[わけ]ありません。現金[げんきん]のみなんです。|Sinto muito. Só aceitamos dinheiro.
Ana|じゃ、現金[げんきん]で。はい、四千円[よんせんえん]。|Então em dinheiro. Aqui, 4.000 ienes.
Atendente|五百円[ごひゃくえん]のおつりです。ありがとうございました。|Seu troco de 500 ienes. Muito obrigado.`,
          q: [
            ["Quanto custou a compra?", ["3.500 ienes", "4.000 ienes", "500 ienes"], 0],
            ["Por que Ana pagou em dinheiro?", ["Esqueceu o cartão", "A loja só aceita dinheiro", "Era mais barato"], 1],
          ],
        },
        w: ["Num restaurante, diga o que vai pedir usando にします.", "私[わたし]はラーメンにします。", ["にします=にします|にしました"]],
      },
    ],
  },
  // ───────────────────────── Capítulo 3
  {
    t: "Experiências",
    d: "Falar do que você já fez e de viagens",
    icon: "🗻",
    color: "#7C5CFA",
    lessons: [
      {
        t: "Você já...?",
        d: "Experiências com ～たことがあります",
        v: `
経験[けいけん]|experiência|海外[かいがい]で働[はたら]いた経験[けいけん]があります。|Tenho experiência trabalhando no exterior.
富士山[ふじさん]|Monte Fuji|富士山[ふじさん]はとてもきれいです。|O Monte Fuji é muito bonito.
登[のぼ]る|subir, escalar|山[やま]に登[のぼ]りました。|Subi a montanha.
着物[きもの]|quimono|祭[まつ]りで着物[きもの]を着[き]ました。|Vesti quimono no festival.
一度[いちど]|uma vez|一度[いちど]だけ行[い]きました。|Fui só uma vez.
まだ|ainda (não)|まだ食[た]べていません。|Ainda não comi.`,
        k: `
山|サン|やま|montanha|山[やま]=montanha;富士山[ふじさん]=Monte Fuji
度|ド|たび|vez; grau|一度[いちど]=uma vez;今度[こんど]=da próxima vez`,
        g: {
          t: "～たことがあります: experiências",
          e: `**Verbo (forma た) + ことがあります** = “já fiz... (alguma vez na vida)”.
A forma た é a forma て com た/だ no lugar de て/で: 食[た]べて → 食[た]べた, 飲[の]んで → 飲[の]んだ.
• 富士山[ふじさん]に登[のぼ]ったことがあります。 Já subi o Monte Fuji.
Negativo: **～たことがありません** (nunca fiz).
Pergunta: **～たことがありますか**. Resposta curta: はい、あります / いいえ、ありません.
⚠️ Não use para ações recentes e específicas (“ontem comi sushi” = 昨日[きのう]すしを食[た]べました).`,
          x: `
着物[きもの]を着[き]たことがありますか。|Você já vestiu quimono?
一度[いちど]、北海道[ほっかいどう]に行[い]ったことがあります。|Já fui uma vez a Hokkaido.
まだ納豆[なっとう]を食[た]べたことがありません。|Ainda nunca comi natto.`,
          q: [
            g("すしを＿＿ことがありますか。", ["食[た]べた", "食[た]べる", "食[た]べて", "食[た]べ"], 0, "Você já comeu sushi?", "Experiência: forma た + ことがあります."),
            g("日本[にほん]の映画[えいが]を＿＿ことがあります。", ["見[み]た", "見[み]る", "見[み]て", "見[み]ない"], 0, "Já assisti a um filme japonês.", "見る → 見た."),
            g("A: 沖縄[おきなわ]に行[い]ったことがありますか。 B: いいえ、＿＿。", ["ありません", "いません", "しません", "行[い]きません"], 0, "A: Você já foi a Okinawa? B: Não, nunca.", "Resposta negativa: いいえ、ありません."),
            g("富士山[ふじさん]に＿＿ことがありません。", ["登[のぼ]った", "登[のぼ]って", "登[のぼ]る", "登[のぼ]り"], 0, "Nunca subi o Monte Fuji.", "登る → 登った (る de verbo -u → った)."),
            o("私[わたし]は/一度[いちど]/着物[きもの]を/着[き]たことが/あります", "Já vesti quimono uma vez.", "私[わたし]は/着物[きもの]を/一度[いちど]/着[き]たことが/あります"),
          ],
        },
        dl: {
          t: "Planos para o verão",
          l: `
Ken|アナさん、富士山[ふじさん]に登[のぼ]ったことある？|Ana, você já subiu o Monte Fuji?
Ana|ううん、まだない。ケンさんは？|Não, ainda não. E você, Ken?
Ken|僕[ぼく]は二回[にかい]あるよ。朝日[あさひ]がすごくきれいだった。|Eu já subi duas vezes. O nascer do sol foi lindíssimo.
Ana|いいなあ。私[わたし]も一度[いちど]登[のぼ]ってみたい。|Que inveja. Eu também quero tentar subir uma vez.
Ken|じゃ、今年[ことし]の夏[なつ]、一緒[いっしょ]に行[い]こうよ。|Então vamos juntos neste verão!
Ana|うん、行[い]きたい！|Sim, quero ir!`,
          q: [
            ["Quantas vezes Ken já subiu o Monte Fuji?", ["Nenhuma", "Uma", "Duas"], 2],
            ["O que Ken achou muito bonito?", ["A neve", "O nascer do sol", "O lago"], 1],
          ],
        },
        w: ["Escreva sobre algo que você já fez (use たことがあります).", "リオデジャネイロに行[い]ったことがあります。", ["たことがあります=たことがあります|だことがあります|たことがありません|だことがありません|たことがある|だことがある"]],
      },
      {
        t: "Fim de semana agitado",
        d: "Listar ações com ～たり～たりする",
        v: `
週末[しゅうまつ]|fim de semana|週末[しゅうまつ]は何[なに]をしますか。|O que você faz no fim de semana?
掃除[そうじ]する|limpar, faxinar|部屋[へや]を掃除[そうじ]しました。|Limpei o quarto.
洗濯[せんたく]する|lavar roupa|日曜日[にちようび]に洗濯[せんたく]します。|Lavo roupa no domingo.
散歩[さんぽ]する|passear, caminhar|公園[こうえん]を散歩[さんぽ]します。|Passeio pelo parque.
遊[あそ]ぶ|divertir-se, sair com amigos|友達[ともだち]と遊[あそ]びました。|Saí com amigos.
ゆっくり|com calma, devagar|今日[きょう]はゆっくり休[やす]みます。|Hoje vou descansar com calma.`,
        k: `
週|シュウ|—|semana|週末[しゅうまつ]=fim de semana;毎週[まいしゅう]=toda semana
休|キュウ|やす(む)|descansar|休[やす]む=descansar;休[やす]み=folga, férias`,
        g: {
          t: "～たり～たりする: listar exemplos de ações",
          e: `**Verbo₁ (forma た) + り、Verbo₂ (forma た) + り + する** = “faço coisas como... e...”. Indica exemplos de uma lista maior, sem ordem definida.
• 週末[しゅうまつ]は掃除[そうじ]したり、洗濯[せんたく]したりします。
O tempo verbal fica no **する final**: ～たりしました (passado).
Compare: a forma て (～て、～て) indica a sequência exata; ～たり～たり dá apenas exemplos.`,
          x: `
休[やす]みの日[ひ]は本[ほん]を読[よ]んだり、映画[えいが]を見[み]たりします。|Nos dias de folga, leio livros, assisto a filmes etc.
昨日[きのう]は友達[ともだち]と買[か]い物[もの]をしたり、カラオケに行[い]ったりしました。|Ontem fiz compras e fui ao karaokê com amigos, entre outras coisas.
日曜日[にちようび]は公園[こうえん]を散歩[さんぽ]したり、寝[ね]たりします。|No domingo, passeio pelo parque, durmo etc.`,
          q: [
            g("週末[しゅうまつ]はテレビを見[み]たり、音楽[おんがく]を＿＿します。", ["聞[き]いたり", "聞[き]いて", "聞[き]く", "聞[き]きたり"], 0, "No fim de semana, vejo TV, ouço música etc.", "聞く → 聞いた → 聞いたり."),
            g("夏休[なつやす]みは海[うみ]で泳[およ]いだり、山[やま]に登[のぼ]ったり＿＿。", ["しました", "ました", "でした", "ありました"], 0, "Nas férias de verão, nadei no mar, subi montanhas etc.", "A estrutura termina com する conjugado: しました."),
            g("パーティーで歌[うた]を＿＿、踊[おど]ったりしました。", ["歌[うた]ったり", "歌[うた]いたり", "歌[うた]って", "歌[うた]う"], 0, "Na festa, cantamos, dançamos etc.", "歌う → 歌った → 歌ったり."),
            g("日曜日[にちようび]は掃除[そうじ]＿＿、洗濯[せんたく]したりします。", ["したり", "して", "すり", "しり"], 0, "No domingo, limpo a casa, lavo roupa etc.", "する → した → したり."),
            o("休[やす]みの日[ひ]は/散歩[さんぽ]したり/寝[ね]たり/します", "Nos dias de folga, passeio, durmo etc.", "休[やす]みの日[ひ]は/寝[ね]たり/散歩[さんぽ]したり/します"),
          ],
        },
        dl: {
          t: "Segunda-feira no escritório",
          l: `
Tanaka|アナさん、週末[しゅうまつ]はどうでしたか。|Ana, como foi o fim de semana?
Ana|楽[たの]しかったです。友達[ともだち]と浅草[あさくさ]に行[い]って、お寺[てら]を見[み]たり、お土産[みやげ]を買[か]ったりしました。|Foi divertido. Fui a Asakusa com amigos; vimos templos, compramos lembranças etc.
Tanaka|いいですね。日曜日[にちようび]は？|Que bom. E no domingo?
Ana|日曜日[にちようび]は家[いえ]で掃除[そうじ]したり、洗濯[せんたく]したりしました。田中[たなか]さんは？|No domingo fiquei em casa limpando e lavando roupa. E o senhor?
Tanaka|私[わたし]は子供[こども]と公園[こうえん]を散歩[さんぽ]しました。|Eu passeei no parque com meus filhos.`,
          q: [
            ["O que Ana fez em Asakusa?", ["Viu templos e comprou lembranças", "Lavou roupa", "Passeou no parque com crianças"], 0],
            ["Onde Ana passou o domingo?", ["Em Asakusa", "Em casa", "No parque"], 1],
          ],
        },
        w: ["Conte o que você fez no último fim de semana usando ～たり～たりしました.", "週末[しゅうまつ]は映画[えいが]を見[み]たり、料理[りょうり]をしたりしました。", ["たり=たり|だり"]],
      },
      {
        t: "Diário de viagem",
        d: "Forma simples do passado e ～た後で",
        v: `
旅行[りょこう]|viagem|京都[きょうと]へ旅行[りょこう]しました。|Viajei para Quioto.
お寺[てら]|templo budista|古[ふる]いお寺[てら]を見[み]ました。|Vi um templo antigo.
写真[しゃしん]を撮[と]る|tirar foto|たくさん写真[しゃしん]を撮[と]りました。|Tirei muitas fotos.
お土産[みやげ]|lembrancinha|家族[かぞく]にお土産[みやげ]を買[か]いました。|Comprei lembranças para a família.
景色[けしき]|paisagem|ここの景色[けしき]は最高[さいこう]だ。|A paisagem daqui é maravilhosa.
疲[つか]れる|cansar-se|たくさん歩[ある]いて、疲[つか]れた。|Andei muito e fiquei cansada.`,
        k: `
旅|リョ|たび|viagem|旅行[りょこう]=viagem;旅[たび]=jornada
写|シャ|うつ(す)|copiar, fotografar|写真[しゃしん]=foto;写[うつ]す=copiar`,
        g: {
          t: "Forma simples do passado e ～た後で",
          e: `Em diários, mensagens a amigos e textos pessoais, usa-se a **forma simples** (sem ます).
• 行[い]きました → 行[い]った
• 食[た]べませんでした → 食[た]べなかった
• 楽[たの]しかったです → 楽[たの]しかった
• きれいでした → きれいだった
**Verbo (forma た) + 後[あと]で** = “depois de...”. Com substantivo: **Substantivo + の後[あと]で**.
• 晩[ばん]ご飯[はん]を食[た]べた後[あと]で、散歩[さんぽ]した。`,
          x: `
今日[きょう]は京都[きょうと]でお寺[てら]を三[みっ]つ見[み]た。|Hoje vi três templos em Quioto.
お寺[てら]を見[み]た後[あと]で、抹茶[まっちゃ]を飲[の]んだ。|Depois de ver os templos, tomei matchá.
昨日[きのう]は雨[あめ]で、あまり楽[たの]しくなかった。|Ontem choveu e não foi muito divertido.`,
          q: [
            g("昨日[きのう]、友達[ともだち]と映画[えいが]を＿＿。（forma simples）", ["見[み]た", "見[み]ました", "見[み]る", "見[み]て"], 0, "Ontem vi um filme com um amigo.", "Forma simples do passado de 見る: 見た."),
            g("旅行[りょこう]はとても＿＿。（forma simples）", ["楽[たの]しかった", "楽[たの]しいだった", "楽[たの]しかったでした", "楽[たの]しくた"], 0, "A viagem foi muito divertida.", "Adjetivo -い no passado: troque い por かった."),
            g("お風呂[ふろ]に＿＿後[あと]で、ビールを飲[の]んだ。", ["入[はい]った", "入[はい]る", "入[はい]って", "入[はい]り"], 0, "Depois de tomar banho, bebi cerveja.", "後で exige a forma た: 入った後で."),
            g("その店[みせ]は＿＿。（静[しず]か・passado・forma simples）", ["静[しず]かだった", "静[しず]かかった", "静[しず]かった", "静[しず]かでした"], 0, "Aquela loja era tranquila.", "Adjetivo -な / substantivo no passado simples: ～だった."),
            o("お寺[てら]を/見[み]た後[あと]で/お土産[みやげ]を/買[か]った", "Depois de ver o templo, comprei lembranças."),
          ],
        },
        dl: {
          t: "Mensagens de viagem",
          l: `
Ana|ケンさん、今[いま]、京都[きょうと]にいるよ！|Ken, estou em Quioto agora!
Ken|いいね！どこに行[い]ったの？|Que legal! Aonde você foi?
Ana|午前中[ごぜんちゅう]は金閣寺[きんかくじ]に行[い]った。写真[しゃしん]をたくさん撮[と]ったよ。|De manhã fui ao Kinkaku-ji. Tirei muitas fotos.
Ken|午後[ごご]は？|E à tarde?
Ana|お昼[ひる]ご飯[はん]を食[た]べた後[あと]で、着物[きもの]を着[き]て、町[まち]を歩[ある]いた。ちょっと疲[つか]れた。|Depois do almoço, vesti quimono e caminhei pela cidade. Fiquei um pouco cansada.
Ken|お土産[みやげ]、楽[たの]しみにしてるね。|Estou ansioso pela lembrancinha, hein.`,
          q: [
            ["Aonde Ana foi pela manhã?", ["Ao Kinkaku-ji", "A Asakusa", "Ao Monte Fuji"], 0],
            ["O que Ana fez depois do almoço?", ["Voltou ao hotel", "Vestiu quimono e caminhou pela cidade", "Comprou lembranças"], 1],
          ],
        },
        w: ["Escreva uma frase de diário sobre ontem, na forma simples, usando 後で.", "仕事[しごと]が終[お]わった後[あと]で、友達[ともだち]と晩[ばん]ご飯[はん]を食[た]べた。", ["後で=後で|あとで"]],
      },
    ],
  },
  // ───────────────────────── Capítulo 4
  {
    t: "Saúde",
    d: "No médico, conselhos e regras",
    icon: "🩺",
    color: "#16A39A",
    lessons: [
      {
        t: "No médico",
        d: "Explicar sintomas com ～んです",
        v: `
病院[びょういん]|hospital, clínica|病院[びょういん]に行[い]きました。|Fui ao hospital.
熱[ねつ]|febre|熱[ねつ]があります。|Estou com febre.
頭[あたま]が痛[いた]い|estar com dor de cabeça|朝[あさ]から頭[あたま]が痛[いた]いです。|Estou com dor de cabeça desde manhã.
風邪[かぜ]をひく|pegar resfriado|風邪[かぜ]をひきました。|Peguei um resfriado.
薬[くすり]|remédio|薬[くすり]を飲[の]みます。|Tomo remédio.
喉[のど]|garganta|喉[のど]が痛[いた]いです。|Estou com dor de garganta.`,
        k: `
病|ビョウ|や(む)|doença|病院[びょういん]=hospital;病気[びょうき]=doença
薬|ヤク|くすり|remédio|薬[くすり]=remédio;薬局[やっきょく]=farmácia`,
        g: {
          t: "～んです: explicar e pedir explicação",
          e: `**～んです** (ou のです) é usado para dar ou pedir uma explicação, mostrando envolvimento com a situação.
Formação (forma simples +):
• Verbo: 熱[ねつ]がある**んです** / 行[い]った**んです**
• Adjetivo -い: 痛[いた]い**んです**
• Adjetivo -な / substantivo: 静[しず]か**なんです** / 風邪[かぜ]**なんです**
No médico, ouve-se muito **どうしたんですか** (O que aconteceu?).
Ex.: A: どうしたんですか。 B: 頭[あたま]が痛[いた]いんです。`,
          x: `
どうしたんですか。顔色[かおいろ]が悪[わる]いですよ。|O que houve? Você está pálido.
昨日[きのう]から喉[のど]が痛[いた]いんです。|É que estou com dor de garganta desde ontem.
今日[きょう]は休[やす]みます。風邪[かぜ]なんです。|Hoje vou faltar. É que estou resfriada.`,
          q: [
            g("A: どう＿＿んですか。 B: お腹[なか]が痛[いた]いんです。", ["した", "する", "して", "し"], 0, "A: O que houve? B: É que estou com dor de barriga.", "どうしたんですか = O que aconteceu?"),
            g("すみません、遅[おく]れました。電車[でんしゃ]が＿＿んです。", ["遅[おく]れた", "遅[おく]れて", "遅[おく]れ", "遅[おく]れます"], 0, "Desculpe o atraso. É que o trem atrasou.", "んです vem depois da forma simples: 遅れたんです."),
            g("今日[きょう]は早[はや]く帰[かえ]ります。子供[こども]が病気[びょうき]＿＿んです。", ["な", "だ", "の", "に"], 0, "Hoje vou embora cedo. É que meu filho está doente.", "Substantivo + なんです."),
            g("A: 食[た]べないんですか。 B: ええ、あまりお腹[なか]が＿＿んです。", ["すいていない", "すいていないな", "すいてません", "すかないだ"], 0, "A: Você não vai comer? B: É que não estou com muita fome.", "Forma simples negativa + んです: すいていないんです."),
            o("昨日[きのう]から/熱[ねつ]が/ある/んです", "É que estou com febre desde ontem."),
          ],
        },
        dl: {
          t: "Na clínica",
          l: `
Médico|どうしましたか。|O que a traz aqui?
Ana|昨日[きのう]の夜[よる]から熱[ねつ]があるんです。それに、喉[のど]も痛[いた]いんです。|Estou com febre desde ontem à noite. Além disso, minha garganta também dói.
Médico|そうですか。ちょっと口[くち]を開[あ]けてください。…ああ、風邪[かぜ]ですね。|Entendo. Abra a boca, por favor... Ah, é um resfriado.
Ana|仕事[しごと]に行[い]ってもいいですか。|Posso ir trabalhar?
Médico|二日[ふつか]ぐらい家[いえ]で休[やす]んでください。薬[くすり]を出[だ]しますね。|Descanse em casa uns dois dias. Vou receitar um remédio.
Ana|はい、ありがとうございます。|Está bem, obrigada.`,
          q: [
            ["Desde quando Ana tem febre?", ["Desde ontem à noite", "Desde hoje de manhã", "Há uma semana"], 0],
            ["O que o médico recomenda?", ["Ir trabalhar normalmente", "Descansar em casa uns dois dias", "Ir a um hospital maior"], 1],
          ],
        },
        w: ["Explique ao seu chefe por que você vai faltar hoje, usando んです.", "すみません、熱[ねつ]があるんです。今日[きょう]は休[やす]みます。", ["んです=んです|のです|んだ"]],
      },
      {
        t: "Conselhos de saúde",
        d: "Aconselhar com ～たほうがいい",
        v: `
体[からだ]|corpo|体[からだ]に気[き]をつけてください。|Cuide-se.
運動[うんどう]する|fazer exercício|毎日[まいにち]運動[うんどう]します。|Faço exercícios todos os dias.
野菜[やさい]|verdura, legume|野菜[やさい]をたくさん食[た]べます。|Como muitas verduras.
早[はや]く|cedo; rápido|早[はや]く寝[ね]ました。|Dormi cedo.
無理[むり]をする|forçar demais, exagerar|無理[むり]をしないでください。|Não exagere.
健康[けんこう]|saúde|健康[けんこう]のために歩[ある]きます。|Caminho pela saúde.`,
        k: `
体|タイ|からだ|corpo|体[からだ]=corpo;体育[たいいく]=educação física
早|ソウ|はや(い)|cedo|早[はや]い=cedo;早朝[そうちょう]=madrugada`,
        g: {
          t: "～たほうがいい / ～ないほうがいい: conselhos",
          e: `**Verbo (forma た) + ほうがいいです** = “é melhor fazer...” (conselho forte).
• 早[はや]く寝[ね]たほうがいいですよ。
**Verbo (forma ない) + ほうがいいです** = “é melhor não fazer...”.
• 無理[むり]をしないほうがいいです。
⚠️ No afirmativo usa-se a forma た (passado) mesmo falando do futuro; no negativo, a forma ない (não なかった).`,
          x: `
野菜[やさい]をもっと食[た]べたほうがいいですよ。|É melhor comer mais verduras.
熱[ねつ]があるときは、お風呂[ふろ]に入[はい]らないほうがいいです。|Quando se tem febre, é melhor não tomar banho de banheira.
病院[びょういん]に行[い]ったほうがいいと思[おも]います。|Acho que é melhor você ir ao hospital.`,
          q: [
            g("疲[つか]れているなら、早[はや]く＿＿ほうがいいですよ。", ["寝[ね]た", "寝[ね]る", "寝[ね]て", "寝[ね]ない"], 0, "Se você está cansado, é melhor dormir cedo.", "Conselho afirmativo: forma た + ほうがいい."),
            g("お酒[さけ]をたくさん＿＿ほうがいいです。", ["飲[の]まない", "飲[の]まなかった", "飲[の]んで", "飲[の]みない"], 0, "É melhor não beber muito álcool.", "Conselho negativo: forma ない + ほうがいい."),
            g("毎日[まいにち]少[すこ]し＿＿ほうがいいですよ。", ["運動[うんどう]した", "運動[うんどう]して", "運動[うんどう]しなかった", "運動[うんどう]し"], 0, "É melhor fazer um pouco de exercício todos os dias.", "運動する → 運動した + ほうがいい."),
            g("風邪[かぜ]のときは、無理[むり]を＿＿ほうがいいです。", ["しない", "しなかった", "して", "し"], 0, "Quando se está resfriado, é melhor não forçar.", "Negativo: しないほうがいい."),
            o("もっと/野菜[やさい]を/食[た]べた/ほうがいいです", "É melhor comer mais verduras.", "野菜[やさい]を/もっと/食[た]べた/ほうがいいです"),
          ],
        },
        dl: {
          t: "Cansada demais",
          l: `
Ken|アナさん、最近[さいきん]元気[げんき]がないね。|Ana, você anda sem energia ultimamente.
Ana|うん、毎晩[まいばん]二時[にじ]まで勉強[べんきょう]しているの。|É, estou estudando até as duas da manhã toda noite.
Ken|無理[むり]をしないほうがいいよ。もっと早[はや]く寝[ね]たほうがいい。|Melhor não exagerar. É melhor dormir mais cedo.
Ana|そうだね。それに、ご飯[はん]もコンビニのお弁当[べんとう]ばかりなんだ。|Verdade. Além disso, só como marmita de loja de conveniência.
Ken|野菜[やさい]も食[た]べたほうがいいよ。週末[しゅうまつ]、一緒[いっしょ]に料理[りょうり]しない？|É melhor comer verduras também. Que tal cozinharmos juntos no fim de semana?
Ana|ありがとう。そうする！|Obrigada. Vou fazer isso!`,
          q: [
            ["Até que horas Ana estuda?", ["Até a meia-noite", "Até as duas da manhã", "Até as onze"], 1],
            ["O que Ken propõe para o fim de semana?", ["Ir ao médico", "Cozinhar juntos", "Correr no parque"], 1],
          ],
        },
        w: ["Dê um conselho de saúde a um amigo usando ほうがいい.", "毎日[まいにち]少[すこ]し歩[ある]いたほうがいいですよ。", ["ほうがいい=ほうがいい"]],
      },
      {
        t: "Regras do hospital",
        d: "Proibições: ～てはいけません e ～ないでください",
        v: `
入院[にゅういん]する|ser internado|一週間[いっしゅうかん]入院[にゅういん]しました。|Fiquei internada uma semana.
注射[ちゅうしゃ]|injeção|注射[ちゅうしゃ]は痛[いた]くなかったです。|A injeção não doeu.
お見舞[みま]い|visita a um doente|友達[ともだち]のお見舞[みま]いに行[い]きます。|Vou visitar um amigo doente.
受付[うけつけ]|recepção|受付[うけつけ]で名前[なまえ]を書[か]きます。|Escrevo meu nome na recepção.
静[しず]か|silencioso|病院[びょういん]では静[しず]かにしてください。|No hospital, fique em silêncio.
携帯電話[けいたいでんわ]|telefone celular|携帯電話[けいたいでんわ]の電源[でんげん]を切[き]ります。|Desligo o celular.`,
        k: `
院|イン|—|instituição|病院[びょういん]=hospital;入院[にゅういん]=internação
痛|ツウ|いた(い)|dor|痛[いた]い=dolorido;頭痛[ずつう]=dor de cabeça`,
        g: {
          t: "～てはいけません e ～ないでください: proibições",
          e: `**Verbo (forma て) + はいけません** = “não é permitido...” (regra, proibição forte).
• ここでたばこを吸[す]ってはいけません。
**Verbo (forma ない) + でください** = “por favor, não...” (pedido educado).
• ここで電話[でんわ]をしないでください。
Forma ない: 吸[す]う → 吸[す]わない, 食[た]べる → 食[た]べない, する → しない, 来[く]る → 来[こ]ない.`,
          x: `
病室[びょうしつ]で大[おお]きい声[こえ]で話[はな]してはいけません。|Não é permitido falar alto no quarto do hospital.
写真[しゃしん]を撮[と]らないでください。|Por favor, não tire fotos.
この薬[くすり]を飲[の]んだ後[あと]で、運転[うんてん]してはいけません。|Não se deve dirigir depois de tomar este remédio.`,
          q: [
            g("病院[びょういん]の中[なか]で、たばこを＿＿はいけません。", ["吸[す]って", "吸[す]わない", "吸[す]う", "吸[す]った"], 0, "Não é permitido fumar dentro do hospital.", "Proibição: forma て + はいけません."),
            g("ここに車[くるま]を＿＿でください。", ["止[と]めない", "止[と]めて", "止[と]める", "止[と]めなく"], 0, "Por favor, não estacione o carro aqui.", "Pedido negativo: forma ない + でください."),
            g("テストの時[とき]、辞書[じしょ]を＿＿はいけません。", ["使[つか]って", "使[つか]わない", "使[つか]う", "使[つか]いて"], 0, "Na prova, não é permitido usar dicionário.", "使う → 使って + はいけません."),
            g("心配[しんぱい]＿＿でください。すぐ治[なお]りますよ。", ["しない", "して", "する", "しなく"], 0, "Não se preocupe. Vai sarar logo.", "する → しない + でください."),
            o("ここで/写真[しゃしん]を/撮[と]らないで/ください", "Por favor, não tire fotos aqui.", "写真[しゃしん]を/ここで/撮[と]らないで/ください"),
          ],
        },
        dl: {
          t: "Visitando o Ken no hospital",
          l: `
Recepção|こんにちは。お見舞[みま]いですか。|Boa tarde. Vem visitar alguém?
Ana|はい、山田[やまだ]ケンさんの部屋[へや]はどこですか。|Sim, onde fica o quarto do Ken Yamada?
Recepção|三〇五号室[さんびゃくごごうしつ]です。病室[びょうしつ]では携帯電話[けいたいでんわ]を使[つか]わないでください。|Quarto 305. Por favor, não use o celular no quarto.
Ana|わかりました。花[はな]を持[も]って行[い]ってもいいですか。|Entendi. Posso levar flores?
Recepção|すみません、花[はな]は持[も]って行[い]ってはいけないんです。|Desculpe, não é permitido levar flores.
Ana|そうですか。じゃ、ここに置[お]いておきます。|Entendo. Então vou deixá-las aqui.`,
          q: [
            ["Qual é o número do quarto do Ken?", ["205", "305", "350"], 1],
            ["O que não é permitido levar ao quarto?", ["Comida", "Flores", "Livros"], 1],
          ],
        },
        w: ["Escreva uma regra da sua casa ou do trabalho usando てはいけません ou ないでください.", "家[いえ]の中[なか]で靴[くつ]を履[は]いてはいけません。", ["proibição=てはいけ|ではいけ|ないでください"]],
      },
    ],
  },
];
