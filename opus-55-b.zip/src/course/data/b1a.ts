import { g, o, type RawUnit } from "../dsl";

export const B1_PART1: RawUnit[] = [
  // ───────────────────────── Capítulo 1 (B1)
  {
    t: "Notícias e boatos",
    d: "Transmitir informações e fazer suposições",
    icon: "📰",
    color: "#5B6CFF",
    lessons: [
      {
        t: "Ouvi dizer que...",
        d: "Informação de terceiros com ～そうです",
        v: `
ニュース|notícia, noticiário|毎朝[まいあさ]ニュースを見[み]ます。|Vejo o noticiário toda manhã.
天気予報[てんきよほう]|previsão do tempo|天気予報[てんきよほう]によると、明日[あした]は雪[ゆき]です。|Segundo a previsão do tempo, amanhã vai nevar.
噂[うわさ]|boato, rumor|変[へん]な噂[うわさ]を聞[き]きました。|Ouvi um boato estranho.
台風[たいふう]|tufão|台風[たいふう]が近[ちか]づいています。|Um tufão está se aproximando.
値上[ねあ]げ|aumento de preço|来月[らいげつ]から電車[でんしゃ]が値上[ねあ]げになります。|A partir do mês que vem, a passagem de trem vai aumentar.
によると|segundo, de acordo com|新聞[しんぶん]によると、事故[じこ]があったそうです。|Segundo o jornal, houve um acidente.`,
        k: `
報|ホウ|むく(いる)|notícia, informar|天気予報[てんきよほう]=previsão do tempo;情報[じょうほう]=informação
台|ダイ、タイ|—|plataforma; contador de máquinas|台風[たいふう]=tufão;一台[いちだい]=uma unidade (máquina)`,
        g: {
          t: "～そうです: “ouvi dizer que...”",
          e: `**Forma simples + そうです** transmite uma informação que você ouviu ou leu.
• 明日[あした]は雨[あめ]が降[ふ]る**そうです**。 (Dizem que amanhã vai chover.)
• Adjetivo -な / substantivo: 静[しず]か**だ**そうです / 休[やす]み**だ**そうです
A fonte vem com **～によると** ou **～の話[はなし]では**.
⚠️ Não confunda com o そう de aparência (A2):
• 降[ふ]り**そう**です = parece que vai chover (eu vejo)
• 降[ふ]る**そう**です = dizem que vai chover (eu ouvi)`,
          x: `
天気予報[てんきよほう]によると、週末[しゅうまつ]は台風[たいふう]が来[く]るそうです。|Segundo a previsão, um tufão vai chegar no fim de semana.
ユイさんの話[はなし]では、あの店[みせ]はとてもおいしいそうです。|Pelo que a Yui disse, aquele restaurante é muito bom.
田中[たなか]さんは来月[らいげつ]、大阪[おおさか]に転勤[てんきん]するそうです。|Dizem que o Sr. Tanaka será transferido para Osaka no mês que vem.`,
          q: [
            g("ニュースによると、昨日[きのう]東京[とうきょう]で地震[じしん]が＿＿そうです。", ["あった", "ありそう", "あって", "あり"], 0, "Segundo o noticiário, houve um terremoto em Tóquio ontem.", "Informação ouvida: forma simples (passado) + そうです."),
            g("天気予報[てんきよほう]では、明日[あした]は＿＿そうです。", ["晴[は]れる", "晴[は]れて", "晴[は]れた方[ほう]", "晴[は]れます"], 0, "Pela previsão do tempo, amanhã vai fazer sol.", "Hearsay: forma simples + そう (晴れるそうです)."),
            g("あのレストランは今月[こんげつ]で＿＿そうです。", ["閉店[へいてん]する", "閉店[へいてん]して", "閉店[へいてん]な", "閉店[へいてん]の"], 0, "Dizem que aquele restaurante vai fechar este mês.", "Verbo na forma simples + そうです."),
            g("ケンさんのお父[とう]さんは医者[いしゃ]＿＿そうです。", ["だ", "な", "の", "で"], 0, "Dizem que o pai do Ken é médico.", "Substantivo + だ + そうです (informação ouvida)."),
            o("新聞[しんぶん]によると/来月[らいげつ]から/電車[でんしゃ]が/値上[ねあ]げになるそうです", "Segundo o jornal, a passagem de trem vai aumentar a partir do mês que vem."),
          ],
        },
        dl: {
          t: "Novidades do escritório",
          l: `
Ken|ねえ、聞[き]いた？田中[たなか]さん、大阪[おおさか]に転勤[てんきん]するそうだよ。|Ei, ficou sabendo? Dizem que o Sr. Tanaka vai ser transferido para Osaka.
Ana|えっ、本当[ほんとう]？誰[だれ]に聞[き]いたの？|O quê, sério? Quem te contou?
Ken|部長[ぶちょう]の話[はなし]では、四月[しがつ]から大阪支社[おおさかししゃ]の課長[かちょう]になるそうだ。|Pelo que o gerente disse, a partir de abril ele vai ser chefe de seção na filial de Osaka.
Ana|それは昇進[しょうしん]だね。でも、寂[さび]しくなるなあ。|Então é uma promoção. Mas vou sentir falta dele.
Ken|送別会[そうべつかい]をするそうだから、プレゼントを考[かんが]えよう。|Dizem que vão fazer uma festa de despedida, então vamos pensar num presente.`,
          q: [
            ["Quem deu a informação sobre o Sr. Tanaka?", ["A Yui", "O gerente", "O próprio Sr. Tanaka"], 1],
            ["A partir de quando o Sr. Tanaka vai para Osaka?", ["Março", "Abril", "Maio"], 1],
          ],
        },
        w: ["Conte uma notícia que você ouviu ou leu recentemente, usando ～によると…そうです.", "ニュースによると、来週[らいしゅう]は暑[あつ]くなるそうです。", ["そうです=そうです|そうだ"]],
      },
      {
        t: "Parece que...",
        d: "Suposições com ～ようだ e ～らしい",
        v: `
事故[じこ]|acidente|駅[えき]の近[ちか]くで事故[じこ]がありました。|Houve um acidente perto da estação.
渋滞[じゅうたい]|congestionamento|道[みち]が渋滞[じゅうたい]しています。|A rua está congestionada.
遅延[ちえん]|atraso (transporte)|電車[でんしゃ]が遅延[ちえん]しています。|O trem está atrasado.
様子[ようす]|situação, aspecto|様子[ようす]を見[み]ましょう。|Vamos observar a situação.
音[おと]|som, barulho|変[へん]な音[おと]がします。|Está fazendo um barulho estranho.
どうやら|ao que parece|どうやら道[みち]を間違[まちが]えたようです。|Ao que parece, erramos o caminho.`,
        k: `
様|ヨウ|さま|aspecto; senhor(a)|様子[ようす]=situação;お客様[きゃくさま]=cliente
事|ジ|こと|coisa, assunto|事故[じこ]=acidente;仕事[しごと]=trabalho`,
        g: {
          t: "～ようだ e ～らしい: suposição por indícios",
          e: `**～ようです** (ou ～みたいです, coloquial): suposição a partir do que **você mesmo percebe** (vê, ouve, sente).
• 外[そと]が騒[さわ]がしい。事故[じこ]があった**ようです**。
• Formação: forma simples + ようだ; adjetivo -な + **な**ようだ; substantivo + **の**ようだ.
**～らしいです**: suposição a partir de **informação externa** (algo que se ouviu), mais distante.
• 田中[たなか]さんは来月[らいげつ]結婚[けっこん]する**らしい**よ。
• Substantivo e adjetivo -な ligam-se diretamente: 休[やす]み**らしい**.
**Substantivo + らしい** também significa “típico de”: 男[おとこ]らしい (másculo).`,
          x: `
電車[でんしゃ]が来[こ]ない。どうやら事故[じこ]があったようだ。|O trem não vem. Ao que parece, houve um acidente.
隣[となり]の部屋[へや]は留守[るす]のようです。|Parece que o vizinho não está em casa.
あの店[みせ]、来週[らいしゅう]閉店[へいてん]するらしいよ。|Parece que aquela loja vai fechar semana que vem.`,
          q: [
            g("部屋[へや]の電気[でんき]が消[き]えている。ユイさんはもう寝[ね]た＿＿だ。", ["よう", "そう", "はず", "つもり"], 0, "A luz do quarto está apagada. Parece que a Yui já dormiu.", "Suposição pelo que eu vejo: ようだ."),
            g("ケンさんは風邪[かぜ]＿＿ようです。今日[きょう]は休[やす]みです。", ["の", "な", "だ", "に"], 0, "Parece que o Ken está resfriado. Hoje ele faltou.", "Substantivo + の + ようです."),
            g("噂[うわさ]では、あの二人[ふたり]は付[つ]き合[あ]っている＿＿よ。", ["らしい", "ようで", "そうな", "みたく"], 0, "Pelos boatos, parece que aqueles dois estão namorando.", "Informação ouvida, distante: らしい."),
            g("この部屋[へや]、静[しず]か＿＿ようですね。", ["な", "の", "だ", "に"], 0, "Este quarto parece ser silencioso.", "Adjetivo -な + な + ようだ."),
            o("どうやら/道[みち]を/間違[まちが]えた/ようです", "Ao que parece, erramos o caminho."),
          ],
        },
        dl: {
          t: "Trem parado",
          l: `
Ana|あれ、電車[でんしゃ]、全然[ぜんぜん]来[こ]ないね。|Ué, o trem não vem de jeito nenhum.
Ken|アナウンスを聞[き]いて。…どうやら前[まえ]の駅[えき]で事故[じこ]があったようだ。|Escuta o anúncio... Ao que parece, houve um acidente na estação anterior.
Ana|どのくらい遅[おく]れるのかな。|Quanto será que vai atrasar?
Ken|ネットの情報[じょうほう]によると、一時間[いちじかん]ぐらい止[と]まるらしいよ。|Segundo informações da internet, parece que vai ficar parado por cerca de uma hora.
Ana|えー、困[こま]ったなあ。会議[かいぎ]に間[ま]に合[あ]わない。|Ah, que problema. Não vou chegar a tempo da reunião.
Ken|バスで行[い]ったほうがいいかもね。|Talvez seja melhor ir de ônibus.`,
          q: [
            ["Por que o trem não vem?", ["Houve um tufão", "Houve um acidente na estação anterior", "É feriado"], 1],
            ["Segundo a internet, por quanto tempo o trem vai ficar parado?", ["Trinta minutos", "Cerca de uma hora", "O dia todo"], 1],
          ],
        },
        w: ["Descreva uma situação e faça uma suposição usando ようです ou らしいです.", "道[みち]が混[こ]んでいる。どうやら事故[じこ]があったようです。", ["suposição=よう|らしい|みたい"]],
      },
      {
        t: "Ele disse que...",
        d: "Recados: ～と言っていました e ～ように言う",
        v: `
伝[つた]える|transmitir, avisar|田中[たなか]さんに伝[つた]えてください。|Por favor, avise o Sr. Tanaka.
伝言[でんごん]|recado|伝言[でんごん]をお願[ねが]いします。|Gostaria de deixar um recado.
頼[たの]む|pedir, encomendar|友達[ともだち]に手伝[てつだ]いを頼[たの]みました。|Pedi ajuda a um amigo.
遅[おく]れる|atrasar-se|十分[じゅっぷん]遅[おく]れます。|Vou me atrasar dez minutos.
連絡[れんらく]する|entrar em contato|後[あと]で連絡[れんらく]します。|Entro em contato depois.
折[お]り返[かえ]し|retorno (de ligação)|折[お]り返[かえ]しお電話[でんわ]します。|Retorno a ligação.`,
        k: `
伝|デン|つた(える)|transmitir|伝[つた]える=transmitir;手伝[てつだ]う=ajudar
連|レン|つ(れる)|ligar; levar junto|連絡[れんらく]=contato;連[つ]れて行[い]く=levar alguém`,
        g: {
          t: "Discurso indireto: ～と言っていました e ～ように言う",
          e: `**Forma simples + と言[い]っていました** = “(alguém) disse que...” — usado para transmitir recados.
• 田中[たなか]さんは少[すこ]し遅[おく]れる**と言[い]っていました**。
A citação direta usa 「 」: 田中[たなか]さんは「少[すこ]し遅[おく]れます」と言[い]いました。
Para transmitir **pedidos ou ordens**: **Verbo (dicionário / ない) + ように言[い]う / 頼[たの]む / 伝[つた]える**.
• 部長[ぶちょう]が会議室[かいぎしつ]に来[く]る**ように言[い]っていました**。
• 遅[おく]れない**ように伝[つた]えてください**。`,
          x: `
ケンさんは明日[あした]のパーティーに行[い]けないと言[い]っていました。|O Ken disse que não pode ir à festa amanhã.
先生[せんせい]は宿題[しゅくだい]を忘[わす]れないように言[い]いました。|O professor disse para não esquecermos a lição.
田中[たなか]さんに折[お]り返[かえ]し電話[でんわ]するように伝[つた]えてください。|Por favor, peça ao Sr. Tanaka que retorne a ligação.`,
          q: [
            g("ユイさんは今日[きょう]は来[こ]られない＿＿言[い]っていました。", ["と", "を", "に", "が"], 0, "A Yui disse que não pode vir hoje.", "Citação: ～と言っていました."),
            g("医者[いしゃ]にお酒[さけ]を飲[の]まない＿＿言[い]われました。", ["ように", "そうに", "らしく", "ために"], 0, "O médico me disse para não beber álcool.", "Ordem/pedido indireto: ～ないように言う."),
            g("部長[ぶちょう]に、すぐ会議室[かいぎしつ]へ＿＿ように伝[つた]えてください。", ["来[く]る", "来[き]て", "来[こ]よう", "来[き]た"], 0, "Por favor, avise o gerente para vir logo à sala de reuniões.", "～ように vem após a forma de dicionário."),
            g("田中[たなか]さんは「明日[あした]休[やす]みます」＿＿言[い]いました。", ["と", "を", "に", "が"], 0, "O Sr. Tanaka disse: “Amanhã vou faltar”.", "Citação direta com 「」 + と言いました."),
            o("ケンさんは/少[すこ]し/遅[おく]れると/言[い]っていました", "O Ken disse que vai se atrasar um pouco."),
          ],
        },
        dl: {
          t: "Deixando um recado",
          l: `
Ana|はい、営業部[えいぎょうぶ]のシルバです。|Alô, Silva, do departamento de vendas.
Sato|ABC商事[しょうじ]の佐藤[さとう]と申[もう]します。田中[たなか]さんはいらっしゃいますか。|Aqui é Sato, da ABC Comercial. O Sr. Tanaka está?
Ana|申[もう]し訳[わけ]ありません、田中[たなか]は今[いま]、会議中[かいぎちゅう]です。|Sinto muito, o Tanaka está em reunião agora.
Sato|では、伝言[でんごん]をお願[ねが]いできますか。明日[あした]の打[う]ち合[あ]わせを三時[さんじ]からに変更[へんこう]したいと伝[つた]えてください。|Então, posso deixar um recado? Diga que eu gostaria de mudar a reunião de amanhã para as três.
Ana|かしこまりました。三時[さんじ]からですね。折[お]り返[かえ]し電話[でんわ]するように伝[つた]えましょうか。|Certamente. A partir das três, certo? Quer que eu peça para ele retornar a ligação?
Sato|はい、お願[ねが]いします。|Sim, por favor.
Ana|（田中[たなか]さんに）佐藤[さとう]さんが明日[あした]の打[う]ち合[あ]わせを三時[さんじ]からにしたいと言[い]っていました。|(Ao Sr. Tanaka) O Sr. Sato disse que gostaria de fazer a reunião de amanhã a partir das três.`,
          q: [
            ["Por que o Sr. Tanaka não pode atender?", ["Está almoçando", "Está em reunião", "Já foi embora"], 1],
            ["Qual é a mudança pedida pelo Sr. Sato?", ["Cancelar a reunião", "Mudar a reunião para as três", "Mudar o local da reunião"], 1],
          ],
        },
        w: ["Transmita um recado de um colega usando と言っていました.", "ユイさんは明日[あした]少[すこ]し遅[おく]れると言[い]っていました。", ["と言っていました=と言っていました|と言っていた|と言いました|といっていました"]],
      },
    ],
  },
  // ───────────────────────── Capítulo 2 (B1)
  {
    t: "Condicionais",
    d: "たら, ば e なら em situações reais",
    icon: "🔀",
    color: "#FF7A59",
    lessons: [
      {
        t: "E se...?",
        d: "Hipóteses e “quando” com ～たら",
        v: `
もし|se (por acaso)|もし雨[あめ]が降[ふ]ったら、中止[ちゅうし]です。|Se chover, será cancelado.
宝[たから]くじ|loteria|宝[たから]くじを買[か]いました。|Comprei um bilhete de loteria.
当[あ]たる|acertar; ser sorteado|一等[いっとう]が当[あ]たったら、家[いえ]を買[か]います。|Se eu ganhar o primeiro prêmio, compro uma casa.
中止[ちゅうし]|cancelamento|試合[しあい]は中止[ちゅうし]になりました。|O jogo foi cancelado.
着[つ]く|chegar|駅[えき]に着[つ]いたら、電話[でんわ]してください。|Quando chegar à estação, me ligue.
卒業[そつぎょう]する|formar-se|大学[だいがく]を卒業[そつぎょう]しました。|Formei-me na universidade.`,
        k: `
着|チャク|き(る)、つ(く)|vestir; chegar|着[つ]く=chegar;到着[とうちゃく]=chegada
当|トウ|あ(たる)|acertar; este|当[あ]たる=acertar;本当[ほんとう]=verdade`,
        g: {
          t: "～たら: condição e “quando”",
          e: `**Forma た + ら** é o condicional mais versátil.
1. **Hipótese** (se...): もし宝[たから]くじが当[あ]たったら、世界[せかい]旅行[りょこう]をしたい。
2. **Quando (algo certo acontecer)**: 駅[えき]に着[つ]いたら、電話[でんわ]してください。
3. **Descoberta no passado**: 窓[まど]を開[あ]けたら、雪[ゆき]が降[ふ]っていた。 (Ao abrir a janela, estava nevando.)
Formação: 行[い]った**ら**, 食[た]べた**ら**, 安[やす]かった**ら**, 暇[ひま]だった**ら**, 雨[あめ]だった**ら**.
Diferente de ～と, a segunda parte **pode** ser pedido, convite ou desejo.`,
          x: `
もし時間[じかん]があったら、一緒[いっしょ]に行[い]きませんか。|Se tiver tempo, não quer ir junto?
仕事[しごと]が終[お]わったら、飲[の]みに行[い]こう。|Quando o trabalho acabar, vamos beber.
家[いえ]に帰[かえ]ったら、荷物[にもつ]が届[とど]いていた。|Quando cheguei em casa, a encomenda tinha chegado.`,
          q: [
            g("もし百万円[ひゃくまんえん]＿＿、何[なに]をしますか。", ["あったら", "あって", "あった", "あるから"], 0, "Se você tivesse um milhão de ienes, o que faria?", "Hipótese com もし: ～たら."),
            g("日本[にほん]に＿＿、連絡[れんらく]してください。", ["着[つ]いたら", "着[つ]くと", "着[つ]いて", "着[つ]くから"], 0, "Quando chegar ao Japão, entre em contato.", "Pedido na segunda parte: use ～たら (não ～と)."),
            g("ドアを開[あ]け＿＿、猫[ねこ]が入[はい]ってきた。", ["たら", "ても", "ながら", "たり"], 0, "Quando abri a porta, um gato entrou.", "Acontecimento inesperado no passado: ～たら."),
            g("天気[てんき]が＿＿、海[うみ]に行[い]きましょう。", ["よかったら", "いいたら", "よいたら", "よくたら"], 0, "Se o tempo estiver bom, vamos à praia.", "いい → よかった → よかったら."),
            o("大学[だいがく]を/卒業[そつぎょう]したら/日本[にほん]で/働[はたら]きたいです", "Quando me formar na universidade, quero trabalhar no Japão."),
          ],
        },
        dl: {
          t: "E se ganhasse na loteria?",
          l: `
Ken|アナさん、もし宝[たから]くじで一億円[いちおくえん]当[あ]たったら、どうする？|Ana, se você ganhasse 100 milhões de ienes na loteria, o que faria?
Ana|うーん、まず家族[かぞく]を日本[にほん]に呼[よ]びたいな。ケンさんは？|Hmm, primeiro eu queria trazer minha família para o Japão. E você, Ken?
Ken|僕[ぼく]は会社[かいしゃ]をやめて、世界中[せかいじゅう]を旅行[りょこう]したい。|Eu sairia da empresa e viajaria pelo mundo todo.
Ana|いいね。でも、お金[かね]がなくなったら、どうするの？|Legal. Mas e quando o dinheiro acabar?
Ken|そうしたら、また働[はたら]くよ。|Aí eu volto a trabalhar.
Ana|ははは。じゃ、まず宝[たから]くじを買[か]わないとね。|Hahaha. Então, primeiro precisamos comprar um bilhete de loteria.`,
          q: [
            ["O que Ana faria com o dinheiro?", ["Compraria uma casa", "Traria a família para o Japão", "Viajaria pelo mundo"], 1],
            ["O que Ken faria quando o dinheiro acabasse?", ["Voltaria a trabalhar", "Pediria emprestado", "Voltaria para a casa dos pais"], 0],
          ],
        },
        w: ["Escreva o que você faria se tivesse um mês de férias, usando たら.", "もし一[いっ]か月[げつ]休[やす]みがあったら、日本中[にほんじゅう]を旅行[りょこう]したいです。", ["たら=たら|だら"]],
      },
      {
        t: "Se você praticar...",
        d: "Condição necessária com ～ば",
        v: `
努力[どりょく]する|esforçar-se|毎日[まいにち]努力[どりょく]しています。|Esforço-me todos os dias.
上手[じょうず]になる|ficar bom (em algo)|日本語[にほんご]が上手[じょうず]になりました。|Fiquei bom em japonês.
練習[れんしゅう]する|praticar|ピアノを練習[れんしゅう]します。|Pratico piano.
合格[ごうかく]する|ser aprovado|試験[しけん]に合格[ごうかく]しました。|Fui aprovada no exame.
方法[ほうほう]|método, maneira|いい方法[ほうほう]がありますか。|Há algum bom método?
説明書[せつめいしょ]|manual de instruções|説明書[せつめいしょ]を読[よ]めば、わかります。|Lendo o manual, você entende.`,
        k: `
練|レン|ね(る)|treinar, polir|練習[れんしゅう]=prática;訓練[くんれん]=treinamento
習|シュウ|なら(う)|aprender|習[なら]う=aprender (com alguém);練習[れんしゅう]=prática`,
        g: {
          t: "～ば: condição para um resultado",
          e: `**～ば** enfatiza a **condição necessária** para que algo aconteça: “se (fizer isso), então...”.
Formação:
• Verbos: último som → **e + ば**: 行[い]く → 行[い]けば, 読[よ]む → 読[よ]めば, 食[た]べる → 食[た]べれば, する → すれば, 来[く]る → 来[く]れば
• Adjetivo -い: い → **ければ**: 安[やす]い → 安[やす]ければ, いい → **よければ**
• Negativo: ない → **なければ**: 行[い]かなければ
• Adjetivo -な / substantivo: **なら(ば)**: 暇[ひま]なら
Expressão útil: **どうすればいいですか** = O que devo fazer?`,
          x: `
毎日[まいにち]練習[れんしゅう]すれば、上手[じょうず]になりますよ。|Se praticar todos os dias, vai ficar bom.
安[やす]ければ、買[か]います。|Se for barato, eu compro.
この問題[もんだい]は、どうすればいいですか。|O que devo fazer com este problema?`,
          q: [
            g("この説明書[せつめいしょ]を＿＿、使[つか]い方[かた]がわかります。", ["読[よ]めば", "読[よ]むば", "読[よ]みば", "読[よ]んば"], 0, "Lendo este manual, você entende como usar.", "読む → 読め + ば."),
            g("もっと勉強[べんきょう]＿＿、合格[ごうかく]できたのに。", ["すれば", "しば", "するば", "されば"], 0, "Se eu tivesse estudado mais, teria passado.", "する → すれば."),
            g("天気[てんき]が＿＿、富士山[ふじさん]が見[み]えます。", ["よければ", "いければ", "いいば", "よいば"], 0, "Se o tempo estiver bom, dá para ver o Monte Fuji.", "Exceção: いい → よければ."),
            g("駅[えき]までどう＿＿いいですか。", ["行[い]けば", "行[い]くば", "行[い]けると", "行[い]けて"], 0, "Como devo fazer para ir até a estação?", "Pedido de conselho: どう～ばいいですか."),
            o("毎日[まいにち]/練習[れんしゅう]すれば/上手[じょうず]に/なります", "Se praticar todos os dias, vai melhorar."),
          ],
        },
        dl: {
          t: "Como passar no JLPT?",
          l: `
Ana|田中[たなか]さん、Ｎ３に合格[ごうかく]したいんですが、どうすればいいでしょうか。|Sr. Tanaka, quero passar no N3. O que devo fazer?
Tanaka|そうですね。毎日[まいにち]少[すこ]しずつ漢字[かんじ]を覚[おぼ]えれば、大丈夫[だいじょうぶ]ですよ。|Bem, se você memorizar um pouco de kanji todos os dias, vai dar certo.
Ana|聴解[ちょうかい]が苦手[にがて]なんです。|É que tenho dificuldade com a compreensão auditiva.
Tanaka|それなら、ニュースを毎日[まいにち]聞[き]けば、耳[みみ]が慣[な]れますよ。|Nesse caso, se ouvir o noticiário todos os dias, seu ouvido se acostuma.
Ana|なるほど。時間[じかん]があれば、ドラマも見[み]ます。|Entendi. Se tiver tempo, também vou assistir a doramas.
Tanaka|いい方法[ほうほう]ですね。頑張[がんば]ってください。|Ótimo método. Boa sorte.`,
          q: [
            ["Com o que Ana tem dificuldade?", ["Kanji", "Compreensão auditiva", "Gramática"], 1],
            ["O que o Sr. Tanaka recomenda para essa dificuldade?", ["Ler mangás", "Ouvir o noticiário todos os dias", "Fazer um curso"], 1],
          ],
        },
        w: ["Dê uma dica a quem estuda japonês usando ～ば.", "毎日[まいにち]日本語[にほんご]を聞[き]けば、上手[じょうず]になりますよ。", ["condicional ば=ば"]],
      },
      {
        t: "Se for o caso de...",
        d: "Recomendações com ～なら",
        v: `
おすすめ|recomendação|おすすめの店[みせ]はありますか。|Tem alguma loja recomendada?
温泉[おんせん]|fonte termal|週末[しゅうまつ]、温泉[おんせん]に行[い]きます。|No fim de semana vou a uma fonte termal.
紅葉[こうよう]|folhas de outono|京都[きょうと]の紅葉[こうよう]はきれいです。|As folhas de outono de Quioto são lindas.
季節[きせつ]|estação do ano|一番[いちばん]好[す]きな季節[きせつ]は秋[あき]です。|Minha estação favorita é o outono.
案内[あんない]する|guiar, mostrar o caminho|町[まち]を案内[あんない]します。|Vou te mostrar a cidade.
詳[くわ]しい|detalhado; entendido em|彼[かれ]は歴史[れきし]に詳[くわ]しいです。|Ele entende muito de história.`,
        k: `
季|キ|—|estação|季節[きせつ]=estação do ano;四季[しき]=as quatro estações
節|セツ|ふし|época; nó|季節[きせつ]=estação;節約[せつやく]=economia`,
        g: {
          t: "～なら: “se for o caso de...”",
          e: `**～なら** retoma algo que a outra pessoa disse, ou um tópico, para dar **conselho, opinião ou informação** sobre ele.
• A: 京都[きょうと]に行[い]きたいんです。 B: 京都[きょうと]**なら**、秋[あき]がいいですよ。
Formação: substantivo / forma simples + なら.
• 温泉[おんせん]なら / 行[い]くなら / 安[やす]いなら / 暇[ひま]なら
Diferença importante:
• 京都[きょうと]に**行[い]くなら**、新幹線[しんかんせん]を予約[よやく]したほうがいい。 (antes de ir)
• 京都[きょうと]に**行[い]ったら**、お寺[てら]を見[み]てください。 (depois de chegar)`,
          x: `
温泉[おんせん]なら、箱根[はこね]がおすすめです。|Se é fonte termal, recomendo Hakone.
パソコンを買[か]うなら、軽[かる]いのがいいですよ。|Se vai comprar um computador, um leve é melhor.
疲[つか]れているなら、今日[きょう]は早[はや]く帰[かえ]ってください。|Se você está cansada, vá embora cedo hoje.`,
          q: [
            g("A: おいしいラーメンが食[た]べたいです。 B: ラーメン＿＿、駅前[えきまえ]の店[みせ]がおすすめですよ。", ["なら", "たら", "ば", "と"], 0, "A: Quero comer um ramen gostoso. B: Se é ramen, recomendo a loja em frente à estação.", "Retomar o tópico do outro para recomendar: なら."),
            g("北海道[ほっかいどう]に＿＿なら、暖[あたた]かい服[ふく]を持[も]って行[い]ったほうがいいですよ。", ["行[い]く", "行[い]って", "行[い]け", "行[い]こう"], 0, "Se você vai a Hokkaido, é melhor levar roupas quentes.", "Conselho antes da ação: forma de dicionário + なら."),
            g("日本[にほん]の歴史[れきし]のこと＿＿、田中[たなか]さんが詳[くわ]しいですよ。", ["なら", "たら", "と", "ば"], 0, "Se é sobre história do Japão, o Sr. Tanaka entende muito.", "Tópico + なら + informação."),
            g("A: 来週[らいしゅう]、ブラジルに帰[かえ]ります。 B: 帰[かえ]る＿＿、お土産[みやげ]を頼[たの]んでもいいですか。", ["なら", "と", "たり", "ても"], 0, "A: Semana que vem volto para o Brasil. B: Se você vai voltar, posso te pedir uma lembrancinha?", "Retomando o que o outro disse: ～なら."),
            o("温泉[おんせん]なら/箱根[はこね]が/おすすめです", "Se é fonte termal, recomendo Hakone."),
          ],
        },
        dl: {
          t: "Viagem de outono",
          l: `
Ana|ユイさん、秋[あき]に旅行[りょこう]したいんだけど、どこがいいと思[おも]う？|Yui, quero viajar no outono. Que lugar você acha bom?
Yui|紅葉[こうよう]を見[み]るなら、京都[きょうと]が一番[いちばん]だよ。|Se é para ver as folhas de outono, Quioto é o melhor.
Ana|京都[きょうと]は夏[なつ]に行[い]ったから、違[ちが]うところがいいな。|Já fui a Quioto no verão, então prefiro outro lugar.
Yui|それなら、日光[にっこう]はどう？紅葉[こうよう]もきれいだし、温泉[おんせん]もあるよ。|Nesse caso, que tal Nikko? As folhas são lindas e tem fontes termais também.
Ana|いいね！行[い]くなら、いつがいい？|Ótimo! Se eu for, quando é melhor?
Yui|十月[じゅうがつ]の終[お]わりごろがいいよ。週末[しゅうまつ]は混[こ]むから、平日[へいじつ]なら、もっといいね。|Por volta do fim de outubro. No fim de semana fica cheio, então, se for num dia útil, melhor ainda.`,
          q: [
            ["Por que Ana não quer ir a Quioto?", ["É caro", "Já foi no verão", "Não gosta de templos"], 1],
            ["Quando é melhor ir a Nikko, segundo Yui?", ["Começo de outubro, no fim de semana", "Fim de outubro, num dia útil", "Novembro, no feriado"], 1],
          ],
        },
        w: ["Dê uma recomendação sobre a sua cidade usando なら.", "おいしいコーヒーなら、駅[えき]の近[ちか]くのカフェがおすすめです。", ["なら=なら"]],
      },
    ],
  },
  // ───────────────────────── Capítulo 3 (B1)
  {
    t: "Favores e cortesia",
    d: "Favores, pedidos educados e keigo de respeito",
    icon: "🙇",
    color: "#C04CF0",
    lessons: [
      {
        t: "Uma ajudinha",
        d: "Favores: ～てあげる, ～てくれる, ～てもらう",
        v: `
手伝[てつだ]う|ajudar|引[ひ]っ越[こ]しを手伝[てつだ]いました。|Ajudei na mudança.
貸[か]す|emprestar|傘[かさ]を貸[か]してくれました。|Ele me emprestou o guarda-chuva.
借[か]りる|pegar emprestado|図書館[としょかん]で本[ほん]を借[か]りました。|Peguei um livro emprestado na biblioteca.
直[なお]す|consertar, corrigir|作文[さくぶん]を直[なお]してもらいました。|Pedi que corrigissem minha redação.
迎[むか]えに行[い]く|ir buscar|空港[くうこう]まで迎[むか]えに行[い]きます。|Vou buscar no aeroporto.
助[たす]かる|ser de grande ajuda|本当[ほんとう]に助[たす]かりました。|Ajudou muito.`,
        k: `
貸|タイ|か(す)|emprestar|貸[か]す=emprestar;賃貸[ちんたい]=aluguel
借|シャク|か(りる)|tomar emprestado|借[か]りる=pegar emprestado;借金[しゃっきん]=dívida`,
        g: {
          t: "～てあげる / ～てくれる / ～てもらう: favores",
          e: `Os verbos de dar e receber combinam-se com a **forma て** para indicar **favores**:
• **～てあげる**: faço um favor a alguém. 妹[いもうと]に宿題[しゅくだい]を教[おし]えてあげました。
• **～てくれる**: alguém faz um favor a mim. ケンさんが駅[えき]まで送[おく]ってくれました。
• **～てもらう**: eu recebo o favor de alguém (muitas vezes porque pedi). 先生[せんせい]に作文[さくぶん]を直[なお]してもらいました。
⚠️ ～てあげる dito diretamente a superiores pode soar arrogante; prefira ～ましょうか.
Para agradecer: **～てくれて、ありがとう**.`,
          x: `
ユイさんが傘[かさ]を貸[か]してくれました。|A Yui me emprestou um guarda-chuva.
友達[ともだち]に引[ひ]っ越[こ]しを手伝[てつだ]ってもらいました。|Um amigo me ajudou com a mudança.
弟[おとうと]に自転車[じてんしゃ]を直[なお]してあげました。|Consertei a bicicleta do meu irmão mais novo.`,
          q: [
            g("ケンさんが空港[くうこう]まで迎[むか]えに来[き]て＿＿。", ["くれました", "あげました", "もらいました", "やりました"], 0, "O Ken veio me buscar no aeroporto.", "Favor que alguém fez para mim: ～てくれる."),
            g("私[わたし]は田中[たなか]さんに資料[しりょう]をチェックして＿＿。", ["もらいました", "くれました", "あげました", "くださいました"], 0, "Pedi ao Sr. Tanaka que verificasse o material (e ele verificou).", "Eu recebo o favor de alguém: ～てもらう (quem faz é marcado com に)."),
            g("友達[ともだち]が困[こま]っていたので、ノートを貸[か]して＿＿。", ["あげました", "くれました", "もらいました", "いただきました"], 0, "Meu amigo estava em apuros, então emprestei meu caderno.", "Eu faço o favor: ～てあげる."),
            g("手伝[てつだ]って＿＿、ありがとう。本当[ほんとう]に助[たす]かったよ。", ["くれて", "あげて", "もらって", "やって"], 0, "Obrigado por me ajudar. Ajudou muito.", "Agradecer um favor: ～てくれて、ありがとう."),
            o("先生[せんせい]に/作文[さくぶん]を/直[なお]して/もらいました", "O professor corrigiu minha redação (a meu pedido).", "作文[さくぶん]を/先生[せんせい]に/直[なお]して/もらいました"),
          ],
        },
        dl: {
          t: "Dia de mudança",
          l: `
Ken|アナさん、引[ひ]っ越[こ]しお疲[つか]れさま。|Ana, bom trabalho com a mudança.
Ana|ケンさん、手伝[てつだ]ってくれて本当[ほんとう]にありがとう。すごく助[たす]かった。|Ken, muito obrigada por me ajudar. Ajudou demais.
Ken|いいよ。車[くるま]はユイさんのお父[とう]さんに貸[か]してもらったんだ。|Imagina. O carro, o pai da Yui me emprestou.
Ana|そうだったんだ。じゃ、お礼[れい]に何[なに]か送[おく]ってあげたいな。|Ah, foi isso. Então quero mandar algo para agradecer.
Ken|お父[とう]さん、お酒[さけ]が好[す]きだよ。|O pai dela gosta de bebida.
Ana|わかった。今度[こんど]、ブラジルのお酒[さけ]をプレゼントするね。|Entendi. Da próxima vez vou dar uma bebida brasileira de presente.`,
          q: [
            ["De quem era o carro usado na mudança?", ["Do Ken", "Do pai da Yui", "De uma locadora"], 1],
            ["O que Ana vai dar de presente?", ["Um doce japonês", "Uma bebida brasileira", "Flores"], 1],
          ],
        },
        w: ["Escreva sobre um favor que alguém fez para você, usando てくれました ou てもらいました.", "友達[ともだち]が日本語[にほんご]を教[おし]えてくれました。", ["favor=てくれ|でくれ|てもら|でもら"]],
      },
      {
        t: "Poderia, por favor...?",
        d: "Pedidos educados: ～ていただけませんか",
        v: `
申込書[もうしこみしょ]|formulário de inscrição|申込書[もうしこみしょ]に記入[きにゅう]してください。|Preencha o formulário de inscrição.
記入[きにゅう]する|preencher|ここに住所[じゅうしょ]を記入[きにゅう]します。|Preencho o endereço aqui.
確認[かくにん]する|confirmar, verificar|もう一度[いちど]確認[かくにん]します。|Vou verificar mais uma vez.
もう一度[いちど]|mais uma vez|もう一度[いちど]言[い]ってください。|Diga mais uma vez, por favor.
窓口[まどぐち]|guichê|二番[にばん]の窓口[まどぐち]へどうぞ。|Dirija-se ao guichê 2.
印鑑[いんかん]|carimbo pessoal (hanko)|ここに印鑑[いんかん]を押[お]してください。|Carimbe aqui com seu hanko, por favor.`,
        k: `
確|カク|たし(か)|certo, firme|確認[かくにん]=confirmação;確[たし]か=se não me engano
認|ニン|みと(める)|reconhecer|確認[かくにん]=confirmação;認[みと]める=reconhecer`,
        g: {
          t: "Pedidos educados: ～てくださいませんか / ～ていただけませんか",
          e: `Do menos ao mais educado:
• **～てください** — instrução ou pedido direto.
• **～てくれない？ / ～てくれませんか** — pedido gentil (entre amigos e colegas).
• **～てくださいませんか** — pedido educado.
• **～ていただけませんか / ～ていただけないでしょうか** — muito educado (superiores, clientes, desconhecidos).
• ゆっくり話[はな]していただけませんか。
Para suavizar o pedido: **すみませんが、～** / **お忙[いそが]しいところすみませんが、～**.`,
          x: `
すみませんが、もう一度[いちど]説明[せつめい]していただけませんか。|Desculpe, poderia explicar mais uma vez?
この書類[しょるい]を確認[かくにん]してくださいませんか。|Poderia verificar este documento?
ちょっとペンを貸[か]してくれませんか。|Você pode me emprestar uma caneta?`,
          q: [
            g("（店[みせ]の人[ひと]に）すみません、もう少[すこ]しゆっくり話[はな]して＿＿。", ["いただけませんか", "あげませんか", "もらいませんか", "くれましょうか"], 0, "(Para o atendente) Desculpe, poderia falar um pouco mais devagar?", "Pedido muito educado: ～ていただけませんか."),
            g("（友達[ともだち]に）ちょっと手伝[てつだ]って＿＿？", ["くれない", "あげない", "さしあげない", "いただきない"], 0, "(Para um amigo) Pode me ajudar um pouco?", "Entre amigos: ～てくれない?"),
            g("部長[ぶちょう]、この資料[しりょう]を見[み]て＿＿でしょうか。", ["いただけない", "くれる", "あげる", "もらう"], 0, "Gerente, será que o senhor poderia olhar este material?", "Com superiores: ～ていただけないでしょうか (muito educado)."),
            g("すみません＿＿、写真[しゃしん]を撮[と]っていただけませんか。", ["が", "を", "に", "で"], 0, "Com licença, poderia tirar uma foto (de nós)?", "すみませんが、～ suaviza o pedido."),
            o("もう一度[いちど]/説明[せつめい]して/いただけませんか", "Poderia explicar mais uma vez?"),
          ],
        },
        dl: {
          t: "No guichê da prefeitura",
          l: `
Funcionário|次[つぎ]の方[かた]、どうぞ。|Próximo, por favor.
Ana|住所[じゅうしょ]の変更[へんこう]をしたいんですが。|Eu gostaria de mudar meu endereço.
Funcionário|では、こちらの申込書[もうしこみしょ]に記入[きにゅう]していただけますか。|Então, poderia preencher este formulário?
Ana|すみません、この漢字[かんじ]が読[よ]めないんですが、教[おし]えていただけませんか。|Desculpe, não consigo ler este kanji. Poderia me dizer?
Funcionário|「世帯主[せたいぬし]」です。家族[かぞく]の代表者[だいひょうしゃ]のことですよ。|É “setainushi”. Significa o chefe da família.
Ana|あ、一人暮[ひとりぐ]らしなので、私[わたし]ですね。在留[ざいりゅう]カードも必要[ひつよう]ですか。|Ah, como moro sozinha, sou eu. Também precisa do cartão de residente?
Funcionário|はい、確認[かくにん]しますので、見[み]せていただけますか。|Sim, vou conferir, poderia me mostrar?`,
          q: [
            ["O que Ana foi fazer na prefeitura?", ["Tirar o cartão de residente", "Mudar o endereço", "Pagar impostos"], 1],
            ["O que significa 世帯主?", ["Endereço novo", "Chefe da família", "Proprietário do imóvel"], 1],
          ],
        },
        w: ["Faça um pedido muito educado a um professor usando ていただけませんか.", "先生[せんせい]、この文[ぶん]をチェックしていただけませんか。", ["ていただけ=ていただけ|でいただけ"]],
      },
      {
        t: "Keigo de respeito",
        d: "尊敬語: elevar a outra pessoa",
        v: `
いらっしゃる|estar / ir / vir (respeitoso)|社長[しゃちょう]は今[いま]、会議室[かいぎしつ]にいらっしゃいます。|O presidente está na sala de reuniões agora.
召[め]し上[あ]がる|comer / beber (respeitoso)|どうぞ召[め]し上[あ]がってください。|Por favor, sirva-se.
おっしゃる|dizer (respeitoso)|先生[せんせい]がそうおっしゃいました。|O professor disse isso.
ご覧[らん]になる|ver (respeitoso)|こちらをご覧[らん]ください。|Por favor, vejam isto.
お客様[きゃくさま]|cliente, visitante|お客様[きゃくさま]がお待[ま]ちです。|O cliente está esperando.
社長[しゃちょう]|presidente da empresa|社長[しゃちょう]は出張中[しゅっちょうちゅう]です。|O presidente está em viagem de negócios.`,
        k: `
社|シャ|やしろ|empresa; santuário|社長[しゃちょう]=presidente;会社[かいしゃ]=empresa
長|チョウ|なが(い)|longo; chefe|社長[しゃちょう]=presidente;長[なが]い=longo`,
        g: {
          t: "尊敬語 (sonkeigo): elevar a outra pessoa",
          e: `O **尊敬語** eleva as ações de quem é superior (clientes, chefes, professores).
Verbos especiais:
• いる / 行[い]く / 来[く]る → **いらっしゃる**
• 食[た]べる / 飲[の]む → **召[め]し上[あ]がる**
• 言[い]う → **おっしゃる** • 見[み]る → **ご覧[らん]になる**
• する → **なさる** • 知[し]っている → **ご存[ぞん]じだ**
Padrão geral: **お + radical + になる**: 待[ま]つ → お待[ま]ちになる.
Pedido respeitoso: **お + radical + ください**: お待[ま]ちください。
⚠️ Nunca use 尊敬語 para as suas próprias ações.`,
          x: `
田中様[たなかさま]はいらっしゃいますか。|O Sr. Tanaka se encontra?
社長[しゃちょう]は何[なに]を召[め]し上[あ]がりますか。|O que o presidente vai comer?
少々[しょうしょう]お待[ま]ちください。|Aguarde um momento, por favor.`,
          q: [
            g("先生[せんせい]は何時[なんじ]ごろ＿＿か。", ["いらっしゃいます", "参[まい]ります", "おります", "伺[うかが]います"], 0, "A que horas o professor vem?", "来る (ação do superior) → いらっしゃる."),
            g("お客様[きゃくさま]、コーヒーを＿＿か。", ["召[め]し上[あ]がります", "いただきます", "食[た]べさせます", "拝見[はいけん]します"], 0, "Senhor(a), vai tomar café?", "Comer/beber (cliente) → 召し上がる."),
            g("社長[しゃちょう]がそう＿＿んですか。", ["おっしゃった", "申[もう]した", "言[い]わせた", "伺[うかが]った"], 0, "O presidente disse isso?", "言う (superior) → おっしゃる."),
            g("こちらでお＿＿ください。", ["待[ま]ち", "待[ま]って", "待[ま]つ", "待[ま]た"], 0, "Aguarde aqui, por favor.", "Pedido respeitoso: お + radical + ください."),
            o("少々[しょうしょう]/お待[ま]ち/ください", "Aguarde um momento, por favor."),
          ],
        },
        dl: {
          t: "Visita do cliente",
          l: `
Ana|いらっしゃいませ。ABC商事[しょうじ]の佐藤様[さとうさま]でいらっしゃいますか。|Bem-vindo. O senhor é o Sr. Sato, da ABC Comercial?
Sato|はい、佐藤[さとう]です。田中[たなか]さんと二時[にじ]にお約束[やくそく]しているんですが。|Sim, sou Sato. Tenho um compromisso com o Sr. Tanaka às duas.
Ana|お待[ま]ちしておりました。こちらへどうぞ。|Estávamos esperando. Por aqui, por favor.
Ana|お飲[の]み物[もの]は何[なに]を召[め]し上[あ]がりますか。コーヒーと緑茶[りょくちゃ]がございます。|O que o senhor deseja beber? Temos café e chá verde.
Sato|じゃ、緑茶[りょくちゃ]をお願[ねが]いします。|Então, chá verde, por favor.
Ana|かしこまりました。田中[たなか]はすぐ参[まい]りますので、少々[しょうしょう]お待[ま]ちください。|Certamente. O Tanaka já vem, aguarde um momento, por favor.`,
          q: [
            ["A que horas é o compromisso do Sr. Sato?", ["Às duas", "Às três", "À uma"], 0],
            ["O que o Sr. Sato escolhe beber?", ["Café", "Chá verde", "Água"], 1],
          ],
        },
        w: ["Pergunte educadamente a um cliente o que ele vai beber, usando 召し上がる.", "お客様[きゃくさま]、何[なに]を召[め]し上[あ]がりますか。", ["召し上がる=召し上が|めしあが"]],
      },
    ],
  },
  // ───────────────────────── Capítulo 4 (B1)
  {
    t: "No escritório",
    d: "Keigo humilde e rotina de trabalho",
    icon: "🏢",
    color: "#0FA3B1",
    lessons: [
      {
        t: "Keigo humilde",
        d: "謙譲語: rebaixar-se com humildade",
        v: `
参[まい]る|ir / vir (humilde)|明日[あした]、そちらに参[まい]ります。|Amanhã irei até aí.
申[もう]す|dizer, chamar-se (humilde)|シルバと申[もう]します。|Chamo-me Silva.
伺[うかが]う|visitar; perguntar (humilde)|明日[あした]、御社[おんしゃ]に伺[うかが]います。|Amanhã visitarei sua empresa.
いただく|receber; comer (humilde)|お土産[みやげ]をいただきました。|Recebi uma lembrança.
拝見[はいけん]する|ver (humilde)|資料[しりょう]を拝見[はいけん]しました。|Vi o material.
名刺[めいし]|cartão de visita|名刺[めいし]を交換[こうかん]しました。|Trocamos cartões de visita.`,
        k: `
申|シン|もう(す)|dizer (humilde)|申[もう]す=dizer;申込[もうしこみ]=inscrição
名|メイ|な|nome|名刺[めいし]=cartão de visita;名前[なまえ]=nome`,
        g: {
          t: "謙譲語 (kenjōgo): humildade",
          e: `O **謙譲語** rebaixa as **suas** ações (ou as do seu grupo/empresa) para mostrar respeito a quem ouve.
Verbos especiais:
• 行[い]く / 来[く]る → **参[まい]る** / **伺[うかが]う** (visitar)
• 言[い]う → **申[もう]す** / **申[もう]し上[あ]げる**
• 食[た]べる / もらう → **いただく** • 見[み]る → **拝見[はいけん]する**
• いる → **おる** • する → **いたす**
Padrão geral: **お/ご + radical + する (いたす)**: 持[も]つ → お持[も]ちします, 案内[あんない] → ご案内[あんない]します.
Ao falar com clientes, refira-se ao seu chefe **sem** さん: 田中[たなか]は外出[がいしゅつ]しております。`,
          x: `
はじめまして。ブラジルから参[まい]りましたシルバと申[もう]します。|Muito prazer. Sou Silva e vim do Brasil.
お荷物[にもつ]をお持[も]ちします。|Eu carrego sua bagagem.
明日[あした]の午後[ごご]、御社[おんしゃ]に伺[うかが]います。|Amanhã à tarde visitarei sua empresa.`,
          q: [
            g("はじめまして。シルバと＿＿。", ["申[もう]します", "おっしゃいます", "言[い]われます", "申[もう]されます"], 0, "Muito prazer. Chamo-me Silva.", "Apresentar-se com humildade: ～と申します."),
            g("では、明日[あした]十時[じゅうじ]にそちらへ＿＿。", ["伺[うかが]います", "いらっしゃいます", "お越[こ]しになります", "ご覧[らん]になります"], 0, "Então, amanhã às dez irei até aí.", "Visitar (minha ação) → 伺う."),
            g("（客[きゃく]に）すみません、田中[たなか]は今[いま]、席[せき]を外[はず]して＿＿。", ["おります", "いらっしゃいます", "ございません", "なさいます"], 0, "(Para o cliente) Desculpe, o Tanaka não está na mesa no momento.", "Ação de alguém do meu grupo diante do cliente: ～ております (humilde)."),
            g("会議室[かいぎしつ]までご案内[あんない]＿＿。", ["します", "なります", "なさいます", "されます"], 0, "Vou acompanhá-lo até a sala de reuniões.", "Humilde: ご + substantivo + します."),
            o("資料[しりょう]を/拝見[はいけん]しても/よろしいですか", "Posso ver o material?"),
          ],
        },
        dl: {
          t: "Troca de cartões",
          l: `
Ana|はじめまして。グローバル社[しゃ]のシルバと申[もう]します。|Muito prazer. Sou Silva, da empresa Global.
Kimura|はじめまして。木村[きむら]と申[もう]します。よろしくお願[ねが]いいたします。|Muito prazer. Sou Kimura. Conto com sua colaboração.
Ana|頂戴[ちょうだい]いたします。…木村様[きむらさま]は営業部[えいぎょうぶ]の部長[ぶちょう]でいらっしゃるんですね。|Muito obrigada (pelo cartão). ...O senhor é o gerente do departamento de vendas, certo?
Kimura|ええ。本日[ほんじつ]は遠[とお]いところをありがとうございます。|Sim. Obrigado por vir de tão longe hoje.
Ana|いいえ。本日[ほんじつ]は新[あたら]しいサービスのご説明[せつめい]に参[まい]りました。資料[しりょう]をお持[も]ちしましたので、ご覧[らん]ください。|Imagine. Hoje vim explicar nosso novo serviço. Trouxe o material; por favor, veja.
Kimura|拝見[はいけん]します。|Vou dar uma olhada.`,
          q: [
            ["Qual é o cargo do Sr. Kimura?", ["Presidente", "Gerente de vendas", "Funcionário novo"], 1],
            ["Por que Ana foi visitar o Sr. Kimura?", ["Para assinar um contrato", "Para explicar um novo serviço", "Para entregar uma lembrança"], 1],
          ],
        },
        w: ["Apresente-se formalmente para um cliente usando 申します.", "はじめまして。ブラジル商事[しょうじ]のシルバと申[もう]します。よろしくお願[ねが]いいたします。", ["と申します=と申します|ともうします"]],
      },
      {
        t: "Deixando tudo pronto",
        d: "Preparação com ～ておく",
        v: `
準備[じゅんび]する|preparar|会議[かいぎ]の準備[じゅんび]をします。|Preparo a reunião.
予約[よやく]する|reservar|レストランを予約[よやく]しました。|Reservei o restaurante.
コピーする|fotocopiar|資料[しりょう]をコピーしました。|Fotocopiei o material.
片付[かたづ]ける|arrumar, guardar|机[つくえ]の上[うえ]を片付[かたづ]けます。|Arrumo a mesa.
並[なら]べる|enfileirar, arrumar|いすを並[なら]べてください。|Arrume as cadeiras, por favor.
出張[しゅっちょう]|viagem de negócios|来週[らいしゅう]、大阪[おおさか]に出張[しゅっちょう]します。|Semana que vem farei uma viagem de negócios a Osaka.`,
        k: `
準|ジュン|—|padrão; preparar|準備[じゅんび]=preparação;基準[きじゅん]=critério
備|ビ|そな(える)|equipar, preparar|準備[じゅんび]=preparação;備[そな]える=preparar-se`,
        g: {
          t: "～ておく: fazer algo com antecedência",
          e: `**Verbo (forma て) + おく** = fazer algo **antecipadamente**, como preparação, ou **deixar** algo em determinado estado.
• 会議[かいぎ]の前[まえ]に資料[しりょう]をコピーしておきます。 (preparação)
• 窓[まど]を開[あ]けておいてください。 (deixe aberta)
Na fala informal, contrai-se: **～ておく → ～とく**, **～でおく → ～どく**.
• 予約[よやく]しとくね。 (Vou deixar reservado.)`,
          x: `
出張[しゅっちょう]の前[まえ]に、ホテルを予約[よやく]しておきます。|Antes da viagem de negócios, vou reservar o hotel.
使[つか]った後[あと]は、片付[かたづ]けておいてください。|Depois de usar, deixe tudo arrumado.
飲[の]み物[もの]は冷蔵庫[れいぞうこ]に入[い]れとくね。|Vou deixar as bebidas na geladeira.`,
          q: [
            g("会議[かいぎ]の前[まえ]に、いすを並[なら]べて＿＿ください。", ["おいて", "いて", "あって", "しまって"], 0, "Antes da reunião, deixe as cadeiras arrumadas.", "Preparação: ～ておく → ～ておいてください."),
            g("旅行[りょこう]の前[まえ]に、ホテルを予約[よやく]して＿＿。", ["おきます", "います", "あります", "あげます"], 0, "Antes da viagem, vou reservar o hotel.", "Ação preparatória: ～ておきます."),
            g("暑[あつ]いので、窓[まど]を開[あ]けて＿＿ください。", ["おいて", "しまって", "みて", "あげて"], 0, "Está quente, então deixe a janela aberta.", "Manter um estado: ～ておいてください."),
            g("ビール、冷蔵庫[れいぞうこ]に入[い]れ＿＿ね。", ["とく", "ちゃう", "たり", "ながら"], 0, "Vou deixar a cerveja na geladeira, tá?", "Forma coloquial de ～ておく: ～とく."),
            o("お客様[きゃくさま]が/来[く]る前[まえ]に/部屋[へや]を/片付[かたづ]けておきます", "Antes de o cliente chegar, vou arrumar a sala."),
          ],
        },
        dl: {
          t: "Preparativos para a reunião",
          l: `
Tanaka|アナさん、明日[あした]の会議[かいぎ]の準備[じゅんび]はどうですか。|Ana, como está a preparação da reunião de amanhã?
Ana|資料[しりょう]は二十部[にじゅうぶ]コピーしておきました。|Já deixei 20 cópias do material prontas.
Tanaka|ありがとう。会議室[かいぎしつ]の予約[よやく]は？|Obrigado. E a reserva da sala de reuniões?
Ana|あ、まだです。今[いま]すぐ予約[よやく]しておきます。|Ah, ainda não. Vou reservar agora mesmo.
Tanaka|お願[ねが]いします。それから、プロジェクターも確認[かくにん]しておいてください。去年[きょねん]、壊[こわ]れていたので。|Por favor. E verifique também o projetor. No ano passado, ele estava quebrado.
Ana|わかりました。明日[あした]は早[はや]めに来[き]て、いすも並[なら]べておきます。|Entendido. Amanhã venho cedo e deixo as cadeiras arrumadas também.`,
          q: [
            ["Quantas cópias do material Ana fez?", ["Dez", "Vinte", "Trinta"], 1],
            ["Por que o Sr. Tanaka pede para verificar o projetor?", ["Porque é novo", "Porque estava quebrado no ano passado", "Porque o cliente pediu"], 1],
          ],
        },
        w: ["Escreva algo que você faz antes de uma viagem, usando ておきます.", "旅行[りょこう]の前[まえ]に、ホテルを予約[よやく]しておきます。", ["ておく=ておき|でおき|ておい|でおい|ておく|とく|どく"]],
      },
      {
        t: "Ops!",
        d: "Conclusão e arrependimento com ～てしまう",
        v: `
忘[わす]れる|esquecer|傘[かさ]を電車[でんしゃ]に忘[わす]れました。|Esqueci o guarda-chuva no trem.
なくす|perder (objeto)|鍵[かぎ]をなくしました。|Perdi a chave.
壊[こわ]す|quebrar (algo)|パソコンを壊[こわ]しました。|Quebrei o computador.
間違[まちが]える|errar, enganar-se|名前[なまえ]を間違[まちが]えました。|Errei o nome.
寝坊[ねぼう]する|dormir demais (perder a hora)|今朝[けさ]、寝坊[ねぼう]しました。|Hoje de manhã perdi a hora.
全部[ぜんぶ]|tudo|宿題[しゅくだい]を全部[ぜんぶ]終[お]えました。|Terminei toda a lição.`,
        k: `
忘|ボウ|わす(れる)|esquecer|忘[わす]れる=esquecer;忘年会[ぼうねんかい]=festa de fim de ano
違|イ|ちが(う)|diferir, errar|間違[まちが]える=errar;違[ちが]う=ser diferente`,
        g: {
          t: "～てしまう: conclusão total ou arrependimento",
          e: `**Verbo (forma て) + しまう** tem dois usos:
1. **Arrependimento / acidente**: 財布[さいふ]をなくしてしまいました。 (Acabei perdendo a carteira.)
2. **Conclusão total**: 宿題[しゅくだい]を全部[ぜんぶ]やってしまいました。 (Terminei toda a lição.)
Contrações na fala:
• ～てしまう → **～ちゃう** (忘[わす]れちゃった)
• ～でしまう → **～じゃう** (飲[の]んじゃった)`,
          x: `
電車[でんしゃ]に傘[かさ]を忘[わす]れてしまいました。|Acabei esquecendo o guarda-chuva no trem.
ケーキを全部[ぜんぶ]食[た]べてしまった。|Comi o bolo inteiro.
また寝坊[ねぼう]しちゃった！|Perdi a hora de novo!`,
          q: [
            g("すみません、お皿[さら]を割[わ]って＿＿。", ["しまいました", "おきました", "みました", "あげました"], 0, "Desculpe, acabei quebrando um prato.", "Acidente/arrependimento: ～てしまいました."),
            g("この本[ほん]、面白[おもしろ]くて一晩[ひとばん]で読[よ]んで＿＿。", ["しまった", "おいた", "あった", "あげた"], 0, "Este livro era tão interessante que li tudo em uma noite.", "Conclusão total: ～てしまった."),
            g("あ、ユイさんの名前[なまえ]を間違[まちが]え＿＿。", ["ちゃった", "とく", "たり", "ながら"], 0, "Ah, acabei errando o nome da Yui.", "Forma coloquial de ～てしまった: ～ちゃった."),
            g("お酒[さけ]を全部[ぜんぶ]飲[の]ん＿＿。", ["じゃった", "ちゃった", "どいた", "だり"], 0, "Acabei bebendo todo o saquê.", "飲んで + しまった → 飲んじゃった (で → じゃ)."),
            o("電車[でんしゃ]に/財布[さいふ]を/忘[わす]れて/しまいました", "Acabei esquecendo a carteira no trem.", "財布[さいふ]を/電車[でんしゃ]に/忘[わす]れて/しまいました"),
          ],
        },
        dl: {
          t: "Um dia de azar",
          l: `
Ken|アナさん、どうしたの？元気[げんき]ないね。|Ana, o que houve? Você parece desanimada.
Ana|今日[きょう]は最悪[さいあく]なの。まず寝坊[ねぼう]しちゃって、会議[かいぎ]に遅[おく]れてしまったんだ。|Hoje foi péssimo. Primeiro, perdi a hora e acabei chegando atrasada à reunião.
Ken|それは大変[たいへん]だったね。|Que situação.
Ana|それに、急[いそ]いでいたから、電車[でんしゃ]に傘[かさ]を忘[わす]れちゃった。|Além disso, como estava com pressa, esqueci o guarda-chuva no trem.
Ken|駅[えき]の忘[わす]れ物[もの]センターに連絡[れんらく]してみた？|Você tentou contatar o setor de achados e perdidos da estação?
Ana|うん、さっき電話[でんわ]したら、見[み]つかったって！|Sim, liguei agora há pouco e disseram que encontraram!
Ken|よかったね！|Que bom!`,
          q: [
            ["Por que Ana chegou atrasada à reunião?", ["O trem atrasou", "Ela perdeu a hora", "Esqueceu o guarda-chuva"], 1],
            ["O que aconteceu com o guarda-chuva?", ["Foi encontrado", "Foi perdido para sempre", "Quebrou"], 0],
          ],
        },
        w: ["Conte algo que você acabou fazendo sem querer, usando てしまいました ou ちゃった.", "昨日[きのう]、スマホを家[いえ]に忘[わす]れてしまいました。", ["てしまう=てしま|でしま|ちゃっ|じゃっ|ちゃう|じゃう"]],
      },
    ],
  },
];
