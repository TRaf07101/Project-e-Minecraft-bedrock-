import { g, o, type RawUnit } from "../dsl";

export const B1_PART2: RawUnit[] = [
  // ───────────────────────── Capítulo 5 (B1)
  {
    t: "Sociedade e ambiente",
    d: "Voz passiva, causativa e finalidade",
    icon: "🌱",
    color: "#2EAD5B",
    lessons: [
      {
        t: "Foi construído...",
        d: "A voz passiva (受身形)",
        v: `
環境[かんきょう]|meio ambiente|環境[かんきょう]を守[まも]りましょう。|Vamos proteger o meio ambiente.
ごみ|lixo|ごみを分別[ぶんべつ]します。|Separo o lixo.
捨[す]てる|jogar fora|ごみをここに捨[す]てないでください。|Não jogue lixo aqui.
建[た]てる|construir|新[あたら]しい駅[えき]が建[た]てられました。|Uma nova estação foi construída.
発明[はつめい]する|inventar|電話[でんわ]はベルによって発明[はつめい]されました。|O telefone foi inventado por Bell.
世界中[せかいじゅう]|no mundo todo|この歌[うた]は世界中[せかいじゅう]で歌[うた]われています。|Esta canção é cantada no mundo todo.`,
        k: `
環|カン|わ|anel, ao redor|環境[かんきょう]=meio ambiente;循環[じゅんかん]=circulação
境|キョウ|さかい|fronteira|環境[かんきょう]=meio ambiente;国境[こっきょう]=fronteira nacional`,
        g: {
          t: "Voz passiva (受身形)",
          e: `**Formação**:
• Verbos -u: som final → **-a + れる**: 書[か]く → 書[か]かれる, 言[い]う → 言[い]われる
• Verbos -ru: る → **られる**: 見[み]る → 見[み]られる
• する → **される** / 来[く]る → **来[こ]られる**
**Usos**:
1. Fatos gerais e impessoais: この寺[てら]は八百年前[はっぴゃくねんまえ]に建[た]て**られ**ました。
2. Agente marcado com **に** (ou **によって** para criações e obras): 電話[でんわ]はベル**によって**発明[はつめい]**され**ました。
3. **Passiva de incômodo**: o sujeito sofre algo. 雨[あめ]に降[ふ]られました。 (Fui pego pela chuva.)`,
          x: `
このお寺[てら]は八百年前[はっぴゃくねんまえ]に建[た]てられました。|Este templo foi construído há 800 anos.
日本[にほん]のアニメは世界中[せかいじゅう]で見[み]られています。|Os animes japoneses são assistidos no mundo todo.
電車[でんしゃ]の中[なか]で足[あし]を踏[ふ]まれました。|Pisaram no meu pé no trem.`,
          q: [
            g("この小説[しょうせつ]は多[おお]くの人[ひと]に＿＿います。", ["読[よ]まれて", "読[よ]ませて", "読[よ]めて", "読[よ]んで"], 0, "Este romance é lido por muitas pessoas.", "Passiva de 読む: 読まれる."),
            g("『源氏物語[げんじものがたり]』は紫式部[むらさきしきぶ]＿＿書[か]かれました。", ["によって", "にとって", "について", "によると"], 0, "“O Conto de Genji” foi escrito por Murasaki Shikibu.", "Autor de uma obra: ～によって + passiva."),
            g("先生[せんせい]に＿＿、とてもうれしかったです。", ["褒[ほ]められて", "褒[ほ]めて", "褒[ほ]めさせて", "褒[ほ]められって"], 0, "Fui elogiada pelo professor e fiquei muito feliz.", "褒める (-ru) → 褒められる."),
            g("帰[かえ]る途中[とちゅう]で雨[あめ]に＿＿。", ["降[ふ]られました", "降[ふ]りました", "降[ふ]らせました", "降[ふ]れました"], 0, "No caminho de volta, fui pega pela chuva.", "Passiva de incômodo: 雨に降られる."),
            o("この橋[はし]は/百年前[ひゃくねんまえ]に/作[つく]られました", "Esta ponte foi construída há cem anos."),
          ],
        },
        dl: {
          t: "Regras do lixo",
          l: `
Vizinha|すみません、このごみ、あなたのですか。|Com licença, este lixo é seu?
Ana|あ、はい…。何[なに]か問題[もんだい]がありましたか。|Ah, sim... Houve algum problema?
Vizinha|今日[きょう]はペットボトルの日[ひ]じゃないんですよ。ペットボトルは水曜日[すいようび]に出[だ]すことになっています。|Hoje não é dia de garrafas PET. Elas devem ser colocadas na quarta-feira.
Ana|すみません、知[し]りませんでした。ブラジルではこんなに細[こま]かく分[わ]けられていないので…。|Desculpe, eu não sabia. No Brasil, o lixo não é separado de forma tão detalhada...
Vizinha|そうなんですね。このカレンダーを見[み]れば、わかりますよ。英語[えいご]でも書[か]かれていますから。|Entendo. Olhando este calendário, você entende. Está escrito em inglês também.
Ana|ご親切[しんせつ]にありがとうございます。|Muito obrigada pela gentileza.`,
          q: [
            ["Em que dia devem ser colocadas as garrafas PET?", ["Segunda-feira", "Quarta-feira", "Sexta-feira"], 1],
            ["O que a vizinha recomenda?", ["Perguntar na prefeitura", "Olhar o calendário de coleta", "Jogar tudo junto"], 1],
          ],
        },
        w: ["Escreva um fato sobre o Brasil usando a voz passiva.", "ブラジルではポルトガル語[ご]が話[はな]されています。", ["passiva=れて|れま|れる|られ|され"]],
      },
      {
        t: "Fazer alguém fazer",
        d: "A forma causativa (使役形)",
        v: `
部下[ぶか]|subordinado|部下[ぶか]に仕事[しごと]を頼[たの]みました。|Pedi um trabalho ao subordinado.
習[なら]い事[ごと]|atividade extracurricular|子供[こども]の習[なら]い事[ごと]はピアノです。|A atividade extra do meu filho é piano.
塾[じゅく]|cursinho|息子[むすこ]は塾[じゅく]に通[かよ]っています。|Meu filho frequenta o cursinho.
許[ゆる]す|permitir; perdoar|親[おや]が留学[りゅうがく]を許[ゆる]してくれました。|Meus pais permitiram o intercâmbio.
親[おや]|pais|親[おや]と一緒[いっしょ]に住[す]んでいます。|Moro com meus pais.
笑[わら]う|rir|みんなで笑[わら]いました。|Rimos todos juntos.`,
        k: `
親|シン|おや、した(しい)|pais; íntimo|親[おや]=pais;両親[りょうしん]=os pais
笑|ショウ|わら(う)|rir|笑[わら]う=rir;笑顔[えがお]=sorriso`,
        g: {
          t: "Forma causativa: fazer / deixar alguém fazer",
          e: `**Formação**:
• Verbos -u: som final → **-a + せる**: 行[い]く → 行[い]かせる, 飲[の]む → 飲[の]ませる
• Verbos -ru: る → **させる**: 食[た]べる → 食[た]べさせる
• する → **させる** / 来[く]る → **来[こ]させる**
**Significados**:
• **Obrigar**: 母[はは]は子供[こども]に野菜[やさい]を食[た]べさせます。
• **Permitir**: 父[ちち]は私[わたし]を留学[りゅうがく]させてくれました。
• **Provocar emoção**: 冗談[じょうだん]でみんなを笑[わら]わせた。
Para pedir permissão educadamente: **～させてください** (Deixe-me...): 私[わたし]にやらせてください。`,
          x: `
部長[ぶちょう]は部下[ぶか]に資料[しりょう]をコピーさせました。|O gerente mandou o subordinado fotocopiar o material.
両親[りょうしん]は私[わたし]を日本[にほん]に留学[りゅうがく]させてくれました。|Meus pais me deixaram fazer intercâmbio no Japão.
少[すこ]し考[かんが]えさせてください。|Deixe-me pensar um pouco.`,
          q: [
            g("母[はは]は弟[おとうと]に部屋[へや]を掃除[そうじ]＿＿。", ["させました", "されました", "しました", "させられました"], 0, "Minha mãe fez meu irmão limpar o quarto.", "Causativa de する: させる."),
            g("先生[せんせい]は学生[がくせい]に本[ほん]を＿＿。", ["読[よ]ませました", "読[よ]まれました", "読[よ]めました", "読[よ]みさせました"], 0, "O professor fez os alunos lerem o livro.", "読む → 読ませる."),
            g("その仕事[しごと]、ぜひ私[わたし]に＿＿ください。", ["やらせて", "やられて", "やって", "やらさせて"], 0, "Por favor, deixe esse trabalho comigo.", "Pedir para fazer algo: ～させてください (やる → やらせる)."),
            g("彼[かれ]はいつも面白[おもしろ]い話[はなし]でみんなを＿＿。", ["笑[わら]わせます", "笑[わら]います", "笑[わら]われます", "笑[わら]えます"], 0, "Ele sempre faz todos rirem com histórias engraçadas.", "Provocar emoção: 笑う → 笑わせる."),
            o("父[ちち]は/私[わたし]を/一人[ひとり]で/旅行[りょこう]させてくれました", "Meu pai me deixou viajar sozinha."),
          ],
        },
        dl: {
          t: "Infância",
          l: `
Yui|アナさんは子供[こども]のころ、習[なら]い事[ごと]をしていた？|Ana, você fazia alguma atividade extra quando criança?
Ana|うん、母[はは]が私[わたし]にピアノを習[なら]わせたの。でも、本当[ほんとう]はサッカーがしたかった。|Sim, minha mãe me fez aprender piano. Mas, na verdade, eu queria jogar futebol.
Yui|そうなんだ。私[わたし]の親[おや]は厳[きび]しくて、毎日[まいにち]私[わたし]を塾[じゅく]に通[かよ]わせたんだ。|Entendi. Meus pais eram rigorosos e me faziam ir ao cursinho todos os dias.
Ana|大変[たいへん]だったね。遊[あそ]ぶ時間[じかん]はあった？|Deve ter sido difícil. Você tinha tempo para brincar?
Yui|週末[しゅうまつ]だけ、好[す]きなことをさせてくれたよ。|Só nos fins de semana eles me deixavam fazer o que eu gostava.
Ana|将来[しょうらい]、自分[じぶん]の子供[こども]には好[す]きなことをさせたいな。|No futuro, quero deixar meus filhos fazerem o que gostam.`,
          q: [
            ["O que a mãe de Ana a fez aprender?", ["Futebol", "Piano", "Inglês"], 1],
            ["Quando os pais da Yui a deixavam fazer o que gostava?", ["Todos os dias", "Só nos fins de semana", "Nas férias"], 1],
          ],
        },
        w: ["Escreva o que seus pais faziam você fazer (ou deixavam você fazer) quando criança, usando a forma causativa.", "子供[こども]のころ、母[はは]は私[わたし]に毎日[まいにち]野菜[やさい]を食[た]べさせました。", ["causativa=せた|せま|せる|させ|せて"]],
      },
      {
        t: "Para quê?",
        d: "Finalidade com ～ために e ～ように",
        v: `
目的[もくてき]|objetivo|旅行[りょこう]の目的[もくてき]は何[なん]ですか。|Qual é o objetivo da viagem?
節約[せつやく]する|economizar|電気[でんき]を節約[せつやく]しています。|Economizo energia elétrica.
守[まも]る|proteger; cumprir|約束[やくそく]を守[まも]ります。|Cumpro as promessas.
減[へ]らす|reduzir|ごみを減[へ]らしましょう。|Vamos reduzir o lixo.
リサイクル|reciclagem|缶[かん]をリサイクルします。|Reciclo latas.
地球[ちきゅう]|planeta Terra|地球[ちきゅう]を守[まも]りたいです。|Quero proteger a Terra.`,
        k: `
的|テキ|まと|alvo; -ico|目的[もくてき]=objetivo;具体的[ぐたいてき]=concreto
守|シュ|まも(る)|proteger|守[まも]る=proteger;留守[るす]=ausência de casa`,
        g: {
          t: "～ために e ～ように: finalidade",
          e: `**～ために** (para / a fim de): o sujeito controla a ação; usa-se com verbos **volitivos**.
• 日本[にほん]で働[はたら]く**ために**、日本語[にほんご]を勉強[べんきょう]しています。
• Com substantivo: 健康[けんこう]**の**ために
**～ように** (para que): usado com verbos **não volitivos** (potencial, なる, わかる, 見える...) ou na forma negativa.
• 後[うし]ろの人[ひと]にも見[み]える**ように**、大[おお]きく書[か]きます。
• 風邪[かぜ]をひかない**ように**、マスクをします。`,
          x: `
地球[ちきゅう]を守[まも]るために、ごみを減[へ]らしましょう。|Para proteger a Terra, vamos reduzir o lixo.
忘[わす]れないように、メモしておきます。|Vou anotar para não esquecer.
日本語[にほんご]が話[はな]せるように、毎日[まいにち]練習[れんしゅう]しています。|Pratico todos os dias para conseguir falar japonês.`,
          q: [
            g("家[いえ]を買[か]う＿＿、貯金[ちょきん]しています。", ["ために", "ように", "のに", "ので"], 0, "Estou economizando para comprar uma casa.", "Verbo volitivo (comprar) + ために."),
            g("遅[おく]れない＿＿、早[はや]く家[いえ]を出[で]ました。", ["ように", "ために", "のに", "まで"], 0, "Saí de casa cedo para não me atrasar.", "Negativo (não volitivo): ～ないように."),
            g("漢字[かんじ]が読[よ]める＿＿、毎日[まいにち]練習[れんしゅう]します。", ["ように", "ために", "から", "のは"], 0, "Pratico todos os dias para conseguir ler kanji.", "Forma potencial + ように."),
            g("健康[けんこう]＿＿ために、毎朝[まいあさ]走[はし]っています。", ["の", "な", "に", "を"], 0, "Corro toda manhã pela saúde.", "Substantivo + の + ために."),
            o("環境[かんきょう]を/守[まも]るために/リサイクルを/しています", "Faço reciclagem para proteger o meio ambiente."),
          ],
        },
        dl: {
          t: "Pequenas ações",
          l: `
Ken|アナさん、いつもマイバッグを持[も]っているね。|Ana, você sempre carrega sua própria sacola, né.
Ana|うん、プラスチックごみを減[へ]らすために、レジ袋[ぶくろ]はもらわないの。|Sim, para reduzir o lixo plástico, não pego sacolas no caixa.
Ken|えらいなあ。僕[ぼく]も何[なに]かしなきゃ。|Que admirável. Eu também preciso fazer alguma coisa.
Ana|簡単[かんたん]なことからでいいよ。例[たと]えば、電気[でんき]を節約[せつやく]するために、使[つか]わない部屋[へや]の電気[でんき]を消[け]すとか。|Pode começar por coisas simples. Por exemplo, para economizar energia, apagar a luz dos cômodos que não está usando.
Ken|それならできそう。忘[わす]れないように、スイッチにメモを貼[は]っておくよ。|Isso eu consigo. Para não esquecer, vou colar um bilhete no interruptor.`,
          q: [
            ["Por que Ana carrega sua própria sacola?", ["Para reduzir o lixo plástico", "Porque é mais bonita", "Porque a loja cobra caro"], 0],
            ["O que Ken vai fazer para não esquecer?", ["Programar o celular", "Colar um bilhete no interruptor", "Pedir ajuda a Ana"], 1],
          ],
        },
        w: ["Escreva algo que você faz pelo meio ambiente ou pela saúde, usando ために ou ように.", "健康[けんこう]のために、毎日[まいにち]歩[ある]いています。", ["finalidade=ために|ように"]],
      },
    ],
  },
  // ───────────────────────── Capítulo 6 (B1)
  {
    t: "Mudanças e decisões",
    d: "Mudanças, decisões e hábitos",
    icon: "🔄",
    color: "#F2994A",
    lessons: [
      {
        t: "Passei a conseguir",
        d: "Mudanças com ～ようになる",
        v: `
最近[さいきん]|ultimamente|最近[さいきん]、忙[いそが]しいです。|Ultimamente estou ocupada.
慣[な]れる|acostumar-se|日本[にほん]の生活[せいかつ]に慣[な]れました。|Acostumei-me à vida no Japão.
生活[せいかつ]|vida, cotidiano|東京[とうきょう]の生活[せいかつ]は便利[べんり]です。|A vida em Tóquio é prática.
だんだん|gradualmente|だんだん寒[さむ]くなってきました。|Está ficando cada vez mais frio.
苦手[にがて]|ter dificuldade com; não gostar|納豆[なっとう]が苦手[にがて]です。|Não gosto de natto.
箸[はし]|hashi (pauzinhos)|箸[はし]で食[た]べます。|Como com hashi.`,
        k: `
慣|カン|な(れる)|acostumar|慣[な]れる=acostumar-se;習慣[しゅうかん]=hábito
活|カツ|—|vida, atividade|生活[せいかつ]=vida;活動[かつどう]=atividade`,
        g: {
          t: "～ようになる: mudança de capacidade ou hábito",
          e: `**Verbo (dicionário / potencial) + ようになる** = “passar a (conseguir) fazer”. Indica uma mudança gradual.
• 箸[はし]が使[つか]える**ようになりました**。 (Passei a conseguir usar hashi.)
• 毎朝[まいあさ]、野菜[やさい]ジュースを飲[の]む**ようになりました**。 (Passei a tomar...)
Negativo: **～なくなる** = deixar de...
• 忙[いそが]しくて、本[ほん]を読[よ]ま**なくなりました**。
**～てくる** indica uma mudança que vem acontecendo até agora: 慣[な]れてきました.
Compare com **adjetivo + なる**: 寒[さむ]く**なる** (ficar frio), 上手[じょうず]**に**なる (ficar bom).`,
          x: `
日本[にほん]に来[き]て、納豆[なっとう]が食[た]べられるようになりました。|Depois de vir ao Japão, passei a conseguir comer natto.
最近[さいきん]、子供[こども]は外[そと]で遊[あそ]ばなくなりました。|Ultimamente, as crianças deixaram de brincar na rua.
練習[れんしゅう]して、漢字[かんじ]が書[か]けるようになりました。|Pratiquei e passei a conseguir escrever kanji.`,
          q: [
            g("毎日[まいにち]練習[れんしゅう]して、日本語[にほんご]で電話[でんわ]が＿＿ようになりました。", ["できる", "できて", "できた", "できない"], 0, "Pratiquei todos os dias e passei a conseguir falar ao telefone em japonês.", "Potencial na forma de dicionário + ようになる."),
            g("引[ひ]っ越[こ]してから、自転車[じてんしゃ]で会社[かいしゃ]に＿＿ようになりました。", ["行[い]く", "行[い]って", "行[い]った", "行[い]こう"], 0, "Depois da mudança, passei a ir à empresa de bicicleta.", "Mudança de hábito: forma de dicionário + ようになる."),
            g("スマホを買[か]ってから、本[ほん]を＿＿なりました。", ["読[よ]まなく", "読[よ]まない", "読[よ]めない", "読[よ]まず"], 0, "Depois de comprar o smartphone, deixei de ler livros.", "Deixar de: ～なくなる."),
            g("日本[にほん]の生活[せいかつ]にだいぶ＿＿きました。", ["慣[な]れて", "慣[な]れる", "慣[な]れた", "慣[な]れ"], 0, "Fui me acostumando bastante à vida no Japão.", "～てくる indica mudança gradual até agora: 慣れてきました."),
            o("やっと/箸[はし]が/使[つか]えるように/なりました", "Finalmente passei a conseguir usar hashi."),
          ],
        },
        dl: {
          t: "Um ano depois",
          l: `
Tanaka|アナさん、日本[にほん]に来[き]て一年[いちねん]ですね。何[なに]か変[か]わりましたか。|Ana, já faz um ano que você veio ao Japão. Algo mudou?
Ana|はい、色々[いろいろ]変[か]わりました。前[まえ]は漢字[かんじ]が全然[ぜんぜん]読[よ]めませんでしたが、今[いま]は新聞[しんぶん]も少[すこ]し読[よ]めるようになりました。|Sim, muita coisa. Antes eu não conseguia ler nada de kanji, mas agora consigo ler um pouco até o jornal.
Tanaka|すごいですね。食[た]べ物[もの]はどうですか。|Incrível. E a comida?
Ana|最初[さいしょ]は納豆[なっとう]が苦手[にがて]でしたが、毎朝[まいあさ]食[た]べるようになりました。|No começo eu não gostava de natto, mas passei a comer todas as manhãs.
Tanaka|それは日本人[にほんじん]より日本人[にほんじん]らしいですね。|Assim você está mais japonesa que os japoneses.
Ana|でも、ブラジルのコーヒーは、やめられません。|Mas o café brasileiro eu não consigo largar.`,
          q: [
            ["O que Ana consegue fazer agora com kanji?", ["Ler um pouco o jornal", "Escrever cartas", "Nada ainda"], 0],
            ["O que mudou na relação de Ana com o natto?", ["Ela parou de comer", "Passou a comer todas as manhãs", "Nunca experimentou"], 1],
          ],
        },
        w: ["Escreva uma mudança na sua vida usando ようになりました ou なくなりました.", "日本語[にほんご]を勉強[べんきょう]して、ひらがなが読[よ]めるようになりました。", ["mudança=ようになり|ようになっ|なくなり|なくなっ"]],
      },
      {
        t: "Decidi que...",
        d: "～ことにする e ～ことになる",
        v: `
転職[てんしょく]する|mudar de emprego|来年[らいねん]、転職[てんしょく]します。|No ano que vem vou mudar de emprego.
決心[けっしん]する|decidir-se, resolver|留学[りゅうがく]を決心[けっしん]しました。|Resolvi fazer intercâmbio.
転勤[てんきん]|transferência (de trabalho)|父[ちち]は転勤[てんきん]が多[おお]いです。|Meu pai é transferido com frequência.
支社[ししゃ]|filial|大阪支社[おおさかししゃ]で働[はたら]きます。|Vou trabalhar na filial de Osaka.
禁煙[きんえん]|proibido fumar; parar de fumar|店内[てんない]は禁煙[きんえん]です。|É proibido fumar dentro do estabelecimento.
ダイエット|dieta|ダイエットを始[はじ]めました。|Comecei uma dieta.`,
        k: `
決|ケツ|き(める)|decidir|決[き]める=decidir;決心[けっしん]=resolução
転|テン|ころ(ぶ)|rolar; mudar|転職[てんしょく]=mudança de emprego;自転車[じてんしゃ]=bicicleta`,
        g: {
          t: "～ことにする e ～ことになる: decisões",
          e: `**Verbo (dicionário / ない) + ことにする** = **eu decido** fazer (decisão pessoal).
• 来年[らいねん]、日本[にほん]で転職[てんしょく]することにしました。
**～ことにしている** = regra pessoal, hábito decidido.
• 毎朝[まいあさ]三十分[さんじゅっぷん]歩[ある]くことにしています。
**Verbo + ことになる** = **foi decidido** (por outros ou pelas circunstâncias).
• 四月[しがつ]から大阪[おおさか]に転勤[てんきん]することになりました。
**～ことになっている** = regra, norma estabelecida.
• この部屋[へや]では靴[くつ]を脱[ぬ]ぐことになっています。`,
          x: `
健康[けんこう]のために、たばこをやめることにしました。|Pela saúde, decidi parar de fumar.
来月[らいげつ]から福岡支社[ふくおかししゃ]で働[はたら]くことになりました。|Ficou decidido que vou trabalhar na filial de Fukuoka a partir do mês que vem.
寝[ね]る前[まえ]はスマホを見[み]ないことにしています。|Tenho como regra não olhar o celular antes de dormir.`,
          q: [
            g("色々[いろいろ]考[かんが]えて、会社[かいしゃ]をやめる＿＿。", ["ことにしました", "ことになりました", "ようになりました", "ことがあります"], 0, "Depois de pensar bastante, decidi largar a empresa.", "Decisão própria: ～ことにする."),
            g("会社[かいしゃ]の命令[めいれい]で、来年[らいねん]アメリカに転勤[てんきん]する＿＿。", ["ことになりました", "ことにしました", "ようにしました", "つもりでした"], 0, "Por ordem da empresa, ficou decidido que serei transferido para os EUA no ano que vem.", "Decisão externa: ～ことになる."),
            g("この寮[りょう]では、夜[よる]十時[じゅうじ]以降[いこう]は静[しず]かにする＿＿。", ["ことになっています", "ことにしました", "ようになりました", "ことがあります"], 0, "Neste dormitório, a regra é fazer silêncio após as dez da noite.", "Regra estabelecida: ～ことになっている."),
            g("ダイエットのため、甘[あま]い物[もの]は食[た]べない＿＿しています。", ["ことに", "ことが", "ことを", "ことで"], 0, "Por causa da dieta, tenho como regra não comer doces.", "Regra pessoal: ～ないことにしている."),
            o("来月[らいげつ]から/大阪[おおさか]で/働[はたら]くことに/なりました", "Ficou decidido que vou trabalhar em Osaka a partir do mês que vem.", "大阪[おおさか]で/来月[らいげつ]から/働[はたら]くことに/なりました"),
          ],
        },
        dl: {
          t: "Grande decisão",
          l: `
Ken|アナさん、話[はなし]って何[なに]？|Ana, o que você queria me contar?
Ana|実[じつ]は、転職[てんしょく]することにしたの。|Na verdade, decidi mudar de emprego.
Ken|えっ、どうして？今[いま]の会社[かいしゃ]、好[す]きだったでしょ？|O quê? Por quê? Você gostava da empresa atual, né?
Ana|うん。でも、通訳[つうやく]の仕事[しごと]がしたくて、ずっと考[かんが]えていたんだ。翻訳会社[ほんやくがいしゃ]に入[はい]ることになったよ。|Sim. Mas eu queria trabalhar como intérprete e vinha pensando nisso há tempo. Fui contratada por uma empresa de tradução.
Ken|おめでとう！いつから？|Parabéns! A partir de quando?
Ana|来月[らいげつ]から。最初[さいしょ]の三[さん]か月[げつ]は研修[けんしゅう]を受[う]けることになっているの。|A partir do mês que vem. Nos primeiros três meses, está previsto que eu faça um treinamento.`,
          q: [
            ["Por que Ana decidiu mudar de emprego?", ["Ganhava pouco", "Queria trabalhar como intérprete", "Brigou com o chefe"], 1],
            ["O que Ana fará nos primeiros três meses?", ["Treinamento", "Viagem ao Brasil", "Trabalho remoto"], 0],
          ],
        },
        w: ["Escreva uma decisão que você tomou recentemente, usando ことにしました.", "毎日[まいにち]三十分[さんじゅっぷん]日本語[にほんご]を勉強[べんきょう]することにしました。", ["ことにした=ことにしました|ことにした|ことにしています|ことにしている"]],
      },
      {
        t: "Procuro sempre...",
        d: "Esforço com ～ようにする",
        v: `
なるべく|o máximo possível|なるべく早[はや]く来[き]てください。|Venha o mais cedo possível.
階段[かいだん]|escada|階段[かいだん]を使[つか]います。|Uso a escada.
甘[あま]い物[もの]|doces|甘[あま]い物[もの]が大好[だいす]きです。|Adoro doces.
夜更[よふ]かし|ficar acordado até tarde|夜更[よふ]かしは体[からだ]に悪[わる]いです。|Ficar acordado até tarde faz mal à saúde.
習慣[しゅうかん]|hábito|いい習慣[しゅうかん]を作[つく]りましょう。|Vamos criar bons hábitos.
エレベーター|elevador|エレベーターに乗[の]ります。|Pego o elevador.`,
        k: `
階|カイ|—|andar, degrau|階段[かいだん]=escada;二階[にかい]=segundo andar
段|ダン|—|degrau|階段[かいだん]=escada;値段[ねだん]=preço`,
        g: {
          t: "～ようにする: esforçar-se para (não) fazer",
          e: `**Verbo (dicionário / ない) + ようにする** = procurar fazer, esforçar-se para que algo aconteça.
• なるべく階段[かいだん]を使[つか]う**ようにしています**。 (hábito em andamento)
• 夜更[よふ]かしをしない**ようにします**。 (vou me esforçar)
Pedidos: **～ようにしてください** = por favor, procure...
• 遅刻[ちこく]しないようにしてください。
Compare:
• ～ことにする: decisão clara (decidi parar).
• ～ようにする: esforço contínuo (procuro não...).
• ～ようになる: mudança que aconteceu (passei a...).`,
          x: `
健康[けんこう]のために、なるべく階段[かいだん]を使[つか]うようにしています。|Pela saúde, procuro usar a escada sempre que possível.
甘[あま]い物[もの]を食[た]べすぎないようにしています。|Procuro não comer doces demais.
明日[あした]は遅[おく]れないようにしてください。|Amanhã, procure não se atrasar.`,
          q: [
            g("毎日[まいにち]、野菜[やさい]を食[た]べる＿＿しています。", ["ように", "ために", "そうに", "らしく"], 0, "Procuro comer verduras todos os dias.", "Esforço habitual: ～ようにしている."),
            g("夜更[よふ]かししない＿＿してください。", ["ように", "ために", "ほうに", "のに"], 0, "Procure não ficar acordado até tarde.", "Pedido: ～ないようにしてください."),
            g("なるべく日本語[にほんご]で話[はな]すように＿＿。", ["しています", "なっています", "あります", "できます"], 0, "Procuro falar em japonês o máximo possível.", "～ようにしている (esforço) ≠ ～ようになる (mudança)."),
            g("忘[わす]れ物[もの]を＿＿ようにしてください。", ["しない", "しなく", "しなかった", "しないで"], 0, "Procure não esquecer nada.", "Forma ない + ようにする."),
            o("なるべく/エレベーターを/使[つか]わないように/しています", "Procuro não usar o elevador sempre que possível.", "エレベーターを/なるべく/使[つか]わないように/しています"),
          ],
        },
        dl: {
          t: "Hábitos saudáveis",
          l: `
Médico|シルバさん、検査[けんさ]の結果[けっか]、少[すこ]し血圧[けつあつ]が高[たか]いですね。|Sra. Silva, pelos resultados dos exames, sua pressão está um pouco alta.
Ana|そうですか…。最近[さいきん]、仕事[しごと]が忙[いそが]しくて、夜更[よふ]かしが多[おお]いんです。|É mesmo... Ultimamente o trabalho anda puxado e fico acordada até tarde com frequência.
Médico|なるべく十二時[じゅうにじ]前[まえ]に寝[ね]るようにしてください。それから、塩分[えんぶん]を取[と]りすぎないようにしましょう。|Procure dormir antes da meia-noite. E vamos procurar não consumir sal em excesso.
Ana|運動[うんどう]もしたほうがいいですか。|Também é melhor fazer exercício?
Médico|ええ。エレベーターではなく、階段[かいだん]を使[つか]うようにするだけでも違[ちが]いますよ。|Sim. Só procurar usar a escada em vez do elevador já faz diferença.
Ana|わかりました。今日[きょう]から気[き]をつけるようにします。|Entendi. A partir de hoje vou me cuidar.`,
          q: [
            ["Qual é o problema de saúde de Ana?", ["Pressão um pouco alta", "Febre", "Dor nas costas"], 0],
            ["O que o médico recomenda sobre o sono?", ["Dormir oito horas", "Dormir antes da meia-noite", "Tirar sonecas"], 1],
          ],
        },
        w: ["Escreva um bom hábito que você procura manter, usando ようにしています.", "毎日[まいにち]、水[みず]をたくさん飲[の]むようにしています。", ["ようにする=ようにしてい|ようにする|ようにします"]],
      },
    ],
  },
  // ───────────────────────── Capítulo 7 (B1)
  {
    t: "Cultura e tradições",
    d: "Variação, expectativa e dever",
    icon: "🏮",
    color: "#D7263D",
    lessons: [
      {
        t: "Depende da região",
        d: "～によって e ～について",
        v: `
文化[ぶんか]|cultura|日本[にほん]の文化[ぶんか]に興味[きょうみ]があります。|Tenho interesse pela cultura japonesa.
伝統[でんとう]|tradição|伝統[でんとう]を大切[たいせつ]にします。|Valorizamos as tradições.
地域[ちいき]|região|地域[ちいき]によって方言[ほうげん]が違[ちが]います。|Os dialetos variam conforme a região.
方言[ほうげん]|dialeto|大阪[おおさか]の方言[ほうげん]は面白[おもしろ]いです。|O dialeto de Osaka é interessante.
祭[まつ]り|festival|夏[なつ]には祭[まつ]りがあります。|No verão há festivais.
興味[きょうみ]|interesse|歴史[れきし]に興味[きょうみ]があります。|Tenho interesse em história.`,
        k: `
化|カ|ば(ける)|transformar|文化[ぶんか]=cultura;変化[へんか]=mudança
祭|サイ|まつ(り)|festival|祭[まつ]り=festival;文化祭[ぶんかさい]=festival cultural`,
        g: {
          t: "～によって e ～について",
          e: `**～によって** tem vários usos:
• **Varia conforme**: 地域[ちいき]**によって**、お雑煮[ぞうに]の味[あじ]が違[ちが]います。
• **Por (agente da passiva)**: この絵[え]はピカソ**によって**描[か]かれた。
• **Por causa de**: 台風[たいふう]**によって**、電車[でんしゃ]が止[と]まった。
Antes de substantivo: **～による**: 地震[じしん]による被害[ひがい].
**～について** = sobre, a respeito de.
• 日本[にほん]の祭[まつ]り**について**調[しら]べています。
Antes de substantivo: **～についての**: 文化[ぶんか]についての本[ほん].`,
          x: `
国[くに]によって、文化[ぶんか]や習慣[しゅうかん]が違[ちが]います。|A cultura e os costumes variam conforme o país.
日本[にほん]の伝統[でんとう]について、レポートを書[か]きました。|Escrevi um relatório sobre as tradições japonesas.
大雨[おおあめ]によって、祭[まつ]りは中止[ちゅうし]になりました。|Por causa da chuva forte, o festival foi cancelado.`,
          q: [
            g("人[ひと]＿＿、考[かんが]え方[かた]が違[ちが]います。", ["によって", "について", "にとって", "によると"], 0, "O modo de pensar varia de pessoa para pessoa.", "Variação: ～によって違う."),
            g("日本[にほん]の歴史[れきし]＿＿発表[はっぴょう]します。", ["について", "によって", "にとって", "として"], 0, "Vou fazer uma apresentação sobre a história do Japão.", "Assunto: ～について."),
            g("これは環境問題[かんきょうもんだい]＿＿本[ほん]です。", ["についての", "についた", "によっての", "にとっての"], 0, "Este é um livro sobre problemas ambientais.", "Antes de substantivo: ～についての."),
            g("季節[きせつ]＿＿、景色[けしき]が変[か]わります。", ["によって", "について", "まで", "のに"], 0, "A paisagem muda conforme a estação.", "Variação: ～によって."),
            o("地域[ちいき]によって/祭[まつ]りの/やり方[かた]が/違[ちが]います", "A forma de fazer os festivais varia conforme a região."),
          ],
        },
        dl: {
          t: "Ano-novo japonês",
          l: `
Ana|ユイさん、日本[にほん]のお正月[しょうがつ]について教[おし]えてくれない？レポートを書[か]くんだ。|Yui, você pode me contar sobre o Ano-Novo japonês? Vou escrever um relatório.
Yui|いいよ。お正月[しょうがつ]には「お雑煮[ぞうに]」を食[た]べるんだけど、地域[ちいき]によって味[あじ]が全然[ぜんぜん]違[ちが]うの。|Claro. No Ano-Novo comemos “ozoni”, mas o sabor muda completamente conforme a região.
Ana|へえ、どう違[ちが]うの？|É mesmo? Como muda?
Yui|東京[とうきょう]はしょうゆ味[あじ]で、四角[しかく]いお餅[もち]。京都[きょうと]は白味噌[しろみそ]で、丸[まる]いお餅[もち]なんだ。|Em Tóquio é sabor shoyu, com mochi quadrado. Em Quioto é missô branco, com mochi redondo.
Ana|面白[おもしろ]い！家族[かぞく]によっても違[ちが]うの？|Interessante! Também varia de família para família?
Yui|うん、うちは母[はは]の実家[じっか]の作[つく]り方[かた]だよ。|Sim, lá em casa seguimos a receita da família da minha mãe.`,
          q: [
            ["Como é o ozoni de Tóquio?", ["Missô branco e mochi redondo", "Sabor shoyu e mochi quadrado", "Sem mochi"], 1],
            ["Sobre o que Ana vai escrever?", ["O Ano-Novo japonês", "Festivais de verão", "Comida de Quioto"], 0],
          ],
        },
        w: ["Escreva algo que varia conforme a região no Brasil, usando によって.", "ブラジルでは地域[ちいき]によって、料理[りょうり]が違[ちが]います。", ["によって=によって"]],
      },
      {
        t: "Deve ser...",
        d: "Expectativa lógica com ～はずです",
        v: `
開[ひら]く|abrir; realizar (evento)|毎年[まいとし]、ここで花火大会[はなびたいかい]が開[ひら]かれます。|Todo ano é realizado aqui um festival de fogos.
花火[はなび]|fogos de artifício|夏[なつ]は花火[はなび]を見[み]に行[い]きます。|No verão vou ver fogos de artifício.
浴衣[ゆかた]|yukata|浴衣[ゆかた]を着[き]て出[で]かけます。|Saio vestindo yukata.
屋台[やたい]|barraquinha|屋台[やたい]でたこ焼[や]きを買[か]いました。|Comprei takoyaki numa barraquinha.
混[こ]む|ficar lotado|会場[かいじょう]はとても混[こ]んでいました。|O local estava muito lotado.
確[たし]か|se não me engano|確[たし]か、明日[あした]は休[やす]みです。|Se não me engano, amanhã é folga.`,
        k: `
花|カ|はな|flor|花火[はなび]=fogos de artifício;花見[はなみ]=contemplação das flores
火|カ|ひ|fogo|花火[はなび]=fogos;火曜日[かようび]=terça-feira`,
        g: {
          t: "～はずです: expectativa lógica",
          e: `**Forma simples + はずです** = “deve ser / deveria”, com base em **lógica ou informação confiável**.
• 田中[たなか]さんは会議[かいぎ]に出[で]る**はずです**。 (Ele disse que viria.)
• Adjetivo -な: 静[しず]か**な**はず / Substantivo: 休[やす]み**の**はず
Negação:
• **～ないはずです**: espera-se que não.
• **～はずがありません**: é impossível que... (forte).
**～はずでした / はずだった** = era para ter... (mas não aconteceu).
• 電車[でんしゃ]は八時[はちじ]に着[つ]くはずでしたが、遅[おく]れました。`,
          x: `
花火大会[はなびたいかい]は七時[しちじ]から始[はじ]まるはずです。|O festival de fogos deve começar às sete.
ケンさんは大阪出身[おおさかしゅっしん]だから、たこ焼[や]きを作[つく]るのが上手[じょうず]なはずです。|O Ken é de Osaka, então deve ser bom em fazer takoyaki.
あんなに練習[れんしゅう]したんだから、失敗[しっぱい]するはずがない。|Ele praticou tanto que é impossível falhar.`,
          q: [
            g("荷物[にもつ]は昨日[きのう]送[おく]ったので、明日[あした]＿＿はずです。", ["届[とど]く", "届[とど]いて", "届[とど]こう", "届[とど]け"], 0, "Enviei a encomenda ontem, então deve chegar amanhã.", "Expectativa lógica: forma simples + はず."),
            g("今日[きょう]は日曜日[にちようび]だから、銀行[ぎんこう]は休[やす]み＿＿はずです。", ["の", "な", "だ", "に"], 0, "Hoje é domingo, então o banco deve estar fechado.", "Substantivo + の + はず."),
            g("彼[かれ]は日本[にほん]に十年[じゅうねん]住[す]んでいたから、日本語[にほんご]が＿＿はずです。", ["上手[じょうず]な", "上手[じょうず]だ", "上手[じょうず]の", "上手[じょうず]に"], 0, "Ele morou dez anos no Japão, então deve ser bom em japonês.", "Adjetivo -な + な + はず."),
            g("こんなに簡単[かんたん]な問題[もんだい]、彼[かれ]が間違[まちが]える＿＿がありません。", ["はず", "よう", "そう", "つもり"], 0, "É impossível ele errar um problema tão fácil.", "～はずがない = é impossível que."),
            o("会議[かいぎ]は/三時[さんじ]に/終[お]わる/はずです", "A reunião deve terminar às três.", "三時[さんじ]に/会議[かいぎ]は/終[お]わる/はずです"),
          ],
        },
        dl: {
          t: "Festival de fogos",
          l: `
Ana|ユイさん、花火大会[はなびたいかい]は何時[なんじ]から？|Yui, a que horas começa o festival de fogos?
Yui|確[たし]か、七時半[しちじはん]から始[はじ]まるはずだよ。|Se não me engano, deve começar às sete e meia.
Ana|ケンさんは？もう来[く]るはずだよね。|E o Ken? Ele já devia estar chegando, né?
Yui|六時[ろくじ]に駅[えき]で会[あ]うはずだったんだけど…。あ、メッセージが来[き]た。電車[でんしゃ]がすごく混[こ]んでいて、遅[おく]れるって。|Era para nos encontrarmos às seis na estação, mas... Ah, chegou uma mensagem. Ele disse que o trem está muito lotado e que vai se atrasar.
Ana|今日[きょう]は百万人[ひゃくまんにん]ぐらい来[く]るらしいからね。|Dizem que hoje vêm cerca de um milhão de pessoas, né.
Yui|じゃ、先[さき]に屋台[やたい]で何[なに]か買[か]っておこう。|Então vamos comprar algo nas barraquinhas antes.`,
          q: [
            ["A que horas os fogos devem começar?", ["Às seis", "Às sete e meia", "Às oito"], 1],
            ["Por que Ken vai se atrasar?", ["Esqueceu o horário", "O trem está muito lotado", "Está trabalhando"], 1],
          ],
        },
        w: ["Escreva uma expectativa lógica sobre algo, usando はずです.", "今日[きょう]は土曜日[どようび]だから、道[みち]は混[こ]んでいないはずです。", ["はず=はず"]],
      },
      {
        t: "O que se deve fazer",
        d: "Dever moral com ～べきです",
        v: `
マナー|etiqueta, boas maneiras|電車[でんしゃ]のマナーを守[まも]りましょう。|Vamos respeitar a etiqueta no trem.
お辞儀[じぎ]|reverência|日本[にほん]ではお辞儀[じぎ]をします。|No Japão, faz-se reverência.
敬語[けいご]|linguagem honorífica|敬語[けいご]は難[むずか]しいです。|O keigo é difícil.
迷惑[めいわく]|incômodo, transtorno|人[ひと]に迷惑[めいわく]をかけないでください。|Não cause transtorno às pessoas.
尊重[そんちょう]する|respeitar|相手[あいて]の意見[いけん]を尊重[そんちょう]します。|Respeito a opinião do outro.
常識[じょうしき]|senso comum|それは常識[じょうしき]です。|Isso é senso comum.`,
        k: `
敬|ケイ|うやま(う)|respeitar|敬語[けいご]=linguagem honorífica;尊敬[そんけい]=respeito
識|シキ|—|conhecer, discernir|常識[じょうしき]=senso comum;知識[ちしき]=conhecimento`,
        g: {
          t: "～べきだ: dever moral",
          e: `**Verbo (dicionário) + べきです** = “deve-se...”, expressando o que é **certo**, uma **obrigação moral** ou uma **opinião forte**.
• 約束[やくそく]は守[まも]る**べきです**。
• する → **するべき** ou **すべき** (ambos corretos).
Negativo: **～べきではありません** = não se deve...
• 人[ひと]の悪口[わるぐち]を言[い]う**べきではない**。
Compare:
• ～なければならない: obrigação (regra, necessidade).
• ～たほうがいい: conselho.
• ～べきだ: dever moral, opinião forte.`,
          x: `
電車[でんしゃ]の中[なか]では、大[おお]きい声[こえ]で話[はな]すべきではありません。|Não se deve falar alto dentro do trem.
間違[まちが]えたら、すぐ謝[あやま]るべきです。|Se errar, deve-se pedir desculpas imediatamente.
若[わか]いうちに、色々[いろいろ]な経験[けいけん]をすべきだと思[おも]います。|Acho que se deve ter várias experiências enquanto se é jovem.`,
          q: [
            g("約束[やくそく]は＿＿べきです。", ["守[まも]る", "守[まも]って", "守[まも]った", "守[まも]り"], 0, "Promessas devem ser cumpridas.", "べき vem após a forma de dicionário."),
            g("他[ほか]の人[ひと]に迷惑[めいわく]をかける＿＿。", ["べきではありません", "べきです", "はずです", "ことにします"], 0, "Não se deve causar transtorno aos outros.", "Dever moral negativo: ～べきではない."),
            g("学生[がくせい]はもっと勉強[べんきょう]＿＿べきだ。", ["す", "して", "し", "さ"], 0, "Os estudantes deveriam estudar mais.", "する + べき → すべき (forma tradicional)."),
            g("相手[あいて]の文化[ぶんか]を＿＿べきだと思[おも]います。", ["尊重[そんちょう]する", "尊重[そんちょう]して", "尊重[そんちょう]した", "尊重[そんちょう]し"], 0, "Acho que se deve respeitar a cultura do outro.", "Forma de dicionário + べき."),
            o("お年寄[としよ]りには/席[せき]を/譲[ゆず]る/べきです", "Deve-se ceder o lugar aos idosos.", "席[せき]を/お年寄[としよ]りには/譲[ゆず]る/べきです"),
          ],
        },
        dl: {
          t: "Debate sobre etiqueta",
          l: `
Professor|今日[きょう]は「日本[にほん]のマナー」について話[はな]し合[あ]いましょう。アナさん、どう思[おも]いますか。|Hoje vamos discutir “a etiqueta japonesa”. Ana, o que você acha?
Ana|電車[でんしゃ]の中[なか]で電話[でんわ]をしないのは、いいマナーだと思[おも]います。周[まわ]りの人[ひと]の迷惑[めいわく]になるので、するべきではないです。|Acho que não falar ao telefone no trem é uma boa etiqueta. Incomoda as pessoas ao redor, então não se deve fazer isso.
Professor|なるほど。ケンさんは？|Entendo. E você, Ken?
Ken|僕[ぼく]は、外国人[がいこくじん]の観光客[かんこうきゃく]に、日本[にほん]のマナーを全部[ぜんぶ]守[まも]らせるべきではないと思[おも]います。|Eu acho que não se deve obrigar os turistas estrangeiros a seguir todas as regras de etiqueta japonesas.
Ana|でも、ごみの捨[す]て方[かた]みたいな基本[きほん]のルールは、守[まも]るべきですよね。|Mas regras básicas, como a forma de jogar o lixo, devem ser seguidas, não?
Ken|それは賛成[さんせい]です。|Com isso eu concordo.`,
          q: [
            ["Segundo Ana, o que não se deve fazer no trem?", ["Comer", "Falar ao telefone", "Dormir"], 1],
            ["Com o que Ken concorda?", ["Que regras básicas, como as do lixo, devem ser seguidas", "Que turistas não precisam seguir nenhuma regra", "Que é preciso proibir celulares"], 0],
          ],
        },
        w: ["Dê sua opinião sobre uma regra de etiqueta usando べきです ou べきではありません.", "人[ひと]と話[はな]すときは、スマホを見[み]るべきではありません。", ["べき=べき"]],
      },
    ],
  },
  // ───────────────────────── Capítulo 8 (B1)
  {
    t: "Opiniões e futuro",
    d: "Certeza, contraste e persistência",
    icon: "💬",
    color: "#3D5AFE",
    lessons: [
      {
        t: "Talvez... com certeza!",
        d: "かもしれない, だろう e に違いない",
        v: `
可能性[かのうせい]|possibilidade|雨[あめ]の可能性[かのうせい]があります。|Há possibilidade de chuva.
未来[みらい]|futuro (distante)|未来[みらい]の生活[せいかつ]を想像[そうぞう]します。|Imagino a vida do futuro.
想像[そうぞう]する|imaginar|そんな生活[せいかつ]は想像[そうぞう]できません。|Não consigo imaginar uma vida assim.
人工知能[じんこうちのう]|inteligência artificial|人工知能[じんこうちのう]が進歩[しんぽ]しています。|A inteligência artificial está avançando.
増[ふ]える|aumentar|外国人[がいこくじん]観光客[かんこうきゃく]が増[ふ]えました。|Os turistas estrangeiros aumentaram.
きっと|com certeza|きっと大丈夫[だいじょうぶ]です。|Com certeza vai dar tudo certo.`,
        k: `
能|ノウ|—|capacidade|可能性[かのうせい]=possibilidade;才能[さいのう]=talento
未|ミ|いま(だ)|ainda não|未来[みらい]=futuro;未成年[みせいねん]=menor de idade`,
        g: {
          t: "Graus de certeza: かもしれない, だろう, に違いない",
          e: `Da menor para a maior certeza:
• **～かもしれません** (talvez): 明日[あした]は雨[あめ]が降[ふ]る**かもしれません**。
• **～でしょう / だろう** (provavelmente): 明日[あした]は晴[は]れる**でしょう**。
• **～に違[ちが]いない** (com certeza, convicção pessoal): あの人[ひと]が犯人[はんにん]**に違[ちが]いない**。
Formação: forma simples + かもしれない / に違いない. Adjetivo -な e substantivo ligam-se **diretamente** (sem だ): 便利[べんり]かもしれない, 学生[がくせい]に違[ちが]いない.
Advérbios que combinam: **もしかしたら～かもしれない**, **きっと～に違[ちが]いない**.`,
          x: `
もしかしたら、十年後[じゅうねんご]には車[くるま]が空[そら]を飛[と]んでいるかもしれません。|Talvez daqui a dez anos os carros estejam voando.
人工知能[じんこうちのう]の仕事[しごと]は、これから増[ふ]えるでしょう。|Os empregos ligados à IA provavelmente vão aumentar daqui para a frente.
電気[でんき]がついている。ケンさんは家[いえ]にいるに違[ちが]いない。|A luz está acesa. Com certeza o Ken está em casa.`,
          q: [
            g("もしかしたら、午後[ごご]は雨[あめ]が降[ふ]る＿＿。", ["かもしれません", "に違[ちが]いないです", "はずがありません", "べきです"], 0, "Talvez chova à tarde.", "もしかしたら combina com ～かもしれません (possibilidade)."),
            g("あの人[ひと]は毎日[まいにち]ジムに行[い]っている。きっとスポーツが＿＿。", ["好[す]きに違[ちが]いない", "好[す]きなに違[ちが]いない", "好[す]きだに違[ちが]いない", "好[す]きのに違[ちが]いない"], 0, "Aquela pessoa vai à academia todo dia. Com certeza gosta de esportes.", "Adjetivo -な liga-se direto: 好きに違いない."),
            g("この問題[もんだい]は、子供[こども]には少[すこ]し難[むずか]しい＿＿。", ["かもしれません", "かもしれないです", "かもしりません", "かもしれましょう"], 0, "Talvez este problema seja um pouco difícil para crianças.", "Forma educada padrão: ～かもしれません."),
            g("あの店[みせ]は今日[きょう]、休[やす]み＿＿。", ["かもしれない", "だかもしれない", "なかもしれない", "のかもしれなく"], 0, "Talvez aquela loja esteja fechada hoje.", "Substantivo + かもしれない (sem だ)."),
            o("十年後[じゅうねんご]には/ロボットが/増[ふ]えている/かもしれません", "Daqui a dez anos, talvez haja mais robôs.", "ロボットが/十年後[じゅうねんご]には/増[ふ]えている/かもしれません"),
          ],
        },
        dl: {
          t: "O futuro do trabalho",
          l: `
Ken|ねえ、十年後[じゅうねんご]、僕[ぼく]たちの仕事[しごと]はどうなっていると思[おも]う？|Ei, como você acha que estarão os nossos empregos daqui a dez anos?
Ana|翻訳[ほんやく]の仕事[しごと]は、人工知能[じんこうちのう]に取[と]られるかもしれないね。|Talvez o trabalho de tradução seja tomado pela inteligência artificial.
Ken|そうかな。機械[きかい]は速[はや]いけど、文化[ぶんか]の違[ちが]いまでは理解[りかい]できないだろう。|Será? A máquina é rápida, mas provavelmente não consegue entender até as diferenças culturais.
Ana|うん、だから通訳[つうやく]は人間[にんげん]が必要[ひつよう]だと思[おも]う。|É, por isso acho que intérpretes humanos ainda são necessários.
Ken|アナさんならきっと大丈夫[だいじょうぶ]。いい通訳者[つうやくしゃ]になるに違[ちが]いないよ。|Com você vai dar tudo certo, com certeza. Sem dúvida vai ser uma ótima intérprete.
Ana|ありがとう。頑張[がんば]るね。|Obrigada. Vou me esforçar.`,
          q: [
            ["Segundo Ana, o que talvez aconteça com a tradução?", ["Será tomada pela IA", "Vai pagar mais", "Vai deixar de existir o japonês"], 0],
            ["Segundo Ken, o que a máquina provavelmente não entende?", ["Gramática", "Diferenças culturais", "Números"], 1],
          ],
        },
        w: ["Faça uma previsão sobre o futuro usando かもしれません ou に違いない.", "十年後[じゅうねんご]には、もっと多[おお]くの人[ひと]が家[いえ]で働[はたら]いているかもしれません。", ["grau de certeza=かもしれ|に違いな|にちがいな|でしょう|だろう"]],
      },
      {
        t: "Apesar de tudo",
        d: "Frustração com ～のに",
        v: `
せっかく|com todo o esforço; já que|せっかく来[き]たのに、休[やす]みでした。|Vim especialmente, mas estava fechado.
一生懸命[いっしょうけんめい]|com todo o empenho|一生懸命[いっしょうけんめい]勉強[べんきょう]しました。|Estudei com todo o empenho.
文句[もんく]|reclamação|文句[もんく]ばかり言[い]わないでください。|Não fique só reclamando.
結果[けっか]|resultado|試験[しけん]の結果[けっか]が出[で]ました。|Saiu o resultado do exame.
不公平[ふこうへい]|injusto|それは不公平[ふこうへい]です。|Isso é injusto.
落[お]ちる|cair; ser reprovado|試験[しけん]に落[お]ちました。|Fui reprovado no exame.`,
        k: `
結|ケツ|むす(ぶ)|amarrar, concluir|結果[けっか]=resultado;結婚[けっこん]=casamento
果|カ|は(たす)|fruto, resultado|結果[けっか]=resultado;果物[くだもの]=fruta`,
        g: {
          t: "～のに: “apesar de” (com frustração)",
          e: `**～のに** = “apesar de / mesmo que”, com sentimento de **surpresa, insatisfação ou frustração** pelo resultado inesperado.
• 一生懸命[いっしょうけんめい]勉強[べんきょう]した**のに**、試験[しけん]に落[お]ちた。
Formação: forma simples + のに. Adjetivo -な e substantivo: **なのに**.
• 日曜日[にちようび]**なのに**、仕事[しごと]がある。
No fim da frase, expressa lamento: **～のに。** (= que pena...)
• もっと早[はや]く言[い]ってくれればよかった**のに**。
⚠️ Diferente de ～けど (contraste neutro), のに carrega emoção.`,
          x: `
せっかく作[つく]ったのに、誰[だれ]も食[た]べなかった。|Me dei ao trabalho de cozinhar, mas ninguém comeu.
この店[みせ]は高[たか]いのに、あまりおいしくない。|Este restaurante é caro e, mesmo assim, não é muito bom.
もう四月[しがつ]なのに、まだ寒[さむ]いですね。|Já é abril, mas ainda está frio, né.`,
          q: [
            g("約束[やくそく]した＿＿、彼[かれ]は来[こ]なかった。", ["のに", "ので", "ために", "から"], 0, "Ele prometeu, mas não veio.", "Resultado frustrante: ～のに."),
            g("今日[きょう]は休[やす]み＿＿、会社[かいしゃ]に行[い]かなければならない。", ["なのに", "のに", "だのに", "でのに"], 0, "Hoje é folga, mas tenho que ir à empresa.", "Substantivo + なのに."),
            g("毎日[まいにち]運動[うんどう]している＿＿、全然[ぜんぜん]やせない。", ["のに", "ので", "ように", "ために"], 0, "Faço exercício todos os dias, mas não emagreço nada.", "Expectativa frustrada: ～のに."),
            g("せっかく京都[きょうと]まで来[き]た＿＿、雨[あめ]で何[なに]も見[み]られなかった。", ["のに", "から", "ので", "と"], 0, "Viemos até Quioto, mas, por causa da chuva, não conseguimos ver nada.", "せっかく～のに: um esforço que não valeu."),
            o("一生懸命[いっしょうけんめい]/練習[れんしゅう]したのに/試合[しあい]に/負[ま]けた", "Treinei com todo o empenho, mas perdi a partida."),
          ],
        },
        dl: {
          t: "Resultado do exame",
          l: `
Yui|アナさん、ＪＬＰＴの結果[けっか]、どうだった？|Ana, como foi o resultado do JLPT?
Ana|それが…落[お]ちちゃった。毎晩[まいばん]遅[おそ]くまで勉強[べんきょう]したのに。|Pois é... reprovei. Mesmo estudando até tarde toda noite.
Yui|えっ、本当[ほんとう]？あんなに頑張[がんば]っていたのに…。何点[なんてん]だったの？|O quê, sério? Você se esforçou tanto... Quantos pontos você fez?
Ana|合格点[ごうかくてん]まで、あと二点[にてん]だったの。聴解[ちょうかい]はよかったのに、読解[どっかい]で時間[じかん]が足[た]りなかった。|Faltaram só dois pontos para passar. A compreensão auditiva foi boa, mas faltou tempo na leitura.
Yui|惜[お]しい！でも、次[つぎ]はきっと合格[ごうかく]できるよ。|Por pouco! Mas na próxima com certeza você passa.
Ana|うん。今度[こんど]は読[よ]むスピードを上[あ]げる練習[れんしゅう]をするよ。|Sim. Desta vez vou treinar para aumentar a velocidade de leitura.`,
          q: [
            ["Quantos pontos faltaram para Ana passar?", ["Dois", "Cinco", "Dez"], 0],
            ["Em que parte do exame Ana teve problema?", ["Compreensão auditiva", "Leitura (faltou tempo)", "Vocabulário"], 1],
          ],
        },
        w: ["Escreva sobre uma situação frustrante usando のに.", "早[はや]く家[いえ]を出[で]たのに、電車[でんしゃ]が遅[おく]れて遅刻[ちこく]しました。", ["のに=のに"]],
      },
      {
        t: "Mesmo que...",
        d: "Persistência com ～ても",
        v: `
反対[はんたい]する|opor-se|親[おや]は留学[りゅうがく]に反対[はんたい]しました。|Meus pais se opuseram ao intercâmbio.
賛成[さんせい]する|concordar, ser a favor|その意見[いけん]に賛成[さんせい]です。|Sou a favor dessa opinião.
意見[いけん]|opinião|意見[いけん]を言[い]ってください。|Dê sua opinião.
諦[あきら]める|desistir|夢[ゆめ]を諦[あきら]めません。|Não desisto do meu sonho.
夢[ゆめ]|sonho|私[わたし]の夢[ゆめ]は通訳者[つうやくしゃ]になることです。|Meu sonho é ser intérprete.
たとえ|mesmo que (enfático)|たとえ失敗[しっぱい]しても、後悔[こうかい]しません。|Mesmo que eu falhe, não vou me arrepender.`,
        k: `
夢|ム|ゆめ|sonho|夢[ゆめ]=sonho;悪夢[あくむ]=pesadelo
意|イ|—|intenção, mente|意見[いけん]=opinião;意味[いみ]=significado`,
        g: {
          t: "～ても: “mesmo que”",
          e: `**Forma て + も** = “mesmo que / ainda que”. A segunda parte acontece **independentemente** da condição.
• 雨[あめ]が降[ふ]っ**ても**、試合[しあい]はあります。
Formação:
• Verbo: 行[い]っ**ても**, 食[た]べ**ても**
• Adjetivo -い: 高[たか]**くても**
• Adjetivo -な / substantivo: 静[しず]か**でも**, 雨[あめ]**でも**
Ênfase: **たとえ～ても** (mesmo que...). Com interrogativos: **いくら～ても** (por mais que), **何[なに]があっても** (aconteça o que acontecer).
• いくら勉強[べんきょう]しても、覚[おぼ]えられない。`,
          x: `
たとえ親[おや]が反対[はんたい]しても、日本[にほん]に行[い]きます。|Mesmo que meus pais se oponham, vou ao Japão.
高[たか]くても、このパソコンを買[か]いたいです。|Mesmo que seja caro, quero comprar este computador.
いくら説明[せつめい]しても、彼[かれ]はわかってくれなかった。|Por mais que eu explicasse, ele não entendeu.`,
          q: [
            g("雨[あめ]が＿＿、明日[あした]の試合[しあい]は行[おこな]われます。", ["降[ふ]っても", "降[ふ]ったら", "降[ふ]れば", "降[ふ]るなら"], 0, "Mesmo que chova, o jogo de amanhã será realizado.", "Independentemente da condição: ～ても."),
            g("この仕事[しごと]は＿＿、やりがいがあります。", ["大変[たいへん]でも", "大変[たいへん]くても", "大変[たいへん]なでも", "大変[たいへん]だても"], 0, "Mesmo sendo difícil, este trabalho é gratificante.", "Adjetivo -な + でも."),
            g("いくらコーヒーを＿＿、眠[ねむ]いです。", ["飲[の]んでも", "飲[の]んだら", "飲[の]むと", "飲[の]めば"], 0, "Por mais café que eu tome, continuo com sono.", "いくら～ても = por mais que."),
            g("たとえ失敗[しっぱい]＿＿、諦[あきら]めません。", ["しても", "したら", "すれば", "すると"], 0, "Mesmo que eu fracasse, não vou desistir.", "たとえ～ても."),
            o("たとえ/難[むずか]しくても/夢[ゆめ]を/諦[あきら]めません", "Mesmo que seja difícil, não vou desistir do meu sonho."),
          ],
        },
        dl: {
          t: "Sonhos",
          l: `
Tanaka|アナさん、来月[らいげつ]から新[あたら]しい会社[かいしゃ]ですね。不安[ふあん]はありませんか。|Ana, a partir do mês que vem você vai para a nova empresa, né. Não está insegura?
Ana|正直[しょうじき]、少[すこ]し不安[ふあん]です。でも、たとえ大変[たいへん]でも、頑張[がんば]りたいです。|Sinceramente, um pouco. Mas, mesmo que seja difícil, quero me esforçar.
Tanaka|アナさんの夢[ゆめ]は何[なん]ですか。|Qual é o seu sonho, Ana?
Ana|日本[にほん]とブラジルをつなぐ通訳者[つうやくしゃ]になることです。家族[かぞく]は最初[さいしょ]反対[はんたい]しましたが、今[いま]は応援[おうえん]してくれています。|Ser uma intérprete que conecte o Japão e o Brasil. No começo minha família se opôs, mas agora me apoia.
Tanaka|素晴[すば]らしい夢[ゆめ]ですね。何[なに]があっても、諦[あきら]めないでください。|Que sonho maravilhoso. Aconteça o que acontecer, não desista.
Ana|はい。田中[たなか]さん、今[いま]まで本当[ほんとう]にありがとうございました。|Sim. Sr. Tanaka, muito obrigada por tudo até hoje.`,
          q: [
            ["Qual é o sonho de Ana?", ["Ser professora no Brasil", "Ser intérprete entre o Japão e o Brasil", "Abrir uma empresa"], 1],
            ["Como a família de Ana reagiu no começo?", ["Apoiou imediatamente", "Se opôs", "Não disse nada"], 1],
          ],
        },
        w: ["Escreva sobre algo que você fará mesmo diante de dificuldades, usando ても.", "たとえ時間[じかん]がかかっても、日本語[にほんご]が上手[じょうず]になりたいです。", ["ても=ても|でも"]],
      },
    ],
  },
];
