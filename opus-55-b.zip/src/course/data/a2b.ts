import { g, o, type RawUnit } from "../dsl";

export const A2_PART2: RawUnit[] = [
  // ───────────────────────── Capítulo 5
  {
    t: "Planos e convites",
    d: "Intenções, planos e convites",
    icon: "🗓️",
    color: "#F2A900",
    lessons: [
      {
        t: "O que vou fazer",
        d: "Forma volitiva + と思っています",
        v: `
将来[しょうらい]|futuro|将来[しょうらい]、先生[せんせい]になりたいです。|No futuro, quero ser professora.
留学[りゅうがく]する|estudar no exterior|日本[にほん]に留学[りゅうがく]しました。|Fiz intercâmbio no Japão.
引[ひ]っ越[こ]す|mudar-se|来月[らいげつ]、大阪[おおさか]に引[ひ]っ越[こ]します。|No mês que vem, vou me mudar para Osaka.
貯金[ちょきん]する|economizar dinheiro|毎月[まいつき]三万円[さんまんえん]貯金[ちょきん]しています。|Economizo 30 mil ienes por mês.
資格[しかく]|qualificação, certificado|資格[しかく]を取[と]りたいです。|Quero obter uma qualificação.
試験[しけん]|exame, prova|来週[らいしゅう]、試験[しけん]があります。|Tenho prova semana que vem.`,
        k: `
思|シ|おも(う)|pensar|思[おも]う=pensar, achar;思[おも]い出[で]=lembrança
来|ライ|く(る)|vir; próximo|来年[らいねん]=ano que vem;来[く]る=vir`,
        g: {
          t: "Forma volitiva + と思っています: planos",
          e: `A **forma volitiva** expressa “vamos...” ou intenção:
• Verbos -u: う → おう (行[い]く → 行[い]こう, 買[か]う → 買[か]おう)
• Verbos -ru: る → よう (食[た]べる → 食[た]べよう)
• する → しよう / 来[く]る → 来[こ]よう
**Volitiva + と思[おも]っています** = “estou pensando em...”, “pretendo...” (plano que a pessoa vem considerando).
• 来年[らいねん]、日本[にほん]に留学[りゅうがく]しようと思[おも]っています。
**Volitiva + と思[おも]います** expressa uma decisão tomada no momento da fala.`,
          x: `
来月[らいげつ]、引[ひ]っ越[こ]そうと思[おも]っています。|Estou pensando em me mudar no mês que vem.
夏休[なつやす]みに、ＪＬＰＴの勉強[べんきょう]をしようと思[おも]っています。|Pretendo estudar para o JLPT nas férias de verão.
今日[きょう]は早[はや]く帰[かえ]ろうと思[おも]います。|Acho que hoje vou voltar cedo.`,
          q: [
            g("来年[らいねん]、車[くるま]を＿＿と思[おも]っています。", ["買[か]おう", "買[か]う", "買[か]いよう", "買[か]った"], 0, "Pretendo comprar um carro no ano que vem.", "買う → 買おう (volitiva)."),
            g("週末[しゅうまつ]は家[いえ]で映画[えいが]を＿＿と思[おも]っています。", ["見[み]よう", "見[み]おう", "見[み]ろう", "見[み]る"], 0, "Pretendo ver um filme em casa no fim de semana.", "見る (-ru) → 見よう."),
            g("毎月[まいつき]、お金[かね]を貯金[ちょきん]＿＿と思[おも]っています。", ["しよう", "すよう", "しおう", "さよう"], 0, "Pretendo economizar dinheiro todo mês.", "する → しよう."),
            g("明日[あした]から毎朝[まいあさ]六時[ろくじ]に＿＿と思[おも]います。", ["起[お]きよう", "起[お]こう", "起[お]きろう", "起[お]きおう"], 0, "Acho que a partir de amanhã vou acordar às seis todas as manhãs.", "起きる (-ru) → 起きよう."),
            o("来年[らいねん]/日本[にほん]に/留学[りゅうがく]しようと/思[おも]っています", "Estou pensando em fazer intercâmbio no Japão no ano que vem."),
          ],
        },
        dl: {
          t: "Planos de futuro",
          l: `
Tanaka|アナさん、日本[にほん]に来[き]て、もう一年[いちねん]ですね。|Ana, já faz um ano que você veio ao Japão, não?
Ana|はい、早[はや]いですね。来年[らいねん]はＪＬＰＴのＮ３を受[う]けようと思[おも]っています。|Sim, passou rápido. No ano que vem, pretendo fazer o N3 do JLPT.
Tanaka|それはいいですね。将来[しょうらい]は日本[にほん]で働[はたら]くつもりですか。|Que ótimo. No futuro, pretende trabalhar no Japão?
Ana|ええ、通訳[つうやく]の資格[しかく]を取[と]ろうと思[おも]っています。|Sim, estou pensando em obter uma qualificação de intérprete.
Tanaka|応援[おうえん]していますよ。|Estou torcendo por você.`,
          q: [
            ["Que exame Ana pretende fazer no ano que vem?", ["JLPT N3", "JLPT N1", "Um exame de direção"], 0],
            ["Que qualificação Ana quer obter?", ["Professora", "Intérprete", "Guia turística"], 1],
          ],
        },
        w: ["Escreva um plano para o próximo ano usando a forma volitiva + と思っています.", "来年[らいねん]、日本[にほん]へ旅行[りょこう]しようと思[おも]っています。", ["volitiva + と思う=うと思|うとおも"]],
      },
      {
        t: "Intenções firmes",
        d: "Planos decididos com ～つもりです",
        v: `
予定[よてい]|programação, plano|明日[あした]の予定[よてい]は何[なん]ですか。|Qual é a sua programação para amanhã?
休暇[きゅうか]|férias, folga|休暇[きゅうか]を取[と]ります。|Vou tirar férias.
就職[しゅうしょく]する|conseguir emprego|来年[らいねん]、就職[しゅうしょく]します。|Vou começar a trabalhar no ano que vem.
結婚[けっこん]する|casar-se|姉[あね]は来月[らいげつ]結婚[けっこん]します。|Minha irmã mais velha vai se casar no mês que vem.
やめる|parar, desistir|たばこをやめました。|Parei de fumar.
続[つづ]ける|continuar|日本語[にほんご]の勉強[べんきょう]を続[つづ]けます。|Vou continuar estudando japonês.`,
        k: `
予|ヨ|—|prévio|予定[よてい]=plano;予約[よやく]=reserva
定|テイ|さだ(める)|fixar|予定[よてい]=plano;定食[ていしょく]=prato feito`,
        g: {
          t: "～つもりです: intenção decidida",
          e: `**Verbo (forma de dicionário) + つもりです** = “tenho a intenção de...”. Indica um plano já decidido, mais firme que ～ようと思っています.
• 夏[なつ]に国[くに]へ帰[かえ]るつもりです。
Negativo: **Verbo (forma ない) + つもりです** = pretendo não...
• もうお酒[さけ]は飲[の]まないつもりです。
**～つもりはありません** = não tenho a menor intenção de...
Para perguntar a outra pessoa, prefira **～予定[よてい]ですか**: perguntar ～つもりですか pode soar direto demais.`,
          x: `
来年[らいねん]も日本語[にほんご]の勉強[べんきょう]を続[つづ]けるつもりです。|Pretendo continuar estudando japonês no ano que vem.
今年[ことし]は休暇[きゅうか]を取[と]らないつもりです。|Este ano pretendo não tirar férias.
週末[しゅうまつ]はどこへ行[い]く予定[よてい]ですか。|Aonde você planeja ir no fim de semana?`,
          q: [
            g("大学[だいがく]を卒業[そつぎょう]したら、日本[にほん]で＿＿つもりです。", ["働[はたら]く", "働[はたら]いて", "働[はたら]こう", "働[はたら]いた"], 0, "Quando me formar, pretendo trabalhar no Japão.", "つもり vem depois da forma de dicionário."),
            g("もうたばこは＿＿つもりです。", ["吸[す]わない", "吸[す]いません", "吸[す]わなく", "吸[す]って"], 0, "Pretendo não fumar mais.", "Intenção negativa: forma ない + つもり."),
            g("今度[こんど]の休[やす]みは、どこへ行[い]く＿＿ですか。", ["予定[よてい]", "つもりに", "ほう", "こと"], 0, "Aonde você planeja ir nas próximas férias?", "Para perguntar os planos de outra pessoa, 予定ですか é mais educado."),
            g("仕事[しごと]は＿＿つもりはありません。続[つづ]けます。", ["やめる", "やめて", "やめた", "やめよう"], 0, "Não tenho intenção de largar o emprego. Vou continuar.", "～つもりはありません = não tenho a menor intenção de..."),
            o("来年[らいねん]/結婚[けっこん]する/つもりです", "Pretendo me casar no ano que vem."),
          ],
        },
        dl: {
          t: "Notícia importante",
          l: `
Ken|アナさん、実[じつ]は報告[ほうこく]があるんだ。|Ana, na verdade, tenho uma novidade.
Ana|何[なに]？|O quê?
Ken|来年[らいねん]の春[はる]、結婚[けっこん]するつもりなんだ。|Pretendo me casar na próxima primavera.
Ana|えっ、本当[ほんとう]？おめでとう！仕事[しごと]はどうするの？|Sério?! Parabéns! E o trabalho?
Ken|今[いま]の会社[かいしゃ]で続[つづ]けるつもり。でも、新婚旅行[しんこんりょこう]で二週間[にしゅうかん]休暇[きゅうか]を取[と]る予定[よてい]だよ。|Pretendo continuar na empresa atual. Mas planejo tirar duas semanas de férias para a lua de mel.
Ana|いいなあ。どこに行[い]くの？|Que inveja. Para onde vão?
Ken|ブラジル！アナさんの国[くに]を見[み]たいんだ。|Para o Brasil! Quero conhecer o seu país.`,
          q: [
            ["Quando Ken pretende se casar?", ["No próximo verão", "Na próxima primavera", "Neste inverno"], 1],
            ["Para onde Ken vai na lua de mel?", ["Havaí", "Brasil", "Quioto"], 1],
          ],
        },
        w: ["Escreva algo que você pretende fazer (ou não fazer) usando つもりです.", "来年[らいねん]、ＪＬＰＴを受[う]けるつもりです。", ["つもり=つもり"]],
      },
      {
        t: "Vamos juntos?",
        d: "Convites: ～ませんか, ～ましょう, ～ましょうか",
        v: `
誘[さそ]う|convidar|友達[ともだち]を映画[えいが]に誘[さそ]いました。|Convidei um amigo ao cinema.
都合[つごう]|conveniência, disponibilidade|土曜日[どようび]は都合[つごう]がいいです。|Sábado é bom para mim.
花見[はなみ]|contemplação das cerejeiras|公園[こうえん]で花見[はなみ]をします。|Fazemos hanami no parque.
待[ま]ち合[あ]わせ|encontro marcado|待[ま]ち合[あ]わせは駅[えき]の前[まえ]です。|O ponto de encontro é em frente à estação.
残念[ざんねん]|que pena|行[い]けなくて残念[ざんねん]です。|Que pena que não posso ir.
ぜひ|sem falta, com certeza|ぜひ来[き]てください。|Venha sem falta.`,
        k: `
会|カイ|あ(う)|encontrar; reunião|会[あ]う=encontrar;会社[かいしゃ]=empresa
待|タイ|ま(つ)|esperar|待[ま]つ=esperar;招待[しょうたい]=convite`,
        g: {
          t: "Convites: ～ませんか, ～ましょう, ～ましょうか",
          e: `**Verbo (radical) + ませんか** = “Que tal...? / Não quer...?” Convite educado que deixa a pessoa livre para recusar.
• 一緒[いっしょ]に花見[はなみ]をしませんか。
**～ましょう** = “Vamos...!” Aceita ou propõe com entusiasmo.
• ええ、行[い]きましょう。
**～ましょうか** = “Vamos...? / Quer que eu...?” Sugere algo ou oferece ajuda.
• 何時[なんじ]に会[あ]いましょうか。 / 荷物[にもつ]を持[も]ちましょうか。
Para recusar com educação: **すみません、その日[ひ]はちょっと…**`,
          x: `
今度[こんど]の日曜日[にちようび]、一緒[いっしょ]に映画[えいが]を見[み]ませんか。|Que tal assistirmos a um filme juntos no próximo domingo?
いいですね。見[み]ましょう。|Boa ideia. Vamos assistir.
どこで待[ま]ち合[あ]わせましょうか。|Onde nos encontramos?`,
          q: [
            g("A: 一緒[いっしょ]に昼[ひる]ご飯[はん]を食[た]べ＿＿。 B: ええ、いいですね。", ["ませんか", "ないでください", "たことがあります", "てはいけません"], 0, "A: Não quer almoçar comigo? B: Sim, boa ideia.", "Convite educado: ～ませんか."),
            g("A: 映画[えいが]の日[ひ]、何時[なんじ]に会[あ]い＿＿。 B: 六時[ろくじ]はどうですか。", ["ましょうか", "ました", "ません", "ませんでした"], 0, "A: A que horas nos encontramos no dia do filme? B: Que tal às seis?", "Para combinar algo juntos com pergunta: ～ましょうか."),
            g("重[おも]そうですね。荷物[にもつ]を持[も]ち＿＿。", ["ましょうか", "ませんか", "ません", "ませんでした"], 0, "Parece pesado. Quer que eu carregue a bagagem?", "Oferecer ajuda: ～ましょうか."),
            g("A: 土曜日[どようび]、カラオケに行[い]きませんか。 B: すみません、土曜日[どようび]は＿＿…。", ["ちょっと", "ぜひ", "いいですね", "行[い]きましょう"], 0, "A: Vamos ao karaokê no sábado? B: Desculpe, sábado é meio complicado...", "Recusa indireta: ちょっと…."),
            o("一緒[いっしょ]に/花見[はなみ]を/しませんか", "Que tal fazermos hanami juntos?", "花見[はなみ]を/一緒[いっしょ]に/しませんか"),
          ],
        },
        dl: {
          t: "Convite para o hanami",
          l: `
Yui|アナさん、今度[こんど]の土曜日[どようび]、上野公園[うえのこうえん]で花見[はなみ]をしませんか。|Ana, que tal fazermos hanami no Parque Ueno no próximo sábado?
Ana|わあ、ぜひ！何時[なんじ]に会[あ]いましょうか。|Uau, com certeza! A que horas nos encontramos?
Yui|十一時[じゅういちじ]はどうですか。|Que tal às onze?
Ana|大丈夫[だいじょうぶ]です。待[ま]ち合[あ]わせはどこにしましょうか。|Pode ser. Onde marcamos o encontro?
Yui|上野駅[うえのえき]の公園口[こうえんぐち]にしましょう。|Vamos marcar na saída do parque da estação Ueno.
Ana|わかりました。お弁当[べんとう]を作[つく]って行[い]きましょうか。|Entendido. Quer que eu prepare um bentô para levar?
Yui|うれしい！お願[ねが]いします。|Que alegria! Por favor.`,
          q: [
            ["A que horas elas vão se encontrar?", ["Às dez", "Às onze", "Ao meio-dia"], 1],
            ["O que Ana se oferece para fazer?", ["Comprar bebidas", "Preparar um bentô", "Reservar um lugar"], 1],
          ],
        },
        w: ["Convide um amigo para fazer algo no fim de semana usando ませんか.", "日曜日[にちようび]、一緒[いっしょ]にテニスをしませんか。", ["ませんか=ませんか"]],
      },
    ],
  },
  // ───────────────────────── Capítulo 6
  {
    t: "Pela cidade",
    d: "Direções, transporte e capacidades",
    icon: "🚉",
    color: "#2F80ED",
    lessons: [
      {
        t: "Como chego lá?",
        d: "Direções com o condicional ～と",
        v: `
まっすぐ|reto, em frente|この道[みち]をまっすぐ行[い]ってください。|Siga reto por esta rua.
曲[ま]がる|virar (dobrar)|次[つぎ]の角[かど]を右[みぎ]に曲[ま]がります。|Viro à direita na próxima esquina.
信号[しんごう]|semáforo|信号[しんごう]を渡[わた]ります。|Atravesso no semáforo.
交差点[こうさてん]|cruzamento|交差点[こうさてん]の近[ちか]くにあります。|Fica perto do cruzamento.
渡[わた]る|atravessar|橋[はし]を渡[わた]りました。|Atravessei a ponte.
右[みぎ]|direita|銀行[ぎんこう]は右[みぎ]にあります。|O banco fica à direita.`,
        k: `
右|ウ|みぎ|direita|右[みぎ]=direita;右側[みぎがわ]=lado direito
左|サ|ひだり|esquerda|左[ひだり]=esquerda;左手[ひだりて]=mão esquerda`,
        g: {
          t: "～と: consequência natural e direções",
          e: `**Verbo (forma de dicionário) + と、～** = “quando/se ..., (sempre/naturalmente) ...”. Expressa um resultado automático ou inevitável.
• この道[みち]をまっすぐ行[い]くと、駅[えき]があります。
• 春[はる]になると、桜[さくら]が咲[さ]きます。
É muito usado para dar direções e explicar o funcionamento de máquinas:
• このボタンを押[お]すと、お釣[つ]りが出[で]ます。
⚠️ A segunda parte não pode ser pedido, convite ou intenção (não diga ～と、行[い]ってください).`,
          x: `
二[ふた]つ目[め]の信号[しんごう]を左[ひだり]に曲[ま]がると、郵便局[ゆうびんきょく]があります。|Virando à esquerda no segundo semáforo, há uma agência dos correios.
橋[はし]を渡[わた]ると、右[みぎ]に公園[こうえん]が見[み]えます。|Atravessando a ponte, você vê um parque à direita.
このボタンを押[お]すと、切符[きっぷ]が出[で]ます。|Apertando este botão, sai o bilhete.`,
          q: [
            g("まっすぐ＿＿と、右[みぎ]に銀行[ぎんこう]があります。", ["行[い]く", "行[い]って", "行[い]った", "行[い]こう"], 0, "Seguindo reto, há um banco à direita.", "と exige a forma de dicionário: 行くと."),
            g("冬[ふゆ]に＿＿と、雪[ゆき]が降[ふ]ります。", ["なる", "なって", "なった", "なり"], 0, "Quando chega o inverno, neva.", "Resultado natural: なると."),
            g("この角[かど]を左[ひだり]に曲[ま]がる＿＿、駅[えき]が見[み]えます。", ["と", "から", "ので", "まで"], 0, "Virando esta esquina à esquerda, você verá a estação.", "Direções: ～と、～があります/見えます."),
            g("このボタンを＿＿と、ドアが開[あ]きます。", ["押[お]す", "押[お]して", "押[お]した", "押[お]そう"], 0, "Apertando este botão, a porta abre.", "Funcionamento de máquina: forma de dicionário + と."),
            o("信号[しんごう]を/渡[わた]ると/左[ひだり]に/コンビニがあります", "Atravessando no semáforo, há uma loja de conveniência à esquerda."),
          ],
        },
        dl: {
          t: "Perdida em Shibuya",
          l: `
Ana|すみません、渋谷図書館[しぶやとしょかん]はどこですか。|Com licença, onde fica a biblioteca de Shibuya?
Passante|図書館[としょかん]ですか。この道[みち]をまっすぐ行[い]くと、大[おお]きい交差点[こうさてん]があります。|A biblioteca? Seguindo reto por esta rua, há um grande cruzamento.
Ana|はい。|Sim.
Passante|その交差点[こうさてん]を右[みぎ]に曲[ま]がると、左[ひだり]に白[しろ]い建物[たてもの]が見[み]えます。それが図書館[としょかん]ですよ。|Virando à direita nesse cruzamento, você verá um prédio branco à esquerda. É a biblioteca.
Ana|ここから歩[ある]いて何分[なんぷん]ぐらいですか。|Quantos minutos leva a pé daqui?
Passante|十分[じゅっぷん]ぐらいですね。|Uns dez minutos.
Ana|ご親切[しんせつ]に、ありがとうございます。|Muito obrigada pela gentileza.`,
          q: [
            ["Onde Ana deve virar à direita?", ["No semáforo", "No grande cruzamento", "Na ponte"], 1],
            ["Como é o prédio da biblioteca?", ["Branco", "Alto e cinza", "Vermelho"], 0],
          ],
        },
        w: ["Explique o caminho da estação até a sua casa usando と.", "駅[えき]を出[で]て、まっすぐ行[い]くと、右[みぎ]に私[わたし]の家[いえ]があります。", ["condicional と=くと|ると|すと|うと|つと|むと|ぐと|ぶと|ぬと"]],
      },
      {
        t: "Transporte público",
        d: "に乗る, を降りる, から～まで e かかる",
        v: `
乗[の]る|embarcar, pegar (transporte)|バスに乗[の]ります。|Pego o ônibus.
降[お]りる|descer (do transporte)|次[つぎ]の駅[えき]で降[お]ります。|Desço na próxima estação.
乗[の]り換[か]える|fazer baldeação|新宿[しんじゅく]で乗[の]り換[か]えます。|Faço baldeação em Shinjuku.
かかる|levar (tempo); custar|駅[えき]まで十分[じゅっぷん]かかります。|Leva dez minutos até a estação.
地下鉄[ちかてつ]|metrô|地下鉄[ちかてつ]は便利[べんり]です。|O metrô é prático.
切符[きっぷ]|bilhete|切符[きっぷ]を買[か]いました。|Comprei o bilhete.`,
        k: `
駅|エキ|—|estação|駅[えき]=estação;駅員[えきいん]=funcionário da estação
乗|ジョウ|の(る)|embarcar|乗[の]る=embarcar;乗車[じょうしゃ]=embarque`,
        g: {
          t: "Transporte: に乗る, を降りる e かかる",
          e: `Partículas com transporte:
• **Transporte + に乗[の]る** (embarcar em): 電車[でんしゃ]に乗[の]ります。
• **Transporte/lugar + を降[お]りる** (sair de): バスを降[お]ります。
• **Lugar + で乗[の]り換[か]える** (fazer baldeação em).
• **Transporte + で** (meio): 地下鉄[ちかてつ]で行[い]きます。
**A から B まで** = de A até B.
**(Tempo/dinheiro) + かかります** = leva / custa.
• 家[いえ]から会社[かいしゃ]まで、電車[でんしゃ]で四十分[よんじゅっぷん]かかります。
Pergunta: **どのくらいかかりますか**.`,
          x: `
渋谷[しぶや]で銀座線[ぎんざせん]に乗[の]り換[か]えてください。|Faça baldeação para a linha Ginza em Shibuya.
次[つぎ]の駅[えき]で電車[でんしゃ]を降[お]ります。|Desço do trem na próxima estação.
東京[とうきょう]から大阪[おおさか]まで、新幹線[しんかんせん]でどのくらいかかりますか。|Quanto tempo leva de Tóquio a Osaka de trem-bala?`,
          q: [
            g("駅[えき]でタクシー＿＿乗[の]りました。", ["に", "を", "で", "が"], 0, "Peguei um táxi na estação.", "Embarcar EM algo: ～に乗る."),
            g("次[つぎ]の駅[えき]で電車[でんしゃ]＿＿降[お]ります。", ["を", "に", "へ", "が"], 0, "Desço do trem na próxima estação.", "Sair de um transporte: ～を降りる."),
            g("家[いえ]から学校[がっこう]＿＿、自転車[じてんしゃ]で十五分[じゅうごふん]です。", ["まで", "から", "を", "が"], 0, "De casa até a escola são 15 minutos de bicicleta.", "A から B まで = de A até B."),
            g("空港[くうこう]まで、どのくらい＿＿か。", ["かかります", "あります", "います", "します"], 0, "Quanto tempo leva até o aeroporto?", "Tempo ou custo: かかります."),
            o("新宿[しんじゅく]で/地下鉄[ちかてつ]に/乗[の]り換[か]えます", "Faço baldeação para o metrô em Shinjuku.", "地下鉄[ちかてつ]に/新宿[しんじゅく]で/乗[の]り換[か]えます"),
          ],
        },
        dl: {
          t: "No guichê da estação",
          l: `
Ana|すみません、横浜[よこはま]まで行[い]きたいんですが。|Com licença, eu gostaria de ir até Yokohama.
Funcionário|横浜[よこはま]ですね。ここから東横線[とうよこせん]に乗[の]ってください。乗[の]り換[か]えはありません。|Yokohama, certo? Daqui, pegue a linha Toyoko. Não há baldeação.
Ana|どのくらいかかりますか。|Quanto tempo leva?
Funcionário|急行[きゅうこう]で三十分[さんじゅっぷん]ぐらいです。|De expresso, cerca de 30 minutos.
Ana|切符[きっぷ]はいくらですか。|Quanto custa o bilhete?
Funcionário|三百十円[さんびゃくじゅうえん]です。ＩＣカードも使[つか]えますよ。|310 ienes. Também dá para usar cartão IC.`,
          q: [
            ["Ana precisa fazer baldeação?", ["Sim, em Shibuya", "Não", "Sim, duas vezes"], 1],
            ["Quanto custa o bilhete?", ["310 ienes", "300 ienes", "130 ienes"], 0],
          ],
        },
        w: ["Escreva quanto tempo leva da sua casa até o trabalho ou a escola, usando から, まで e かかります.", "家[いえ]から会社[かいしゃ]まで、バスで三十分[さんじゅっぷん]かかります。", ["から=から", "まで=まで", "かかります=かかります|かかる"]],
      },
      {
        t: "Você consegue?",
        d: "A forma potencial",
        v: `
泳[およ]ぐ|nadar|海[うみ]で泳[およ]ぎます。|Nado no mar.
漢字[かんじ]|kanji|漢字[かんじ]を練習[れんしゅう]します。|Pratico kanji.
読[よ]める|conseguir ler|この漢字[かんじ]が読[よ]めますか。|Você consegue ler este kanji?
話[はな]せる|conseguir falar|英語[えいご]が話[はな]せます。|Consigo falar inglês.
自転車[じてんしゃ]|bicicleta|自転車[じてんしゃ]で通[かよ]っています。|Vou de bicicleta.
見[み]える|ser visível, dar para ver|ここから富士山[ふじさん]が見[み]えます。|Daqui dá para ver o Monte Fuji.`,
        k: `
話|ワ|はな(す)|falar; conversa|話[はな]す=falar;電話[でんわ]=telefone
読|ドク|よ(む)|ler|読[よ]む=ler;読書[どくしょ]=leitura`,
        g: {
          t: "Forma potencial: conseguir fazer",
          e: `A **forma potencial** indica capacidade ou possibilidade.
• Verbos -u: troque o som final por **-e + る**: 話[はな]す → 話[はな]せる, 行[い]く → 行[い]ける, 泳[およ]ぐ → 泳[およ]げる
• Verbos -ru: る → **られる**: 食[た]べる → 食[た]べられる, 見[み]る → 見[み]られる
• する → **できる** / 来[く]る → **来[こ]られる**
O objeto costuma ser marcado com **が**: 日本語[にほんご]**が**話[はな]せます。
A forma potencial se conjuga como verbo -ru: 話[はな]せます, 話[はな]せない, 話[はな]せた.
Alternativa: **Verbo (dicionário) + ことができる**.`,
          x: `
ケンさんはピアノが弾[ひ]けます。|O Ken sabe tocar piano.
私[わたし]は辛[から]い物[もの]が食[た]べられません。|Eu não consigo comer comida apimentada.
明日[あした]のパーティーに来[こ]られますか。|Você consegue vir à festa amanhã?`,
          q: [
            g("アナさんは日本語[にほんご]が＿＿。", ["話[はな]せます", "話[はな]します", "話[はな]られます", "話[はな]させます"], 0, "A Ana consegue falar japonês.", "話す → 話せる → 話せます."),
            g("この漢字[かんじ]が＿＿か。", ["読[よ]めます", "読[よ]みます", "読[よ]まれます", "読[よ]められます"], 0, "Você consegue ler este kanji?", "読む → 読める."),
            g("納豆[なっとう]は＿＿。においが苦手[にがて]なんです。", ["食[た]べられません", "食[た]べれません", "食[た]べさせません", "食[た]べません"], 0, "Não consigo comer natto. É que não suporto o cheiro.", "Na norma padrão, verbos -ru usam られる: 食べられる."),
            g("子供[こども]のとき、自転車[じてんしゃ]に乗[の]ることが＿＿。", ["できませんでした", "できます", "しませんでした", "乗[の]れます"], 0, "Quando criança, eu não conseguia andar de bicicleta.", "～ことができる no passado negativo: できませんでした."),
            o("私[わたし]は/百[ひゃく]メートル/泳[およ]げます", "Consigo nadar cem metros."),
          ],
        },
        dl: {
          t: "Habilidades",
          l: `
Ken|アナさん、泳[およ]げる？|Ana, você sabe nadar?
Ana|うん、泳[およ]げるよ。ブラジルの海[うみ]でよく泳[およ]いでいたから。どうして？|Sei sim. Eu nadava muito no mar no Brasil. Por quê?
Ken|来週[らいしゅう]、みんなで海[うみ]に行[い]くんだ。一緒[いっしょ]に来[こ]られる？|Semana que vem vamos todos à praia. Você consegue vir junto?
Ana|行[い]きたい！でも、朝[あさ]は早[はや]く起[お]きられないかも…。|Quero ir! Mas talvez eu não consiga acordar cedo...
Ken|大丈夫[だいじょうぶ]。車[くるま]で迎[むか]えに行[い]けるよ。|Sem problemas. Posso ir te buscar de carro.`,
          q: [
            ["Onde Ana nadava muito?", ["Na piscina da escola", "No mar no Brasil", "Em um rio"], 1],
            ["Qual é a preocupação de Ana?", ["Não sabe nadar", "Talvez não consiga acordar cedo", "Não tem carro"], 1],
          ],
        },
        w: ["Escreva uma coisa que você consegue e outra que não consegue fazer (forma potencial).", "私[わたし]はギターが弾[ひ]けますが、ピアノは弾[ひ]けません。", ["potencial=えます|せます|けます|げます|てます|めます|れます|られ|でき|える|せる|ける|げる|める|れる"]],
      },
    ],
  },
  // ───────────────────────── Capítulo 7
  {
    t: "Pessoas",
    d: "Aparência, impressões e qualidades",
    icon: "👥",
    color: "#EB5757",
    lessons: [
      {
        t: "Como ela é?",
        d: "～ている para estados e aparência",
        v: `
眼鏡[めがね]をかける|usar óculos|父[ちち]は眼鏡[めがね]をかけています。|Meu pai usa óculos.
背[せ]が高[たか]い|ser alto (pessoa)|兄[あに]は背[せ]が高[たか]いです。|Meu irmão mais velho é alto.
髪[かみ]|cabelo|彼女[かのじょ]は髪[かみ]が長[なが]いです。|Ela tem cabelo comprido.
帽子[ぼうし]をかぶる|usar chapéu/boné|赤[あか]い帽子[ぼうし]をかぶっています。|Está de boné vermelho.
結婚[けっこん]している|ser casado|姉[あね]は結婚[けっこん]しています。|Minha irmã é casada.
住[す]んでいる|morar|東京[とうきょう]に住[す]んでいます。|Moro em Tóquio.`,
        k: `
髪|ハツ|かみ|cabelo|髪[かみ]=cabelo;金髪[きんぱつ]=cabelo loiro
住|ジュウ|す(む)|morar|住[す]む=morar;住所[じゅうしょ]=endereço`,
        g: {
          t: "～ている para estados e aparência",
          e: `Além de “ação em progresso”, **～ている** descreve um **estado resultante** de uma ação.
• 結婚[けっこん]しています = é casado (casou-se e continua casado)
• 東京[とうきょう]に住[す]んでいます = mora em Tóquio
Para descrever roupas e acessórios, cada parte do corpo tem seu verbo:
• シャツを**着[き]て**いる (tronco) • ズボンを**はいて**いる (pernas/pés)
• 帽子[ぼうし]を**かぶって**いる (cabeça) • 眼鏡[めがね]を**かけて**いる
Para características físicas: **Pessoa は + parte do corpo が + adjetivo**: 髪[かみ]が長[なが]い.`,
          x: `
あの白[しろ]いシャツを着[き]ている人[ひと]が田中[たなか]さんです。|A pessoa vestindo camisa branca é o Sr. Tanaka.
妹[いもうと]は大阪[おおさか]に住[す]んでいます。|Minha irmã mais nova mora em Osaka.
ケンさんは背[せ]が高[たか]くて、髪[かみ]が短[みじか]いです。|O Ken é alto e tem cabelo curto.`,
          q: [
            g("田中[たなか]さんは眼鏡[めがね]を＿＿います。", ["かけて", "着[き]て", "はいて", "かぶって"], 0, "O Sr. Tanaka usa óculos.", "Óculos: かける → かけている."),
            g("ユイさんは青[あお]いスカートを＿＿います。", ["はいて", "着[き]て", "かけて", "かぶって"], 0, "A Yui está de saia azul.", "Peças da cintura para baixo: はく."),
            g("兄[あに]はもう＿＿います。子供[こども]が二人[ふたり]います。", ["結婚[けっこん]して", "結婚[けっこん]する", "結婚[けっこん]した", "結婚[けっこん]し"], 0, "Meu irmão já é casado. Tem dois filhos.", "Estado atual: 結婚している."),
            g("あの人[ひと]は背[せ]＿＿高[たか]いですね。", ["が", "を", "に", "で"], 0, "Aquela pessoa é alta, né?", "Característica física: 背が高い."),
            o("黒[くろ]い/帽子[ぼうし]を/かぶっている人[ひと]は/誰[だれ]ですか", "Quem é a pessoa de chapéu preto?"),
          ],
        },
        dl: {
          t: "Procurando alguém",
          l: `
Ana|ケンさん、今日[きょう]、新[あたら]しい先生[せんせい]が来[く]るんだよね。どんな人[ひと]？|Ken, hoje vem o novo professor, né? Como ele é?
Ken|鈴木先生[すずきせんせい]？背[せ]が高[たか]くて、眼鏡[めがね]をかけている人[ひと]だよ。|O professor Suzuki? É alto e usa óculos.
Ana|あ、あそこでスーツを着[き]ている人[ひと]？|Ah, aquele de terno ali?
Ken|ううん、あの人[ひと]は事務[じむ]の人[ひと]。先生[せんせい]は帽子[ぼうし]をかぶっているよ。|Não, aquele é da secretaria. O professor está de chapéu.
Ana|あ、わかった！ドアの前[まえ]にいる人[ひと]だね。|Ah, entendi! É a pessoa na frente da porta.`,
          q: [
            ["Como é o professor Suzuki?", ["Baixo e de cabelo comprido", "Alto e de óculos", "Usa terno"], 1],
            ["Quem é a pessoa de terno?", ["O professor", "Alguém da secretaria", "O Ken"], 1],
          ],
        },
        w: ["Descreva a aparência de alguém da sua família usando ～ている e が + adjetivo.", "母[はは]は髪[かみ]が長[なが]くて、眼鏡[めがね]をかけています。", ["ている=ている|ています"]],
      },
      {
        t: "Parece...",
        d: "Impressões com ～そうです",
        v: `
優[やさ]しい|gentil, bondoso|祖母[そぼ]はとても優[やさ]しいです。|Minha avó é muito gentil.
厳[きび]しい|rigoroso|あの先生[せんせい]は厳[きび]しいです。|Aquele professor é rigoroso.
面白[おもしろ]い|interessante, engraçado|この本[ほん]は面白[おもしろ]いです。|Este livro é interessante.
真面目[まじめ]|sério, dedicado|彼[かれ]は真面目[まじめ]な学生[がくせい]です。|Ele é um aluno dedicado.
元気[げんき]|animado, bem de saúde|子供[こども]たちは元気[げんき]です。|As crianças estão animadas.
おいしい|gostoso|このケーキはおいしいです。|Este bolo é gostoso.`,
        k: `
優|ユウ|やさ(しい)|gentil; superior|優[やさ]しい=gentil;女優[じょゆう]=atriz
面|メン|おも、つら|rosto, superfície|面白[おもしろ]い=interessante;画面[がめん]=tela`,
        g: {
          t: "～そうです: “parece...” (aparência)",
          e: `**～そうです** expressa a impressão que temos ao **ver** algo.
• Adjetivo -い: tire い + そう: おいしい → おいしそう
• Adjetivo -な: tire な + そう: 元気[げんき] → 元気[げんき]そう
• Verbo (radical ます): 降[ふ]ります → 降[ふ]りそう (parece que vai...)
Exceções: **いい → よさそう**, **ない → なさそう**.
Antes de substantivo: **～そうな + substantivo**: 優[やさ]しそうな人[ひと].
⚠️ Não se usa para o que é óbvio à vista: não diga きれいそう olhando para uma pessoa bonita.`,
          x: `
このラーメン、おいしそうですね。|Este ramen parece gostoso.
雨[あめ]が降[ふ]りそうです。傘[かさ]を持[も]って行[い]きましょう。|Parece que vai chover. Vamos levar guarda-chuva.
新[あたら]しい部長[ぶちょう]は優[やさ]しそうな人[ひと]です。|O novo gerente parece ser uma pessoa gentil.`,
          q: [
            g("わあ、このケーキ、＿＿ですね。", ["おいしそう", "おいしいそう", "おいしさそう", "おいしくそう"], 0, "Uau, este bolo parece delicioso.", "Adjetivo -い: tire o い e coloque そう."),
            g("あの映画[えいが]は＿＿ですね。見[み]てみたいです。", ["面白[おもしろ]そう", "面白[おもしろ]いそう", "面白[おもしろ]くそう", "面白[おもしろ]そうな"], 0, "Aquele filme parece interessante. Quero ver.", "面白い → 面白そう."),
            g("今日[きょう]は天気[てんき]が＿＿ですね。", ["よさそう", "いさそう", "いいそう", "よそう"], 0, "Parece que o tempo está bom hoje.", "Exceção: いい → よさそう."),
            g("ユイさんは＿＿な人[ひと]ですね。", ["真面目[まじめ]そう", "真面目[まじめ]なそう", "真面目[まじめ]いそう", "真面目[まじめ]だそう"], 0, "A Yui parece uma pessoa séria.", "Adjetivo -な: radical + そう + な + substantivo."),
            o("空[そら]が/暗[くら]いですね/雨[あめ]が/降[ふ]りそうです", "O céu está escuro. Parece que vai chover."),
          ],
        },
        dl: {
          t: "O novo vizinho",
          l: `
Ana|ユイさん、隣[となり]に新[あたら]しい人[ひと]が引[ひ]っ越[こ]してきたよ。|Yui, uma pessoa nova se mudou para o apartamento ao lado.
Yui|へえ、どんな人[ひと]？|É mesmo? Como ela é?
Ana|まだ話[はな]していないけど、優[やさ]しそうなおじいさんだよ。毎朝[まいあさ]、元気[げんき]そうに散歩[さんぽ]してる。|Ainda não conversei, mas é um senhor que parece gentil. Toda manhã ele faz caminhada todo animado.
Yui|いいね。あ、それ何[なに]？おいしそう！|Que bom. Ah, o que é isso? Parece gostoso!
Ana|そのおじいさんがくれたお菓子[かし]。一緒[いっしょ]に食[た]べよう。|É um doce que aquele senhor me deu. Vamos comer juntas.`,
          q: [
            ["Como Ana descreve o novo vizinho?", ["Um jovem sério", "Um senhor que parece gentil", "Uma senhora rigorosa"], 1],
            ["O que o vizinho deu a Ana?", ["Flores", "Um doce", "Um livro"], 1],
          ],
        },
        w: ["Olhe ao seu redor e descreva algo que “parece” alguma coisa, usando そう.", "この本[ほん]は難[むずか]しそうです。", ["そう=そう"]],
      },
      {
        t: "Por vários motivos",
        d: "Listar razões com ～し、～し",
        v: `
親切[しんせつ]|gentil, prestativo|店員[てんいん]さんが親切[しんせつ]でした。|O atendente foi prestativo.
頭[あたま]がいい|inteligente|彼女[かのじょ]は頭[あたま]がいいです。|Ela é inteligente.
明[あか]るい|alegre; claro|明[あか]るい性格[せいかく]です。|Tem uma personalidade alegre.
性格[せいかく]|personalidade|性格[せいかく]が合[あ]います。|Nossas personalidades combinam.
人気[にんき]がある|ser popular|彼[かれ]はクラスで人気[にんき]があります。|Ele é popular na turma.
話[はな]しやすい|fácil de conversar|田中[たなか]さんは話[はな]しやすいです。|O Sr. Tanaka é fácil de conversar.`,
        k: `
明|メイ|あか(るい)|claro, brilhante|明[あか]るい=claro, alegre;説明[せつめい]=explicação
性|セイ|—|natureza; sexo|性格[せいかく]=personalidade;女性[じょせい]=mulher`,
        g: {
          t: "～し、～し: listar motivos",
          e: `**Forma simples + し、forma simples + し** lista razões ou qualidades, com a ideia de “e além disso...”. Geralmente leva a uma conclusão.
• Verbo: 料理[りょうり]もできる**し**
• Adjetivo -い: 優[やさ]しい**し**
• Adjetivo -な / substantivo: 親切[しんせつ]**だし** / 学生[がくせい]**だし**
• ケンさんは優[やさ]しいし、面白[おもしろ]いし、人気[にんき]があります。
A partícula **も** costuma acompanhar os itens: 頭[あたま]**も**いいし、性格[せいかく]**も**明[あか]るいし…`,
          x: `
この店[みせ]は安[やす]いし、おいしいし、よく来[き]ます。|Este restaurante é barato e gostoso, então venho sempre.
今日[きょう]は雨[あめ]だし、寒[さむ]いし、家[いえ]にいます。|Hoje está chovendo e frio, então vou ficar em casa.
田中[たなか]さんは親切[しんせつ]だし、話[はな]しやすいし、とてもいい上司[じょうし]です。|O Sr. Tanaka é prestativo e fácil de conversar; é um ótimo chefe.`,
          q: [
            g("この部屋[へや]は広[ひろ]い＿＿、駅[えき]から近[ちか]いし、いいですね。", ["し", "から", "て", "が"], 0, "Este apartamento é espaçoso, perto da estação... é ótimo.", "Listar razões: ～し、～し."),
            g("ユイさんは＿＿し、頭[あたま]もいいし、すごいですね。", ["きれいだ", "きれい", "きれいな", "きれいで"], 0, "A Yui é bonita, inteligente... é incrível.", "Adjetivo -な + だ + し."),
            g("今日[きょう]は熱[ねつ]もある＿＿、頭[あたま]も痛[いた]いし、休[やす]みます。", ["し", "と", "ながら", "たり"], 0, "Hoje estou com febre e dor de cabeça, então vou faltar.", "Razões acumuladas: ～し."),
            g("あのレストランは＿＿、おいしくないし、もう行[い]きません。", ["高[たか]いし", "高[たか]いだし", "高[たか]くし", "高[たか]いなし"], 0, "Aquele restaurante é caro e não é gostoso; não vou mais.", "Adjetivo -い: forma simples + し (高いし)."),
            o("彼[かれ]は/優[やさ]しいし/面白[おもしろ]いし/人気[にんき]があります", "Ele é gentil, engraçado e popular.", "彼[かれ]は/面白[おもしろ]いし/優[やさ]しいし/人気[にんき]があります"),
          ],
        },
        dl: {
          t: "O melhor colega",
          l: `
Yui|アナさんの会社[かいしゃ]の人[ひと]たちはどう？|Como são as pessoas da sua empresa, Ana?
Ana|みんないい人[ひと]だよ。特[とく]に田中[たなか]さんが好[す]き。|São todos boas pessoas. Gosto especialmente do Sr. Tanaka.
Yui|どうして？|Por quê?
Ana|親切[しんせつ]だし、話[はな]しやすいし、仕事[しごと]もよくできるし。それに、いつも明[あか]るいんだ。|Ele é prestativo, fácil de conversar e muito competente. Além disso, está sempre de bom humor.
Yui|いい上司[じょうし]だね。|Que bom chefe.
Ana|うん。でも、会議[かいぎ]のときはちょっと厳[きび]しいよ。|Sim. Mas nas reuniões ele é um pouco rigoroso.`,
          q: [
            ["Por que Ana gosta do Sr. Tanaka?", ["Ele é engraçado e alto", "Ele é prestativo, fácil de conversar e competente", "Ele dá presentes"], 1],
            ["Quando o Sr. Tanaka é rigoroso?", ["Nas reuniões", "No almoço", "Às sextas"], 0],
          ],
        },
        w: ["Explique por que você gosta de um lugar ou de uma pessoa, listando motivos com し.", "この町[まち]は静[しず]かだし、便利[べんり]だし、大好[だいす]きです。", ["し=し、|し,"]],
      },
    ],
  },
  // ───────────────────────── Capítulo 8
  {
    t: "Trabalho e escola",
    d: "Obrigações, dispensas e presentes",
    icon: "💼",
    color: "#27AE60",
    lessons: [
      {
        t: "Tenho que...",
        d: "Obrigação com ～なければなりません",
        v: `
締[し]め切[き]り|prazo final|締[し]め切[き]りは金曜日[きんようび]です。|O prazo é sexta-feira.
書類[しょるい]|documento|書類[しょるい]を出[だ]してください。|Entregue os documentos, por favor.
提出[ていしゅつ]する|entregar, submeter|レポートを提出[ていしゅつ]しました。|Entreguei o relatório.
残業[ざんぎょう]する|fazer hora extra|今日[きょう]は残業[ざんぎょう]します。|Hoje vou fazer hora extra.
会議[かいぎ]|reunião|三時[さんじ]から会議[かいぎ]があります。|Há uma reunião a partir das três.
急[いそ]ぐ|apressar-se|急[いそ]いでください。|Apresse-se, por favor.`,
        k: `
働|ドウ|はたら(く)|trabalhar|働[はたら]く=trabalhar;労働[ろうどう]=trabalho, labor
急|キュウ|いそ(ぐ)|urgente, apressar|急[いそ]ぐ=apressar-se;急行[きゅうこう]=expresso`,
        g: {
          t: "～なければなりません: obrigação",
          e: `**Verbo (forma ない sem い) + ければなりません** = “tenho que / devo...”.
• 書[か]かない → 書[か]かなければなりません
• 食[た]べない → 食[た]べなければなりません
• しない → しなければなりません
Variações comuns:
• **～なければいけません** (mais coloquial, mesma ideia)
• Na fala informal: **～なきゃ** (行[い]かなきゃ！ Tenho que ir!)`,
          x: `
明日[あした]までに書類[しょるい]を提出[ていしゅつ]しなければなりません。|Tenho que entregar os documentos até amanhã.
今日[きょう]は残業[ざんぎょう]しなければいけません。|Hoje tenho que fazer hora extra.
もう九時[くじ]だ。急[いそ]がなきゃ！|Já são nove horas. Tenho que me apressar!`,
          q: [
            g("明日[あした]は六時[ろくじ]に＿＿なりません。", ["起[お]きなければ", "起[お]きないければ", "起[お]きなくて", "起[お]きれば"], 0, "Amanhã tenho que acordar às seis.", "起きない → 起きなければなりません."),
            g("レポートを金曜日[きんようび]までに＿＿なりません。", ["出[だ]さなければ", "出[だ]しなければ", "出[だ]すなければ", "出[だ]さないで"], 0, "Tenho que entregar o relatório até sexta.", "出す → 出さない → 出さなければ."),
            g("この薬[くすり]は毎日[まいにち]＿＿いけません。", ["飲[の]まなければ", "飲[の]みなければ", "飲[の]まないで", "飲[の]まなくて"], 0, "Tenho que tomar este remédio todos os dias.", "飲む → 飲まない → 飲まなければいけません."),
            g("あ、もう電車[でんしゃ]の時間[じかん]だ。帰[かえ]ら＿＿！", ["なきゃ", "なくて", "ないで", "なかった"], 0, "Ah, já está na hora do trem. Tenho que ir embora!", "Forma coloquial de ～なければ: ～なきゃ."),
            o("今日[きょう]は/残業[ざんぎょう]しなければ/なりません", "Hoje tenho que fazer hora extra."),
          ],
        },
        dl: {
          t: "Prazo apertado",
          l: `
Tanaka|アナさん、例[れい]の書類[しょるい]、もうできましたか。|Ana, aquele documento já está pronto?
Ana|すみません、まだです。締[し]め切[き]りはいつでしたっけ。|Desculpe, ainda não. Quando era o prazo mesmo?
Tanaka|明日[あした]の朝[あさ]、部長[ぶちょう]に提出[ていしゅつ]しなければなりません。|Temos que entregar ao gerente amanhã de manhã.
Ana|わかりました。今日[きょう]は残業[ざんぎょう]して、終[お]わらせます。|Entendido. Vou fazer hora extra hoje e terminar.
Tanaka|無理[むり]をしないでくださいね。手伝[てつだ]いましょうか。|Não exagere, hein. Quer que eu ajude?
Ana|ありがとうございます。じゃ、データの確認[かくにん]をお願[ねが]いできますか。|Obrigada. Então, o senhor poderia verificar os dados?`,
          q: [
            ["Quando o documento deve ser entregue?", ["Hoje à tarde", "Amanhã de manhã", "Na sexta-feira"], 1],
            ["O que Ana pede ao Sr. Tanaka?", ["Que entregue o documento", "Que verifique os dados", "Que adie o prazo"], 1],
          ],
        },
        w: ["Escreva algo que você tem que fazer esta semana usando なければなりません ou なければいけません.", "今週[こんしゅう]、レポートを書[か]かなければなりません。", ["obrigação=なければ|なきゃ"]],
      },
      {
        t: "Não precisa",
        d: "Dispensar com ～なくてもいいです",
        v: `
制服[せいふく]|uniforme|学校[がっこう]に制服[せいふく]があります。|A escola tem uniforme.
自由[じゆう]|livre|服装[ふくそう]は自由[じゆう]です。|A vestimenta é livre.
ネクタイ|gravata|今日[きょう]はネクタイをしていません。|Hoje não estou de gravata.
出席[しゅっせき]する|comparecer|会議[かいぎ]に出席[しゅっせき]します。|Vou comparecer à reunião.
在宅勤務[ざいたくきんむ]|trabalho remoto (home office)|水曜日[すいようび]は在宅勤務[ざいたくきんむ]です。|Quarta-feira é home office.
心配[しんぱい]する|preocupar-se|心配[しんぱい]しないでください。|Não se preocupe.`,
        k: `
自|ジ|みずか(ら)|si mesmo|自由[じゆう]=liberdade;自分[じぶん]=si mesmo
由|ユウ|よし|razão, origem|自由[じゆう]=liberdade;理由[りゆう]=motivo`,
        g: {
          t: "～なくてもいいです: não precisa",
          e: `**Verbo (forma ない sem い) + くてもいいです** = “não precisa...”.
• 来[こ]ない → 来[こ]なくてもいいです
• 着[き]ない → 着[き]なくてもいいです
É o oposto de ～なければなりません:
• A: 明日[あした]、会社[かいしゃ]に来[こ]なければなりませんか。
• B: いいえ、来[こ]なくてもいいですよ。
Forma coloquial: **～なくてもいい** / **～なくていい**.`,
          x: `
金曜日[きんようび]はネクタイをしなくてもいいです。|Na sexta não precisa usar gravata.
明日[あした]の会議[かいぎ]には出席[しゅっせき]しなくてもいいですよ。|Você não precisa comparecer à reunião de amanhã.
全部[ぜんぶ]食[た]べなくてもいいですよ。|Não precisa comer tudo.`,
          q: [
            g("在宅勤務[ざいたくきんむ]の日[ひ]は、スーツを＿＿もいいです。", ["着[き]なくて", "着[き]ないで", "着[き]なければ", "着[き]なく"], 0, "Nos dias de home office, não precisa usar terno.", "着ない → 着なくてもいい."),
            g("A: 名前[なまえ]を書[か]かなければなりませんか。 B: いいえ、＿＿もいいですよ。", ["書[か]かなくて", "書[か]かないで", "書[か]かなければ", "書[か]かなく"], 0, "A: Tenho que escrever meu nome? B: Não, não precisa.", "Resposta: ～なくてもいいです."),
            g("この会社[かいしゃ]は服装[ふくそう]が自由[じゆう]なので、制服[せいふく]を着[き]＿＿。", ["なくてもいいです", "なければなりません", "てはいけません", "ましょう"], 0, "Nesta empresa a roupa é livre, então não precisa usar uniforme.", "Sem obrigação: ～なくてもいいです."),
            g("明日[あした]は休[やす]みだから、早[はや]く＿＿いいよ。", ["起[お]きなくても", "起[お]きなければ", "起[お]きないで", "起[お]きても"], 0, "Amanhã é folga, então não precisa acordar cedo.", "起きない → 起きなくてもいい."),
            o("土曜日[どようび]は/会社[かいしゃ]に/来[こ]なくても/いいです", "No sábado não precisa vir à empresa."),
          ],
        },
        dl: {
          t: "Primeiro dia de home office",
          l: `
Ana|田中[たなか]さん、水曜日[すいようび]は在宅勤務[ざいたくきんむ]ですよね。会社[かいしゃ]に来[こ]なくてもいいんですか。|Sr. Tanaka, quarta-feira é home office, certo? Não preciso vir à empresa?
Tanaka|ええ、来[こ]なくてもいいですよ。でも、朝[あさ]九時[くじ]のオンライン会議[かいぎ]には出席[しゅっせき]しなければなりません。|Isso, não precisa vir. Mas você tem que participar da reunião online das nove.
Ana|服装[ふくそう]はどうしたらいいですか。|E a roupa, como devo me vestir?
Tanaka|自由[じゆう]ですよ。スーツを着[き]なくてもいいです。|É livre. Não precisa usar terno.
Ana|よかった！パジャマでもいいですか。|Que bom! Pode ser de pijama?
Tanaka|ははは、カメラに映[うつ]るから、それはちょっと…。|Hahaha, você aparece na câmera, então isso é meio complicado...`,
          q: [
            ["O que Ana tem que fazer na quarta-feira?", ["Ir à empresa", "Participar da reunião online das nove", "Usar terno"], 1],
            ["Por que não é bom usar pijama?", ["É contra as regras da empresa", "Ela aparece na câmera", "Faz frio"], 1],
          ],
        },
        w: ["Escreva algo que você não precisa fazer no fim de semana, usando なくてもいいです.", "日曜日[にちようび]は早[はや]く起[お]きなくてもいいです。", ["なくてもいい=なくてもいい|なくていい"]],
      },
      {
        t: "Dar e receber",
        d: "あげる, くれる e もらう",
        v: `
プレゼント|presente|誕生日[たんじょうび]にプレゼントをもらいました。|Ganhei um presente de aniversário.
あげる|dar (a outra pessoa)|友達[ともだち]に本[ほん]をあげました。|Dei um livro a um amigo.
くれる|dar (a mim/ao meu grupo)|母[はは]が手紙[てがみ]をくれました。|Minha mãe me deu uma carta.
もらう|receber|先生[せんせい]に辞書[じしょ]をもらいました。|Recebi um dicionário do professor.
誕生日[たんじょうび]|aniversário|誕生日[たんじょうび]はいつですか。|Quando é seu aniversário?
花束[はなたば]|buquê de flores|花束[はなたば]を買[か]いました。|Comprei um buquê de flores.`,
        k: `
誕|タン|—|nascimento|誕生日[たんじょうび]=aniversário;誕生[たんじょう]=nascimento
生|セイ|い(きる)、う(まれる)|vida, nascer|先生[せんせい]=professor;生[う]まれる=nascer`,
        g: {
          t: "あげる, くれる e もらう",
          e: `Em japonês, o verbo depende de **quem dá e quem recebe**:
• **A は B に ～をあげる**: A dá para B (o objeto se afasta de mim). 私[わたし]は妹[いもうと]に本[ほん]をあげました。
• **A が (私[わたし]に) ～をくれる**: A dá para mim / para o meu grupo. 友達[ともだち]が私[わたし]に花[はな]をくれました。
• **私[わたし]は A に/から ～をもらう**: eu recebo de A. 私[わたし]は友達[ともだち]に花[はな]をもらいました。
⚠️ Nunca use あげる quando alguém dá algo a você: diga くれる.`,
          x: `
ケンさんは私[わたし]にチョコレートをくれました。|O Ken me deu chocolate.
私[わたし]は父[ちち]にネクタイをあげました。|Dei uma gravata ao meu pai.
ユイさんから花束[はなたば]をもらいました。|Recebi um buquê da Yui.`,
          q: [
            g("友達[ともだち]が私[わたし]に誕生日[たんじょうび]のプレゼントを＿＿。", ["くれました", "あげました", "もらいました", "やりました"], 0, "Meu amigo me deu um presente de aniversário.", "Alguém dá para mim: くれる."),
            g("私[わたし]は田中[たなか]さんにお土産[みやげ]を＿＿。", ["あげました", "くれました", "もらいました", "くださいました"], 0, "Dei uma lembrança ao Sr. Tanaka.", "Eu dou para outra pessoa: あげる."),
            g("私[わたし]は先生[せんせい]＿＿本[ほん]をもらいました。", ["に", "が", "を", "で"], 0, "Recebi um livro do professor.", "Com もらう, quem dá é marcado com に (ou から)."),
            g("母[はは]がセーターを＿＿。とても暖[あたた]かいです。", ["くれました", "あげました", "もらいました", "あげます"], 0, "Minha mãe me deu um suéter. É bem quentinho.", "Da mãe para mim: くれる."),
            o("私[わたし]は/ユイさんに/花束[はなたば]を/もらいました", "Recebi um buquê da Yui.", "私[わたし]は/花束[はなたば]を/ユイさんに/もらいました"),
          ],
        },
        dl: {
          t: "O aniversário da Ana",
          l: `
Yui|アナさん、お誕生日[たんじょうび]おめでとう！これ、プレゼント。|Ana, feliz aniversário! Isto é um presente.
Ana|わあ、ありがとう！開[あ]けてもいい？|Uau, obrigada! Posso abrir?
Yui|どうぞ。|Claro.
Ana|かわいいマフラー！大切[たいせつ]にするね。今朝[けさ]、ケンさんも花束[はなたば]をくれたんだ。|Que cachecol lindo! Vou cuidar bem dele. Hoje de manhã o Ken também me deu um buquê.
Yui|ケンさん、優[やさ]しいね。ブラジルの家族[かぞく]からは？|O Ken é atencioso, né. E da sua família no Brasil?
Ana|母[はは]から手紙[てがみ]をもらったよ。ちょっと泣[な]いちゃった。|Recebi uma carta da minha mãe. Chorei um pouquinho.`,
          q: [
            ["O que Yui deu a Ana?", ["Um buquê", "Um cachecol", "Uma carta"], 1],
            ["O que Ana recebeu da mãe?", ["Um cachecol", "Uma carta", "Chocolate"], 1],
          ],
        },
        w: ["Escreva sobre um presente que você deu e outro que recebeu (use あげる / くれる / もらう).", "去年[きょねん]、母[はは]に花[はな]をあげました。友達[ともだち]は私[わたし]に本[ほん]をくれました。", ["dar/receber=あげ|くれ|もら"]],
      },
    ],
  },
];
