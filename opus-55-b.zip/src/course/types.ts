export type Level = "A2" | "B1";

export interface Vocab {
  id: string;
  jp: string; // with furigana markup: 朝[あさ]ご飯[はん]
  kana: string;
  romaji: string;
  pt: string;
  ex: string;
  exPt: string;
  lessonId: string;
}

export interface KanjiWord {
  jp: string;
  pt: string;
}

export interface Kanji {
  id: string;
  char: string;
  on: string;
  kun: string;
  pt: string;
  words: KanjiWord[];
  lessonId: string;
}

export interface GapEx {
  kind: "gap";
  id: string;
  jp: string; // contains ＿＿
  options: string[];
  answer: number;
  pt: string;
  exp: string;
}

export interface OrderEx {
  kind: "order";
  id: string;
  tiles: string[];
  alts: string[][];
  pt: string;
}

export type GrammarEx = GapEx | OrderEx;

export interface Grammar {
  id: string;
  title: string;
  explanation: string;
  examples: { jp: string; pt: string }[];
  exercises: GrammarEx[];
  lessonId: string;
}

export interface DialogueLine {
  speaker: string;
  jp: string;
  pt: string;
}

export interface Question {
  id: string;
  q: string;
  options: string[];
  answer: number;
}

export interface Dialogue {
  title: string;
  lines: DialogueLine[];
  questions: Question[];
}

export interface WritingCheck {
  label: string;
  any: string[];
}

export interface Writing {
  prompt: string;
  model: string;
  checks: WritingCheck[];
}

export interface Lesson {
  id: string;
  unitId: string;
  level: Level;
  index: number; // 0-based inside unit
  title: string;
  desc: string;
  vocab: Vocab[];
  kanji: Kanji[];
  grammar: Grammar;
  dialogue: Dialogue;
  writing: Writing;
}

export interface Unit {
  id: string;
  level: Level;
  levelIndex: number; // 1-based inside level
  index: number; // 1-based global
  title: string;
  desc: string;
  icon: string;
  color: string;
  lessons: Lesson[];
}

export const ACTIVITY_TYPES = ["vocab", "kanji", "grammar", "dialogue", "practice"] as const;
export type ActivityType = (typeof ACTIVITY_TYPES)[number];

export const ACTIVITY_LABEL: Record<ActivityType, string> = {
  vocab: "Vocabulário",
  kanji: "Kanji",
  grammar: "Gramática",
  dialogue: "Diálogo",
  practice: "Prática final",
};

export const ACTIVITY_DESC: Record<ActivityType, string> = {
  vocab: "Novas palavras com áudio e exemplos",
  kanji: "Leituras, significado e palavras",
  grammar: "Explicação e exercícios",
  dialogue: "Ouça, leia e responda",
  practice: "Revisão da lição e escrita",
};
