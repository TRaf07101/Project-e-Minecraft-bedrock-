import type { Level, Unit, Lesson, GrammarEx } from "./types";
import { reading, toRomaji } from "./kana";

export interface RawGap {
  kind: "gap";
  jp: string;
  options: string[];
  answer: number;
  pt: string;
  exp: string;
}
export interface RawOrder {
  kind: "order";
  tiles: string;
  pt: string;
  alts: string[];
}
export interface RawLesson {
  t: string;
  d: string;
  /** jp|pt|exemplo|tradução do exemplo (uma palavra por linha) */
  v: string;
  /** kanji|on|kun|significado|palavra=tradução;palavra=tradução */
  k: string;
  g: { t: string; e: string; x: string; q: (RawGap | RawOrder)[] };
  /** falante|jp|pt */
  dl: { t: string; l: string; q: [string, string[], number][] };
  /** [enunciado, modelo, ["rótulo=alt1|alt2"]] */
  w: [string, string, string[]];
}
export interface RawUnit {
  t: string;
  d: string;
  icon: string;
  color: string;
  lessons: RawLesson[];
}

export const g = (jp: string, options: string[], answer: number, pt: string, exp: string): RawGap => ({
  kind: "gap",
  jp,
  options,
  answer,
  pt,
  exp,
});
export const o = (tiles: string, pt: string, ...alts: string[]): RawOrder => ({ kind: "order", tiles, pt, alts });

const lines = (s: string) =>
  s
    .split("\n")
    .map((l) => l.trim())
    .filter(Boolean);

export function buildUnit(raw: RawUnit, level: Level, levelIndex: number, globalIndex: number): Unit {
  const unitId = `${level.toLowerCase()}-${levelIndex}`;
  const lessons: Lesson[] = raw.lessons.map((rl, li) => {
    const lessonId = `${unitId}-${li + 1}`;
    const vocab = lines(rl.v).map((line, i) => {
      const [jp, pt, ex, exPt] = line.split("|").map((s) => s.trim());
      const kana = reading(jp);
      return { id: `${lessonId}-v${i + 1}`, jp, kana, romaji: toRomaji(kana), pt, ex: ex ?? "", exPt: exPt ?? "", lessonId };
    });
    const kanji = lines(rl.k).map((line, i) => {
      const [char, on, kun, pt, words] = line.split("|").map((s) => s.trim());
      return {
        id: `${lessonId}-k${i + 1}`,
        char,
        on,
        kun,
        pt,
        words: (words ?? "").split(";").map((w) => {
          const [jp, wpt] = w.split("=");
          return { jp: jp.trim(), pt: (wpt ?? "").trim() };
        }),
        lessonId,
      };
    });
    const exercises: GrammarEx[] = rl.g.q.map((q, i) => {
      const id = `${lessonId}-g${i + 1}`;
      if (q.kind === "gap") return { ...q, id };
      return {
        kind: "order",
        id,
        tiles: q.tiles.split("/").map((s) => s.trim()),
        alts: q.alts.map((a) => a.split("/").map((s) => s.trim())),
        pt: q.pt,
      };
    });
    const grammar = {
      id: `${lessonId}-grammar`,
      title: rl.g.t,
      explanation: rl.g.e.trim(),
      examples: lines(rl.g.x).map((l) => {
        const [jp, pt] = l.split("|").map((s) => s.trim());
        return { jp, pt };
      }),
      exercises,
      lessonId,
    };
    const dialogue = {
      title: rl.dl.t,
      lines: lines(rl.dl.l).map((l) => {
        const [speaker, jp, pt] = l.split("|").map((s) => s.trim());
        return { speaker, jp, pt };
      }),
      questions: rl.dl.q.map(([q, options, answer], i) => ({ id: `${lessonId}-q${i + 1}`, q, options, answer })),
    };
    const writing = {
      prompt: rl.w[0],
      model: rl.w[1],
      checks: rl.w[2].map((c) => {
        const [label, alts] = c.includes("=") ? c.split("=") : [c, c];
        return { label, any: alts.split("|") };
      }),
    };
    return {
      id: lessonId,
      unitId,
      level,
      index: li,
      title: rl.t,
      desc: rl.d,
      vocab,
      kanji,
      grammar,
      dialogue,
      writing,
    };
  });
  return {
    id: unitId,
    level,
    levelIndex,
    index: globalIndex,
    title: raw.t,
    desc: raw.d,
    icon: raw.icon,
    color: raw.color,
    lessons,
  };
}
