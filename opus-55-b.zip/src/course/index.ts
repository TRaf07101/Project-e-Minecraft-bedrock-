import { buildUnit } from "./dsl";
import { A2_PART1 } from "./data/a2a";
import { A2_PART2 } from "./data/a2b";
import { B1_PART1 } from "./data/b1a";
import { B1_PART2 } from "./data/b1b";
import type { Grammar, Kanji, Lesson, Level, Unit, Vocab } from "./types";
import { hasJapanese, plain, reading } from "./kana";

export * from "./types";

const A2_RAW = [...A2_PART1, ...A2_PART2];
const B1_RAW = [...B1_PART1, ...B1_PART2];

export const UNITS: Unit[] = [
  ...A2_RAW.map((u, i) => buildUnit(u, "A2", i + 1, i + 1)),
  ...B1_RAW.map((u, i) => buildUnit(u, "B1", i + 1, A2_RAW.length + i + 1)),
];

export const LEVELS: Level[] = ["A2", "B1"];
export const LEVEL_INFO: Record<Level, { name: string; desc: string; can: string[] }> = {
  A2: {
    name: "Elementar",
    desc: "Comunique-se em situações do dia a dia: rotina, compras, saúde, planos e trabalho.",
    can: [
      "Descrever sua rotina e experiências passadas",
      "Pedir permissão, dar conselhos e entender regras",
      "Fazer convites, dar direções e falar de planos",
      "Usar a forma potencial e falar de obrigações",
    ],
  },
  B1: {
    name: "Intermediário",
    desc: "Lide com situações sociais e profissionais, dê opiniões e use keigo básico.",
    can: [
      "Transmitir notícias, boatos e recados",
      "Usar condicionais (たら・ば・なら) com naturalidade",
      "Usar keigo de respeito e de humildade no trabalho",
      "Expressar opiniões, deveres, expectativas e contrastes",
    ],
  },
};

export const unitsOf = (level: Level) => UNITS.filter((u) => u.level === level);
export const LESSONS: Lesson[] = UNITS.flatMap((u) => u.lessons);
export const ALL_VOCAB: Vocab[] = LESSONS.flatMap((l) => l.vocab);
export const ALL_KANJI: Kanji[] = LESSONS.flatMap((l) => l.kanji);
export const ALL_GRAMMAR: Grammar[] = LESSONS.map((l) => l.grammar);

export const unitById = new Map(UNITS.map((u) => [u.id, u]));
export const lessonById = new Map(LESSONS.map((l) => [l.id, l]));
export const vocabById = new Map(ALL_VOCAB.map((v) => [v.id, v]));
export const kanjiById = new Map(ALL_KANJI.map((k) => [k.id, k]));
export const grammarById = new Map(ALL_GRAMMAR.map((g) => [g.id, g]));

export const COURSE_STATS = {
  units: UNITS.length,
  lessons: LESSONS.length,
  vocab: ALL_VOCAB.length,
  kanji: ALL_KANJI.length,
  grammar: ALL_GRAMMAR.length,
  exercises: ALL_GRAMMAR.reduce((n, g) => n + g.exercises.length, 0),
  dialogues: LESSONS.length,
  questions: LESSONS.reduce((n, l) => n + l.dialogue.questions.length, 0),
};

// ───────────────────────────────── Validation (runs in the app: Ajustes → Verificação do conteúdo)
export interface Issue {
  where: string;
  msg: string;
}

const KANJI_RE = /[\u4E00-\u9FFF\u3005]/;
function checkFuri(s: string, where: string, out: Issue[]) {
  if (/\[|\]/.test(plain(s))) out.push({ where, msg: `Marcação de furigana malformada: ${s}` });
  if (KANJI_RE.test(reading(s))) out.push({ where, msg: `Kanji sem furigana: ${s}` });
}

export function validateCourse(): Issue[] {
  const out: Issue[] = [];
  const ids = new Set<string>();
  const dupe = (id: string) => {
    if (ids.has(id)) out.push({ where: id, msg: "ID duplicado" });
    ids.add(id);
  };
  for (const u of UNITS) {
    dupe(u.id);
    if (u.lessons.length !== 3) out.push({ where: u.id, msg: "Capítulo deve ter 3 lições" });
    for (const l of u.lessons) {
      dupe(l.id);
      if (l.vocab.length < 6) out.push({ where: l.id, msg: "Menos de 6 palavras" });
      for (const v of l.vocab) {
        dupe(v.id);
        if (!v.pt || !v.ex || !v.exPt || !v.romaji) out.push({ where: v.id, msg: "Campos de vocabulário incompletos" });
        checkFuri(v.jp, v.id, out);
        checkFuri(v.ex, v.id + " (exemplo)", out);
        if (KANJI_RE.test(v.kana)) out.push({ where: v.id, msg: "Leitura com kanji" });
      }
      if (l.kanji.length < 2) out.push({ where: l.id, msg: "Menos de 2 kanji" });
      for (const k of l.kanji) {
        dupe(k.id);
        if (k.char.length !== 1) out.push({ where: k.id, msg: "Kanji inválido" });
        if (k.words.length < 2) out.push({ where: k.id, msg: "Menos de 2 palavras de exemplo" });
        for (const w of k.words) {
          if (!w.pt) out.push({ where: k.id, msg: `Palavra sem tradução: ${w.jp}` });
          if (!plain(w.jp).includes(k.char)) out.push({ where: k.id, msg: `Palavra não contém o kanji: ${w.jp}` });
          checkFuri(w.jp, k.id, out);
        }
      }
      const g = l.grammar;
      if (!g.explanation || g.examples.length < 2) out.push({ where: g.id, msg: "Gramática incompleta" });
      g.examples.forEach((x, i) => {
        if (!x.pt) out.push({ where: g.id, msg: `Exemplo ${i + 1} sem tradução` });
        checkFuri(x.jp, `${g.id} ex${i + 1}`, out);
      });
      if (g.exercises.length < 5) out.push({ where: g.id, msg: "Menos de 5 exercícios" });
      for (const e of g.exercises) {
        dupe(e.id);
        if (e.kind === "gap") {
          if (!e.jp.includes("＿＿")) out.push({ where: e.id, msg: "Lacuna ＿＿ ausente" });
          if (e.answer < 0 || e.answer >= e.options.length) out.push({ where: e.id, msg: "Índice de resposta inválido" });
          if (new Set(e.options.map(plain)).size !== e.options.length) out.push({ where: e.id, msg: "Alternativas repetidas" });
          if (e.options.length < 3) out.push({ where: e.id, msg: "Poucas alternativas" });
          if (!e.pt || !e.exp) out.push({ where: e.id, msg: "Tradução/explicação ausente" });
          checkFuri(e.jp, e.id, out);
          e.options.forEach((op) => checkFuri(op, e.id + " (alternativa)", out));
        } else {
          if (e.tiles.length < 3) out.push({ where: e.id, msg: "Poucos blocos" });
          const sorted = [...e.tiles].sort().join("|");
          for (const a of e.alts)
            if ([...a].sort().join("|") !== sorted) out.push({ where: e.id, msg: "Ordem alternativa usa blocos diferentes" });
          e.tiles.forEach((t) => checkFuri(t, e.id, out));
        }
      }
      const d = l.dialogue;
      if (d.lines.length < 4) out.push({ where: l.id, msg: "Diálogo curto demais" });
      d.lines.forEach((ln, i) => {
        if (!ln.speaker || !ln.jp || !ln.pt) out.push({ where: `${l.id} fala ${i + 1}`, msg: "Fala incompleta" });
        checkFuri(ln.jp, `${l.id} fala ${i + 1}`, out);
      });
      for (const q of d.questions) {
        dupe(q.id);
        if (q.answer < 0 || q.answer >= q.options.length) out.push({ where: q.id, msg: "Índice de resposta inválido" });
        if (new Set(q.options).size !== q.options.length) out.push({ where: q.id, msg: "Alternativas repetidas" });
      }
      const w = l.writing;
      checkFuri(w.model, l.id + " (escrita)", out);
      if (!hasJapanese(w.model)) out.push({ where: l.id, msg: "Modelo de escrita sem japonês" });
      for (const c of w.checks) {
        if (!c.any.some((a) => plain(w.model).includes(a)))
          out.push({ where: l.id, msg: `O modelo não satisfaz o critério “${c.label}”` });
      }
    }
  }
  return out;
}
