// Furigana parsing + kana → romaji (Hepburn) + lenient answer comparison

const FURI_SRC = "([\\u4E00-\\u9FFF\\u3005\\u3006\\u3007\\u30F6]+)\\[([^\\]]+)\\]";

export interface Seg {
  t: string;
  r?: string;
}

export function parseFurigana(s: string): Seg[] {
  const re = new RegExp(FURI_SRC, "g");
  const out: Seg[] = [];
  let last = 0;
  let m: RegExpExecArray | null;
  while ((m = re.exec(s))) {
    if (m.index > last) out.push({ t: s.slice(last, m.index) });
    out.push({ t: m[1], r: m[2] });
    last = m.index + m[0].length;
  }
  if (last < s.length) out.push({ t: s.slice(last) });
  return out;
}

/** Text without furigana: 朝[あさ] → 朝 */
export const plain = (s: string) => s.replace(new RegExp(FURI_SRC, "g"), "$1");
/** Reading only: 朝[あさ] → あさ */
export const reading = (s: string) => s.replace(new RegExp(FURI_SRC, "g"), "$2");

export function toHiragana(s: string) {
  let out = "";
  for (const ch of s) {
    const c = ch.charCodeAt(0);
    out += c >= 0x30a1 && c <= 0x30f6 ? String.fromCharCode(c - 0x60) : ch;
  }
  return out;
}

const MAP: Record<string, string> = {};
(() => {
  const kana = "あいうえお|かきくけこ|さしすせそ|たちつてと|なにぬねの|はひふへほ|まみむめも|や-ゆ-よ|らりるれろ|わ---を|がぎぐげご|ざじずぜぞ|だぢづでど|ばびぶべぼ|ぱぴぷぺぽ".split("|");
  const roma = "a i u e o|ka ki ku ke ko|sa shi su se so|ta chi tsu te to|na ni nu ne no|ha hi fu he ho|ma mi mu me mo|ya - yu - yo|ra ri ru re ro|wa - - - o|ga gi gu ge go|za ji zu ze zo|da ji zu de do|ba bi bu be bo|pa pi pu pe po".split("|");
  kana.forEach((row, i) => {
    const rs = roma[i].split(" ");
    [...row].forEach((k, j) => {
      if (k !== "-") MAP[k] = rs[j];
    });
  });
  const yoon: Record<string, string> = { き: "ky", し: "sh", ち: "ch", に: "ny", ひ: "hy", み: "my", り: "ry", ぎ: "gy", じ: "j", ぢ: "j", び: "by", ぴ: "py" };
  for (const k of Object.keys(yoon)) {
    MAP[k + "ゃ"] = yoon[k] + "a";
    MAP[k + "ゅ"] = yoon[k] + "u";
    MAP[k + "ょ"] = yoon[k] + "o";
  }
  Object.assign(MAP, {
    ん: "n", ぁ: "a", ぃ: "i", ぅ: "u", ぇ: "e", ぉ: "o", ゔ: "vu",
    てぃ: "ti", でぃ: "di", ふぁ: "fa", ふぃ: "fi", ふぇ: "fe", ふぉ: "fo",
    うぃ: "wi", うぇ: "we", うぉ: "wo", しぇ: "she", じぇ: "je", ちぇ: "che",
    とぅ: "tu", どぅ: "du", ゔぁ: "va", ゔぃ: "vi", ゔぇ: "ve", ゔぉ: "vo",
  });
})();

export function toRomaji(input: string): string {
  const s = toHiragana(input);
  let out = "";
  let sokuon = false;
  for (let i = 0; i < s.length; i++) {
    const ch = s[i];
    if (ch === "っ") {
      sokuon = true;
      continue;
    }
    if (ch === "ー") {
      const v = out.match(/[aeiou]$/);
      if (v) out += v[0];
      continue;
    }
    let r = MAP[s.slice(i, i + 2)];
    if (r) i++;
    else r = MAP[ch];
    if (r === undefined) {
      // punctuation, latin, etc.
      const map: Record<string, string> = { "、": ", ", "。": ". ", "？": "? ", "！": "! ", "　": " " };
      r = map[ch] ?? ch;
    } else if (sokuon) {
      r = (r.startsWith("ch") ? "t" : r[0]) + r;
    }
    sokuon = false;
    out += r;
  }
  return out.trim();
}

export function normalizeRomaji(s: string) {
  let r = s
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
  r = r.replace(/[^a-z']/g, "");
  r = r
    .replace(/n'/g, "n")
    .replace(/'/g, "")
    .replace(/sy/g, "sh")
    .replace(/ty/g, "ch")
    .replace(/zy|jy/g, "j")
    .replace(/si/g, "shi")
    .replace(/ti/g, "chi")
    .replace(/tu/g, "tsu")
    .replace(/hu/g, "fu")
    .replace(/zi|di/g, "ji")
    .replace(/du/g, "zu")
    .replace(/wo/g, "o")
    .replace(/m(?=[bpm])/g, "n")
    .replace(/nn/g, "n")
    .replace(/ou|oo/g, "o")
    .replace(/uu/g, "u")
    .replace(/aa/g, "a")
    .replace(/ii/g, "i")
    .replace(/ee|ei/g, "e");
  return r;
}

const strip = (s: string) => s.replace(/[\s　。、.,!?！？・]/g, "");

/** Accepts kanji, kana (hiragana/katakana) or romaji (Hepburn or Kunrei, with or without long vowels). */
export function checkTyped(input: string, jp: string, kana: string): boolean {
  const raw = strip(input.trim());
  if (!raw) return false;
  if (raw === strip(plain(jp))) return true;
  if (toHiragana(raw) === toHiragana(strip(kana))) return true;
  const userR = /[\u3040-\u30ff]/.test(raw) ? toRomaji(raw) : raw;
  return normalizeRomaji(userR) === normalizeRomaji(toRomaji(strip(kana)));
}

export const hasJapanese = (s: string) => /[\u3040-\u30ff\u4e00-\u9fff]/.test(s);
