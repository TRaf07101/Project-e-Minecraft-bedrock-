// @ts-check
// ProjectE para Minecraft Bedrock — port não oficial do ProjectE (MIT, sinkillerj/ProjectE).
// Script API estável: @minecraft/server 2.0.0 / @minecraft/server-ui 2.0.0 (Minecraft 1.21.90+).
import { world, system, ItemStack, BlockPermutation, EquipmentSlot, Direction, EntityDamageCause, InputButton, ButtonState } from "@minecraft/server";
import { ActionFormData, ModalFormData, FormCancelationReason } from "@minecraft/server-ui";
import { EMC, WORLD_TRANSMUTATIONS, SMELTING, NAMES, ICONS } from "./emc_data.js";

/** @typedef {import("@minecraft/server").Player} Player */
/** @typedef {import("@minecraft/server").Block} Block */
/** @typedef {import("@minecraft/server").Container} Container */
/** @typedef {import("@minecraft/server").Dimension} Dimension */
/** @typedef {import("@minecraft/server").Vector3} Vector3 */
/** @typedef {import("@minecraft/server").RawMessage} RawMessage */
/** @typedef {{id: string, n: number}} VStack */
/** @typedef {{t: string, d: string, x: number, y: number, z: number, emc: number, frac: number, inv: VStack[], lock: string | null, star: {id: string, emc: number} | null}} Machine */

// ───────────────────────────────────────────── constantes (valores do ProjectE)
const P = "projecte:";
const PHIL = P + "philosophers_stone";
const TABLET = P + "transmutation_tablet";
const TABLE = P + "transmutation_table";
const TOME = P + "tome_of_knowledge";
const TALISMAN = P + "repair_talisman";
const BHB = P + "black_hole_band";
const EVERTIDE = P + "evertide_amulet";
const VOLCANITE = P + "volcanite_amulet";
const CONDENSER = P + "condenser";
const CHEST = P + "alchemical_chest";
const CONDENSER_SLOTS = 91; // CondenserBlockEntity: StackHandler(91)
const CHEST_SLOTS = 104; // Alchemical Chest: 104 espaços
const VOLCANITE_COST = 32;

/** KleinStar.KleinTier */
/** @type {Record<string, number>} */
const KLEIN = {
  [P + "klein_star_ein"]: 50000,
  [P + "klein_star_zwei"]: 200000,
  [P + "klein_star_drei"]: 800000,
  [P + "klein_star_vier"]: 3200000,
  [P + "klein_star_sphere"]: 12800000,
  [P + "klein_star_omega"]: 51200000,
};
/** EnumCollectorTier (geração por segundo com luz máxima, armazenamento) */
/** @type {Record<string, {gen: number, cap: number}>} */
const COLLECTORS = {
  [P + "collector_mk1"]: { gen: 4, cap: 10000 },
  [P + "collector_mk2"]: { gen: 12, cap: 30000 },
  [P + "collector_mk3"]: { gen: 40, cap: 60000 },
};
/** EnumRelayTier (taxa de saída, armazenamento) */
/** @type {Record<string, {rate: number, cap: number}>} */
const RELAYS = {
  [P + "relay_mk1"]: { rate: 64, cap: 100000 },
  [P + "relay_mk2"]: { rate: 192, cap: 1000000 },
  [P + "relay_mk3"]: { rate: 640, cap: 10000000 },
};
const CONDENSER_MK2 = P + "condenser_mk2";
const TORCH = P + "interdiction_torch";
/** @param {string} t */
const isCondenser = (t) => t === CONDENSER || t === CONDENSER_MK2;
const MACHINE_TYPES = new Set([...Object.keys(COLLECTORS), ...Object.keys(RELAYS), CONDENSER, CONDENSER_MK2, CHEST, TORCH]);
/** Varas de adivinhação: profundidade da varredura 3x3 */
/** @type {Record<string, number>} */
const DIVINING = { [P + "low_divining_rod"]: 3, [P + "medium_divining_rod"]: 16, [P + "high_divining_rod"]: 64 };
/** Receitas de conversão com a Pedra Filosofal (PERecipeProvider: fuelUpgradeRecipe + addConversionRecipes) */
/** @type {[string, number, string, number][]} */
const PHILO_CONVERSIONS = [];
(() => {
  /** @type {[string, number, string, number][]} */
  const base = [
    ["minecraft:coal", 4, P + "alchemical_coal", 1],
    [P + "alchemical_coal", 4, P + "mobius_fuel", 1],
    [P + "mobius_fuel", 4, P + "aeternalis_fuel", 1],
    ["minecraft:charcoal", 4, "minecraft:coal", 1],
    ["minecraft:diamond", 2, "minecraft:emerald", 1],
    ["minecraft:gold_ingot", 4, "minecraft:diamond", 1],
    ["minecraft:iron_ingot", 8, "minecraft:gold_ingot", 1],
    ["minecraft:iron_ingot", 4, "minecraft:ender_pearl", 1],
  ];
  for (const [a, an, b, bn] of base) PHILO_CONVERSIONS.push([a, an, b, bn], [b, bn, a, an]);
})();
/** Drops diretos de minérios (para a vara de adivinhação, que mede o EMC dos drops) */
/** @type {Record<string, string>} */
const ORE_DROPS = {
  "minecraft:coal_ore": "minecraft:coal",
  "minecraft:deepslate_coal_ore": "minecraft:coal",
  "minecraft:diamond_ore": "minecraft:diamond",
  "minecraft:deepslate_diamond_ore": "minecraft:diamond",
  "minecraft:emerald_ore": "minecraft:emerald",
  "minecraft:deepslate_emerald_ore": "minecraft:emerald",
  "minecraft:lapis_ore": "minecraft:lapis_lazuli",
  "minecraft:deepslate_lapis_ore": "minecraft:lapis_lazuli",
  "minecraft:redstone_ore": "minecraft:redstone",
  "minecraft:deepslate_redstone_ore": "minecraft:redstone",
  "minecraft:lit_redstone_ore": "minecraft:redstone",
  "minecraft:lit_deepslate_redstone_ore": "minecraft:redstone",
  "minecraft:quartz_ore": "minecraft:quartz",
  "minecraft:nether_gold_ore": "minecraft:gold_nugget",
  "minecraft:stone": "minecraft:cobblestone",
  "minecraft:deepslate": "minecraft:cobbled_deepslate",
  "minecraft:grass_block": "minecraft:dirt",
};
const UNBREAKABLE = new Set([
  "minecraft:bedrock", "minecraft:barrier", "minecraft:end_portal_frame", "minecraft:end_portal", "minecraft:portal",
  "minecraft:command_block", "minecraft:chain_command_block", "minecraft:repeating_command_block", "minecraft:structure_block",
  "minecraft:jigsaw", "minecraft:light_block", "minecraft:reinforced_deepslate", "minecraft:allow", "minecraft:deny", "minecraft:border_block",
]);

const WT = new Map(WORLD_TRANSMUTATIONS.map(([a, b, c]) => [a, [b, c]]));

// ───────────────────────────────────────────── utilidades
/** @param {number} n */
const fmt = (n) => Math.floor(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
/** @param {string} id */
const pretty = (id) => NAMES[id] ?? (id.split(":")[1] ?? id).replace(/_/g, " ");
/** @param {string} id */
const emcOf = (id) => EMC[id] ?? 0;

/** @type {Map<string, string | undefined>} */
const locCache = new Map();
/** @param {string} id */
function locKey(id) {
  if (locCache.has(id)) return locCache.get(id);
  let key;
  try {
    const s = /** @type {any} */ (new ItemStack(id, 1));
    key = typeof s.localizationKey === "string" ? s.localizationKey : undefined;
  } catch {
    key = undefined;
  }
  locCache.set(id, key);
  return key;
}
/** @param {string} id @returns {RawMessage} */
function nameMsg(id) {
  if (NAMES[id]) return { text: NAMES[id] };
  const k = locKey(id);
  return k ? { translate: k } : { text: pretty(id) };
}
/** @param {string} id @param {string} suffix @returns {RawMessage} */
function label(id, suffix) {
  return { rawtext: [nameMsg(id), { text: suffix }] };
}

/** @type {Map<string, number>} */
const stackCache = new Map();
/** @param {string} id */
function maxStack(id) {
  let m = stackCache.get(id);
  if (m === undefined) {
    try {
      m = new ItemStack(id, 1).maxAmount;
    } catch {
      m = 0;
    }
    stackCache.set(id, m);
  }
  return m;
}

/** @param {Player} p @returns {Container} */
function inv(p) {
  const c = /** @type {import("@minecraft/server").EntityInventoryComponent} */ (p.getComponent("minecraft:inventory"));
  return /** @type {Container} */ (c.container);
}

/** @param {Player} p @param {string} msg */
function tell(p, msg) {
  try {
    p.sendMessage(msg);
  } catch {
    /* jogador saiu */
  }
}

/** @param {Player} p @param {string} sound */
function sound(p, sound) {
  try {
    p.playSound(sound);
  } catch {
    /* ignore */
  }
}

/** Mostra um formulário, repetindo se o jogador estiver ocupado (ex.: chat aberto). */
/**
 * @template {{show(p: Player): Promise<any>}} F
 * @param {F} form @param {Player} p
 * @returns {Promise<Awaited<ReturnType<F["show"]>> | undefined>}
 */
async function show(form, p) {
  for (let i = 0; i < 10; i++) {
    let r;
    try {
      r = await form.show(p);
    } catch {
      return undefined;
    }
    if (r.canceled && r.cancelationReason === FormCancelationReason.UserBusy) {
      await system.waitTicks(10);
      continue;
    }
    return r;
  }
  return undefined;
}

/** @param {import("@minecraft/server-ui").ModalFormResponse | undefined} r @param {number} i */
function formNum(r, i) {
  if (!r || r.canceled || !r.formValues) return NaN;
  const v = r.formValues[i];
  return typeof v === "number" ? v : Math.floor(Number(String(v ?? "").replace(/\./g, "").trim()));
}

/** @param {Direction | undefined} face @returns {Vector3} */
function faceVec(face) {
  switch (face) {
    case Direction.Up: return { x: 0, y: 1, z: 0 };
    case Direction.Down: return { x: 0, y: -1, z: 0 };
    case Direction.North: return { x: 0, y: 0, z: -1 };
    case Direction.South: return { x: 0, y: 0, z: 1 };
    case Direction.East: return { x: 1, y: 0, z: 0 };
    case Direction.West: return { x: -1, y: 0, z: 0 };
    default: return { x: 0, y: 1, z: 0 };
  }
}

// ───────────────────────────────────────────── persistência em propriedades dinâmicas
const CHUNK = 30000;
/** @param {Player | import("@minecraft/server").World} h @param {string} key @param {unknown} value */
function writeChunked(h, key, value) {
  const s = JSON.stringify(value);
  const n = Math.max(1, Math.ceil(s.length / CHUNK));
  const old = Number(h.getDynamicProperty(key + "#n") ?? 0);
  for (let i = 0; i < n; i++) h.setDynamicProperty(`${key}#${i}`, s.slice(i * CHUNK, (i + 1) * CHUNK));
  for (let i = n; i < old; i++) h.setDynamicProperty(`${key}#${i}`, undefined);
  h.setDynamicProperty(key + "#n", n);
}
/** @param {Player | import("@minecraft/server").World} h @param {string} key */
function clearChunked(h, key) {
  const old = Number(h.getDynamicProperty(key + "#n") ?? 0);
  for (let i = 0; i < old; i++) h.setDynamicProperty(`${key}#${i}`, undefined);
  h.setDynamicProperty(key + "#n", undefined);
}
/** @template T @param {Player | import("@minecraft/server").World} h @param {string} key @param {T} fallback @returns {T} */
function readChunked(h, key, fallback) {
  const n = Number(h.getDynamicProperty(key + "#n") ?? 0);
  if (!n) return fallback;
  let s = "";
  for (let i = 0; i < n; i++) {
    const part = h.getDynamicProperty(`${key}#${i}`);
    if (typeof part !== "string") return fallback;
    s += part;
  }
  try {
    return JSON.parse(s);
  } catch {
    return fallback;
  }
}

// ───────────────────────────────────────────── EMC pessoal e conhecimento
/** @param {Player} p */
function getEmc(p) {
  const v = p.getDynamicProperty("pe:emc");
  return typeof v === "number" && Number.isFinite(v) ? v : 0;
}
/** @param {Player} p @param {number} v */
function setEmc(p, v) {
  p.setDynamicProperty("pe:emc", Math.max(0, Math.floor(v)));
}
/** @type {Map<string, Set<string>>} */
const knowCache = new Map();
/** @param {Player} p */
function knowledge(p) {
  let s = knowCache.get(p.id);
  if (!s) {
    s = new Set(readChunked(p, "pe:know", /** @type {string[]} */ ([])));
    knowCache.set(p.id, s);
  }
  return s;
}
/** @param {Player} p */
function saveKnowledge(p) {
  writeChunked(p, "pe:know", [...knowledge(p)]);
}
/** @param {Player} p @param {string} id */
function learn(p, id) {
  const k = knowledge(p);
  if (k.has(id) || emcOf(id) <= 0) return false;
  k.add(id);
  saveKnowledge(p);
  return true;
}

// ───────────────────────────────────────────── itens
/** @param {ItemStack} it */
function starEmc(it) {
  const v = it.getDynamicProperty("pe:emc");
  return typeof v === "number" ? v : 0;
}
/** @param {ItemStack} it @param {number} v */
function setStarEmc(it, v) {
  const max = KLEIN[it.typeId] ?? 0;
  const e = Math.max(0, Math.min(max, Math.floor(v)));
  it.setDynamicProperty("pe:emc", e);
  it.setLore([`§r§7EMC: §e${fmt(e)}§7 / ${fmt(max)}`]);
}
/** @param {ItemStack} it */
function hasEnchant(it) {
  try {
    const e = /** @type {import("@minecraft/server").ItemEnchantableComponent | undefined} */ (it.getComponent("minecraft:enchantable"));
    return !!e && e.getEnchantments().length > 0;
  } catch {
    return false;
  }
}
/** @param {ItemStack} it */
function durability(it) {
  try {
    return /** @type {import("@minecraft/server").ItemDurabilityComponent | undefined} */ (it.getComponent("minecraft:durability"));
  } catch {
    return undefined;
  }
}
/** Valor de venda de 1 unidade (ProjectE: itens danificados valem proporcionalmente à durabilidade restante). */
/** @param {ItemStack} it */
function unitEmc(it) {
  const base = emcOf(it.typeId);
  if (base <= 0) return 0;
  let v = base;
  const d = durability(it);
  if (d && d.maxDurability > 0 && d.damage > 0) v = Math.max(1, Math.floor((base * (d.maxDurability - d.damage)) / d.maxDurability));
  if (KLEIN[it.typeId]) v += starEmc(it);
  return v;
}
/** Item simples, sem dados extras: pode ir para inventários virtuais sem perder nada. */
/** @param {ItemStack} it */
function isPlain(it) {
  if (it.maxAmount <= 1) return false;
  if (it.nameTag) return false;
  if (it.getLore().length > 0) return false;
  if (hasEnchant(it)) return false;
  return true;
}

/** Entrega itens ao jogador; o que não couber cai aos pés dele. @returns {number} quantidade entregue */
/** @param {Player} p @param {string} id @param {number} count */
function giveItems(p, id, count) {
  const max = maxStack(id);
  if (max <= 0) return 0;
  const c = inv(p);
  let given = 0;
  while (given < count) {
    const n = Math.min(max, count - given);
    let stack;
    try {
      stack = new ItemStack(id, n);
    } catch {
      break;
    }
    const rest = c.addItem(stack);
    if (rest) p.dimension.spawnItem(rest, p.location);
    given += n;
  }
  return given;
}
/** @param {Container} c @param {string} id */
function countPlain(c, id) {
  let n = 0;
  for (let i = 0; i < c.size; i++) {
    const it = c.getItem(i);
    if (it && it.typeId === id && isPlain(it)) n += it.amount;
  }
  return n;
}
/** @param {Container} c @param {string} id @param {number} n @returns {number} removidos */
function removePlain(c, id, n) {
  let left = n;
  for (let i = 0; i < c.size && left > 0; i++) {
    const it = c.getItem(i);
    if (!it || it.typeId !== id || !isPlain(it)) continue;
    const take = Math.min(left, it.amount);
    if (take >= it.amount) c.setItem(i, undefined);
    else {
      it.amount -= take;
      c.setItem(i, it);
    }
    left -= take;
  }
  return n - left;
}
/** Consome EMC das Klein Stars do inventário (como os itens do ProjectE que usam combustível/EMC). */
/** @param {Player} p @param {number} amount */
function consumeStarEmc(p, amount) {
  const c = inv(p);
  /** @type {number[]} */
  const slots = [];
  let total = 0;
  for (let i = 0; i < c.size; i++) {
    const it = c.getItem(i);
    if (it && KLEIN[it.typeId]) {
      slots.push(i);
      total += starEmc(it);
    }
  }
  if (total < amount) return false;
  let left = amount;
  for (const i of slots) {
    if (left <= 0) break;
    const it = /** @type {ItemStack} */ (c.getItem(i));
    const take = Math.min(starEmc(it), left);
    setStarEmc(it, starEmc(it) - take);
    c.setItem(i, it);
    left -= take;
  }
  return true;
}

// ───────────────────────────────────────────── debounce de interação
/** @type {Map<string, number>} */
const lastBlockUse = new Map();
/** @param {Player} p */
const markBlockUse = (p) => lastBlockUse.set(p.id, Date.now());
/** @param {Player} p */
const recentBlockUse = (p) => Date.now() - (lastBlockUse.get(p.id) ?? 0) < 400;

// ───────────────────────────────────────────── Mesa / Tablete de Transmutação
// Interface portada de GUITransmutation + TransmutationContainer + TransmutationInventory (ProjectE mc1.21.1).
// O formulário é desenhado pelo pacote de recursos (ui/server_form.json) quando o título começa com TABLE_MARK.
// Ordem dos botões (índices usados pelo JSON UI):
//   0-11 matéria (anel externo) • 12-15 combustíveis (anel interno) • 16 trava (centro) • 17 queimar • 18 desaprender
//   19-26 entradas (círculo esquerdo) • 27 pesquisa • 28 « • 29 » • 30-65 inventário do jogador (índice do contêiner)
const TABLE_MARK = "pe:table:";
const MAX_MATTER = 12; // TransmutationInventory.MAX_MATTER_DISPLAY
const MAX_FUEL = 4; // TransmutationInventory.MAX_FUEL_DISPLAY
const BTN = { MATTER: 0, FUEL: 12, LOCK: 16, BURN: 17, UNLEARN: 18, INPUT: 19, SEARCH: 27, PREV: 28, NEXT: 29, INV: 30 };
const INPUT_SLOTS = 8;
/** data/projecte/tags/item/collector_fuel.json */
const COLLECTOR_FUEL = new Set([
  "minecraft:charcoal", "minecraft:redstone", "minecraft:redstone_block", "minecraft:coal", "minecraft:coal_block",
  "minecraft:gunpowder", "minecraft:glowstone_dust", "minecraft:blaze_powder", "minecraft:glowstone",
  P + "alchemical_coal", P + "alchemical_coal_block", P + "mobius_fuel", P + "mobius_fuel_block", P + "aeternalis_fuel", P + "aeternalis_fuel_block",
]);
const LEARN_FLAG_MS = 15000; // learnFlag = 300 ticks

/** @typedef {{id: string, n: number, emc?: number} | null} TSlot */
/** @param {Player} p @returns {TSlot[]} */
function tInputs(p) {
  const v = readChunked(p, "pe:tin", /** @type {TSlot[] | null} */ (null));
  const arr = Array.isArray(v) ? v.slice(0, INPUT_SLOTS) : [];
  while (arr.length < INPUT_SLOTS) arr.push(null);
  return arr;
}
/** @param {Player} p @param {TSlot[]} arr */
const saveInputs = (p, arr) => writeChunked(p, "pe:tin", arr);
/** @param {Player} p @returns {TSlot} */
const tLock = (p) => readChunked(p, "pe:tlock", /** @type {TSlot} */ (null));
/** @param {Player} p @param {TSlot} v */
function saveLock(p, v) {
  if (v) writeChunked(p, "pe:tlock", v);
  else clearChunked(p, "pe:tlock");
}

/** getAvailableEmc: EMC pessoal + Klein Stars nos slots de entrada. @param {Player} p */
function availableEmc(p) {
  let e = getEmc(p);
  for (const s of tInputs(p)) if (s && KLEIN[s.id]) e += s.emc ?? 0;
  return e;
}
/** addEmc: enche primeiro as Klein Stars das entradas; o excedente vai para o EMC pessoal. @param {Player} p @param {number} value */
function tableAddEmc(p, value) {
  const ins = tInputs(p);
  let changed = false;
  for (const s of ins) {
    if (value <= 0) break;
    if (!s || !KLEIN[s.id]) continue;
    const add = Math.min(value, KLEIN[s.id] - (s.emc ?? 0));
    if (add > 0) {
      s.emc = (s.emc ?? 0) + add;
      value -= add;
      changed = true;
    }
  }
  if (changed) saveInputs(p, ins);
  if (value > 0) setEmc(p, getEmc(p) + value);
}
/** removeEmc: retira do EMC pessoal e, se faltar, das Klein Stars das entradas. @param {Player} p @param {number} value */
function tableRemoveEmc(p, value) {
  if (availableEmc(p) < value) return false;
  const personal = getEmc(p);
  if (value <= personal) {
    setEmc(p, personal - value);
    return true;
  }
  let rest = value - personal;
  const ins = tInputs(p);
  for (const s of ins) {
    if (rest <= 0) break;
    if (!s || !KLEIN[s.id]) continue;
    const take = Math.min(rest, s.emc ?? 0);
    s.emc = (s.emc ?? 0) - take;
    rest -= take;
  }
  saveInputs(p, ins);
  setEmc(p, 0);
  return true;
}

/** @param {string} id */
const iconFor = (id) => ICONS[id] ?? "textures/ui/projecte/unknown";
/** Texto do botão: [marca 1 char][quantidade 3 chars][dica]. O JSON UI separa as partes com '%.1s' e '%.4s'. */
/** @param {string} flag @param {number} count @param {RawMessage[]} tip @returns {RawMessage} */
function slotText(flag, count, tip) {
  const c = count > 1 ? String(Math.min(999, count)).padStart(3, " ") : "   ";
  return { rawtext: [{ text: flag + c }, ...tip] };
}
/** @param {string} id @param {number} [stored] @returns {RawMessage[]} */
function itemTip(id, stored) {
  /** @type {RawMessage[]} */
  const t = [nameMsg(id)];
  if (KLEIN[id]) t.push({ text: `\n§bEMC: ${fmt(stored ?? 0)} / ${fmt(KLEIN[id])}` });
  else if (emcOf(id) > 0) t.push({ text: `\n§eEMC: ${fmt(emcOf(id))}` });
  return t;
}
/** @param {string} id @param {string} filter */
function matchesFilter(id, filter) {
  if (!filter) return true;
  const words = (id.split(":")[1] ?? id).replace(/_/g, " ");
  return words.includes(filter) || id.includes(filter) || (NAMES[id] ?? "").toLowerCase().includes(filter);
}

/** @typedef {{page: number, filter: string, sel: number, flag: string, flagUntil: number}} TableState */

/** updateClientTargets: monta os 16 itens exibidos. @param {Player} p @param {TableState} st */
function tableTargets(p, st) {
  const k = knowledge(p);
  const avail = availableEmc(p);
  const lock = tLock(p);
  /** @type {string[]} */
  const matter = [];
  /** @type {string[]} */
  const fuel = [];
  let limit = avail;
  let lockId = null;
  if (lock && emcOf(lock.id) > 0 && emcOf(lock.id) <= avail && k.has(lock.id) && maxStack(lock.id) > 0) {
    lockId = lock.id;
    limit = emcOf(lock.id);
    (COLLECTOR_FUEL.has(lock.id) ? fuel : matter).push(lock.id);
  }
  const list = [...k]
    .filter((id) => id !== lockId && emcOf(id) > 0 && emcOf(id) <= limit && maxStack(id) > 0 && matchesFilter(id, st.filter))
    .sort((a, b) => emcOf(b) - emcOf(a) || a.localeCompare(b));
  const skip = st.page * (MAX_MATTER - matter.length);
  let skipped = 0;
  let more = false;
  for (const id of list) {
    if (COLLECTOR_FUEL.has(id)) {
      if (fuel.length < MAX_FUEL) fuel.push(id);
      continue;
    }
    if (skipped < skip) {
      skipped++;
      continue;
    }
    if (matter.length < MAX_MATTER) matter.push(id);
    else more = true;
  }
  return { matter, fuel, avail, hasNext: more, hasPrev: st.page > 0 };
}

/** @param {Player} p @param {TableState} st */
function buildTableForm(p, st) {
  const t = tableTargets(p, st);
  const c = inv(p);
  const f = new ActionFormData().title(TABLE_MARK + st.flag).body(`EMC:\n${fmt(t.avail)}`);
  /** @type {(string | null)[]} */
  const outputs = [];
  for (let i = 0; i < MAX_MATTER; i++) outputs.push(t.matter[i] ?? null);
  for (let i = 0; i < MAX_FUEL; i++) outputs.push(t.fuel[i] ?? null);
  for (const id of outputs) {
    if (id) f.button(slotText(" ", 1, itemTip(id)), iconFor(id));
    else f.button("    ");
  }
  const lock = tLock(p);
  if (lock) f.button(slotText(" ", lock.n, itemTip(lock.id, lock.emc)), iconFor(lock.id));
  else f.button(slotText(" ", 1, [{ text: "Trava: coloque um item para filtrar\npor valor de EMC" }]));
  f.button(slotText(" ", 1, [{ text: "Queimar\n§7Selecione um item do inventário\n§7e clique aqui" }]));
  f.button(slotText(" ", 1, [{ text: "Desaprender\n§7Selecione um item do inventário\n§7e clique aqui" }]));
  for (const s of tInputs(p)) {
    if (s) f.button(slotText(" ", s.n, itemTip(s.id, s.emc)), iconFor(s.id));
    else f.button("    ");
  }
  f.button("    " + (st.filter || "§8Pesquisar..."));
  f.button((t.hasPrev ? " " : "-") + "   <");
  f.button((t.hasNext ? " " : "-") + "   >");
  for (let i = 0; i < 36; i++) {
    const it = i < c.size ? c.getItem(i) : undefined;
    if (!it) {
      f.button((st.sel === i ? "*" : " ") + "   ");
      continue;
    }
    f.button(slotText(st.sel === i ? "*" : " ", it.amount, itemTip(it.typeId, KLEIN[it.typeId] ? starEmc(it) : undefined)), iconFor(it.typeId));
  }
  return { form: f, outputs, t };
}

/** @param {Player} p */
async function transmutationMenu(p) {
  /** @type {TableState} */
  const st = { page: 0, filter: "", sel: -1, flag: "-", flagUntil: 0 };
  for (;;) {
    if (st.flag !== "-" && Date.now() > st.flagUntil) st.flag = "-";
    const view = buildTableForm(p, st);
    const r = await show(view.form, p);
    if (!r || r.canceled || r.selection === undefined) return;
    try {
      await tableClick(p, st, view, r.selection);
    } catch (e) {
      console.warn("[ProjectE] mesa de transmutação: " + e);
    }
  }
}

/** @param {TableState} st @param {"L" | "U"} f */
function setFlag(st, f) {
  st.flag = f;
  st.flagUntil = Date.now() + LEARN_FLAG_MS;
}
/** Item com EMC ou que guarda EMC (SlotPredicates.RELAY_INV). @param {ItemStack} it */
const relayAccepts = (it) => !!KLEIN[it.typeId] || (emcOf(it.typeId) > 0 && isPlain(it));
/** Devolve um item de slot virtual ao inventário (o que não couber cai no chão). @param {Player} p @param {NonNullable<TSlot>} s */
function returnSlot(p, s) {
  if (KLEIN[s.id]) {
    const st = new ItemStack(s.id, 1);
    setStarEmc(st, s.emc ?? 0);
    const rest = inv(p).addItem(st);
    if (rest) p.dimension.spawnItem(rest, p.location);
  } else giveItems(p, s.id, s.n);
}

/** @param {Player} p @param {TableState} st @param {ReturnType<typeof buildTableForm>} view @param {number} i */
async function tableClick(p, st, view, i) {
  const c = inv(p);
  const sel = st.sel >= 0 && st.sel < c.size ? c.getItem(st.sel) : undefined;
  // ── saídas (transmutar)
  if (i < BTN.LOCK) {
    const id = view.outputs[i];
    if (id) await tableTake(p, id);
    return;
  }
  // ── inventário: selecionar / desmarcar
  if (i >= BTN.INV) {
    const slot = i - BTN.INV;
    st.sel = st.sel === slot || !c.getItem(slot) ? -1 : slot;
    return;
  }
  if (i === BTN.SEARCH) {
    const m = await show(new ModalFormData().title("Pesquisar").textField("Filtrar itens (deixe vazio para limpar)", "diamond", { defaultValue: st.filter }), p);
    if (m && !m.canceled && m.formValues) {
      st.filter = String(m.formValues[0] ?? "").trim().toLowerCase();
      st.page = 0;
    }
    return;
  }
  if (i === BTN.PREV) {
    if (view.t.hasPrev) st.page--;
    return;
  }
  if (i === BTN.NEXT) {
    if (view.t.hasNext) st.page++;
    return;
  }
  // ── queimar (SlotConsume)
  if (i === BTN.BURN) {
    if (!sel) return tell(p, "§7Selecione um item do inventário e depois clique no espaço de queima.");
    if (sel.typeId === TOME) {
      c.setItem(st.sel, undefined);
      const k = knowledge(p);
      for (const id of Object.keys(EMC)) if (EMC[id] > 0 && maxStack(id) > 0) k.add(id);
      saveKnowledge(p);
      setFlag(st, "L");
      sound(p, "random.levelup");
    } else {
      const v = unitEmc(sel);
      if (v <= 0 || hasEnchant(sel)) return tell(p, "§cEste item não pode ser queimado.");
      const total = v * sel.amount;
      c.setItem(st.sel, undefined);
      tableAddEmc(p, total);
      if (learn(p, sel.typeId)) setFlag(st, "L");
      sound(p, "random.fizz");
    }
    st.sel = -1;
    return;
  }
  // ── desaprender (SlotUnlearn): o item continua com o jogador
  if (i === BTN.UNLEARN) {
    if (!sel) return tell(p, "§7Selecione um item do inventário e depois clique no espaço de desaprender.");
    if (knowledge(p).delete(sel.typeId)) {
      saveKnowledge(p);
      setFlag(st, "U");
      sound(p, "random.break");
    } else tell(p, "§7Você não conhece este item.");
    st.sel = -1;
    return;
  }
  // ── trava (SlotLock): filtra pelo EMC do item; Klein Star é esvaziada para o EMC pessoal
  if (i === BTN.LOCK) {
    const cur = tLock(p);
    if (sel) {
      if (!relayAccepts(sel)) return tell(p, "§cSó itens com EMC podem ir para a trava.");
      /** @type {NonNullable<TSlot>} */
      const slot = { id: sel.typeId, n: sel.amount };
      if (KLEIN[sel.typeId]) {
        setEmc(p, getEmc(p) + starEmc(sel));
        slot.emc = 0;
      }
      c.setItem(st.sel, undefined);
      if (cur) returnSlot(p, cur);
      saveLock(p, slot);
      if (emcOf(slot.id) > 0 && learn(p, slot.id)) setFlag(st, "L");
      st.sel = -1;
      st.page = 0;
    } else if (cur) {
      saveLock(p, null);
      returnSlot(p, cur);
      st.page = 0;
    }
    return;
  }
  // ── entradas (SlotInput): Klein Stars aqui somam ao EMC disponível e recebem o EMC pessoal
  if (i >= BTN.INPUT && i < BTN.INPUT + INPUT_SLOTS) {
    const idx = i - BTN.INPUT;
    const ins = tInputs(p);
    const cur = ins[idx];
    if (sel) {
      if (!relayAccepts(sel)) return tell(p, "§cSó itens com EMC podem ir para os espaços de entrada.");
      if (cur && !(cur.id === sel.typeId && !KLEIN[cur.id])) return tell(p, "§7Este espaço está ocupado. Clique nele sem seleção para retirar o item.");
      if (KLEIN[sel.typeId]) {
        let stored = starEmc(sel);
        const personal = getEmc(p);
        const ins2 = Math.min(personal, KLEIN[sel.typeId] - stored);
        stored += ins2;
        setEmc(p, personal - ins2);
        ins[idx] = { id: sel.typeId, n: 1, emc: stored };
        c.setItem(st.sel, undefined);
      } else {
        const max = Math.max(1, maxStack(sel.typeId));
        const have = cur ? cur.n : 0;
        const move = Math.min(sel.amount, max - have);
        if (move <= 0) return;
        ins[idx] = { id: sel.typeId, n: have + move };
        if (move >= sel.amount) c.setItem(st.sel, undefined);
        else {
          sel.amount -= move;
          c.setItem(st.sel, sel);
        }
      }
      saveInputs(p, ins);
      if (emcOf(sel.typeId) > 0 && learn(p, sel.typeId)) setFlag(st, "L");
      st.sel = -1;
    } else if (cur) {
      ins[idx] = null;
      saveInputs(p, ins);
      returnSlot(p, cur);
    }
  }
}

/** Retirar um item transmutado (clique = 1, ou uma pilha inteira como o shift-clique do original). @param {Player} p @param {string} id */
async function tableTake(p, id) {
  const cost = emcOf(id);
  if (cost <= 0 || !knowledge(p).has(id)) return;
  const stack = Math.max(1, maxStack(id));
  const affordable = Math.floor(availableEmc(p) / cost);
  if (affordable < 1) return tell(p, "§cEMC insuficiente.");
  let n = 1;
  if (stack > 1 && affordable > 1) {
    const r = await show(
      new ActionFormData()
        .title({ rawtext: [nameMsg(id)] })
        .body(`Custo: ${fmt(cost)} EMC cada\nVocê pode criar até ${fmt(Math.min(affordable, 2304))}.`)
        .button("Pegar 1", iconFor(id))
        .button(`Pegar uma pilha (${Math.min(stack, affordable)})`)
        .button("Outra quantidade...")
        .button("Cancelar"),
      p
    );
    if (!r || r.canceled || r.selection === undefined || r.selection === 3) return;
    if (r.selection === 1) n = Math.min(stack, affordable);
    else if (r.selection === 2) {
      const m = await show(new ModalFormData().title("Quantidade").textField(`1 a ${fmt(Math.min(affordable, 2304))}`, "1", { defaultValue: "1" }), p);
      n = formNum(m, 0);
      if (!Number.isFinite(n) || n < 1) return;
    }
  }
  n = Math.min(n, 2304, Math.floor(availableEmc(p) / cost));
  if (n < 1 || !tableRemoveEmc(p, n * cost)) return;
  const given = giveItems(p, id, n);
  if (given < n) tableAddEmc(p, (n - given) * cost); // devolve o que não pôde ser criado
  if (given > 0) sound(p, "random.orb");
}

// ───────────────────────────────────────────── Pedra Filosofal
const MODES = ["Cubo", "Painel", "Linha"];
/** @param {Player} p */
const philCharge = (p) => Math.max(0, Math.min(4, Number(p.getDynamicProperty("pe:philc") ?? 0)));
/** @param {Player} p */
const philMode = (p) => Math.max(0, Math.min(2, Number(p.getDynamicProperty("pe:philm") ?? 0)));

/** @param {Block} b @param {string} target */
function setTransmuted(b, target) {
  let perm;
  try {
    perm = BlockPermutation.resolve(target, b.permutation.getAllStates());
  } catch {
    try {
      perm = BlockPermutation.resolve(target);
    } catch {
      return false;
    }
  }
  try {
    b.setPermutation(perm);
    return true;
  } catch {
    return false;
  }
}

/** @param {Player} p @param {Block} block @param {Direction | undefined} face */
function philTransmute(p, block, face) {
  const entry = WT.get(block.typeId);
  if (!entry) return false;
  const target = p.isSneaking ? entry[1] : entry[0];
  const from = block.typeId;
  const c = philCharge(p);
  const mode = philMode(p);
  const n = faceVec(face);
  const o = block.location;
  /** @type {Vector3[]} */
  const pos = [];
  if (c === 0) pos.push(o);
  else if (mode === 0) {
    for (let x = -c; x <= c; x++) for (let y = -c; y <= c; y++) for (let z = -c; z <= c; z++) pos.push({ x: o.x + x, y: o.y + y, z: o.z + z });
  } else if (mode === 1) {
    for (let a = -c; a <= c; a++)
      for (let b = -c; b <= c; b++) {
        if (n.y !== 0) pos.push({ x: o.x + a, y: o.y, z: o.z + b });
        else if (n.x !== 0) pos.push({ x: o.x, y: o.y + a, z: o.z + b });
        else pos.push({ x: o.x + a, y: o.y + b, z: o.z });
      }
  } else {
    for (let d = 0; d <= c * 2; d++) pos.push({ x: o.x - n.x * d, y: o.y - n.y * d, z: o.z - n.z * d });
  }
  let changed = 0;
  for (const l of pos) {
    let b;
    try {
      b = block.dimension.getBlock(l);
    } catch {
      continue;
    }
    if (!b || b.typeId !== from) continue;
    if (setTransmuted(b, target)) changed++;
  }
  if (changed) sound(p, "mob.endermen.portal");
  return changed > 0;
}

/** @param {Player} p */
async function philUseAir(p) {
  // permite transmutar líquidos (água ↔ gelo, lava ↔ obsidiana) mirando neles
  try {
    const hit = p.getBlockFromViewDirection({ maxDistance: 7, includeLiquidBlocks: true, includePassableBlocks: true });
    if (hit && hit.block.isLiquid && WT.has(hit.block.typeId)) {
      philTransmute(p, hit.block, hit.face);
      return;
    }
  } catch {
    /* ignore */
  }
  await philMenu(p);
}

/** @param {Player} p */
async function philMenu(p) {
  for (;;) {
    const c = philCharge(p);
    const m = philMode(p);
    const r = await show(
      new ActionFormData()
        .title("§lPedra Filosofal")
        .body(
          `Carga: §e${c}§r/4  (área ${c * 2 + 1}×${c * 2 + 1})\nModo: §e${MODES[m]}§r\n\n§7Use num bloco para transmutá-lo. Agachado: transmutação alternativa. Mire em água/lava e use no ar para transmutar líquidos.`
        )
        .button("Aumentar carga")
        .button("Diminuir carga")
        .button(`Modo: ${MODES[m]} → ${MODES[(m + 1) % 3]}`)
        .button("Conversões alquímicas")
        .button("Fundição filosofal")
        .button("Fechar"),
      p
    );
    if (!r || r.canceled || r.selection === undefined || r.selection === 5) return;
    if (r.selection === 0) p.setDynamicProperty("pe:philc", Math.min(4, c + 1));
    else if (r.selection === 1) p.setDynamicProperty("pe:philc", Math.max(0, c - 1));
    else if (r.selection === 2) p.setDynamicProperty("pe:philm", (m + 1) % 3);
    else if (r.selection === 3) await conversionMenu(p);
    else if (r.selection === 4) await smeltMenu(p);
  }
}

/** @param {Player} p */
async function conversionMenu(p) {
  const c = inv(p);
  const f = new ActionFormData().title("Conversões alquímicas").body("§7Receitas de conversão do ProjectE que usam a Pedra Filosofal (a pedra não é consumida).");
  for (const [a, an, b, bn] of PHILO_CONVERSIONS) {
    const have = countPlain(c, a);
    f.button({ rawtext: [{ text: `${have >= an ? "§2" : "§8"}${an}x ` }, nameMsg(a), { text: " → " }, { text: `${bn}x ` }, nameMsg(b), { text: `\n§7você tem ${have}` }] });
  }
  f.button("Voltar");
  const r = await show(f, p);
  if (!r || r.canceled || r.selection === undefined || r.selection >= PHILO_CONVERSIONS.length) return;
  const [a, an, b, bn] = PHILO_CONVERSIONS[r.selection];
  const maxTimes = Math.floor(countPlain(c, a) / an);
  if (maxTimes < 1) {
    tell(p, "§cIngredientes insuficientes.");
    return;
  }
  const m = await show(new ModalFormData().title("Converter").textField(`Quantas vezes? (1 a ${maxTimes})`, "1", { defaultValue: String(maxTimes) }), p);
  let times = formNum(m, 0);
  if (!Number.isFinite(times) || times < 1) return;
  times = Math.min(times, Math.floor(countPlain(c, a) / an));
  if (times < 1 || !hasItem(p, PHIL)) return;
  const removed = removePlain(c, a, times * an);
  const doneTimes = Math.floor(removed / an);
  const extra = removed - doneTimes * an;
  if (extra > 0) giveItems(p, a, extra);
  giveItems(p, b, doneTimes * bn);
  sound(p, "random.orb");
  tell(p, `§aConversão feita ${doneTimes}x.`);
}

/** @param {Player} p */
async function smeltMenu(p) {
  const c = inv(p);
  const fuel = countPlain(c, "minecraft:coal") + countPlain(c, "minecraft:charcoal");
  /** @type {string[]} */
  const ids = [];
  for (let i = 0; i < c.size; i++) {
    const it = c.getItem(i);
    if (it && SMELTING[it.typeId] && isPlain(it) && !ids.includes(it.typeId)) ids.push(it.typeId);
  }
  const f = new ActionFormData().title("Fundição filosofal").body(`§7Pedra Filosofal + 1 carvão (ou carvão vegetal) + 7 itens = 7 itens fundidos.\nCombustível disponível: ${fuel}`);
  for (const id of ids) f.button({ rawtext: [{ text: `${countPlain(c, id)}x ` }, nameMsg(id), { text: " → " }, nameMsg(SMELTING[id])] });
  f.button("Voltar");
  const r = await show(f, p);
  if (!r || r.canceled || r.selection === undefined || r.selection >= ids.length) return;
  const id = ids[r.selection];
  const out = SMELTING[id];
  const maxBatches = Math.min(Math.floor(countPlain(c, id) / 7), fuel);
  if (maxBatches < 1) {
    tell(p, "§cSão necessários 7 itens e 1 carvão por fundição.");
    return;
  }
  const m = await show(new ModalFormData().title("Fundir").textField(`Quantas fundições de 7? (1 a ${maxBatches})`, "1", { defaultValue: String(maxBatches) }), p);
  let batches = formNum(m, 0);
  if (!Number.isFinite(batches) || batches < 1) return;
  const fuelNow = countPlain(c, "minecraft:coal") + countPlain(c, "minecraft:charcoal");
  batches = Math.min(batches, Math.floor(countPlain(c, id) / 7), fuelNow);
  if (batches < 1 || !hasItem(p, PHIL)) return;
  let fuelLeft = batches;
  fuelLeft -= removePlain(c, "minecraft:charcoal", fuelLeft);
  if (fuelLeft > 0) fuelLeft -= removePlain(c, "minecraft:coal", fuelLeft);
  const okBatches = batches - fuelLeft;
  const removed = removePlain(c, id, okBatches * 7);
  giveItems(p, out, removed);
  sound(p, "random.fizz");
  tell(p, `§aFundidos ${removed} itens.`);
}

/** @param {Player} p @param {string} id */
function hasItem(p, id) {
  const c = inv(p);
  for (let i = 0; i < c.size; i++) if (c.getItem(i)?.typeId === id) return true;
  return false;
}

// ───────────────────────────────────────────── outros itens
/** @param {Player} p */
async function tomeUse(p) {
  const total = Object.keys(EMC).filter((id) => EMC[id] > 0 && maxStack(id) > 0).length;
  const r = await show(new ActionFormData().title("Tomo do Conhecimento").body(`Ler o tomo ensina todos os ${total} itens com EMC e consome o tomo.`).button("Ler o tomo").button("Cancelar"), p);
  if (!r || r.canceled || r.selection !== 0) return;
  const c = inv(p);
  const slot = p.selectedSlotIndex;
  const it = c.getItem(slot);
  if (!it || it.typeId !== TOME) return;
  if (it.amount > 1) {
    it.amount--;
    c.setItem(slot, it);
  } else c.setItem(slot, undefined);
  const k = knowledge(p);
  for (const id of Object.keys(EMC)) if (EMC[id] > 0 && maxStack(id) > 0) k.add(id); // só itens que existem nesta versão
  saveKnowledge(p);
  sound(p, "random.levelup");
  tell(p, `§bVocê aprendeu ${k.size} itens!`);
}

/** @param {Player} p */
function toggleBand(p) {
  const c = inv(p);
  const slot = p.selectedSlotIndex;
  const it = c.getItem(slot);
  if (!it || it.typeId !== BHB) return;
  const on = it.getDynamicProperty("pe:on") !== true;
  it.setDynamicProperty("pe:on", on);
  it.setLore([on ? "§r§aAtivo — atraindo itens" : "§r§7Inativo"]);
  c.setItem(slot, it);
  sound(p, on ? "random.orb" : "random.click");
  p.onScreenDisplay.setActionBar(on ? "§aFaixa do Buraco Negro: ativa" : "§7Faixa do Buraco Negro: inativa");
}

/** @param {Player} p @param {Block} block @param {Direction | undefined} face @param {string} rod */
function divine(p, block, face, rod) {
  const depth = DIVINING[rod];
  const n = faceVec(face);
  const o = block.location;
  // eixos perpendiculares à face
  const u = n.x !== 0 ? { x: 0, y: 1, z: 0 } : { x: 1, y: 0, z: 0 };
  const v = n.z !== 0 ? { x: 0, y: 1, z: 0 } : n.y !== 0 ? { x: 0, y: 0, z: 1 } : { x: 0, y: 0, z: 1 };
  /** @type {number[]} */
  const vals = [];
  let count = 0;
  for (let d = 0; d < depth; d++)
    for (let a = -1; a <= 1; a++)
      for (let b = -1; b <= 1; b++) {
        const l = { x: o.x - n.x * d + u.x * a + v.x * b, y: o.y - n.y * d + u.y * a + v.y * b, z: o.z - n.z * d + u.z * a + v.z * b };
        let blk;
        try {
          blk = block.dimension.getBlock(l);
        } catch {
          continue;
        }
        if (!blk || blk.isAir || blk.isLiquid) continue;
        count++;
        const val = emcOf(ORE_DROPS[blk.typeId] ?? blk.typeId);
        if (val > 0) vals.push(val);
      }
  const avg = count ? Math.floor(vals.reduce((s, x) => s + x, 0) / count) : 0;
  let msg = `§eEMC médio: ${fmt(avg)} §7(${count} blocos, profundidade ${depth})`;
  const sorted = [...new Set(vals)].sort((a, b) => b - a);
  if (depth >= 16 && sorted.length) msg += `\n§eMaior EMC: ${fmt(sorted[0])}`;
  if (depth >= 64 && sorted.length > 1) msg += `\n§eOutros altos: ${sorted.slice(1, 3).map(fmt).join(", ")}`;
  tell(p, msg);
}

/** @param {Player} p @param {Block} block @param {Direction | undefined} face @param {"water" | "lava"} liquid */
function placeLiquid(p, block, face, liquid) {
  const n = faceVec(face);
  const l = { x: block.location.x + n.x, y: block.location.y + n.y, z: block.location.z + n.z };
  let target;
  try {
    target = block.dimension.getBlock(l);
  } catch {
    return;
  }
  if (!target || !(target.isAir || target.isLiquid)) return;
  if (liquid === "water" && block.dimension.id === "minecraft:nether") {
    tell(p, "§7A água evapora no Nether.");
    return;
  }
  if (liquid === "lava" && !consumeStarEmc(p, VOLCANITE_COST)) {
    tell(p, `§cSem EMC: o Amuleto Vulcanita consome ${VOLCANITE_COST} EMC de Klein Stars no inventário.`);
    return;
  }
  try {
    target.setPermutation(BlockPermutation.resolve("minecraft:" + liquid));
    sound(p, liquid === "water" ? "bucket.empty_water" : "bucket.empty_lava");
  } catch {
    /* ignore */
  }
}

/** @param {Block} block */
function till(block) {
  const id = block.typeId;
  let above;
  try {
    above = block.above();
  } catch {
    return false;
  }
  if (!above || !above.isAir) return false;
  if (id === "minecraft:grass_block" || id === "minecraft:dirt" || id === "minecraft:grass_path") {
    block.setPermutation(BlockPermutation.resolve("minecraft:farmland"));
    return true;
  }
  if (id === "minecraft:coarse_dirt") {
    block.setPermutation(BlockPermutation.resolve("minecraft:dirt"));
    return true;
  }
  return false;
}

// ───────────────────────────────────────────── máquinas (coletores, relés, condensador, baú alquímico)
/** @type {Map<string, Machine>} */
const machines = new Map();
/** @type {Set<string>} */
const dirty = new Set();
let listDirty = false;

/** @param {string} dimId @param {Vector3} l */
const mkey = (dimId, l) => `${dimId}|${l.x}|${l.y}|${l.z}`;

function loadMachines() {
  const list = readChunked(world, "pe:mlist", /** @type {string[]} */ ([]));
  for (const k of list) {
    const r = readChunked(world, "pe:m:" + k, /** @type {Machine | null} */ (null));
    if (r && r.t) machines.set(k, r);
  }
}
function flushMachines() {
  for (const k of dirty) {
    const r = machines.get(k);
    if (r) writeChunked(world, "pe:m:" + k, r);
    else clearChunked(world, "pe:m:" + k);
  }
  dirty.clear();
  if (listDirty) {
    writeChunked(world, "pe:mlist", [...machines.keys()]);
    listDirty = false;
  }
}
/** @param {Block} b */
function machineAt(b) {
  const k = mkey(b.dimension.id, b.location);
  let r = machines.get(k);
  if (!r || r.t !== b.typeId) {
    r = { t: b.typeId, d: b.dimension.id, x: b.location.x, y: b.location.y, z: b.location.z, emc: 0, frac: 0, inv: [], lock: null, star: null };
    machines.set(k, r);
    dirty.add(k);
    listDirty = true;
  }
  return { k, r };
}
/** Remove a máquina e devolve TODO o conteúdo ao mundo (nada se perde ao quebrar). */
/** @param {string} k @param {Dimension} dim */
function removeMachine(k, dim) {
  const r = machines.get(k);
  if (!r) return;
  const at = { x: r.x + 0.5, y: r.y + 0.5, z: r.z + 0.5 };
  for (const s of r.inv) {
    let left = s.n;
    const max = Math.max(1, maxStack(s.id));
    while (left > 0) {
      const n = Math.min(max, left);
      try {
        dim.spawnItem(new ItemStack(s.id, n), at);
      } catch {
        /* ignore */
      }
      left -= n;
    }
  }
  if (r.star) {
    try {
      const st = new ItemStack(r.star.id, 1);
      setStarEmc(st, r.star.emc);
      dim.spawnItem(st, at);
    } catch {
      /* ignore */
    }
  }
  machines.delete(k);
  dirty.add(k);
  listDirty = true;
}

/** @param {VStack[]} v @param {string} id @param {number} n @param {number} slots @returns {number} sobra */
function vAdd(v, id, n, slots) {
  const max = Math.max(1, maxStack(id));
  for (const s of v) {
    if (n <= 0) break;
    if (s.id === id && s.n < max) {
      const add = Math.min(max - s.n, n);
      s.n += add;
      n -= add;
    }
  }
  while (n > 0 && v.length < slots) {
    const add = Math.min(max, n);
    v.push({ id, n: add });
    n -= add;
  }
  return n;
}
/** @param {VStack[]} v @param {string} id @param {number} slots */
function vHasSpace(v, id, slots) {
  if (v.length < slots) return true;
  const max = Math.max(1, maxStack(id));
  return v.some((s) => s.id === id && s.n < max);
}

const DIRS = [
  { x: 1, y: 0, z: 0 }, { x: -1, y: 0, z: 0 }, { x: 0, y: 1, z: 0 },
  { x: 0, y: -1, z: 0 }, { x: 0, y: 0, z: 1 }, { x: 0, y: 0, z: -1 },
];
/** @param {Machine} r @param {boolean} fromCollector */
function acceptors(r, fromCollector) {
  /** @type {{k: string, m: Machine}[]} */
  const out = [];
  for (const d of DIRS) {
    const k = mkey(r.d, { x: r.x + d.x, y: r.y + d.y, z: r.z + d.z });
    const m = machines.get(k);
    if (!m) continue;
    if (RELAYS[m.t] && fromCollector && m.emc < RELAYS[m.t].cap) out.push({ k, m });
    else if (isCondenser(m.t) && m.lock && emcOf(m.lock) > 0) out.push({ k, m });
  }
  return out;
}
/** Divide igualmente entre os aceitadores (sendToAllAcceptors). @param {Machine} r @param {number} amount @param {boolean} fromCollector */
function sendEmc(r, amount, fromCollector) {
  const acc = acceptors(r, fromCollector);
  if (!acc.length || amount <= 0) return;
  const per = Math.floor(amount / acc.length);
  for (const { k, m } of acc) {
    let give = per;
    if (RELAYS[m.t]) give = Math.min(give, RELAYS[m.t].cap - m.emc);
    if (give <= 0) continue;
    m.emc += give;
    r.emc -= give;
    dirty.add(k);
  }
}

/** Nível de luz do ProjectE: getMaxLocalRawBrightness(acima) + 1; no Nether = 16. */
/** @param {Dimension} dim @param {Machine} r */
function sunLevel(dim, r) {
  if (dim.id === "minecraft:nether") return 16;
  const above = { x: r.x, y: r.y + 1, z: r.z };
  const d = /** @type {any} */ (dim);
  try {
    if (typeof d.getLightLevel === "function") return Math.min(15, Number(d.getLightLevel(above))) + 1;
  } catch {
    /* API indisponível nesta versão */
  }
  // alternativa: céu aberto + hora do dia (sem luz de blocos)
  let exposed = false;
  try {
    const top = dim.getTopmostBlock({ x: r.x, z: r.z });
    exposed = !top || top.location.y <= r.y;
  } catch {
    exposed = false;
  }
  if (!exposed) return 1;
  const t = world.getTimeOfDay();
  const day = t < 12500 || t > 23500;
  return day ? 16 : 5;
}

/** @param {string} k @param {Machine} r @param {Dimension} dim */
function tickCollector(k, r, dim) {
  const tier = COLLECTORS[r.t];
  if (r.emc < tier.cap) {
    r.frac = (r.frac || 0) + (tier.gen * sunLevel(dim, r)) / 16;
    const whole = Math.floor(r.frac);
    if (whole > 0) {
      r.frac -= whole;
      r.emc = Math.min(tier.cap, r.emc + whole);
    }
  }
  if (r.emc > 0) {
    if (r.star && r.star.emc < KLEIN[r.star.id]) {
      const add = Math.min(r.emc, tier.gen * 20, KLEIN[r.star.id] - r.star.emc);
      r.star.emc += add;
      r.emc -= add;
    } else sendEmc(r, Math.min(r.emc, tier.gen * 20), true);
  }
  dirty.add(k);
}
/** @param {string} k @param {Machine} r */
function tickRelay(k, r) {
  const tier = RELAYS[r.t];
  if (r.emc <= 0) return;
  if (r.star && r.star.emc < KLEIN[r.star.id]) {
    const add = Math.min(r.emc, tier.rate, KLEIN[r.star.id] - r.star.emc);
    r.star.emc += add;
    r.emc -= add;
  } else sendEmc(r, Math.min(r.emc, tier.rate), false);
  dirty.add(k);
}
/** Condensador MK1: a cada tick consome 1 item e cria 1 item-alvo se houver EMC (20 vezes por segundo). */
/** @param {string} k @param {Machine} r */
function tickCondenser(k, r, ops = 20) {
  if (!r.lock) return;
  const req = emcOf(r.lock);
  if (req <= 0) return;
  let changed = false;
  for (let i = 0; i < ops; i++) {
    const idx = r.inv.findIndex((s) => s.id !== r.lock && emcOf(s.id) > 0);
    if (idx >= 0) {
      const s = r.inv[idx];
      s.n--;
      r.emc += emcOf(s.id);
      if (s.n <= 0) r.inv.splice(idx, 1);
      changed = true;
    }
    if (r.emc >= req && vHasSpace(r.inv, r.lock, CONDENSER_SLOTS)) {
      r.emc -= req;
      vAdd(r.inv, r.lock, 1, CONDENSER_SLOTS);
      changed = true;
    } else if (idx < 0) break;
  }
  if (changed) dirty.add(k);
}

function tickMachines() {
  for (const [k, r] of [...machines]) {
    let dim;
    try {
      dim = world.getDimension(r.d);
    } catch {
      continue;
    }
    let block;
    try {
      block = dim.getBlock({ x: r.x, y: r.y, z: r.z });
    } catch {
      continue;
    }
    if (!block) continue; // chunk descarregado: a máquina pausa, como no original
    if (block.typeId !== r.t) {
      removeMachine(k, dim); // destruída por explosão/comando: conteúdo cai no chão
      continue;
    }
    if (COLLECTORS[r.t]) tickCollector(k, r, dim);
    else if (RELAYS[r.t]) tickRelay(k, r);
    else if (isCondenser(r.t)) tickCondenser(k, r, r.t === CONDENSER_MK2 ? 64 : 20);
  }
  flushMachines();
}

/** @param {Player} p @param {Block} b */
async function machineMenu(p, b) {
  const { k } = machineAt(b);
  const dimId = b.dimension.id;
  for (;;) {
    const r = machines.get(k);
    if (!r) return;
    const isGen = !!COLLECTORS[r.t] || !!RELAYS[r.t];
    const f = new ActionFormData();
    /** @type {string[]} */
    const acts = [];
    if (isGen) {
      const cap = COLLECTORS[r.t]?.cap ?? RELAYS[r.t].cap;
      let info = `EMC: §e${fmt(r.emc)}§r / ${fmt(cap)}`;
      if (COLLECTORS[r.t]) {
        const lvl = sunLevel(world.getDimension(dimId), r);
        info += `\nLuz: ${lvl}/16 • Geração: ${((COLLECTORS[r.t].gen * lvl) / 16).toFixed(2)} EMC/s (máx ${COLLECTORS[r.t].gen})`;
      } else info += `\nSaída máxima: ${fmt(RELAYS[r.t].rate)} EMC/s para condensadores vizinhos`;
      info += `\nEspaço de carga: ${r.star ? `${pretty(r.star.id)} (${fmt(r.star.emc)}/${fmt(KLEIN[r.star.id])})` : "vazio"}`;
      info += `\n\n§7${COLLECTORS[r.t] ? "Envia EMC para relés e condensadores encostados." : "Recebe EMC de coletores encostados e repassa a condensadores."}`;
      f.title(COLLECTORS[r.t] ? "§lColetor de Energia" : "§lRelé Anti-Matéria").body(info);
      if (r.star) {
        f.button("Retirar Klein Star");
        acts.push("star_out");
      } else {
        f.button("Inserir Klein Star (da mão)");
        acts.push("star_in");
      }
    } else if (isCondenser(r.t)) {
      const used = r.inv.length;
      f.title("§lCondensador de Energia").body(
        `Alvo: §e${r.lock ? pretty(r.lock) : "nenhum"}§r${r.lock ? ` (${fmt(emcOf(r.lock))} EMC)` : ""}\nEMC armazenado: §e${fmt(r.emc)}\nEspaços: ${used}/${CONDENSER_SLOTS}\n\n§7Itens depositados viram EMC; o EMC vira cópias do alvo.`
      );
      f.button("Definir alvo (item na mão)");
      acts.push("lock");
      if (r.lock) {
        f.button("Limpar alvo");
        acts.push("unlock");
      }
      f.button("Depositar itens");
      acts.push("dep");
      f.button("Retirar itens");
      acts.push("wd");
    } else {
      f.title("§lBaú Alquímico").body(`Espaços usados: ${r.inv.length}/${CHEST_SLOTS}\n§7Guarda itens simples (sem encantos, nomes ou durabilidade).`);
      f.button("Depositar itens");
      acts.push("dep");
      f.button("Retirar itens");
      acts.push("wd");
    }
    f.button("Fechar");
    acts.push("close");
    const res = await show(f, p);
    if (!res || res.canceled || res.selection === undefined) return;
    const a = acts[res.selection];
    if (a === "close") return;
    const cur = machines.get(k);
    if (!cur) return;
    const c = inv(p);
    if (a === "star_in") {
      const slot = p.selectedSlotIndex;
      const it = c.getItem(slot);
      if (!it || !KLEIN[it.typeId]) tell(p, "§cSegure uma Klein Star na mão principal.");
      else if (!cur.star) {
        cur.star = { id: it.typeId, emc: starEmc(it) };
        c.setItem(slot, undefined);
        dirty.add(k);
      }
    } else if (a === "star_out" && cur.star) {
      const st = new ItemStack(cur.star.id, 1);
      setStarEmc(st, cur.star.emc);
      cur.star = null;
      dirty.add(k);
      const rest = c.addItem(st);
      if (rest) p.dimension.spawnItem(rest, p.location);
    } else if (a === "lock") {
      const it = c.getItem(p.selectedSlotIndex);
      if (!it || emcOf(it.typeId) <= 0) tell(p, "§cSegure um item com EMC para usá-lo como alvo.");
      else {
        cur.lock = it.typeId;
        dirty.add(k);
      }
    } else if (a === "unlock") {
      cur.lock = null;
      dirty.add(k);
    } else if (a === "dep") await depositMenu(p, k);
    else if (a === "wd") await withdrawMenu(p, k);
    flushMachines();
  }
}

/** @param {string} k */
const slotsOf = (k) => (isCondenser(machines.get(k)?.t ?? "") ? CONDENSER_SLOTS : CHEST_SLOTS);

/** @param {Player} p @param {string} k */
async function depositMenu(p, k) {
  const r = machines.get(k);
  if (!r) return;
  const c = inv(p);
  const condenser = isCondenser(r.t);
  /** @param {ItemStack} it */
  const ok = (it) => isPlain(it) && (!condenser || (emcOf(it.typeId) > 0 && it.typeId !== r.lock));
  const f = new ActionFormData().title("Depositar").body(condenser ? "§7Só itens com EMC (e diferentes do alvo)." : "§7Itens simples empilháveis.");
  /** @type {number[]} */
  const slots = [-1];
  f.button("§6Depositar todos os itens aceitos");
  for (let i = 0; i < c.size; i++) {
    const it = c.getItem(i);
    if (!it || !ok(it)) continue;
    f.button(label(it.typeId, ` §8x${it.amount}`));
    slots.push(i);
  }
  f.button("Voltar");
  const res = await show(f, p);
  if (!res || res.canceled || res.selection === undefined || res.selection >= slots.length) return;
  const sel = slots[res.selection];
  const cur = machines.get(k);
  if (!cur) return;
  const cap = slotsOf(k);
  const list = sel === -1 ? [...Array(c.size).keys()] : [sel];
  let moved = 0;
  for (const i of list) {
    const it = c.getItem(i);
    if (!it || !ok(it)) continue;
    const left = vAdd(cur.inv, it.typeId, it.amount, cap);
    const n = it.amount - left;
    if (n <= 0) continue;
    moved += n;
    if (left <= 0) c.setItem(i, undefined);
    else {
      it.amount = left;
      c.setItem(i, it);
    }
  }
  dirty.add(k);
  flushMachines();
  tell(p, moved ? `§aDepositados ${moved} itens.` : "§cNada foi depositado (sem espaço ou itens não aceitos).");
}

/** @param {Player} p @param {string} k */
async function withdrawMenu(p, k) {
  const r = machines.get(k);
  if (!r) return;
  if (!r.inv.length) {
    tell(p, "§7Vazio.");
    return;
  }
  const f = new ActionFormData().title("Retirar");
  const snapshot = r.inv.map((s) => ({ ...s }));
  f.button("§6Retirar tudo o que couber");
  for (const s of snapshot) f.button(label(s.id, ` §8x${s.n}`));
  f.button("Voltar");
  const res = await show(f, p);
  if (!res || res.canceled || res.selection === undefined || res.selection > snapshot.length) return;
  const cur = machines.get(k);
  if (!cur) return;
  const c = inv(p);
  /** @param {VStack} s @param {number} want */
  const take = (s, want) => {
    let n = Math.min(want, s.n);
    if (n <= 0) return 0;
    const rest = c.addItem(new ItemStack(s.id, n));
    if (rest) n -= rest.amount; // o que não coube continua guardado
    s.n -= n;
    return n;
  };
  let got = 0;
  if (res.selection === 0) {
    for (const s of cur.inv) got += take(s, s.n);
  } else {
    const want = snapshot[res.selection - 1];
    const s = cur.inv.find((x) => x.id === want.id && x.n > 0);
    if (s) got += take(s, s.n);
  }
  cur.inv = cur.inv.filter((s) => s.n > 0);
  dirty.add(k);
  flushMachines();
  tell(p, got ? `§aRetirados ${got} itens.` : "§cInventário cheio.");
}

// ───────────────────────────────────────────── Ferramentas de matéria (PETool / PESword / PEKatar / ToolHelper)
/** @typedef {"pickaxe"|"axe"|"shovel"|"sword"|"hoe"|"shears"|"hammer"|"katar"|"morning_star"} ToolKind */
/** cargas: PEItems (DM 2, RM 3, Katar/Estrela da Manhã 4); dano: atributo de ataque do ProjectE */
/** @type {Record<string, {kind: ToolKind, charges: number, dmg: number, rm: boolean}>} */
const MATTER_TOOLS = {};
for (const [mat, charges, dmg] of /** @type {[string, number, Record<string, number>][]} */ ([
  ["dark_matter", 2, { pickaxe: 7, axe: 8, shovel: 5, sword: 12, hoe: 1, shears: 1, hammer: 13 }],
  ["red_matter", 3, { pickaxe: 8, axe: 9, shovel: 6, sword: 16, hoe: 1, shears: 1, hammer: 14 }],
])) {
  for (const kind of Object.keys(dmg)) MATTER_TOOLS[`${P}${mat}_${kind}`] = { kind: /** @type {ToolKind} */ (kind), charges, dmg: dmg[kind], rm: mat === "red_matter" };
}
MATTER_TOOLS[P + "red_matter_katar"] = { kind: "katar", charges: 4, dmg: 23, rm: true };
MATTER_TOOLS[P + "red_matter_morning_star"] = { kind: "morning_star", charges: 4, dmg: 20, rm: true };
/** itens com carga que não são ferramentas de matéria (Catalisador, lentes, anéis com carga) */
/** @type {Record<string, number>} */
const CHARGE_ITEMS = {
  [P + "destruction_catalyst"]: 3, [P + "hyperkinetic_lens"]: 3, [P + "catalytic_lens"]: 3,
  [P + "zero_ring"]: 4, [P + "watch_of_flowing_time"]: 2,
};
const PICK_MODES = ["Padrão", "Tiro alto (3 na vertical)", "Tiro largo (3 na horizontal)", "Tiro longo (3 de profundidade)"]; // PickaxeMode
const SLAY_MODES = ["Matar hostis", "Matar todos"]; // KatarMode
const ORE = (/** @type {string} */ id) => id.endsWith("_ore") || id === "minecraft:ancient_debris";
const LOG = (/** @type {string} */ id) => /_(log|wood|stem|hyphae)$/.test(id) || id === "minecraft:mangrove_roots";
const LEAVES = (/** @type {string} */ id) => id.endsWith("_leaves") || id === "minecraft:azalea_leaves_flowered";
const TILLABLE = new Set(["minecraft:grass_block", "minecraft:dirt", "minecraft:grass_path", "minecraft:coarse_dirt", "minecraft:rooted_dirt"]);
const SHEARS_DROP = (/** @type {string} */ id) => LEAVES(id) || ["minecraft:vine", "minecraft:web", "minecraft:short_grass", "minecraft:tall_grass", "minecraft:fern", "minecraft:large_fern", "minecraft:seagrass", "minecraft:glow_lichen", "minecraft:dead_bush", "minecraft:deadbush"].includes(id);
const HARD = new Set(["minecraft:obsidian", "minecraft:crying_obsidian", "minecraft:respawn_anchor", "minecraft:ender_chest", "minecraft:enchanting_table", "minecraft:anvil"]);

/** @param {Player} p @param {string} id */
const getCharge = (p, id) => Math.max(0, Math.min(MATTER_TOOLS[id]?.charges ?? CHARGE_ITEMS[id] ?? 0, Number(p.getDynamicProperty("pe:charge:" + id) ?? 0)));
/** @param {Player} p @param {string} id */
const getMode = (p, id) => Number(p.getDynamicProperty("pe:mode:" + id) ?? 0);

/** Menu de carga/modo (no Java: teclas V e G). @param {Player} p @param {string} id */
async function chargeMenu(p, id) {
  const t = MATTER_TOOLS[id];
  const max = t?.charges ?? CHARGE_ITEMS[id] ?? 0;
  const modes = t && (t.kind === "pickaxe" || t.kind === "morning_star") ? PICK_MODES : t && ((t.kind === "sword" && t.rm) || t.kind === "katar") ? SLAY_MODES : null;
  for (;;) {
    const c = getCharge(p, id);
    const m = getMode(p, id);
    const f = new ActionFormData().title({ rawtext: [nameMsg(id)] }).body(`Carga: §e${c}/${max}${modes ? `§r\nModo: §e${modes[m % modes.length]}` : ""}`);
    f.button("Aumentar carga").button("Diminuir carga");
    if (modes) f.button(`Modo: ${modes[(m + 1) % modes.length]}`);
    f.button("Fechar");
    const r = await show(f, p);
    if (!r || r.canceled || r.selection === undefined) return;
    if (r.selection === 0) p.setDynamicProperty("pe:charge:" + id, Math.min(max, c + 1));
    else if (r.selection === 1) p.setDynamicProperty("pe:charge:" + id, Math.max(0, c - 1));
    else if (modes && r.selection === 2) p.setDynamicProperty("pe:mode:" + id, (m + 1) % modes.length);
    else return;
    sound(p, "random.click");
  }
}

/** Quebra o bloco com os drops normais (como Block.getDrops) e devolve true se quebrou. @param {Dimension} dim @param {Vector3} l */
function breakBlock(dim, l) {
  let b;
  try {
    b = dim.getBlock(l);
  } catch {
    return false;
  }
  if (!b || b.isAir || b.isLiquid || UNBREAKABLE.has(b.typeId) || b.typeId.startsWith(P)) return false;
  if (b.getComponent("minecraft:inventory")) return false;
  try {
    dim.runCommand(`setblock ${l.x} ${l.y} ${l.z} air destroy`);
    return true;
  } catch {
    return false;
  }
}
/** Executa trabalho pesado em várias ticks (System.runJob), como os laços de área do ToolHelper. @param {() => Generator<void>} gen */
function job(gen) {
  system.runJob(gen());
}

const DIG_OK = {
  pick: (/** @type {Block} */ b) => b.hasTag("stone") || b.hasTag("metal") || ORE(b.typeId) || b.hasTag("minecraft:is_pickaxe_item_destructible"),
  shovel: (/** @type {Block} */ b) => b.hasTag("dirt") || b.hasTag("sand") || b.hasTag("gravel") || b.hasTag("snow") || b.hasTag("grass") || b.hasTag("minecraft:is_shovel_item_destructible"),
  axe: (/** @type {Block} */ b) => b.hasTag("wood") || b.hasTag("log") || LOG(b.typeId) || b.hasTag("minecraft:is_axe_item_destructible"),
};
/** @param {ToolKind} kind @param {Block} b */
function correctTool(kind, b) {
  if (kind === "pickaxe" || kind === "hammer") return DIG_OK.pick(b);
  if (kind === "shovel") return DIG_OK.shovel(b);
  if (kind === "axe") return DIG_OK.axe(b);
  if (kind === "morning_star") return DIG_OK.pick(b) || DIG_OK.shovel(b) || DIG_OK.axe(b);
  return false;
}
/** Eixos perpendiculares a uma face. @param {Vector3} n */
function perp(n) {
  if (n.y !== 0) return [{ x: 1, y: 0, z: 0 }, { x: 0, y: 0, z: 1 }];
  if (n.x !== 0) return [{ x: 0, y: 1, z: 0 }, { x: 0, y: 0, z: 1 }];
  return [{ x: 1, y: 0, z: 0 }, { x: 0, y: 1, z: 0 }];
}
/** WorldHelper.getBroadDeepBox: raio `c` nas direções da face e `c` de profundidade. @param {Vector3} o @param {Vector3} n @param {number} c */
function* broadDeep(o, n, c) {
  const [u, v] = perp(n);
  for (let d = 0; d <= c; d++)
    for (let a = -c; a <= c; a++)
      for (let b = -c; b <= c; b++) yield { x: o.x - n.x * d + u.x * a + v.x * b, y: o.y - n.y * d + u.y * a + v.y * b, z: o.z - n.z * d + u.z * a + v.z * b };
}

/** digAOE @param {Player} p @param {Block} block @param {Direction|undefined} face @param {string} id @param {boolean} deep */
function digAOE(p, block, face, id, deep) {
  const t = MATTER_TOOLS[id];
  const c = getCharge(p, id);
  if (c === 0) return p.onScreenDisplay.setActionBar("§7Aumente a carga (agachar + usar) para cavar em área.");
  const dim = block.dimension;
  const o = block.location;
  const n = faceVec(face);
  job(function* () {
    const pos = deep ? [...broadDeep(o, n, c)] : [...broadDeep(o, { x: 0, y: 1, z: 0 }, c)].filter((l) => l.y === o.y);
    for (const l of pos) {
      let b;
      try {
        b = dim.getBlock(l);
      } catch {
        continue;
      }
      if (b && !b.isAir && correctTool(t.kind, b)) breakBlock(dim, l);
      yield;
    }
    sound(p, "random.explode");
  });
}

/** harvestVein: quebra blocos ligados que satisfazem `ok`, dentro de uma caixa, até 250 (Constants.MAX_VEIN_SIZE). */
/** @param {Dimension} dim @param {Vector3[]} seeds @param {(b: Block) => boolean} ok @param {{min: Vector3, max: Vector3}} box */
function harvestVein(dim, seeds, ok, box) {
  job(function* () {
    const seen = new Set();
    const queue = [...seeds];
    let count = 0;
    const inBox = (/** @type {Vector3} */ l) => l.x >= box.min.x && l.x <= box.max.x && l.y >= box.min.y && l.y <= box.max.y && l.z >= box.min.z && l.z <= box.max.z;
    while (queue.length && count < 250) {
      const l = /** @type {Vector3} */ (queue.shift());
      const key = `${l.x},${l.y},${l.z}`;
      if (seen.has(key) || !inBox(l)) continue;
      seen.add(key);
      let b;
      try {
        b = dim.getBlock(l);
      } catch {
        continue;
      }
      if (!b || !ok(b)) continue;
      if (breakBlock(dim, l)) count++;
      for (const d of DIRS) queue.push({ x: l.x + d.x, y: l.y + d.y, z: l.z + d.z });
      yield;
    }
  });
}
/** tryVeinMine: veio do mesmo bloco dentro da caixa larga/profunda da carga. @param {Player} p @param {Block} block @param {Direction|undefined} face @param {string} id */
function veinMine(p, block, face, id) {
  const c = getCharge(p, id);
  const type = block.typeId;
  const o = block.location;
  const n = faceVec(face);
  const pts = [...broadDeep(o, n, c)];
  const min = { x: Math.min(...pts.map((q) => q.x)), y: Math.min(...pts.map((q) => q.y)), z: Math.min(...pts.map((q) => q.z)) };
  const max = { x: Math.max(...pts.map((q) => q.x)), y: Math.max(...pts.map((q) => q.y)), z: Math.max(...pts.map((q) => q.z)) };
  harvestVein(block.dimension, [o], (b) => b.typeId === type, { min, max });
  sound(p, "random.explode");
}
/** mineOreVeinsInAOE: minérios ao redor do jogador (raio carga+3). @param {Player} p @param {string} id */
function mineOreVeins(p, id) {
  const r = getCharge(p, id) + 3;
  const o = { x: Math.floor(p.location.x), y: Math.floor(p.location.y), z: Math.floor(p.location.z) };
  const box = { min: { x: o.x - r, y: o.y - r, z: o.z - r }, max: { x: o.x + r, y: o.y + 1 + r, z: o.z + r } };
  const dim = p.dimension;
  job(function* () {
    /** @type {Vector3[]} */
    const seeds = [];
    for (let x = box.min.x; x <= box.max.x; x++)
      for (let y = box.min.y; y <= box.max.y; y++)
        for (let z = box.min.z; z <= box.max.z; z++) {
          try {
            const b = dim.getBlock({ x, y, z });
            if (b && ORE(b.typeId)) seeds.push({ x, y, z });
          } catch {
            /* fora do mundo */
          }
          yield;
        }
    if (!seeds.length) return p.onScreenDisplay.setActionBar("§7Nenhum minério por perto.");
    harvestVein(dim, seeds, (b) => ORE(b.typeId), box);
    sound(p, "random.explode");
  });
}
/** clearTagAOE: troncos/folhas numa caixa 5c × 10c ao redor do jogador. @param {Player} p @param {string} id @param {(id: string) => boolean} test */
function clearTagAOE(p, id, test) {
  const c = getCharge(p, id);
  if (c === 0) return false;
  const h = 5 * c;
  const v = 2 * h;
  const o = { x: Math.floor(p.location.x), y: Math.floor(p.location.y), z: Math.floor(p.location.z) };
  const dim = p.dimension;
  job(function* () {
    for (let y = o.y - v; y <= o.y + v; y++)
      for (let x = o.x - h; x <= o.x + h; x++)
        for (let z = o.z - h; z <= o.z + h; z++) {
          try {
            const b = dim.getBlock({ x, y, z });
            if (b && test(b.typeId)) breakBlock(dim, { x, y, z });
          } catch {
            /* ignore */
          }
          yield;
        }
  });
  sound(p, "random.explode");
  return true;
}
/** tillAOE / flattenAOE / stripLogsAOE: aplica `fn` no plano do bloco clicado, raio = carga. */
/** @param {Player} p @param {Block} block @param {string} id @param {(b: Block) => boolean} fn */
function planeAOE(p, block, id, fn) {
  const c = getCharge(p, id);
  const o = block.location;
  let any = false;
  for (let x = -c; x <= c; x++)
    for (let z = -c; z <= c; z++) {
      try {
        const b = block.dimension.getBlock({ x: o.x + x, y: o.y, z: o.z + z });
        if (b && fn(b)) any = true;
      } catch {
        /* ignore */
      }
    }
  return any;
}
/** @param {Block} b @param {string} to */
function swapKeepStates(b, to) {
  try {
    b.setPermutation(BlockPermutation.resolve(to, b.permutation.getAllStates()));
  } catch {
    b.setPermutation(BlockPermutation.resolve(to));
  }
}
/** @param {Block} b */
function stripLog(b) {
  if (!LOG(b.typeId) || b.typeId.includes("stripped") || b.typeId === "minecraft:mangrove_roots") return false;
  swapKeepStates(b, b.typeId.replace("minecraft:", "minecraft:stripped_"));
  return true;
}
/** @param {Block} b */
function flatten(b) {
  if (!["minecraft:grass_block", "minecraft:dirt", "minecraft:podzol", "minecraft:coarse_dirt", "minecraft:mycelium", "minecraft:rooted_dirt"].includes(b.typeId)) return false;
  const above = b.above();
  if (!above || !above.isAir) return false;
  b.setPermutation(BlockPermutation.resolve("minecraft:grass_path"));
  return true;
}

/** attackAOE: dano igual ao da espada a todas as criaturas num raio de 2,5 × carga (ignora armadura). @param {Player} p @param {string} id */
function attackAOE(p, id) {
  const t = MATTER_TOOLS[id];
  const c = getCharge(p, id);
  if (c === 0) return p.onScreenDisplay.setActionBar("§7Carga 0: aumente a carga (agachar + usar) para atacar em área.");
  const slayAll = (t.kind === "katar" || t.rm) && getMode(p, id) % 2 === 1;
  const ents = p.dimension.getEntities({ location: p.location, maxDistance: 2.5 * c + 1, excludeTypes: ["minecraft:player", "minecraft:item", "minecraft:xp_orb", "minecraft:arrow"] });
  let hit = 0;
  for (const e of ents) {
    if (!e.isValid || !e.getComponent("minecraft:health")) continue;
    const hostile = e.matches({ families: ["monster"] });
    if (!hostile && !slayAll) continue;
    if (e.getComponent("minecraft:is_tamed")) continue;
    try {
      e.applyDamage(t.dmg + 1, { cause: EntityDamageCause.override, damagingEntity: p });
      hit++;
    } catch {
      /* ignore */
    }
  }
  if (hit) sound(p, "mob.blaze.shoot");
}

const WOOL = ["white", "orange", "magenta", "light_blue", "yellow", "lime", "pink", "gray", "light_gray", "cyan", "purple", "blue", "brown", "green", "red", "black"];
/** Tosquia uma ovelha/golem de neve. @param {import("@minecraft/server").Entity} e @param {number} mult */
function shearEntity(e, mult) {
  if (!e.isValid || e.getComponent("minecraft:is_sheared") || e.getComponent("minecraft:is_baby")) return false;
  const at = e.location;
  if (e.typeId === "minecraft:sheep") {
    const color = /** @type {any} */ (e.getComponent("minecraft:color"))?.value ?? 0;
    e.triggerEvent("minecraft:on_sheared");
    const n = (1 + Math.floor(Math.random() * 3)) * mult;
    e.dimension.spawnItem(new ItemStack(`minecraft:${WOOL[color] ?? "white"}_wool`, n), at);
  } else if (e.typeId === "minecraft:snow_golem") {
    e.triggerEvent("minecraft:on_sheared");
    e.dimension.spawnItem(new ItemStack("minecraft:carved_pumpkin", mult), at);
  } else return false;
  return true;
}
/** shearEntityAOE: raio 2^(2+carga), drops em dobro e 1% de chance de nascer um filhote. @param {Player} p @param {string} id */
function shearAOE(p, id) {
  const r = Math.pow(2, 2 + getCharge(p, id));
  let n = 0;
  for (const e of p.dimension.getEntities({ location: p.location, maxDistance: r, families: ["sheep"] }).concat(p.dimension.getEntities({ location: p.location, maxDistance: r, type: "minecraft:snow_golem" }))) {
    if (shearEntity(e, 2)) {
      n++;
      if (Math.random() < 0.01 && e.typeId === "minecraft:sheep") {
        try {
          e.dimension.spawnEntity(e.typeId, e.location).triggerEvent("minecraft:entity_born");
        } catch {
          /* ignore */
        }
      }
    }
  }
  if (n) sound(p, "mob.sheep.shear");
}

/** Uso no ar (botão direito). @param {Player} p @param {string} id @returns {boolean} tratado */
function toolUseAir(p, id) {
  if (p.isSneaking && (MATTER_TOOLS[id] || CHARGE_ITEMS[id])) {
    chargeMenu(p, id);
    return true;
  }
  const t = MATTER_TOOLS[id];
  if (!t) return false;
  if (t.kind === "sword" || t.kind === "katar") attackAOE(p, id);
  else if (t.kind === "shears") shearAOE(p, id);
  else if (t.kind === "pickaxe" || t.kind === "morning_star") mineOreVeins(p, id);
  return true;
}
/** O uso num bloco deve ser interceptado? (chamado no beforeEvent, só leitura) @param {string} id @param {Block} b */
function toolHandlesBlock(id, b) {
  const t = MATTER_TOOLS[id];
  if (!t || b.getComponent("minecraft:inventory") || b.typeId.startsWith(P)) return false;
  const bid = b.typeId;
  switch (t.kind) {
    case "axe": return LOG(bid);
    case "katar": return LOG(bid) || LEAVES(bid) || TILLABLE.has(bid);
    case "hoe": return TILLABLE.has(bid);
    case "shears": return LEAVES(bid);
    case "shovel": return !b.isAir;
    case "pickaxe": case "hammer": case "morning_star": return !b.isAir && !b.isLiquid;
    default: return false;
  }
}
/** Uso num bloco (PE*.useOn). @param {Player} p @param {Block} b @param {Direction|undefined} face @param {string} id */
function toolUseOn(p, b, face, id) {
  const t = MATTER_TOOLS[id];
  const bid = b.typeId;
  switch (t.kind) {
    case "axe":
    case "katar":
      if (LOG(bid)) {
        if (!clearTagAOE(p, id, LOG) && planeAOE(p, b, id, stripLog)) sound(p, "use.wood");
      } else if (LEAVES(bid)) clearTagAOE(p, id, LEAVES);
      else if (TILLABLE.has(bid) && planeAOE(p, b, id, till)) sound(p, "use.gravel");
      break;
    case "hoe":
      if (planeAOE(p, b, id, till)) sound(p, "use.gravel");
      break;
    case "shears":
      clearTagAOE(p, id, LEAVES);
      break;
    case "shovel":
      if (!planeAOE(p, b, id, flatten)) digAOE(p, b, face, id, false);
      else sound(p, "use.grass");
      break;
    case "pickaxe":
      if (correctTool("pickaxe", b)) veinMine(p, b, face, id);
      break;
    case "hammer":
      digAOE(p, b, face, id, true);
      break;
    case "morning_star":
      if (ORE(bid)) veinMine(p, b, face, id);
      else if (!planeAOE(p, b, id, flatten)) digAOE(p, b, face, id, true);
      break;
  }
}
/** digBasedOnMode (picareta e estrela da manhã ao quebrar). @param {Player} p @param {Dimension} dim @param {Vector3} o @param {string} id */
function digByMode(p, dim, o, id) {
  const mode = getMode(p, id) % 4;
  if (mode === 0) return;
  const view = p.getViewDirection();
  const vertical = Math.abs(view.y) > 0.7;
  const n = vertical ? { x: 0, y: Math.sign(view.y), z: 0 } : Math.abs(view.x) > Math.abs(view.z) ? { x: Math.sign(view.x), y: 0, z: 0 } : { x: 0, y: 0, z: Math.sign(view.z) };
  /** @type {Vector3[]} */
  let offs = [];
  const side = n.x !== 0 ? { x: 0, y: 0, z: 1 } : { x: 1, y: 0, z: 0 };
  if (mode === 1) offs = vertical ? [side, { x: -side.x, y: 0, z: -side.z }] : [{ x: 0, y: 1, z: 0 }, { x: 0, y: -1, z: 0 }];
  else if (mode === 2) offs = vertical ? [{ x: side.z, y: 0, z: side.x }, { x: -side.z, y: 0, z: -side.x }] : [side, { x: -side.x, y: 0, z: -side.z }];
  else offs = [n, { x: n.x * 2, y: n.y * 2, z: n.z * 2 }];
  const t = MATTER_TOOLS[id];
  for (const d of offs) {
    const l = { x: o.x + d.x, y: o.y + d.y, z: o.z + d.z };
    try {
      const b = dim.getBlock(l);
      if (b && correctTool(t.kind, b)) breakBlock(dim, l);
    } catch {
      /* ignore */
    }
  }
}

// ───────────────────────────────────────────── EMC de Klein Stars para itens (ItemPE.consumeFuel)
/** @param {Player} p */
function starTotal(p) {
  const c = inv(p);
  let t = 0;
  for (let i = 0; i < c.size; i++) {
    const it = c.getItem(i);
    if (it && KLEIN[it.typeId]) t += starEmc(it);
  }
  return t;
}
/** @type {Map<string, number>} */
const emcFrac = new Map();
/** Consome EMC fracionado (ex.: 0,32 por tick); devolve false se faltar. @param {Player} p @param {number} amount */
function drainEmc(p, amount) {
  const acc = (emcFrac.get(p.id) ?? 0) + amount;
  const whole = Math.floor(acc);
  if (whole > 0 && !consumeStarEmc(p, whole)) return false;
  emcFrac.set(p.id, acc - whole);
  return true;
}

// ───────────────────────────────────────────── itens com liga/desliga (PEToggleItem)
/** @param {ItemStack} it */
const isOn = (it) => it.getDynamicProperty("pe:on") === true;
/** @param {Player} p @param {string} label */
function toggleHeld(p, label) {
  const c = inv(p);
  const slot = p.selectedSlotIndex;
  const it = c.getItem(slot);
  if (!it) return false;
  const on = !isOn(it);
  it.setDynamicProperty("pe:on", on);
  it.setLore([on ? "§r§aAtivo" : "§r§7Inativo"]);
  c.setItem(slot, it);
  sound(p, on ? "random.orb" : "random.click");
  p.onScreenDisplay.setActionBar(`${label}: ${on ? "§aativo" : "§7inativo"}`);
  return on;
}
/** Itens na barra rápida e na mão secundária (hotBarOrOffHand). @param {Player} p @returns {ItemStack[]} */
function hotbarItems(p) {
  const c = inv(p);
  /** @type {ItemStack[]} */
  const out = [];
  for (let i = 0; i < 9; i++) {
    const it = c.getItem(i);
    if (it) out.push(it);
  }
  try {
    const off = /** @type {any} */ (p.getComponent("minecraft:equippable"))?.getEquipment(EquipmentSlot.Offhand);
    if (off) out.push(off);
  } catch {
    /* ignore */
  }
  return out;
}

const SWRG_MODES = ["Desligado", "Escudo", "Voo", "Voo + escudo"]; // SWRGMode
const WATCH_MODES = ["Desligado", "Avançar o tempo", "Voltar o tempo"]; // TimeWatchMode
const GOED_TARGETS = ["minecraft:iron_ingot", "minecraft:gold_ingot", "minecraft:diamond", P + "dark_matter", P + "red_matter"]; // GemMode
const ARCANA_MODES = ["Zero", "Ignição", "Colheita", "Vendaval (SWRG)"];
const STONES = { [P + "body_stone"]: "body", [P + "soul_stone"]: "soul", [P + "life_stone"]: "life" };
const MAGNETS = new Set([BHB, P + "void_ring"]);

/** freezeInBoundingBox: água vira gelo (e lava vira obsidiana) ao redor. @param {Player} p @param {number} r @param {boolean} random */
function freezeAround(p, r, random) {
  const o = { x: Math.floor(p.location.x), y: Math.floor(p.location.y), z: Math.floor(p.location.z) };
  for (let x = -r; x <= r; x++)
    for (let y = -r; y <= r; y++)
      for (let z = -r; z <= r; z++) {
        if (random && Math.random() > 0.25) continue;
        try {
          const b = p.dimension.getBlock({ x: o.x + x, y: o.y + y, z: o.z + z });
          if (!b) continue;
          if (b.typeId === "minecraft:water" && b.above()?.isAir) b.setPermutation(BlockPermutation.resolve("minecraft:ice"));
          else if (b.typeId === "minecraft:lava" && b.above()?.isAir) b.setPermutation(BlockPermutation.resolve("minecraft:obsidian"));
          else if (b.typeId === "minecraft:fire") b.setPermutation(BlockPermutation.resolve("minecraft:air"));
        } catch {
          /* ignore */
        }
      }
}
/** growNearbyRandomly: avança o crescimento de plantas ao redor. @param {Dimension} dim @param {Vector3} at @param {number} r @param {number} tries */
function growNearby(dim, at, r, tries) {
  for (let i = 0; i < tries; i++) {
    const l = { x: Math.floor(at.x) + Math.floor(Math.random() * (2 * r + 1)) - r, y: Math.floor(at.y) + Math.floor(Math.random() * 3) - 1, z: Math.floor(at.z) + Math.floor(Math.random() * (2 * r + 1)) - r };
    try {
      const b = dim.getBlock(l);
      if (!b) continue;
      const st = /** @type {Record<string, any>} */ (b.permutation.getAllStates());
      if (typeof st["growth"] === "number" && st["growth"] < 7) b.setPermutation(b.permutation.withState(/** @type {any} */ ("growth"), st["growth"] + 1));
      else if (typeof st["age"] === "number" && b.typeId === "minecraft:nether_wart" && st["age"] < 3) b.setPermutation(b.permutation.withState(/** @type {any} */ ("age"), st["age"] + 1));
      else if (b.typeId.endsWith("_sapling") && typeof st["age_bit"] === "boolean" && !st["age_bit"]) b.setPermutation(b.permutation.withState(/** @type {any} */ ("age_bit"), true));
    } catch {
      /* ignore */
    }
  }
}
/** repelEntitiesSWRG: empurra criaturas hostis e projéteis para longe. @param {Player} p @param {number} r */
function repel(p, r) {
  for (const e of p.dimension.getEntities({ location: p.location, maxDistance: r, excludeTypes: ["minecraft:player", "minecraft:item", "minecraft:xp_orb"] })) {
    if (!e.matches({ families: ["monster"] }) && !e.getComponent("minecraft:projectile")) continue;
    const dx = e.location.x - p.location.x;
    const dz = e.location.z - p.location.z;
    const d = Math.hypot(dx, dz) || 1;
    try {
      if (e.getComponent("minecraft:projectile")) e.applyImpulse({ x: (dx / d) * 0.6, y: 0.1, z: (dz / d) * 0.6 });
      else e.applyKnockback({ x: (dx / d) * 0.8, z: (dz / d) * 0.8 }, 0.25);
    } catch {
      /* ignore */
    }
  }
}
/** Movimento de voo no Bedrock (não existe API de voo criativo): segurar pulo sobe, agachar desce, solto paira. @param {Player} p @param {boolean} hover */
function flyTick(p, hover) {
  const v = p.getVelocity();
  if (p.isJumping) p.applyKnockback({ x: v.x, z: v.z }, Math.min(0.6, Math.max(v.y, 0) + 0.15));
  else if (!p.isOnGround) {
    if (p.isSneaking) p.applyKnockback({ x: v.x, z: v.z }, Math.max(-0.6, v.y - 0.1));
    else if (hover) p.applyKnockback({ x: v.x, z: v.z }, 0);
  }
}

/** Flecha teleguiada (EntityHomingArrow). @param {Player} p */
function fireHomingArrow(p) {
  if (!consumeStarEmc(p, Math.max(1, emcOf("minecraft:arrow")))) return p.onScreenDisplay.setActionBar("§cSem EMC nas Klein Stars.");
  const head = p.getHeadLocation();
  const dir = p.getViewDirection();
  try {
    const arrow = p.dimension.spawnEntity("minecraft:arrow", { x: head.x + dir.x, y: head.y + dir.y, z: head.z + dir.z });
    const proj = /** @type {any} */ (arrow.getComponent("minecraft:projectile"));
    if (proj) {
      proj.owner = p;
      proj.shoot({ x: dir.x * 2, y: dir.y * 2, z: dir.z * 2 });
    }
    homing.set(arrow.id, { arrow, ticks: 60, owner: p.id });
    sound(p, "random.bow");
  } catch {
    /* ignore */
  }
}
/** @type {Map<string, {arrow: import("@minecraft/server").Entity, ticks: number, owner: string}>} */
const homing = new Map();

/** Itens extras ao usar no ar. @param {Player} p @param {ItemStack} it @returns {boolean} */
function extraUseAir(p, it) {
  const id = it.typeId;
  if (toolUseAir(p, id)) return true;
  if (id.endsWith("_alchemical_bag")) {
    bagMenu(p, id.slice(P.length, -"_alchemical_bag".length));
    return true;
  }
  switch (id) {
    case P + "swiftwolf_rending_gale": {
      const c = inv(p);
      const cur = c.getItem(p.selectedSlotIndex);
      if (!cur) return true;
      const m = (Number(cur.getDynamicProperty("pe:mode") ?? 0) + 1) % 4;
      cur.setDynamicProperty("pe:mode", m);
      cur.setLore([`§r§7Modo: §e${SWRG_MODES[m]}`]);
      c.setItem(p.selectedSlotIndex, cur);
      p.onScreenDisplay.setActionBar(`Vendaval: §e${SWRG_MODES[m]}`);
      return true;
    }
    case P + "zero_ring":
      if (p.isSneaking) return false;
      freezeAround(p, 3 + getCharge(p, id), false);
      sound(p, "random.glass");
      return true;
    case P + "ignition_ring":
      toggleHeld(p, "Anel da Ignição");
      return true;
    case P + "harvest_goddess_band":
      toggleHeld(p, "Faixa da Deusa da Colheita");
      return true;
    case P + "body_stone":
    case P + "soul_stone":
    case P + "life_stone":
      toggleHeld(p, pretty(id));
      return true;
    case P + "mind_stone":
      mindMenu(p);
      return true;
    case P + "archangel_smite":
      if (p.isSneaking) toggleHeld(p, "Disparo automático");
      else fireHomingArrow(p);
      return true;
    case P + "watch_of_flowing_time": {
      if (p.isSneaking) return false;
      const c = inv(p);
      const cur = c.getItem(p.selectedSlotIndex);
      if (!cur) return true;
      const m = (Number(cur.getDynamicProperty("pe:mode") ?? 0) + 1) % 3;
      cur.setDynamicProperty("pe:mode", m);
      cur.setLore([`§r§7Modo: §e${WATCH_MODES[m]}`]);
      c.setItem(p.selectedSlotIndex, cur);
      p.onScreenDisplay.setActionBar(`Relógio: §e${WATCH_MODES[m]}`);
      return true;
    }
    case P + "void_ring":
      if (p.isSneaking) toggleHeld(p, "Atração do Anel do Vazio");
      else voidTeleport(p);
      return true;
    case P + "gem_of_eternal_density":
      if (p.isSneaking) goedMenu(p);
      else toggleHeld(p, "Gema da Densidade Eterna");
      return true;
    case P + "arcana_ring":
      arcanaMenu(p);
      return true;
    case P + "hyperkinetic_lens":
    case P + "catalytic_lens":
      if (p.isSneaking) return false;
      lensShot(p, id);
      return true;
  }
  return false;
}

/** @param {Player} p */
function voidTeleport(p) {
  const hit = p.getBlockFromViewDirection({ maxDistance: 64 });
  if (!hit) return;
  const n = faceVec(hit.face);
  const l = hit.block.location;
  p.teleport({ x: l.x + 0.5 + n.x, y: l.y + Math.max(0, n.y), z: l.z + 0.5 + n.z });
  sound(p, "mob.endermen.portal");
}
/** HyperkineticLens: projétil explosivo (raio cresce com a carga; custo em EMC das Klein Stars). @param {Player} p @param {string} id */
function lensShot(p, id) {
  const c = getCharge(p, id);
  const cost = 384 * (c + 1);
  if (!consumeStarEmc(p, cost)) return p.onScreenDisplay.setActionBar(`§cSão necessários ${fmt(cost)} EMC nas Klein Stars.`);
  const hit = p.getBlockFromViewDirection({ maxDistance: 128 });
  if (!hit) return;
  const l = hit.block.location;
  p.dimension.createExplosion({ x: l.x + 0.5, y: l.y + 0.5, z: l.z + 0.5 }, 4 + 2 * c, { breaksBlocks: true, source: p });
}
/** DestructionCatalyst.useOn: caixa 3×3 com profundidade pela carga, 8 EMC por bloco. @param {Player} p @param {Block} b @param {Direction|undefined} face @param {string} id */
function destroyDeep(p, b, face, id) {
  const depth = 1 + 3 * getCharge(p, id);
  const n = faceVec(face);
  const [u, v] = perp(n);
  const o = b.location;
  const dim = b.dimension;
  job(function* () {
    for (let d = 0; d < depth; d++)
      for (let a = -1; a <= 1; a++)
        for (let c = -1; c <= 1; c++) {
          const l = { x: o.x - n.x * d + u.x * a + v.x * c, y: o.y - n.y * d + u.y * a + v.y * c, z: o.z - n.z * d + u.z * a + v.z * c };
          let blk;
          try {
            blk = dim.getBlock(l);
          } catch {
            continue;
          }
          if (!blk || blk.isAir || HARD.has(blk.typeId)) continue;
          if (!consumeStarEmc(p, 8)) return p.onScreenDisplay.setActionBar("§cSem EMC nas Klein Stars.");
          breakBlock(dim, l);
          yield;
        }
    sound(p, "random.explode");
  });
}

/** Pedra da Mente: guardar e retirar experiência (MindStone). @param {Player} p */
async function mindMenu(p) {
  const c = inv(p);
  const slot = p.selectedSlotIndex;
  const it = c.getItem(slot);
  if (!it) return;
  const stored = Number(it.getDynamicProperty("pe:xp") ?? 0);
  const r = await show(new ActionFormData().title("Pedra da Mente").body(`XP guardado: §e${fmt(stored)}§r\nSeu XP: §e${fmt(p.getTotalXp())}`).button("Guardar todo o meu XP").button("Retirar todo o XP guardado").button("Fechar"), p);
  if (!r || r.canceled || r.selection === undefined || r.selection === 2) return;
  const cur = c.getItem(slot);
  if (!cur || cur.typeId !== it.typeId) return;
  let xp = Number(cur.getDynamicProperty("pe:xp") ?? 0);
  if (r.selection === 0) {
    const mine = p.getTotalXp();
    p.resetLevel();
    xp += mine;
  } else {
    p.addExperience(xp);
    xp = 0;
  }
  cur.setDynamicProperty("pe:xp", xp);
  cur.setLore([`§r§7XP guardado: §e${fmt(xp)}`]);
  c.setItem(slot, cur);
  sound(p, "random.orb");
}
/** @param {Player} p */
async function goedMenu(p) {
  const c = inv(p);
  const slot = p.selectedSlotIndex;
  const it = c.getItem(slot);
  if (!it) return;
  const m = Number(it.getDynamicProperty("pe:mode") ?? 2);
  const f = new ActionFormData().title("Gema da Densidade Eterna").body(`Alvo: §e${pretty(GOED_TARGETS[m])}§r\nEMC guardado: §e${fmt(Number(it.getDynamicProperty("pe:emc") ?? 0))}`);
  for (const t of GOED_TARGETS) f.button({ rawtext: [nameMsg(t)] });
  const r = await show(f, p);
  if (!r || r.canceled || r.selection === undefined) return;
  const cur = c.getItem(slot);
  if (!cur || cur.typeId !== it.typeId) return;
  cur.setDynamicProperty("pe:mode", r.selection);
  c.setItem(slot, cur);
}
/** @param {Player} p */
async function arcanaMenu(p) {
  const c = inv(p);
  const slot = p.selectedSlotIndex;
  const it = c.getItem(slot);
  if (!it) return;
  const m = Number(it.getDynamicProperty("pe:mode") ?? 0);
  const f = new ActionFormData().title("Anel Arcano").body(`Modo: §e${ARCANA_MODES[m]}§r • ${isOn(it) ? "§aativo" : "§7inativo"}`);
  for (const name of ARCANA_MODES) f.button(name);
  f.button(isOn(it) ? "Desativar" : "Ativar");
  const r = await show(f, p);
  if (!r || r.canceled || r.selection === undefined) return;
  const cur = c.getItem(slot);
  if (!cur || cur.typeId !== it.typeId) return;
  if (r.selection < 4) cur.setDynamicProperty("pe:mode", r.selection);
  else cur.setDynamicProperty("pe:on", !isOn(cur));
  cur.setLore([`§r§7Modo: §e${ARCANA_MODES[Number(cur.getDynamicProperty("pe:mode") ?? 0)]}`, isOn(cur) ? "§r§aAtivo" : "§r§7Inativo"]);
  c.setItem(slot, cur);
}

// ───────────────────────────────────────────── Bolsas Alquímicas (uma por cor, por jogador, 104 espaços)
const BAG_SLOTS = 104;
/** @param {Player} p @param {string} color */
async function bagMenu(p, color) {
  const key = "pe:bag:" + color;
  for (;;) {
    const items = readChunked(p, key, /** @type {VStack[]} */ ([]));
    const r = await show(new ActionFormData().title("Bolsa Alquímica").body(`Espaços usados: ${items.length}/${BAG_SLOTS}\n§7Todas as bolsas desta cor compartilham o conteúdo.`).button("Depositar itens").button("Retirar itens").button("Fechar"), p);
    if (!r || r.canceled || r.selection === undefined || r.selection === 2) return;
    const c = inv(p);
    if (r.selection === 0) {
      const f = new ActionFormData().title("Depositar").button("§6Depositar todos os itens simples");
      /** @type {number[]} */
      const slots = [-1];
      for (let i = 0; i < c.size; i++) {
        const it = c.getItem(i);
        if (it && isPlain(it)) {
          f.button(label(it.typeId, ` §8x${it.amount}`));
          slots.push(i);
        }
      }
      const s = await show(f, p);
      if (!s || s.canceled || s.selection === undefined) continue;
      const cur = readChunked(p, key, /** @type {VStack[]} */ ([]));
      const list = slots[s.selection] === -1 ? [...Array(c.size).keys()] : [slots[s.selection]];
      for (const i of list) {
        const it = c.getItem(i);
        if (!it || !isPlain(it)) continue;
        const left = vAdd(cur, it.typeId, it.amount, BAG_SLOTS);
        if (left === it.amount) continue;
        if (left <= 0) c.setItem(i, undefined);
        else {
          it.amount = left;
          c.setItem(i, it);
        }
      }
      writeChunked(p, key, cur);
    } else {
      const cur = readChunked(p, key, /** @type {VStack[]} */ ([]));
      if (!cur.length) {
        tell(p, "§7A bolsa está vazia.");
        continue;
      }
      const f = new ActionFormData().title("Retirar").button("§6Retirar tudo o que couber");
      for (const v of cur) f.button(label(v.id, ` §8x${v.n}`));
      const s = await show(f, p);
      if (!s || s.canceled || s.selection === undefined) continue;
      const now = readChunked(p, key, /** @type {VStack[]} */ ([]));
      const pick = s.selection === 0 ? now : now.filter((v) => v.id === cur[(s.selection ?? 1) - 1]?.id).slice(0, 1);
      for (const v of pick) {
        const rest = c.addItem(new ItemStack(v.id, v.n));
        v.n = rest ? rest.amount : 0;
      }
      writeChunked(p, key, now.filter((v) => v.n > 0));
    }
  }
}

// ───────────────────────────────────────────── Armaduras (PEArmor: redução de dano; Gem*: efeitos)
const ARMOR_BASE = { dark_matter: 0.8, red_matter: 0.9, gem: 0.9 }; // getFullSetBaseReduction
const PIECE = { Head: 0.2, Chest: 0.3, Legs: 0.3, Feet: 0.2 }; // PEArmor.getPieceEffectiveness
/** @param {Player} p */
function armorPieces(p) {
  const eq = /** @type {any} */ (p.getComponent("minecraft:equippable"));
  /** @type {Record<"Head"|"Chest"|"Legs"|"Feet", string>} */
  const out = { Head: "", Chest: "", Legs: "", Feet: "" };
  if (!eq) return out;
  for (const s of /** @type {("Head"|"Chest"|"Legs"|"Feet")[]} */ (["Head", "Chest", "Legs", "Feet"])) out[s] = eq.getEquipment(EquipmentSlot[s])?.typeId ?? "";
  return out;
}
/** @param {string} id */
function armorMat(id) {
  if (!id.startsWith(P)) return null;
  if (id.startsWith(P + "dark_matter_")) return "dark_matter";
  if (id.startsWith(P + "red_matter_")) return "red_matter";
  if (id.startsWith(P + "gem_")) return "gem";
  return null;
}
/** @param {Player} p @param {string} eff @param {number} amp @param {number} [dur] */
function effect(p, eff, amp, dur = 60) {
  try {
    p.addEffect(eff, dur, { amplifier: amp, showParticles: false });
  } catch {
    /* ignore */
  }
}
/** @param {Player} p @param {number} amount */
function healPlayer(p, amount) {
  const h = /** @type {any} */ (p.getComponent("minecraft:health"));
  if (!h || h.currentValue >= h.effectiveMax) return false;
  h.setCurrentValue(Math.min(h.effectiveMax, h.currentValue + amount));
  return true;
}

/** Menu da armadura de Gema (no Java: teclas). Abre ao agachar duas vezes rápido. @param {Player} p */
async function gemMenu(p) {
  const a = armorPieces(p);
  const f = new ActionFormData().title("Armadura de Gema");
  /** @type {string[]} */
  const acts = [];
  if (a.Head === P + "gem_helmet") {
    f.button(`Visão noturna: ${p.getDynamicProperty("pe:nv") === true ? "§aligada" : "§7desligada"}`);
    acts.push("nv");
    f.button("Raio onde estou olhando");
    acts.push("zap");
  }
  if (a.Chest === P + "gem_chestplate") {
    f.button("Explosão nova (raio 9)");
    acts.push("boom");
  }
  f.button("Fechar");
  acts.push("x");
  const r = await show(f, p);
  if (!r || r.canceled || r.selection === undefined) return;
  const act = acts[r.selection];
  if (act === "nv") {
    const on = p.getDynamicProperty("pe:nv") !== true;
    p.setDynamicProperty("pe:nv", on);
    if (!on) p.removeEffect("night_vision");
  } else if (act === "zap") {
    const hit = p.getBlockFromViewDirection({ maxDistance: 120 });
    if (hit) p.dimension.spawnEntity("minecraft:lightning_bolt", hit.block.center());
  } else if (act === "boom") {
    effect(p, "resistance", 4, 10);
    p.dimension.createExplosion(p.location, 9, { breaksBlocks: true, source: p });
  }
}

// ───────────────────────────────────────────── blocos especiais
const NOVA = { [P + "nova_catalyst"]: 8, [P + "nova_cataclysm"]: 16 };
/** @param {Player} p @param {Block} b */
function igniteNova(p, b) {
  const power = NOVA[b.typeId];
  const dim = b.dimension;
  const at = b.center();
  b.setPermutation(BlockPermutation.resolve("minecraft:air"));
  sound(p, "random.fuse");
  system.runTimeout(() => {
    try {
      dim.createExplosion(at, power, { breaksBlocks: true });
    } catch {
      /* ignore */
    }
  }, 80);
}

// ───────────────────────────────────────────── eventos e laços dos itens
world.afterEvents.entityHitEntity.subscribe((ev) => {
  const p = ev.damagingEntity;
  if (p.typeId !== "minecraft:player") return;
  const held = inv(/** @type {Player} */ (p)).getItem(/** @type {Player} */ (p).selectedSlotIndex);
  if (!held || !MATTER_TOOLS[held.typeId]) return;
  const c = getCharge(/** @type {Player} */ (p), held.typeId);
  if (c > 0 && ev.hitEntity.isValid) {
    try {
      ev.hitEntity.applyDamage(c, { cause: EntityDamageCause.override, damagingEntity: p }); // attackWithCharge: +carga, ignora armadura
    } catch {
      /* ignore */
    }
  }
});

world.beforeEvents.playerInteractWithEntity.subscribe((ev) => {
  const id = ev.itemStack?.typeId;
  if (!id || !(id === P + "dark_matter_shears" || id === P + "red_matter_shears" || id === P + "red_matter_katar")) return;
  const e = ev.target;
  if (e.typeId !== "minecraft:sheep" && e.typeId !== "minecraft:snow_golem") return;
  ev.cancel = true;
  system.run(() => {
    if (shearEntity(e, 1)) sound(ev.player, "mob.sheep.shear");
  });
});

world.beforeEvents.playerBreakBlock.subscribe((ev) => {
  const id = ev.itemStack?.typeId;
  if (!id || !(id.endsWith("_shears") || id === P + "red_matter_katar") || !id.startsWith(P)) return;
  const bid = ev.block.typeId;
  if (!SHEARS_DROP(bid)) return;
  ev.cancel = true; // tesoura: o bloco cai inteiro (folhas, teias, trepadeiras...)
  const dim = ev.block.dimension;
  const l = ev.block.location;
  system.run(() => {
    try {
      const b = dim.getBlock(l);
      if (!b || b.typeId !== bid) return;
      b.setPermutation(BlockPermutation.resolve("minecraft:air"));
      const drop = bid === "minecraft:deadbush" ? "minecraft:deadbush" : bid;
      dim.spawnItem(new ItemStack(drop, 1), { x: l.x + 0.5, y: l.y + 0.5, z: l.z + 0.5 });
    } catch {
      /* item inexistente: nada cai, como a quebra vanilla sem tesoura */
    }
  });
});

/** duplo agachar para o menu da armadura de Gema */
/** @type {Map<string, number>} */
const lastSneak = new Map();
world.afterEvents.playerButtonInput.subscribe((ev) => {
  if (ev.button !== InputButton.Sneak || ev.newButtonState !== ButtonState.Pressed) return;
  const p = ev.player;
  const now = Date.now();
  const prev = lastSneak.get(p.id) ?? 0;
  lastSneak.set(p.id, now);
  if (now - prev > 400) return;
  lastSneak.set(p.id, 0);
  const a = armorPieces(p);
  if (a.Head === P + "gem_helmet" || a.Chest === P + "gem_chestplate") gemMenu(p);
});

let itemTick = 0;
system.runInterval(() => {
  itemTick++;
  for (const p of world.getPlayers()) {
    try {
      const a = armorPieces(p);
      const gemFeet = a.Feet === P + "gem_boots";
      // ── voo: Botas de Gema (GemFeet) e Vendaval/Arcano no modo voo
      let flying = false;
      for (const it of hotbarItems(p)) {
        if (it.typeId === P + "swiftwolf_rending_gale" && Number(it.getDynamicProperty("pe:mode") ?? 0) >= 2) flying = true;
        if (it.typeId === P + "arcana_ring" && isOn(it) && Number(it.getDynamicProperty("pe:mode") ?? 0) === 3) flying = true;
      }
      if (flying && starTotal(p) >= 64 && drainEmc(p, p.isOnGround ? 0 : 0.32)) flyTick(p, true);
      else if (gemFeet) {
        const v = p.getVelocity();
        if (p.isJumping) p.applyKnockback({ x: v.x, z: v.z }, Math.min(0.8, Math.max(v.y, 0) + 0.1)); // +0,1 por tick ao segurar pulo
      }
      if (a.Legs === P + "gem_leggings" && p.isSneaking && !p.isOnGround) {
        const v = p.getVelocity();
        if (v.y > -8) p.applyKnockback({ x: v.x, z: v.z }, v.y - 0.32); // GemLegs: descida rápida
      }
      if (itemTick % 10 !== 0) continue;
      // ── a cada meio segundo: efeitos de armadura e itens passivos
      let red = 0;
      for (const s of /** @type {("Head"|"Chest"|"Legs"|"Feet")[]} */ (["Head", "Chest", "Legs", "Feet"])) {
        const m = armorMat(a[s]);
        if (m) red += ARMOR_BASE[m] * PIECE[s];
      }
      const lvl = Math.min(4, Math.floor(red / 0.2 + 1e-6));
      if (lvl > 0) effect(p, "resistance", lvl - 1, 30);
      if (a.Head === P + "gem_helmet") {
        effect(p, "water_breathing", 0, 30);
        if (p.getDynamicProperty("pe:nv") === true) effect(p, "night_vision", 0, 260);
        if (itemTick % 20 === 0) healPlayer(p, 2);
      }
      if (a.Chest === P + "gem_chestplate") {
        effect(p, "fire_resistance", 0, 30);
        if (itemTick % 200 === 0) effect(p, "saturation", 1, 1);
      }
      if (a.Legs === P + "gem_leggings" && p.isSneaking) repel(p, 3.5);
      if (gemFeet) {
        effect(p, "speed", 4, 30); // +100% de velocidade
        if (!p.isOnGround && p.getVelocity().y < -0.3 && !p.isJumping) effect(p, "slow_falling", 0, 15); // sem dano de queda
      }
      // ── anéis e pedras na barra rápida
      let fireImmune = false;
      for (const it of hotbarItems(p)) {
        const id = it.typeId;
        if (id === P + "swiftwolf_rending_gale") {
          const m = Number(it.getDynamicProperty("pe:mode") ?? 0);
          if ((m === 1 || m === 3) && starTotal(p) >= 64 && drainEmc(p, 3.2)) repel(p, 5);
        } else if (id === P + "zero_ring" && isOn(it)) freezeAround(p, 3, true);
        else if (id === P + "ignition_ring") {
          fireImmune = true;
          if (isOn(it) && starTotal(p) >= 64 && drainEmc(p, 3.2)) {
            for (const e of p.dimension.getEntities({ location: p.location, maxDistance: 8, families: ["monster"] })) e.setOnFire(5, true);
          }
        } else if (id === P + "harvest_goddess_band" && isOn(it) && starTotal(p) >= 64 && drainEmc(p, 3.2)) growNearby(p.dimension, p.location, 5, 12);
        else if (STONES[id] && isOn(it)) {
          const kind = STONES[id];
          if ((kind === "soul" || kind === "life") && itemTick % 20 === 0) {
            const h = /** @type {any} */ (p.getComponent("minecraft:health"));
            if (h && h.currentValue < h.effectiveMax && consumeStarEmc(p, 64)) healPlayer(p, 2);
          }
          if ((kind === "body" || kind === "life") && itemTick % 200 === 0 && consumeStarEmc(p, 64)) effect(p, "saturation", 1, 1);
        } else if (id === P + "archangel_smite" && isOn(it) && itemTick % 20 === 0) {
          if (p.dimension.getEntities({ location: p.location, maxDistance: 24, families: ["monster"] }).length) fireHomingArrow(p);
        } else if (id === P + "watch_of_flowing_time") {
          const m = Number(it.getDynamicProperty("pe:mode") ?? 0);
          if (m > 0 && drainEmc(p, (getCharge(p, id) + 1) * 0.5)) {
            const step = 4 * (getCharge(p, id) + 1) * 10;
            world.setTimeOfDay((((world.getTimeOfDay() + (m === 1 ? step : -step)) % 24000) + 24000) % 24000);
            growNearby(p.dimension, p.location, 8, 6 * (getCharge(p, id) + 1));
            for (const e of p.dimension.getEntities({ location: p.location, maxDistance: 8, families: ["mob"], excludeTypes: ["minecraft:player"] })) effect(/** @type {any} */ (e), "slowness", 2, 20);
          }
        } else if (id === P + "gem_of_eternal_density" && isOn(it) && itemTick % 20 === 0) condenseGem(p, it);
        else if (id === P + "arcana_ring" && isOn(it)) {
          const m = Number(it.getDynamicProperty("pe:mode") ?? 0);
          if (m === 0) freezeAround(p, 3, true);
          else if (m === 1) {
            fireImmune = true;
            for (const e of p.dimension.getEntities({ location: p.location, maxDistance: 8, families: ["monster"] })) e.setOnFire(5, true);
          } else if (m === 2) growNearby(p.dimension, p.location, 5, 12);
          else repel(p, 5);
        }
      }
      if (fireImmune) effect(p, "fire_resistance", 0, 30);
    } catch {
      /* jogador saiu ou entidade inválida */
    }
  }
  // flechas teleguiadas
  for (const [k, h] of homing) {
    if (!h.arrow.isValid || --h.ticks <= 0) {
      homing.delete(k);
      continue;
    }
    try {
      const target = h.arrow.dimension.getEntities({ location: h.arrow.location, maxDistance: 16, families: ["monster"], closest: 1 })[0];
      if (!target) continue;
      const to = target.getHeadLocation();
      const v = h.arrow.getVelocity();
      const d = { x: to.x - h.arrow.location.x, y: to.y - h.arrow.location.y, z: to.z - h.arrow.location.z };
      const len = Math.hypot(d.x, d.y, d.z) || 1;
      h.arrow.applyImpulse({ x: (d.x / len) * 0.4 - v.x * 0.2, y: (d.y / len) * 0.4 - v.y * 0.2, z: (d.z / len) * 0.4 - v.z * 0.2 });
    } catch {
      homing.delete(k);
    }
  }
}, 1);

/** GemEternalDensity.condense: transforma itens de menor EMC no alvo escolhido. @param {Player} p @param {ItemStack} gem */
function condenseGem(p, gem) {
  const c = inv(p);
  const target = GOED_TARGETS[Number(gem.getDynamicProperty("pe:mode") ?? 2)];
  const targetEmc = emcOf(target);
  if (targetEmc <= 0) return;
  let slot = -1;
  for (let i = 0; i < c.size; i++) {
    const it = c.getItem(i);
    if (it && it.typeId === gem.typeId && it.getDynamicProperty("pe:on") === true) slot = i;
  }
  let stored = Number(gem.getDynamicProperty("pe:emc") ?? 0);
  for (let i = 0; i < c.size; i++) {
    const it = c.getItem(i);
    if (!it || !isPlain(it) || it.typeId === target || it.typeId.startsWith(P) || GOED_TARGETS.includes(it.typeId)) continue;
    const v = emcOf(it.typeId);
    if (v <= 0 || v >= targetEmc) continue;
    stored += v * it.amount;
    c.setItem(i, undefined);
  }
  const make = Math.floor(stored / targetEmc);
  if (make > 0) {
    giveItems(p, target, make);
    stored -= make * targetEmc;
  }
  if (slot >= 0) {
    const g = c.getItem(slot);
    if (g) {
      g.setDynamicProperty("pe:emc", stored);
      c.setItem(slot, g);
    }
  }
}

// Tocha de Interdição: afasta criaturas hostis num raio de 8 blocos (WorldHelper.repelEntitiesInterdiction)
system.runInterval(() => {
  for (const r of machines.values()) {
    if (r.t !== P + "interdiction_torch") continue;
    try {
      const dim = world.getDimension(r.d);
      const at = { x: r.x + 0.5, y: r.y + 0.5, z: r.z + 0.5 };
      for (const e of dim.getEntities({ location: at, maxDistance: 8, families: ["monster"] })) {
        const dx = e.location.x - at.x;
        const dz = e.location.z - at.z;
        const d = Math.hypot(dx, dz) || 1;
        e.applyKnockback({ x: (dx / d) * 1.2, z: (dz / d) * 1.2 }, 0.2);
      }
    } catch {
      /* chunk descarregado */
    }
  }
}, 5);

// ───────────────────────────────────────────── eventos
let ready = false;
world.afterEvents.worldLoad.subscribe(() => {
  loadMachines();
  ready = true;
});

world.afterEvents.playerSpawn.subscribe((ev) => {
  if (!ev.initialSpawn) return;
  const p = ev.player;
  if (p.getDynamicProperty("pe:welcomed") !== true) {
    p.setDynamicProperty("pe:welcomed", true);
    tell(p, "§6[ProjectE]§r Addon carregado. Crie uma §ePedra Filosofal§r (redstone, pó de glowstone e diamante) e depois uma §eMesa de Transmutação§r.");
  }
});
world.afterEvents.playerLeave.subscribe((ev) => {
  knowCache.delete(ev.playerId);
  lastBlockUse.delete(ev.playerId);
  lastHeld.delete(ev.playerId);
});

world.afterEvents.playerPlaceBlock.subscribe((ev) => {
  if (MACHINE_TYPES.has(ev.block.typeId)) machineAt(ev.block);
});

world.afterEvents.playerBreakBlock.subscribe((ev) => {
  const brokenId = ev.brokenBlockPermutation.type.id;
  const dim = ev.block.dimension;
  const loc = ev.block.location;
  if (MACHINE_TYPES.has(brokenId)) {
    removeMachine(mkey(dim.id, loc), dim);
    flushMachines();
    return;
  }
  const held = ev.itemStackBeforeBreak;
  const ht = held ? MATTER_TOOLS[held.typeId] : undefined;
  if (held && ht && (ht.kind === "pickaxe" || ht.kind === "morning_star")) digByMode(ev.player, dim, loc, held.typeId);
});

world.beforeEvents.playerInteractWithBlock.subscribe((ev) => {
  const { player, block, itemStack, blockFace } = ev;
  const bid = block.typeId;
  const iid = itemStack?.typeId;
  const igniter = iid === "minecraft:flint_and_steel" || iid === "minecraft:fire_charge";
  const handledBlock = bid === TABLE || (MACHINE_TYPES.has(bid) && bid !== TORCH) || (!!NOVA[bid] && igniter);
  const handledItem = !!iid && (iid === PHIL || iid === EVERTIDE || iid === VOLCANITE || !!DIVINING[iid] || toolHandlesBlock(iid, block) || iid === P + "ignition_ring" || iid === P + "harvest_goddess_band" || iid === P + "destruction_catalyst" || iid === P + "catalytic_lens");
  if (handledBlock && player.isSneaking && itemStack) return; // agachado com item: comportamento normal (colocar bloco)
  if (!handledBlock && !handledItem) return;
  ev.cancel = true;
  if (ev.isFirstEvent === false) return;
  markBlockUse(player);
  const dimId = block.dimension.id;
  const loc = block.location;
  system.run(() => {
    let b;
    try {
      b = world.getDimension(dimId).getBlock(loc);
    } catch {
      return;
    }
    if (!b) return;
    if (handledBlock) {
      if (NOVA[b.typeId] && igniter) igniteNova(player, b);
      else if (b.typeId === TABLE) transmutationMenu(player);
      else if (MACHINE_TYPES.has(b.typeId)) machineMenu(player, b);
      return;
    }
    if (iid === PHIL) philTransmute(player, b, blockFace);
    else if (iid === EVERTIDE) placeLiquid(player, b, blockFace, "water");
    else if (iid === VOLCANITE) placeLiquid(player, b, blockFace, "lava");
    else if (iid && DIVINING[iid]) divine(player, b, blockFace, iid);
    else if (iid && MATTER_TOOLS[iid]) toolUseOn(player, b, blockFace, iid);
    else if (iid === P + "destruction_catalyst" || iid === P + "catalytic_lens") destroyDeep(player, b, blockFace, iid);
    else if (iid === P + "ignition_ring") {
      const n = faceVec(blockFace);
      const f = b.dimension.getBlock({ x: b.location.x + n.x, y: b.location.y + n.y, z: b.location.z + n.z });
      if (f && f.isAir) f.setPermutation(BlockPermutation.resolve("minecraft:fire"));
    } else if (iid === P + "harvest_goddess_band") growNearby(b.dimension, b.location, 2, 40);
  });
});

world.afterEvents.itemUse.subscribe((ev) => {
  const p = ev.source;
  const it = ev.itemStack;
  if (!it || recentBlockUse(p)) return;
  const id = it.typeId;
  if (extraUseAir(p, it)) return;
  if (id === TABLET) transmutationMenu(p);
  else if (id === PHIL) philUseAir(p);
  else if (id === TOME) tomeUse(p);
  else if (id === BHB) toggleBand(p);
  else if (KLEIN[id]) p.onScreenDisplay.setActionBar(`§bKlein Star: §e${fmt(starEmc(it))}§b / ${fmt(KLEIN[id])} EMC`);
});

// ───────────────────────────────────────────── laços periódicos
/** @type {Map<string, string>} */
const lastHeld = new Map();

// máquinas + Talismã de Reparo (1x por segundo)
system.runInterval(() => {
  if (!ready) return;
  try {
    tickMachines();
  } catch (e) {
    console.warn("[ProjectE] erro nas máquinas: " + e);
  }
  for (const p of world.getPlayers()) {
    try {
      if (!hasItem(p, TALISMAN)) continue;
      const c = inv(p);
      for (let i = 0; i < c.size; i++) {
        const it = c.getItem(i);
        if (!it) continue;
        const d = durability(it);
        if (d && d.damage > 0) {
          d.damage = d.damage - 1;
          c.setItem(i, it);
        }
      }
      const eq = /** @type {import("@minecraft/server").EntityEquippableComponent | undefined} */ (p.getComponent("minecraft:equippable"));
      if (eq) {
        for (const slot of [EquipmentSlot.Head, EquipmentSlot.Chest, EquipmentSlot.Legs, EquipmentSlot.Feet, EquipmentSlot.Offhand]) {
          const it = eq.getEquipment(slot);
          if (!it) continue;
          const d = durability(it);
          if (d && d.damage > 0) {
            d.damage = d.damage - 1;
            eq.setEquipment(slot, it);
          }
        }
      }
    } catch {
      /* ignore */
    }
  }
}, 20);

// Faixa do Buraco Negro (atração de itens) + EMC do item na mão
system.runInterval(() => {
  if (!ready) return;
  for (const p of world.getPlayers()) {
    try {
      const c = inv(p);
      const held = c.getItem(p.selectedSlotIndex);
      const hid = held?.typeId ?? "";
      if (lastHeld.get(p.id) !== hid) {
        lastHeld.set(p.id, hid);
        if (held) {
          const v = unitEmc(held);
          if (v > 0) p.onScreenDisplay.setActionBar(`§eEMC: ${fmt(v)}${held.amount > 1 ? ` §7(pilha: ${fmt(v * held.amount)})` : ""}`);
        }
      }
      let band = false;
      for (let i = 0; i < c.size && !band; i++) {
        const it = c.getItem(i);
        if (it && MAGNETS.has(it.typeId) && it.getDynamicProperty("pe:on") === true) band = true;
      }
      if (!band) continue;
      const items = p.dimension.getEntities({ type: "minecraft:item", location: p.location, maxDistance: 7 });
      for (const e of items) e.teleport(p.location);
    } catch {
      /* ignore */
    }
  }
}, 5);
