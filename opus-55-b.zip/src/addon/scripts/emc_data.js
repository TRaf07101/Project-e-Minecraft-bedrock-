// @ts-check
// Arquivo provisório apenas para a checagem de tipos no projeto.
// No .mcaddon este módulo é substituído pelos dados gerados em src/addon/build.ts.

/** @type {Record<string, number>} */
export const EMC = {};
/** @type {[string, string, string][]} */
export const WORLD_TRANSMUTATIONS = [];
/** @type {Record<string, string>} */
export const SMELTING = {};
/** @type {Record<string, string>} */
export const NAMES = {};
/** @type {Record<string, string>} */
export const ICONS = {};
