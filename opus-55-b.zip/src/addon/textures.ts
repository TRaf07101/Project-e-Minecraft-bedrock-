import { PE_TEXTURES } from "./pe_textures";
// Texturas originais em pixel art, geradas proceduralmente (não usam os assets do ProjectE/EE2).
type Shape = string;

type RGB = [number, number, number];
const hex = (c: string): RGB => {
  const n = parseInt(c.replace("#", ""), 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
};
const shade = (c: RGB, f: number): RGB => [Math.min(255, c[0] * f), Math.min(255, c[1] * f), Math.min(255, c[2] * f)];
const mix = (a: RGB, b: RGB, t: number): RGB => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];
const hash = (x: number, y: number, s = 0) => {
  let h = (x * 374761393 + y * 668265263 + s * 982451653) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
};

export class Canvas {
  w: number;
  h: number;
  d: Uint8ClampedArray;
  constructor(w = 16, h = 16) {
    this.w = w;
    this.h = h;
    this.d = new Uint8ClampedArray(w * h * 4);
  }
  set(x: number, y: number, c: RGB, a = 255) {
    x = Math.round(x);
    y = Math.round(y);
    if (x < 0 || y < 0 || x >= this.w || y >= this.h) return;
    const i = (y * this.w + x) * 4;
    this.d[i] = c[0];
    this.d[i + 1] = c[1];
    this.d[i + 2] = c[2];
    this.d[i + 3] = a;
  }
  alpha(x: number, y: number) {
    if (x < 0 || y < 0 || x >= this.w || y >= this.h) return 0;
    return this.d[(y * this.w + x) * 4 + 3];
  }
  /** pinta todo pixel cujo centro satisfaz f */
  fill(f: (x: number, y: number) => RGB | null) {
    for (let y = 0; y < this.h; y++)
      for (let x = 0; x < this.w; x++) {
        const c = f(x + 0.5, y + 0.5);
        if (c) this.set(x, y, c);
      }
  }
  seg(x0: number, y0: number, x1: number, y1: number, w: number, color: (t: number) => RGB) {
    const dx = x1 - x0;
    const dy = y1 - y0;
    const L = dx * dx + dy * dy || 1;
    this.fill((x, y) => {
      let t = ((x - x0) * dx + (y - y0) * dy) / L;
      t = Math.max(0, Math.min(1, t));
      const px = x0 + t * dx - x;
      const py = y0 + t * dy - y;
      return Math.sqrt(px * px + py * py) <= w / 2 ? color(t) : null;
    });
  }
  /** mistura alfa sobre o pixel existente */
  blend(x: number, y: number, c: RGB, a: number) {
    x = Math.round(x);
    y = Math.round(y);
    if (x < 0 || y < 0 || x >= this.w || y >= this.h || a <= 0) return;
    const i = (y * this.w + x) * 4;
    const da = this.d[i + 3] / 255;
    const oa = a + da * (1 - a);
    if (oa <= 0) return;
    for (let k = 0; k < 3; k++) this.d[i + k] = (c[k] * a + this.d[i + k] * da * (1 - a)) / oa;
    this.d[i + 3] = oa * 255;
  }
  rect(x0: number, y0: number, w: number, h: number, c: RGB, a = 255) {
    for (let y = y0; y < y0 + h; y++) for (let x = x0; x < x0 + w; x++) this.set(x, y, c, a);
  }
  ring(cx: number, cy: number, r: number, width: number, c: RGB, a: number) {
    for (let y = Math.floor(cy - r - width); y <= cy + r + width; y++)
      for (let x = Math.floor(cx - r - width); x <= cx + r + width; x++) {
        const d = Math.abs(Math.hypot(x + 0.5 - cx, y + 0.5 - cy) - r);
        if (d < width / 2 + 0.5) this.blend(x, y, c, a * Math.min(1, width / 2 + 0.5 - d));
      }
  }
  disc(cx: number, cy: number, r: number, c: RGB, a: number) {
    for (let y = Math.floor(cy - r); y <= cy + r; y++)
      for (let x = Math.floor(cx - r); x <= cx + r; x++) if (Math.hypot(x + 0.5 - cx, y + 0.5 - cy) <= r) this.blend(x, y, c, a);
  }
  line(x0: number, y0: number, x1: number, y1: number, c: RGB, a: number) {
    const n = Math.ceil(Math.hypot(x1 - x0, y1 - y0) * 1.5);
    const seen = new Set<number>();
    for (let i = 0; i <= n; i++) {
      const x = Math.floor(x0 + ((x1 - x0) * i) / n);
      const y = Math.floor(y0 + ((y1 - y0) * i) / n);
      const k = y * this.w + x;
      if (seen.has(k)) continue;
      seen.add(k);
      this.blend(x, y, c, a);
    }
  }
  outline(c: RGB) {
    const add: [number, number][] = [];
    for (let y = 0; y < this.h; y++)
      for (let x = 0; x < this.w; x++) {
        if (this.alpha(x, y)) continue;
        if (this.alpha(x + 1, y) || this.alpha(x - 1, y) || this.alpha(x, y + 1) || this.alpha(x, y - 1)) add.push([x, y]);
      }
    for (const [x, y] of add) this.set(x, y, c);
  }
  async png(): Promise<Uint8Array> {
    const cv = document.createElement("canvas");
    cv.width = this.w;
    cv.height = this.h;
    const ctx = cv.getContext("2d")!;
    const img = ctx.createImageData(this.w, this.h);
    img.data.set(this.d);
    ctx.putImageData(img, 0, 0);
    const blob: Blob = await new Promise((res, rej) => cv.toBlob((b) => (b ? res(b) : rej(new Error("PNG"))), "image/png"));
    return new Uint8Array(await blob.arrayBuffer());
  }
}

const HANDLE: RGB = [74, 56, 44];

function drawShape(cv: Canvas, shape: Shape, base: RGB, acc: RGB) {
  const light = mix(base, acc, 0.55);
  const dark = shade(base, 0.6);
  const c = 7.5;
  const tex = (x: number, y: number) => shade(base, 0.9 + hash(Math.floor(x), Math.floor(y), 3) * 0.25);
  const head = (t: number) => (t < 0.35 ? light : base);
  switch (shape) {
    case "gem":
      cv.fill((x, y) => {
        const dx = x - c, dy = y - c;
        if (Math.abs(dx) + Math.abs(dy) * 1.1 > 7) return null;
        if (dy < -1.5) return dx < 0 ? acc : light;
        return dx < 0 ? base : dark;
      });
      cv.set(6, 4, [255, 255, 255]);
      break;
    case "coal":
      cv.fill((x, y) => {
        const d = Math.hypot(x - c, y - 8.2);
        if (d > 5.6 + hash(Math.floor(x), Math.floor(y), 7) * 1.2) return null;
        return hash(Math.floor(x), Math.floor(y), 9) > 0.78 ? acc : x + y < 13 ? light : tex(x, y);
      });
      break;
    case "dust":
      cv.fill((x, y) => {
        const top = 13 - (6 - ((x - c) * (x - c)) / 6);
        if (y < top || y > 13.5 || x < 1.5 || x > 14.5) return null;
        return hash(Math.floor(x), Math.floor(y), 5) > 0.7 ? acc : y < top + 1.2 ? light : tex(x, y);
      });
      break;
    case "orb":
      cv.fill((x, y) => {
        const d = Math.hypot(x - c, y - c);
        if (d > 6.3) return null;
        const l = Math.hypot(x - 5.5, y - 5.5);
        if (l < 1.6) return acc;
        return mix(light, dark, Math.min(1, l / 9));
      });
      break;
    case "star":
      cv.fill((x, y) => {
        const dx = x - c, dy = y - c;
        const r = Math.hypot(dx, dy);
        const a = Math.atan2(dy, dx);
        const lim = 2.6 + 4.6 * Math.pow(Math.abs(Math.cos(2 * a)), 6);
        if (r > lim && r > 3.2) return null;
        return r < 2 ? acc : r < 3.4 ? light : base;
      });
      break;
    case "band":
      cv.fill((x, y) => {
        const d = Math.hypot((x - c) * 1.05, y - 8.5);
        if (d < 3.2 || d > 5.6) return null;
        return y < 8 ? light : base;
      });
      cv.fill((x, y) => (Math.abs(x - c) + Math.abs(y - 3) < 2.2 ? acc : null));
      break;
    case "amulet":
      cv.seg(3, 2, c, 7, 1, () => [200, 170, 70]);
      cv.seg(12, 2, c, 7, 1, () => [200, 170, 70]);
      cv.fill((x, y) => (Math.hypot((x - c) * 1.2, y - 10.5) < 4.2 ? (Math.hypot(x - 6.5, y - 9.5) < 1.5 ? acc : base) : null));
      break;
    case "talisman":
      cv.fill((x, y) => (x > 3 && x < 13 && y > 1.5 && y < 14.5 ? base : null));
      cv.fill((x, y) => {
        const d = Math.hypot(x - c, y - c);
        return d > 2 && d < 3.4 ? acc : null;
      });
      cv.seg(5, 4, 11, 4, 1, () => acc);
      cv.seg(5, 12, 11, 12, 1, () => acc);
      break;
    case "book":
      cv.fill((x, y) => (x > 2.5 && x < 13.5 && y > 1.5 && y < 14.5 ? (x > 12 ? [235, 230, 210] : tex(x, y)) : null));
      cv.fill((x, y) => (Math.abs(x - 7.5) + Math.abs(y - 8) < 2.6 ? acc : null));
      break;
    case "tablet":
      cv.fill((x, y) => (x > 1.5 && x < 14.5 && y > 2.5 && y < 13.5 ? tex(x, y) : null));
      cv.fill((x, y) => {
        const d = Math.hypot(x - c, y - 8);
        return (d > 2.6 && d < 3.8) || d < 1.2 ? acc : null;
      });
      break;
    case "rod":
      cv.seg(3, 13, 11, 5, 1.6, () => HANDLE);
      cv.fill((x, y) => (Math.hypot(x - 12, y - 4) < 2.4 ? (Math.hypot(x - 11.3, y - 3.3) < 1 ? acc : base) : null));
      break;
    case "pickaxe":
      cv.seg(4, 13, 11, 6, 1.6, () => HANDLE);
      cv.seg(3, 4, 8, 2, 2.2, head);
      cv.seg(8, 2, 14, 8, 2.2, () => base);
      cv.set(8, 2, acc);
      break;
    case "axe":
      cv.seg(4, 14, 11, 4, 1.6, () => HANDLE);
      cv.fill((x, y) => (x > 7.5 && x < 13.5 && y > 1.5 && y < 7.5 && x + y > 10 ? (x > 12 ? acc : base) : null));
      break;
    case "shovel":
      cv.seg(3, 14, 10, 7, 1.6, () => HANDLE);
      cv.fill((x, y) => (Math.hypot(x - 11.5, y - 4.5) < 3.2 ? (Math.hypot(x - 12.5, y - 3.5) < 1.2 ? acc : base) : null));
      break;
    case "sword":
      cv.seg(5, 11, 13.5, 2.5, 2.4, (t) => (t > 0.85 ? acc : base));
      cv.seg(5.5, 11.5, 13, 3, 0.8, () => light);
      cv.seg(3, 9, 7, 13, 1.4, () => dark);
      cv.seg(2, 14, 4.5, 11.5, 1.6, () => HANDLE);
      break;
    case "hoe":
      cv.seg(4, 14, 11, 4, 1.6, () => HANDLE);
      cv.seg(8, 3, 13.5, 3, 2, (t) => (t > 0.8 ? acc : base));
      break;
    case "shears":
      cv.seg(3, 3, 11, 11, 2, () => base);
      cv.seg(3, 11, 11, 3, 2, () => light);
      cv.fill((x, y) => (Math.hypot(x - 12, y - 12) < 2.2 && Math.hypot(x - 12, y - 12) > 1 ? acc : null));
      cv.fill((x, y) => (Math.hypot(x - 12, y - 4) < 2.2 && Math.hypot(x - 12, y - 4) > 1 ? acc : null));
      break;
    case "hammer":
      cv.seg(4, 14, 10, 8, 1.6, () => HANDLE);
      cv.seg(7, 3, 13, 9, 4.2, (t) => (t < 0.2 || t > 0.8 ? light : base));
      cv.set(10, 6, acc);
      break;
    case "katar":
      cv.fill((x, y) => {
        const t = (y - 1) / 10;
        return y > 1 && y < 11 && Math.abs(x - c) < t * 3.2 ? (Math.abs(x - c) < 0.8 ? light : base) : null;
      });
      cv.seg(3, 11.5, 12, 11.5, 1.4, () => acc);
      cv.seg(7.5, 12, 7.5, 15, 1.6, () => HANDLE);
      break;
    case "morningstar":
      cv.seg(3, 14, 9, 8, 1.6, () => HANDLE);
      cv.fill((x, y) => (Math.hypot(x - 11, y - 5) < 3 ? (Math.hypot(x - 10, y - 4) < 1 ? acc : base) : null));
      for (const [px, py] of [[11, 1], [15, 5], [11, 9], [7, 5], [14, 2], [14, 8]]) cv.set(px, py, light);
      break;
    case "helmet":
      cv.fill((x, y) => (y > 3 && y < 11 && x > 2.5 && x < 13.5 && !(y > 7 && x > 4.5 && x < 11.5) ? (y < 5 ? light : tex(x, y)) : null));
      cv.set(7, 5, acc);
      cv.set(8, 5, acc);
      break;
    case "chestplate":
      cv.fill((x, y) => {
        if (y < 2.5 || y > 14 || x < 1.5 || x > 14.5) return null;
        if (y < 6 && x > 5.5 && x < 10.5) return null;
        if (y > 6 && (x < 3.5 || x > 12.5)) return null;
        return tex(x, y);
      });
      cv.fill((x, y) => (Math.abs(x - c) + Math.abs(y - 9) < 1.8 ? acc : null));
      break;
    case "leggings":
      cv.fill((x, y) => {
        if (y < 2.5 || y > 14.5 || x < 3.5 || x > 12.5) return null;
        if (y > 6 && x > 6.5 && x < 9.5) return null;
        return y < 4 ? light : tex(x, y);
      });
      break;
    case "boots":
      cv.fill((x, y) => {
        if (y < 6.5 || y > 13.5) return null;
        const left = x > 1.5 && x < 6.5 && (y > 10.5 || x > 3.5);
        const right = x > 9.5 && x < 14.5 && (y > 10.5 || x < 12.5);
        return left || right ? (y > 12 ? acc : tex(x, y)) : null;
      });
      break;
  }
  cv.outline(shade(base, 0.32));
}

// ───────────────────────────────────────────── Mesa de Transmutação (bloco)
// Desenho próprio no estilo do original (pedra escura com círculo alquímico rosa/roxo no topo).
const STONE: RGB[] = [[24, 24, 24], [33, 33, 33], [37, 37, 37], [18, 18, 18]];
export async function tableTextures(): Promise<{ top: Uint8Array; side: Uint8Array; bottom: Uint8Array }> {
  const t = tableCanvases();
  return { top: await t.top.png(), side: await t.side.png(), bottom: await t.bottom.png() };
}
export function tableCanvases(): { top: Canvas; side: Canvas; bottom: Canvas } {
  const top = new Canvas();
  top.fill((x, y) => STONE[Math.floor(hash(Math.floor(x), Math.floor(y), 41) * 4)]);
  for (let i = 0; i < 16; i++) {
    top.set(i, 0, [18, 18, 18]);
    top.set(i, 15, [18, 18, 18]);
    top.set(0, i, [18, 18, 18]);
    top.set(15, i, [18, 18, 18]);
  }
  const c = 7.5;
  top.fill((x, y) => {
    const d = Math.hypot(x - c - 0.5, y - c - 0.5);
    if (d > 6.9) return null;
    if (d > 5.9) return hash(Math.floor(x), Math.floor(y), 42) > 0.5 ? [176, 176, 176] : [163, 163, 163];
    return d < 1.6 ? [220, 171, 212] : mix([131, 68, 103], [66, 65, 63], Math.min(1, d / 7) * 0.5);
  });
  // hexagrama rosa
  const pts = (rot: number) => [0, 1, 2].map((k) => [8 + 5.2 * Math.cos(rot + (k * 2 * Math.PI) / 3), 8 + 5.2 * Math.sin(rot + (k * 2 * Math.PI) / 3)]);
  for (const tri of [pts(-Math.PI / 2), pts(Math.PI / 2)])
    for (let k = 0; k < 3; k++) top.line(tri[k][0], tri[k][1], tri[(k + 1) % 3][0], tri[(k + 1) % 3][1], [199, 129, 174], 1);
  top.set(7, 7, [255, 255, 255]);
  top.set(8, 8, [220, 171, 212]);

  const side = new Canvas();
  side.fill((x, y) => {
    const row = Math.floor(y) % 4;
    const col = Math.floor(x);
    const edge = col === 0 || col === 15;
    if (row === 0) return edge ? [54, 54, 53] : [66, 65, 63];
    if (row === 1) return shade([54, 54, 53], 0.9 + hash(col, Math.floor(y), 43) * 0.2);
    if (row === 2) return col % 4 === 2 && !edge ? [131, 68, 103] : [37, 37, 37];
    return [18, 18, 18];
  });

  const bottom = new Canvas();
  bottom.fill((x, y) => STONE[Math.floor(hash(Math.floor(x), Math.floor(y), 44) * 4)]);
  return { top, side, bottom };
}

// ───────────────────────────────────────────── Interface da Mesa (228×196, layout de GUITransmutation)
import { BURN_POS, FUEL_POS, GUI_H, GUI_W, INPUT_POS, LOCK_POS, MATTER_POS, SEARCH_BOX, UNLEARN_POS, invPos } from "./ui";

const PANEL: RGB = [198, 198, 198];
function mcPanel(cv: Canvas, w: number, h: number) {
  cv.fill((x, y) => {
    const ix = Math.floor(x), iy = Math.floor(y);
    const corner = (ix < 1 || ix > w - 2) && (iy < 1 || iy > h - 2);
    if (corner) return null;
    if (ix === 0 || iy === 0 || ix === w - 1 || iy === h - 1) return [0, 0, 0];
    if ((ix <= 2 || iy <= 2) && !(ix >= w - 3 || iy >= h - 3)) return [255, 255, 255];
    if (ix >= w - 3 || iy >= h - 3) return (ix <= 2 || iy <= 2) ? PANEL : [85, 85, 85];
    return PANEL;
  });
}
function mcSlot(cv: Canvas, x: number, y: number) {
  cv.rect(x, y, 18, 18, [139, 139, 139]);
  for (let i = 0; i < 17; i++) {
    cv.set(x + i, y, [55, 55, 55]);
    cv.set(x, y + i, [55, 55, 55]);
    cv.set(x + 17 - i, y + 17, [255, 255, 255]);
    cv.set(x + 17, y + 17 - i, [255, 255, 255]);
  }
}
const ORB: RGB = [205, 110, 230];
function orb(cv: Canvas, cx: number, cy: number) {
  for (let y = Math.floor(cy - 8); y <= cy + 8; y++)
    for (let x = Math.floor(cx - 8); x <= cx + 8; x++) {
      const d = Math.hypot(x + 0.5 - cx, y + 0.5 - cy);
      if (d > 8) continue;
      const t = 1 - d / 8;
      cv.blend(x, y, ORB, Math.pow(t, 1.3) * 0.85);
      if (d < 3.2) cv.blend(x, y, [255, 240, 255], (1 - d / 3.2) * 0.9);
    }
  // raios de brilho
  for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) for (let k = 3; k < 7; k++) cv.blend(cx - 0.5 + dx * k, cy - 0.5 + dy * k, [240, 200, 255], 0.5 * (1 - (k - 3) / 4));
}
const LINE: RGB = [240, 240, 240];
const center = ([x, y]: [number, number]): [number, number] => [x + 8, y + 8];

export function drawTransmuteBg(): Canvas {
  const cv = new Canvas(GUI_W, GUI_H);
  mcPanel(cv, GUI_W, GUI_H);
  // círculo esquerdo (entradas)
  const L = INPUT_POS.map(center);
  cv.disc(51, 58, 37, [214, 214, 214], 0.55);
  cv.ring(51, 58, 37, 1, LINE, 0.9);
  cv.ring(51, 58, 27, 1, LINE, 0.55);
  for (let a = 0; a < L.length; a++) for (let b = a + 1; b < L.length; b++) cv.line(L[a][0], L[a][1], L[b][0], L[b][1], LINE, 0.35);
  cv.ring(31, 77, 3.5, 1, [120, 120, 120], 0.8);
  cv.ring(71, 38, 3.5, 1, [120, 120, 120], 0.8);
  // círculo direito (saídas + trava)
  const R = MATTER_POS.map(center);
  const F = FUEL_POS.map(center);
  const [lx, ly] = center(LOCK_POS);
  cv.disc(lx, ly, 46, [214, 214, 214], 0.55);
  cv.ring(lx, ly, 46, 1, LINE, 0.9);
  cv.ring(lx, ly, 20, 1, LINE, 0.7);
  for (let i = 0; i < R.length; i++) {
    const n = R[(i + 1) % R.length];
    cv.line(R[i][0], R[i][1], n[0], n[1], LINE, 0.5);
    cv.line(R[i][0], R[i][1], lx, ly, LINE, 0.25);
  }
  for (let i = 0; i < F.length; i++) {
    const n = F[(i + 1) % F.length];
    cv.line(F[i][0], F[i][1], n[0], n[1], LINE, 0.6);
    for (const r of R) if (Math.hypot(r[0] - F[i][0], r[1] - F[i][1]) < 30) cv.line(F[i][0], F[i][1], r[0], r[1], LINE, 0.3);
  }
  cv.ring(lx - 42, ly, 3.5, 1, [120, 120, 120], 0.8);
  cv.ring(lx + 40, ly + 19, 3.5, 1, [120, 120, 120], 0.8);
  // orbes roxos (como no original)
  for (const p of [...L, ...R, ...F]) orb(cv, p[0], p[1]);
  // trava: anel cinza com "pupila"
  cv.ring(lx, ly, 7.5, 2, [150, 150, 150], 1);
  cv.disc(lx, ly, 4, [170, 170, 170], 1);
  cv.disc(lx, ly, 2, [110, 110, 110], 1);
  // queimar e desaprender
  for (const [x, y] of [BURN_POS, UNLEARN_POS]) mcSlot(cv, x - 1, y - 1);
  const [bx, by] = BURN_POS;
  // chama em pixel art (desenho próprio)
  const flame = ["....Y...", "...YY...", "...YO..Y", "..YOOY.Y", ".YOOOOYY", ".YORROOY", "YORRRROY", "YORRRROY", ".YORROY.", "..YYYY.."];
  const FC: Record<string, RGB> = { Y: [255, 214, 64], O: [255, 140, 26], R: [214, 54, 22] };
  flame.forEach((row, j) => [...row].forEach((ch, i) => FC[ch] && cv.set(bx + 4 + i, by + 3 + j, FC[ch])));
  // livro em pixel art (desenho próprio)
  const [ux, uy] = UNLEARN_POS;
  const book = ["..BBBBBBBB", ".BRRRRRRWB", "BRRRRRRRWB", "BRRGRRRRWB", "BRRRGRRRWB", "BRRRRRRRWB", "BRRRRRRRWB", "BRRRRRRWB.", "BBBBBBBB.."];
  const BC: Record<string, RGB> = { B: [60, 20, 20], R: [168, 40, 40], W: [235, 228, 210], G: [230, 190, 70] };
  book.forEach((row, j) => [...row].forEach((ch, i) => BC[ch] && cv.set(ux + 3 + i, uy + 4 + j, BC[ch])));
  // caixa de pesquisa (EditBox: borda 0xA0A0A0, fundo preto)
  cv.rect(SEARCH_BOX.x - 1, SEARCH_BOX.y - 1, SEARCH_BOX.w + 2, SEARCH_BOX.h + 2, [160, 160, 160]);
  cv.rect(SEARCH_BOX.x, SEARCH_BOX.y, SEARCH_BOX.w, SEARCH_BOX.h, [0, 0, 0]);
  // inventário do jogador (35,117)
  for (let s = 0; s < 36; s++) {
    const [x, y] = invPos(s);
    mcSlot(cv, x - 1, y - 1);
  }
  return cv;
}

function nine(w: number, h: number, edge: RGB, fill: RGB, light: RGB, dark: RGB, a = 255) {
  const cv = new Canvas(w, h);
  cv.fill((x, y) => {
    const ix = Math.floor(x), iy = Math.floor(y);
    if (ix === 0 || iy === 0 || ix === w - 1 || iy === h - 1) return edge;
    if (ix === 1 || iy === 1) return light;
    if (ix === w - 2 || iy === h - 2) return dark;
    return fill;
  });
  if (a < 255) for (let i = 3; i < cv.d.length; i += 4) cv.d[i] = Math.min(cv.d[i], a);
  return cv;
}

/** Todas as texturas de UI do pacote: caminho relativo (sem .png) → PNG. */
export async function guiTextures(): Promise<Record<string, Uint8Array>> {
  const out: Record<string, Uint8Array> = {};
  out["transmute"] = await drawTransmuteBg().png();
  const hover = new Canvas();
  hover.fill(() => [255, 255, 255]);
  for (let i = 3; i < hover.d.length; i += 4) hover.d[i] = 128; // 0x80FFFFFF, igual ao destaque de slot do Java
  out["slot_hover"] = await hover.png();
  const selected = new Canvas(18, 18);
  selected.fill((x, y) => {
    const ix = Math.floor(x), iy = Math.floor(y);
    return ix === 0 || iy === 0 || ix === 17 || iy === 17 ? [255, 255, 160] : null;
  });
  for (let y = 1; y < 17; y++) for (let x = 1; x < 17; x++) selected.set(x, y, [255, 255, 160], 90);
  out["slot_selected"] = await selected.png();
  // tooltip vanilla do Java: fundo 0xF0100010, borda 0x505000FF→0x5028007F
  const tip = new Canvas();
  tip.fill((x, y) => {
    const ix = Math.floor(x), iy = Math.floor(y);
    const corner = (ix === 0 || ix === 15) && (iy === 0 || iy === 15);
    return corner ? null : [16, 0, 16];
  });
  for (let i = 3; i < tip.d.length; i += 4) if (tip.d[i]) tip.d[i] = 240;
  for (let i = 1; i < 15; i++) {
    const t = (i - 1) / 13;
    tip.blend(i, 1, [80, 0, 255], 0.5);
    tip.blend(i, 14, [40, 0, 127], 0.5);
    tip.blend(1, i, mix([80, 0, 255], [40, 0, 127], t), 0.5);
    tip.blend(14, i, mix([80, 0, 255], [40, 0, 127], t), 0.5);
  }
  out["tooltip"] = await tip.png();
  out["button"] = await nine(16, 16, [0, 0, 0], [111, 111, 111], [170, 170, 170], [58, 58, 58]).png();
  out["button_hover"] = await nine(16, 16, [255, 255, 255], [126, 136, 191], [180, 190, 240], [70, 80, 130]).png();
  out["button_disabled"] = await nine(16, 16, [0, 0, 0], [44, 44, 44], [60, 60, 60], [30, 30, 30], 230).png();
  const focus = new Canvas(3, 3);
  focus.fill((x, y) => (Math.floor(x) === 1 && Math.floor(y) === 1 ? null : [255, 255, 255]));
  out["search_focus"] = await focus.png();
  for (const [name, col] of [["close", [90, 90, 90]], ["close_hover", [200, 40, 40]]] as [string, RGB][]) {
    const cv = new Canvas(9, 9);
    for (let i = 1; i < 8; i++) {
      cv.set(i, i, col);
      cv.set(8 - i, i, col);
    }
    out[name] = await cv.png();
  }
  const unknown = new Canvas();
  unknown.fill((x, y) => ((Math.floor(x / 4) + Math.floor(y / 4)) % 2 ? [248, 0, 248] : [24, 24, 24]));
  out["unknown"] = await unknown.png();
  return out;
}

export async function packIcon(): Promise<Uint8Array> {
  const small = new Canvas();
  drawShape(small, "gem", hex("#c4162a"), hex("#ff8a8a"));
  const big = new Canvas(64, 64);
  big.fill(() => [32, 24, 44]);
  for (let y = 0; y < 16; y++)
    for (let x = 0; x < 16; x++) {
      const i = (y * 16 + x) * 4;
      if (!small.d[i + 3]) continue;
      const c: RGB = [small.d[i], small.d[i + 1], small.d[i + 2]];
      for (let a = 0; a < 3; a++) for (let b = 0; b < 3; b++) big.set(8 + x * 3 + a, 8 + y * 3 + b, c);
    }
  return big.png();
}

/** PNG original do ProjectE (chave relativa a assets/projecte/textures, sem .png). */
export function peTex(key: string): Uint8Array {
  const b64 = PE_TEXTURES[key];
  if (!b64) throw new Error("Textura original ausente: " + key);
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
export const peTexUrl = (key: string) => "data:image/png;base64," + PE_TEXTURES[key];

/** Recorta uma região de uma textura original (ex.: o topo da tampa do baú para usar como ícone). */
export async function cropPng(key: string, x: number, y: number, w: number, h: number): Promise<Uint8Array> {
  const img = new Image();
  img.src = peTexUrl(key);
  await img.decode();
  const cv = document.createElement("canvas");
  cv.width = w;
  cv.height = h;
  cv.getContext("2d")!.drawImage(img, x, y, w, h, 0, 0, w, h);
  const blob: Blob = await new Promise((res, rej) => cv.toBlob((b) => (b ? res(b) : rej(new Error("PNG"))), "image/png"));
  return new Uint8Array(await blob.arrayBuffer());
}
