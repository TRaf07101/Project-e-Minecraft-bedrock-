// Layout da interface da Mesa de Transmutação — coordenadas copiadas do ProjectE (mc1.21.1):
// GUITransmutation (228×196, caixa de pesquisa em 83,8 55×10, botões de página em 125,100 e 193,100 14×14)
// TransmutationContainer.initSlots (posições de cada slot; inventário do jogador em 35,117).
export const GUI_W = 228;
export const GUI_H = 196;
type XY = [number, number];

/** índices 0-11: matéria (slots 11-22 do contêiner) */
export const MATTER_POS: XY[] = [[158, 9], [176, 13], [193, 30], [199, 50], [193, 70], [176, 87], [158, 91], [140, 87], [123, 70], [116, 50], [123, 30], [140, 13]];
/** índices 12-15: combustíveis (slots 23-26) */
export const FUEL_POS: XY[] = [[158, 31], [177, 50], [158, 69], [139, 50]];
export const LOCK_POS: XY = [158, 50];
export const BURN_POS: XY = [107, 97];
export const UNLEARN_POS: XY = [89, 97];
/** índices 19-26: entradas (slots 0-7) */
export const INPUT_POS: XY[] = [[43, 23], [34, 41], [52, 41], [16, 50], [70, 50], [34, 59], [52, 59], [43, 77]];
export const SEARCH_BOX = { x: 83, y: 8, w: 55, h: 10 };
export const PREV_BTN = { x: 125, y: 100, w: 14, h: 14 };
export const NEXT_BTN = { x: 193, y: 100, w: 14, h: 14 };
/** Posição do item do inventário do jogador (índice do contêiner Bedrock: 0-8 barra rápida, 9-35 principal). */
export function invPos(s: number): XY {
  return s < 9 ? [35 + s * 18, 175] : [35 + ((s - 9) % 9) * 18, 117 + Math.floor((s - 9) / 9) * 18];
}
/** Texto diagonal "Learned!"/"Unlearned" (GUITransmutation.renderLabels) */
export const LEARNED_POS: XY[] = [[98, 30], [99, 38], [100, 46], [101, 54], [102, 62], [103, 70], [104, 78], [107, 86]];
export const UNLEARNED_POS: XY[] = [[97, 22], [98, 30], [99, 38], [100, 46], [101, 54], [102, 62], [103, 70], [104, 78], [107, 86]];

export const BUTTON_COUNT = 66;
export const MARK = "pe:table:";
const TEXT_GRAY = [0.251, 0.251, 0.251]; // 0x404040

const collText = { binding_name: "#form_button_text", binding_type: "collection", binding_collection_name: "form_buttons" };
const topLeft = { anchor_from: "top_left", anchor_to: "top_left" };
const titleVisible = (expr: string) => [{ binding_name: "#title_text" }, { binding_type: "view", source_property_name: expr, target_property_name: "#visible" }];

/** Conteúdo de ui/server_form.json do pacote de recursos. */
export function serverFormJson(): object {
  const slots: object[] = [];
  const slot = (idx: number, [x, y]: XY) => slots.push({ [`pe_s${idx}@server_form.pe_slot`]: { offset: [x - 1, y - 1], collection_index: idx } });
  MATTER_POS.forEach((p, i) => slot(i, p));
  FUEL_POS.forEach((p, i) => slot(12 + i, p));
  slot(16, LOCK_POS);
  slot(17, BURN_POS);
  slot(18, UNLEARN_POS);
  INPUT_POS.forEach((p, i) => slot(19 + i, p));
  slots.push({ "pe_s27@server_form.pe_search_button": { offset: [SEARCH_BOX.x, SEARCH_BOX.y], collection_index: 27 } });
  slots.push({ "pe_s28@server_form.pe_page_button": { offset: [PREV_BTN.x, PREV_BTN.y], collection_index: 28 } });
  slots.push({ "pe_s29@server_form.pe_page_button": { offset: [NEXT_BTN.x, NEXT_BTN.y], collection_index: 29 } });
  for (let s = 0; s < 36; s++) slot(30 + s, invPos(s));

  const letters = (prefix: string, pos: XY[], flag: string) =>
    pos.map(([x, y], i) => ({
      [`pe_${prefix}${i}`]: {
        type: "label",
        ...topLeft,
        offset: [x, y],
        text: `pe.gui.${prefix}.${i + 1}`,
        color: TEXT_GRAY,
        shadow: false,
        layer: 6,
        bindings: titleVisible(`(not ((#title_text - '${MARK}${flag}') = #title_text))`),
      },
    }));

  return {
    namespace: "server_form",

    // Mesma estrutura do arquivo vanilla, trocando apenas o controle do formulário de botões por um roteador.
    main_screen_content: {
      type: "panel",
      size: [0, 0],
      controls: [
        {
          server_form_factory: {
            type: "factory",
            control_ids: {
              long_form: "@server_form.pe_long_form_router",
              custom_form: "@server_form.custom_form",
            },
          },
        },
      ],
    },

    // Formulários comuns continuam com a aparência vanilla; só o título marcado abre a mesa.
    pe_long_form_router: {
      type: "panel",
      size: ["100%", "100%"],
      controls: [
        {
          pe_vanilla_wrap: {
            type: "panel",
            size: ["100%", "100%"],
            bindings: titleVisible(`((#title_text - '${MARK}') = #title_text)`),
            controls: [{ "long_form@server_form.long_form": {} }],
          },
        },
        {
          pe_table_wrap: {
            type: "panel",
            size: ["100%", "100%"],
            bindings: titleVisible(`(not ((#title_text - '${MARK}') = #title_text))`),
            controls: [{ "pe_table@server_form.pe_table_screen": {} }],
          },
        },
      ],
    },

    pe_table_screen: {
      type: "panel",
      size: [GUI_W, GUI_H],
      layer: 2,
      controls: [
        { pe_bg: { type: "image", texture: "textures/ui/projecte/transmute", uv: [0, 0], uv_size: [GUI_W, GUI_H], size: [GUI_W, GUI_H], layer: 1 } },
        { pe_title: { type: "label", ...topLeft, offset: [6, 8], text: "pe.gui.transmutation", color: TEXT_GRAY, shadow: false, layer: 3 } },
        { pe_emc: { type: "label", ...topLeft, offset: [6, 92], size: [80, "default"], text: "#form_text", color: TEXT_GRAY, shadow: false, layer: 3 } },
        ...letters("learned", LEARNED_POS, "L"),
        ...letters("unlearned", UNLEARNED_POS, "U"),
        {
          pe_close: {
            type: "button",
            ...topLeft,
            offset: [GUI_W - 13, 4],
            size: [9, 9],
            layer: 8,
            sound_name: "random.click",
            default_control: "default",
            hover_control: "hover",
            pressed_control: "pressed",
            button_mappings: [
              { from_button_id: "button.menu_select", to_button_id: "button.menu_exit", mapping_type: "pressed" },
              { from_button_id: "button.menu_ok", to_button_id: "button.menu_exit", mapping_type: "focused" },
            ],
            controls: [
              { default: { type: "image", texture: "textures/ui/projecte/close", size: [9, 9] } },
              { hover: { type: "image", texture: "textures/ui/projecte/close_hover", size: [9, 9] } },
              { pressed: { type: "image", texture: "textures/ui/projecte/close_hover", size: [9, 9] } },
            ],
          },
        },
        { pe_slots: { type: "panel", ...topLeft, size: [GUI_W, GUI_H], layer: 4, collection_name: "form_buttons", controls: slots } },
      ],
    },

    // ── slot de item (18×18: moldura; item 16×16 em 1,1 como no Java)
    "pe_slot@common.button": {
      ...topLeft,
      size: [18, 18],
      $pressed_button_name: "button.form_button_click",
      bindings: [{ binding_type: "collection_details", binding_collection_name: "form_buttons" }],
      controls: [
        { "default@server_form.pe_slot_face": { $pe_hover: false } },
        { "hover@server_form.pe_slot_face": { $pe_hover: true } },
        { "pressed@server_form.pe_slot_face": { $pe_hover: true } },
      ],
    },

    pe_slot_face: {
      type: "panel",
      size: ["100%", "100%"],
      "$pe_hover|default": false,
      controls: [
        {
          pe_selected: {
            type: "image",
            texture: "textures/ui/projecte/slot_selected",
            size: [18, 18],
            layer: 1,
            bindings: [collText, { binding_type: "view", source_property_name: "(('%.1s' * #form_button_text) = '*')", target_property_name: "#visible" }],
          },
        },
        {
          pe_icon: {
            type: "image",
            ...topLeft,
            size: [16, 16],
            offset: [1, 1],
            layer: 2,
            bindings: [
              { binding_name: "#form_button_texture", binding_name_override: "#texture", binding_type: "collection", binding_collection_name: "form_buttons" },
              { binding_name: "#form_button_texture_file_system", binding_name_override: "#texture_file_system", binding_type: "collection", binding_collection_name: "form_buttons" },
              { binding_type: "view", source_property_name: "(not ((#texture = '') or (#texture = 'loading')))", target_property_name: "#visible" },
            ],
          },
        },
        {
          pe_count: {
            type: "label",
            anchor_from: "bottom_right",
            anchor_to: "bottom_right",
            offset: [0, 0],
            layer: 4,
            color: [1, 1, 1],
            shadow: true,
            text: "#pe_count",
            bindings: [collText, { binding_type: "view", source_property_name: "(('%.4s' * #form_button_text) - ('%.1s' * #form_button_text))", target_property_name: "#pe_count" }],
          },
        },
        { pe_highlight: { type: "image", ...topLeft, texture: "textures/ui/projecte/slot_hover", size: [16, 16], offset: [1, 1], layer: 5, visible: "$pe_hover" } },
        { "pe_tooltip@server_form.pe_tooltip": { visible: "$pe_hover" } },
      ],
    },

    // dica flutuante (no Java: tooltip do item com nome e EMC)
    pe_tooltip: {
      type: "panel",
      ...topLeft,
      size: [0, 0],
      offset: [16, 2],
      layer: 40,
      controls: [
        {
          pe_tip_bg: {
            type: "image",
            anchor_from: "bottom_left",
            anchor_to: "bottom_left",
            texture: "textures/ui/projecte/tooltip",
            nineslice_size: 3,
            size: ["100%c + 8px", "100%c + 8px"],
            layer: 1,
            bindings: [collText, { binding_type: "view", source_property_name: "(not ((#form_button_text - ('%.4s' * #form_button_text)) = ''))", target_property_name: "#visible" }],
            controls: [
              {
                pe_tip_text: {
                  type: "label",
                  ...topLeft,
                  offset: [4, 4],
                  size: ["default", "default"],
                  max_size: [180, 120],
                  layer: 2,
                  color: [1, 1, 1],
                  shadow: true,
                  text: "#pe_tip",
                  bindings: [collText, { binding_type: "view", source_property_name: "(#form_button_text - ('%.4s' * #form_button_text))", target_property_name: "#pe_tip" }],
                },
              },
            ],
          },
        },
      ],
    },

    // ── caixa de pesquisa (EditBox do Java)
    "pe_search_button@common.button": {
      ...topLeft,
      size: [SEARCH_BOX.w, SEARCH_BOX.h],
      $pressed_button_name: "button.form_button_click",
      bindings: [{ binding_type: "collection_details", binding_collection_name: "form_buttons" }],
      controls: [
        { "default@server_form.pe_search_face": { $pe_hover: false } },
        { "hover@server_form.pe_search_face": { $pe_hover: true } },
        { "pressed@server_form.pe_search_face": { $pe_hover: true } },
      ],
    },
    pe_search_face: {
      type: "panel",
      size: ["100%", "100%"],
      "$pe_hover|default": false,
      controls: [
        { pe_focus: { type: "image", texture: "textures/ui/projecte/search_focus", size: ["100% + 2px", "100% + 2px"], nineslice_size: 1, layer: 1, visible: "$pe_hover" } },
        {
          pe_text: {
            type: "label",
            ...topLeft,
            offset: [2, 1],
            size: ["100% - 3px", "default"],
            layer: 2,
            color: [0.878, 0.878, 0.878],
            shadow: true,
            text: "#pe_tip",
            bindings: [collText, { binding_type: "view", source_property_name: "(#form_button_text - ('%.4s' * #form_button_text))", target_property_name: "#pe_tip" }],
          },
        },
      ],
    },

    // ── botões de página "<" e ">" (Button 14×14 do Java)
    "pe_page_button@common.button": {
      ...topLeft,
      size: [PREV_BTN.w, PREV_BTN.h],
      $pressed_button_name: "button.form_button_click",
      bindings: [{ binding_type: "collection_details", binding_collection_name: "form_buttons" }],
      controls: [
        { "default@server_form.pe_page_face": { $pe_tex: "textures/ui/projecte/button" } },
        { "hover@server_form.pe_page_face": { $pe_tex: "textures/ui/projecte/button_hover" } },
        { "pressed@server_form.pe_page_face": { $pe_tex: "textures/ui/projecte/button_hover" } },
      ],
    },
    pe_page_face: {
      type: "panel",
      size: ["100%", "100%"],
      "$pe_tex|default": "textures/ui/projecte/button",
      controls: [
        { pe_btn_bg: { type: "image", texture: "$pe_tex", nineslice_size: 2, size: ["100%", "100%"], layer: 1 } },
        {
          pe_btn_off: {
            type: "image",
            texture: "textures/ui/projecte/button_disabled",
            nineslice_size: 2,
            size: ["100%", "100%"],
            layer: 2,
            bindings: [collText, { binding_type: "view", source_property_name: "(('%.1s' * #form_button_text) = '-')", target_property_name: "#visible" }],
          },
        },
        {
          pe_btn_text: {
            type: "label",
            layer: 3,
            color: [1, 1, 1],
            shadow: true,
            text: "#pe_tip",
            bindings: [collText, { binding_type: "view", source_property_name: "(#form_button_text - ('%.4s' * #form_button_text))", target_property_name: "#pe_tip" }],
          },
        },
      ],
    },
  };
}

/** Geometria da mesa: laje 16×4×16 (models/block/transmutation_table.json: from [0,0,0] to [16,4,16]). */
export function tableGeometry(): object {
  const side = { uv: [0, 12], uv_size: [16, 4] };
  return {
    format_version: "1.12.0",
    "minecraft:geometry": [
      {
        description: {
          identifier: "geometry.projecte.slab",
          texture_width: 16,
          texture_height: 16,
          visible_bounds_width: 2,
          visible_bounds_height: 1.5,
          visible_bounds_offset: [0, 0.25, 0],
        },
        bones: [
          {
            name: "table",
            pivot: [0, 0, 0],
            cubes: [
              {
                origin: [-8, 0, -8],
                size: [16, 4, 16],
                uv: {
                  north: side,
                  south: side,
                  east: side,
                  west: side,
                  up: { uv: [0, 0], uv_size: [16, 16] },
                  down: { uv: [0, 0], uv_size: [16, 16] },
                },
              },
            ],
          },
        ],
      },
    ],
  };
}

/** Face com UV invertido na vertical (o modelo de baú do Java é renderizado de cabeça para baixo). */
const flipV = (u: number, v: number, w: number, h: number) => ({ uv: [u, v + h], uv_size: [w, -h] });
const face = (u: number, v: number, w: number, h: number) => ({ uv: [u, v], uv_size: [w, h] });

/**
 * Baú (Condensador, Condensador MK2 e Baú Alquímico) com a textura de entidade 64×64 do ProjectE.
 * Regiões da textura (layout de baú do Java 1.15+, conferido na própria imagem):
 *   tampa 14×5×14 em (0,0): topo externo (28,0), parte de dentro (14,0), laterais na faixa y=14..19 (frente com o recorte da trava em x=42)
 *   base 14×10×14 em (0,19): interior (28,19), fundo (14,19), laterais na faixa y=33..43 (frente em x=42)
 */
export function chestGeometry(): object {
  return {
    format_version: "1.12.0",
    "minecraft:geometry": [
      {
        description: { identifier: "geometry.projecte.chest", texture_width: 64, texture_height: 64, visible_bounds_width: 2, visible_bounds_height: 2, visible_bounds_offset: [0, 0.5, 0] },
        bones: [
          {
            name: "chest",
            pivot: [0, 0, 0],
            cubes: [
              {
                origin: [-7, 0, -7],
                size: [14, 10, 14],
                uv: { north: flipV(42, 33, 14, 10), south: flipV(14, 33, 14, 10), east: flipV(28, 33, 14, 10), west: flipV(0, 33, 14, 10), up: face(28, 19, 14, 14), down: face(14, 19, 14, 14) },
              },
              {
                origin: [-7, 9, -7],
                size: [14, 5, 14],
                uv: { north: flipV(42, 14, 14, 5), south: flipV(14, 14, 14, 5), east: flipV(28, 14, 14, 5), west: flipV(0, 14, 14, 5), up: face(28, 0, 14, 14), down: face(14, 0, 14, 14) },
              },
              {
                origin: [-1, 7, -8],
                size: [2, 4, 1],
                uv: { north: face(1, 1, 2, 4), south: face(4, 1, 2, 4), east: face(0, 1, 1, 4), west: face(3, 1, 1, 4), up: face(1, 0, 2, 1), down: face(3, 0, 2, 1) },
              },
            ],
          },
        ],
      },
    ],
  };
}

/** Tocha de Interdição: mesmo formato da tocha vanilla (2×10×2 com UV a partir de (7,6)). */
export function torchGeometry(): object {
  return {
    format_version: "1.12.0",
    "minecraft:geometry": [
      {
        description: { identifier: "geometry.projecte.torch", texture_width: 16, texture_height: 16, visible_bounds_width: 1, visible_bounds_height: 1, visible_bounds_offset: [0, 0.5, 0] },
        bones: [
          {
            name: "torch",
            pivot: [0, 0, 0],
            cubes: [
              {
                origin: [-1, 0, -1],
                size: [2, 10, 2],
                uv: { north: face(7, 6, 2, 10), south: face(7, 6, 2, 10), east: face(7, 6, 2, 10), west: face(7, 6, 2, 10), up: face(7, 6, 2, 2), down: face(7, 14, 2, 2) },
              },
            ],
          },
        ],
      },
    ],
  };
}
