// Este arquivo não é usado pelo site. Ele só existe para que o TypeScript verifique
// o script do addon (scripts/main.js, com // @ts-check) contra as tipagens oficiais
// @minecraft/server 2.0.0 e @minecraft/server-ui 2.0.0 instaladas no projeto.
import "./scripts/main.js";
export {};
