import JSZip from "jszip";
import mainJs from "./scripts/main.js?raw";
import { baseValues, resolveEmc, vanillaRecipes, worldTransmutations } from "./emc";
import { BLOCKS, ITEMS, emcRecipes, langFile, recipes, smeltingMap, type RecipeDef, type BlockDef } from "./content";
import { guiTextures, peTex, cropPng } from "./textures";
import vanillaIcons from "./vanilla_icons.json";
import { serverFormJson, tableGeometry, chestGeometry, torchGeometry } from "./ui";

export const VERSION: [number, number, number] = [1, 0, 0];
const MIN_ENGINE: [number, number, number] = [1, 21, 90];
const UUID = {
  bp: "6f3a1b52-8c4d-4e2a-9b7f-1d2e3c4a5b61",
  bpData: "8a2c4d6e-1f3b-4a5c-8d7e-9f0a1b2c3d42",
  bpScript: "c5e7f9a1-3b5d-4c7e-9a1b-2c3d4e5f6a73",
  rp: "2b4d6f8a-0c1e-4a3b-8c5d-7e9f1a2b3c84",
  rpRes: "9d1f3a5b-7c9e-4b1d-8f3a-5b7c9d1e2f95",
};
const ITEM_FORMAT = "1.21.60";
const BLOCK_FORMAT = "1.21.60";
const RECIPE_FORMAT = "1.20.10";

const json = (o: unknown) => JSON.stringify(o, null, 2);

export function computeEmc(): Record<string, number> {
  const defs = recipes();
  const all = [...vanillaRecipes(), ...emcRecipes(defs)];
  const values = resolveEmc(baseValues(), all, new Set(["projecte:philosophers_stone"]));
  const out: Record<string, number> = {};
  for (const k of Object.keys(values).sort()) if (values[k] > 0) out[k] = values[k];
  return out;
}

/** Ícones dos botões da mesa: caminhos de textura vanilla (extraídos de Mojang/bedrock-samples) + texturas do pacote. */
export function iconMap(): Record<string, string> {
  const m: Record<string, string> = {};
  for (const [k, v] of Object.entries(vanillaIcons as Record<string, string>)) m["minecraft:" + k] = v;
  for (const it of ITEMS) m["projecte:" + it.name] = `textures/items/projecte/${it.name}`;
  for (const b of BLOCKS) {
    const key = b.kind === "chest" ? `icon_${b.name}` : (b.tex.top ?? b.tex.all ?? b.tex.side ?? "").replace(/^block\//, "").replace(/\//g, "_");
    m["projecte:" + b.name] = `textures/blocks/projecte/${key}`;
  }
  return m;
}

function recipeJson(d: RecipeDef) {
  const first = d.kind === "shaped" ? Object.values(d.key)[0] : d.ins[0][0];
  const base = {
    description: { identifier: `projecte:${d.id}` },
    tags: ["crafting_table"],
    unlock: [{ item: first }],
    // resultado múltiplo (como o bolo vanilla devolve baldes): devolve os itens de contêiner do Java
    result: d.extra?.length
      ? [{ item: d.out, count: d.count ?? 1 }, ...d.extra.map(([item, count]) => ({ item, count }))]
      : { item: d.out, count: d.count ?? 1 },
  };
  if (d.kind === "shaped") {
    const key: Record<string, { item: string }> = {};
    for (const [k, v] of Object.entries(d.key)) key[k] = { item: v };
    return { format_version: RECIPE_FORMAT, "minecraft:recipe_shaped": { ...base, pattern: d.pattern, key } };
  }
  const ingredients: { item: string }[] = [];
  for (const [id, n] of d.ins) for (let i = 0; i < n; i++) ingredients.push({ item: id });
  return { format_version: RECIPE_FORMAT, "minecraft:recipe_shapeless": { ...base, ingredients } };
}

/** Verificações estáticas do pacote gerado. Retorna lista de problemas (vazia = ok). */
export function validatePack(emc: Record<string, number>): string[] {
  const issues: string[] = [];
  const known = new Set([...ITEMS.map((i) => "projecte:" + i.name), ...BLOCKS.map((b) => "projecte:" + b.name)]);
  const ids = new Set<string>();
  for (const d of recipes()) {
    if (ids.has(d.id)) issues.push(`receita duplicada: ${d.id}`);
    ids.add(d.id);
    const ins = d.kind === "shaped" ? Object.values(d.key) : d.ins.map((x) => x[0]);
    for (const id of [...ins, d.out]) if (id.startsWith("projecte:") && !known.has(id)) issues.push(`receita ${d.id}: item desconhecido ${id}`);
    if (d.kind === "shaped") {
      if (d.pattern.length > 3 || d.pattern.some((r) => r.length > 3)) issues.push(`receita ${d.id}: padrão maior que 3x3`);
      for (const row of d.pattern) for (const ch of row) if (ch !== " " && !d.key[ch]) issues.push(`receita ${d.id}: símbolo sem chave '${ch}'`);
    } else if (d.ins.reduce((s, x) => s + x[1], 0) > 9) issues.push(`receita ${d.id}: mais de 9 ingredientes`);
  }
  for (const id of known) if (!(emc[id] > 0)) issues.push(`sem EMC: ${id}`);
  const names = new Set<string>();
  for (const n of [...ITEMS.map((i) => i.name), ...BLOCKS.map((b) => b.name)]) {
    if (names.has(n)) issues.push(`identificador duplicado: ${n}`);
    names.add(n);
  }
  return issues;
}

export async function buildMcaddon(onProgress?: (msg: string) => void): Promise<Blob> {
  const zip = new JSZip();
  const bp = zip.folder("ProjectE_BP")!;
  const rp = zip.folder("ProjectE_RP")!;
  const emc = computeEmc();
  const issues = validatePack(emc);
  if (issues.length) console.warn("[ProjectE] verificação do pacote:", issues);

  // ── manifests
  bp.file(
    "manifest.json",
    json({
      format_version: 2,
      header: {
        name: "ProjectE (Bedrock) BP",
        description: "Port não oficial do ProjectE: EMC, transmutação e alquimia. Baseado em sinkillerj/ProjectE (MIT).",
        uuid: UUID.bp,
        version: VERSION,
        min_engine_version: MIN_ENGINE,
      },
      modules: [
        { type: "data", uuid: UUID.bpData, version: VERSION },
        { type: "script", language: "javascript", uuid: UUID.bpScript, version: VERSION, entry: "scripts/main.js" },
      ],
      dependencies: [
        { uuid: UUID.rp, version: VERSION },
        { module_name: "@minecraft/server", version: "2.0.0" },
        { module_name: "@minecraft/server-ui", version: "2.0.0" },
      ],
      metadata: { authors: ["Port Bedrock (não oficial)", "ProjectE: SinKillerJ, pupnewfster, MaPePeR e colaboradores"], license: "MIT" },
    })
  );
  rp.file(
    "manifest.json",
    json({
      format_version: 2,
      header: { name: "ProjectE (Bedrock) RP", description: "Recursos do port não oficial do ProjectE.", uuid: UUID.rp, version: VERSION, min_engine_version: MIN_ENGINE },
      modules: [{ type: "resources", uuid: UUID.rpRes, version: VERSION }],
    })
  );

  // ── scripts
  bp.file("scripts/main.js", mainJs);
  bp.file(
    "scripts/emc_data.js",
    `// Gerado automaticamente — valores EMC (ProjectE defaults + receitas), transmutações de mundo e fundição.\n` +
      `export const EMC = ${JSON.stringify(emc)};\n` +
      `export const WORLD_TRANSMUTATIONS = ${JSON.stringify(worldTransmutations())};\n` +
      `export const SMELTING = ${JSON.stringify(smeltingMap())};\n` +
      `export const NAMES = ${JSON.stringify(Object.fromEntries([...ITEMS, ...BLOCKS].map((x) => ["projecte:" + x.name, x.pt])))};\n` +
      `export const ICONS = ${JSON.stringify(iconMap())};\n`
  );

  // ── itens (ícones originais do ProjectE)
  const itemTextures: Record<string, { textures: string }> = {};
  for (const it of ITEMS) {
    const id = "projecte:" + it.name;
    const category = it.kind === "tool" || it.kind === "armor" ? "equipment" : "items";
    const group = it.armor ? `minecraft:itemGroup.name.${{ head: "helmet", chest: "chestplate", legs: "leggings", feet: "boots" }[it.armor.slot]}` : undefined;
    bp.file(
      `items/${it.name}.json`,
      json({
        format_version: ITEM_FORMAT,
        "minecraft:item": {
          description: { identifier: id, menu_category: group ? { category, group } : { category } },
          components: {
            "minecraft:icon": { textures: { default: "pe_" + it.name } },
            "minecraft:display_name": { value: `item.projecte.${it.name}.name` },
            "minecraft:max_stack_size": it.stack ?? 64,
            ...(it.components ?? {}),
          },
        },
      })
    );
    rp.file(`textures/items/projecte/${it.name}.png`, peTex(it.tex));
    itemTextures["pe_" + it.name] = { textures: `textures/items/projecte/${it.name}` };
  }
  rp.file("textures/item_texture.json", json({ resource_pack_name: "projecte", texture_name: "atlas.items", texture_data: itemTextures }));

  // ── armaduras: texturas originais (models/armor/*_layer_1/2, layout 64×32 igual ao do Bedrock) e anexos como os vanilla
  for (const mat of ["dark_matter", "red_matter", "gem_armor"]) {
    rp.file(`textures/models/armor/projecte_${mat}_1.png`, peTex(`models/armor/${mat}_layer_1`));
    rp.file(`textures/models/armor/projecte_${mat}_2.png`, peTex(`models/armor/${mat}_layer_2`));
  }
  const ARMOR = {
    head: { geo: "helmet", vis: "helmet_layer_visible", anim: "helmet" },
    chest: { geo: "chestplate", vis: "chest_layer_visible", anim: "chest" },
    legs: { geo: "leggings", vis: "leg_layer_visible", anim: "leggings" },
    feet: { geo: "boots", vis: "boot_layer_visible", anim: "boots" },
  } as const;
  for (const it of ITEMS.filter((i) => i.armor)) {
    const a = it.armor!;
    const A = ARMOR[a.slot];
    const id = "projecte:" + it.name;
    const tex = { default: `textures/models/armor/projecte_${a.material}_${a.slot === "legs" ? 2 : 1}`, enchanted: "textures/misc/enchanted_actor_glint" };
    rp.file(
      `attachables/${it.name}.player.json`,
      json({
        format_version: "1.10.0",
        "minecraft:attachable": {
          description: {
            identifier: `${id}.player`,
            item: { [id]: "query.owner_identifier == 'minecraft:player'" },
            materials: { default: "armor", enchanted: "armor_enchanted" },
            textures: tex,
            geometry: { default: `geometry.player.armor.${A.geo}` },
            scripts: { parent_setup: `variable.${A.vis} = 0.0;`, animate: ["offset"] },
            animations: { offset: `animation.armor.${A.anim}.offset` },
            render_controllers: ["controller.render.armor"],
          },
        },
      })
    );
    rp.file(
      `attachables/${it.name}.json`,
      json({
        format_version: "1.10.0",
        "minecraft:attachable": {
          description: {
            identifier: id,
            item: { [id]: "query.owner_identifier != 'minecraft:player'" },
            materials: { default: "armor", enchanted: "armor_enchanted" },
            textures: tex,
            geometry: { default: `geometry.humanoid.armor.${A.geo}` },
            scripts: { parent_setup: `variable.${A.vis} = 0.0;` },
            render_controllers: ["controller.render.armor"],
          },
        },
      })
    );
  }

  // ── blocos (texturas e formatos originais)
  const terrain: Record<string, { textures: string }> = {};
  const addTex = (key: string) => {
    const name = "pe_" + key.replace(/^block\//, "").replace(/\//g, "_");
    if (!terrain[name]) {
      rp.file(`textures/blocks/projecte/${name.slice(3)}.png`, peTex(key));
      terrain[name] = { textures: `textures/blocks/projecte/${name.slice(3)}` };
    }
    return name;
  };
  const geos: Record<string, object> = { slab: tableGeometry(), chest: chestGeometry(), torch: torchGeometry() };
  for (const [k, g] of Object.entries(geos)) rp.file(`models/blocks/projecte_${k}.geo.json`, json(g));
  const rotatable = (b: BlockDef) => b.kind === "oriented" || b.kind === "chest";
  for (const b of BLOCKS) {
    const t = b.tex;
    const mat = (tex: string | undefined, method = "opaque") => ({ texture: addTex(tex ?? t.all ?? t.side!), render_method: method });
    let material: Record<string, object>;
    let geometry: unknown = "minecraft:geometry.full_block";
    const extra: Record<string, unknown> = {};
    if (b.kind === "cube") material = { "*": mat(t.all) };
    else if (b.kind === "oriented") material = { "*": mat(t.side), up: mat(t.top), north: mat(t.front) };
    else if (b.kind === "tnt") material = { "*": mat(t.side), up: mat(t.top), down: mat(t.bottom) };
    else if (b.kind === "slab") {
      material = { "*": mat(t.side), up: mat(t.top), down: mat(t.bottom) };
      geometry = { identifier: "geometry.projecte.slab" };
      extra["minecraft:collision_box"] = { origin: [-8, 0, -8], size: [16, 4, 16] };
      extra["minecraft:selection_box"] = { origin: [-8, 0, -8], size: [16, 4, 16] };
      extra["minecraft:light_dampening"] = 0;
    } else if (b.kind === "chest") {
      material = { "*": mat(t.all) };
      geometry = { identifier: "geometry.projecte.chest" };
      extra["minecraft:collision_box"] = { origin: [-7, 0, -7], size: [14, 14, 14] };
      extra["minecraft:selection_box"] = { origin: [-7, 0, -7], size: [14, 14, 14] };
      extra["minecraft:light_dampening"] = 0;
    } else {
      material = { "*": mat(t.all, "alpha_test") };
      geometry = { identifier: "geometry.projecte.torch" };
      extra["minecraft:collision_box"] = false;
      extra["minecraft:selection_box"] = { origin: [-2, 0, -2], size: [4, 10, 4] };
      extra["minecraft:light_dampening"] = 0;
    }
    if (b.light) extra["minecraft:light_emission"] = b.light;
    const def: Record<string, unknown> = {
      description: {
        identifier: "projecte:" + b.name,
        menu_category: { category: "items" },
        ...(rotatable(b) ? { traits: { "minecraft:placement_direction": { enabled_states: ["minecraft:cardinal_direction"], y_rotation_offset: 180 } } } : {}),
      },
      components: {
        "minecraft:geometry": geometry,
        "minecraft:material_instances": material,
        "minecraft:destructible_by_mining": { seconds_to_destroy: b.hardness },
        "minecraft:destructible_by_explosion": { explosion_resistance: b.kind === "tnt" ? 0 : 1200 },
        "minecraft:map_color": b.mapColor,
        ...extra,
      },
    };
    if (rotatable(b))
      def.permutations = [
        ["north", 0],
        ["west", 90],
        ["south", 180],
        ["east", -90],
      ].map(([dir, rot]) => ({
        condition: `query.block_state('minecraft:cardinal_direction') == '${dir}'`,
        components: { "minecraft:transformation": { rotation: [0, rot, 0] } },
      }));
    bp.file(`blocks/${b.name}.json`, json({ format_version: BLOCK_FORMAT, "minecraft:block": def }));
  }

  // ── interface da mesa (JSON UI sobre ActionFormData)
  rp.file("ui/server_form.json", json(serverFormJson()));
  const ui = await guiTextures();
  delete ui["transmute"];
  for (const [name, png] of Object.entries(ui)) rp.file(`textures/ui/projecte/${name}.png`, png);
  rp.file("textures/ui/projecte/transmute.png", peTex("gui/transmute")); // GUI original (256×256; área útil 228×196)
  for (const name of ["tooltip", "button", "button_hover", "button_disabled"])
    rp.file(`textures/ui/projecte/${name}.json`, json({ nineslice_size: name === "tooltip" ? 3 : 2, base_size: [16, 16] }));
  rp.file("textures/ui/projecte/search_focus.json", json({ nineslice_size: 1, base_size: [3, 3] }));

  // ícones 16×16 dos blocos em formato de baú (topo da tampa) para a interface da mesa
  for (const b of BLOCKS.filter((x) => x.kind === "chest")) rp.file(`textures/blocks/projecte/icon_${b.name}.png`, await cropPng(b.tex.all!, 28, 0, 14, 14));

  rp.file("textures/terrain_texture.json", json({ resource_pack_name: "projecte", texture_name: "atlas.terrain", padding: 8, num_mip_levels: 4, texture_data: terrain }));

  // ── receitas
  for (const d of recipes()) bp.file(`recipes/${d.id}.json`, json(recipeJson(d)));

  // ── textos
  rp.file("texts/languages.json", json(["en_US", "pt_BR"]));
  rp.file("texts/en_US.lang", langFile("en"));
  rp.file("texts/pt_BR.lang", langFile("pt"));
  bp.file("texts/languages.json", json(["en_US", "pt_BR"]));
  bp.file("texts/en_US.lang", langFile("en"));
  bp.file("texts/pt_BR.lang", langFile("pt"));

  // ── ícones, licença e leia-me
  const icon = peTex("item/philosophers_stone");
  bp.file("pack_icon.png", icon);
  rp.file("pack_icon.png", icon);
  bp.file("LICENSE-ProjectE.txt", PROJECTE_LICENSE);
  bp.file("LEIA-ME.txt", README);

  onProgress?.("Compactando…");
  return zip.generateAsync({ type: "blob", mimeType: "application/octet-stream", compression: "DEFLATE" });
}

const PROJECTE_LICENSE = `Este addon é um port não oficial, para Minecraft Bedrock, do mod ProjectE.
Valores EMC, receitas, transmutações de mundo e parâmetros de máquinas foram portados do
código-fonte do ProjectE (https://github.com/sinkillerj/ProjectE, branch mc1.21.1).
Os ícones, as texturas de blocos, de armaduras e da interface são os arquivos originais do repositório do
ProjectE (licença MIT do repositório). Parte dessas artes deriva do Equivalent Exchange 2 (x3n0ph0b3 /
MidnightLightning), cujo autor autorizou o uso pelo ProjectE.

---- Licença do ProjectE ----
MIT License

Copyright (c) 2020 Sin Tachikawa

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
`;

const README = `ProjectE (Bedrock) — port não oficial
=====================================

Requisitos: Minecraft Bedrock 1.21.90 ou mais recente (Script API estável @minecraft/server 2.0.0).
Não precisa ativar experimentos.

INSTALAÇÃO
1. Abra o arquivo ProjectE.mcaddon (Windows/Android/iOS: toque/clique duas vezes ou "Abrir com Minecraft").
2. No mundo: Configurações > Pacotes de comportamento > ative "ProjectE (Bedrock) BP"
   (o pacote de recursos é ativado junto).
3. Servidores dedicados (BDS): copie ProjectE_BP para behavior_packs e ProjectE_RP para
   resource_packs e adicione-os em world_behavior_packs.json / world_resource_packs.json.

COMO JOGAR
- Pedra Filosofal: RGR / GDG / RGR (R=redstone, G=pó de glowstone, D=diamante).
  Use num bloco para transmutá-lo (agachado = alternativa). Use no ar para o menu de carga/modo,
  conversões alquímicas e fundição filosofal.
- Mesa de Transmutação: OSO / SPS / OSO (O=obsidiana, S=pedra, P=Pedra Filosofal).
  A interface segue a do mod: toque num item do seu inventário (fica destacado) e depois no
  espaço de queimar (chama), desaprender (livro), na trava (centro do círculo direito) ou num
  dos 8 orbes da esquerda (entradas: Klein Stars ali somam ao EMC disponível). Toque num item
  do círculo direito para transmutá-lo. A caixa no topo pesquisa; < e > trocam de página.
- Coletores enviam EMC a relés e condensadores encostados. Condensador: defina o alvo com o
  item na mão e deposite itens com EMC.

FERRAMENTAS DE MATÉRIA (carga = teclas V/G do Java)
- Agachar + usar no ar: menu de carga e modo (DM: 0–2, RM: 0–3, Katar e Estrela da Manhã: 0–4).
- Espadas e Katar (usar no ar): golpe em área com raio 2,5 × carga (modo hostis ou todos).
  Acertar com carga > 0 causa +carga de dano que ignora armadura.
- Tesouras e Katar: usar no ar tosquia em área (raio 2^(2+carga), lã em dobro); clicar numa ovelha
  tosquia; folhas, teias e trepadeiras caem como bloco.
- Picareta: usar no ar minera os veios de minério ao redor (raio carga+3); clicar num bloco minera o veio.
  Modos ao quebrar: padrão, tiro alto, largo e longo. Machado: troncos/folhas em área (5 × carga).
  Pá: caminho/cava em área. Enxada: ara em área. Martelo: cava em área profunda ao clicar.

ARMADURAS
- Matéria Escura/Vermelha/Gema reduzem dano como no Java (via efeito Resistência: conjunto DM = 80%).
- Gema: capacete cura e dá respiração aquática; peitoral imune a fogo e alimenta; calças descem rápido
  ao agachar no ar e repelem criaturas; BOTAS: segure pulo para subir (voo), +100% de velocidade e sem
  dano de queda. Agache duas vezes rápido para o menu (visão noturna, raio, explosão nova).

ANÉIS E ITENS
- Vendaval de Swiftwolf (SWRG): usar alterna Desligado/Escudo/Voo/Voo+escudo. Voo: segure pulo para
  subir, agache para descer, solto paira. Consome EMC de Klein Stars (0,32 por tick).
- Zero, Ignição, Deusa da Colheita, Arcano, Pedras do Corpo/Alma/Vida, Mente, Golpe do Arcanjo,
  Relógio do Tempo Fluente, Anel do Vazio, Gema da Densidade Eterna, Catalisador, Lentes, Bolsas.

ADAPTAÇÕES DEVIDO AO BEDROCK
- Interfaces de baú personalizadas não existem na Script API: a mesa usa um formulário redesenhado
  pelo pacote de recursos; máquinas e bolsas usam formulários e inventários virtuais salvos no mundo.
- Não há voo criativo pela Script API estável: o voo é simulado com impulsos (applyKnockback).
- Teclas extras do Java viraram "agachar + usar" e "agachar duas vezes".
- Receitas com a Pedra Filosofal ficam no menu da pedra (no Bedrock a pedra seria consumida na bancada).
- Itens encantados não podem ser queimados; inventários virtuais aceitam só itens simples.
- Não implementados: Olho Mercurial, Fornalhas de Matéria, Pedestal de Matéria Escura, assistente de
  degrau das botas e cor das bolsas por tingimento.
`;
