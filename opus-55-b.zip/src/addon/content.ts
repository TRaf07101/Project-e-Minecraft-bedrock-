// Itens, blocos e receitas do ProjectE portados para o formato do Bedrock.
// Receitas: ProjectE mc1.21.1 — src/datagen/java/moze_intel/projecte/common/recipe/PERecipeProvider.java
import type { Recipe } from "./emc";

// Ícones e texturas: arquivos originais do ProjectE (src/main/resources/assets/projecte/textures, branch mc1.21.1).
// Dano das ferramentas: atributos do ProjectE (EnumMatterType: bônus DM 3 / RM 4; valores base em PEItems/PE*.java).
export type ArmorMat = "dark_matter" | "red_matter" | "gem_armor";
export interface ItemDef {
  name: string; // sem namespace
  en: string;
  pt: string;
  tex: string; // chave em PE_TEXTURES (ex.: "item/dm_tools/pickaxe")
  stack?: number;
  kind?: "tool" | "armor" | "item";
  components?: Record<string, unknown>;
  armor?: { slot: "head" | "chest" | "legs" | "feet"; material: ArmorMat };
}

export type BlockKind = "cube" | "oriented" | "chest" | "slab" | "torch" | "tnt";
export interface BlockDef {
  name: string;
  en: string;
  pt: string;
  kind: BlockKind;
  tex: { all?: string; top?: string; bottom?: string; side?: string; front?: string };
  hardness: number;
  light?: number;
  mapColor: string;
}

type ToolKind = "pickaxe" | "axe" | "shovel" | "sword" | "hoe" | "shears" | "hammer" | "katar" | "morning_star";
const DIG: Record<string, string> = {
  pick: "query.any_tag('stone', 'metal', 'minecraft:is_pickaxe_item_destructible')",
  axe: "query.any_tag('wood', 'log', 'pumpkin', 'minecraft:is_axe_item_destructible')",
  shovel: "query.any_tag('dirt', 'sand', 'gravel', 'grass', 'snow', 'minecraft:is_shovel_item_destructible')",
  hoe: "query.any_tag('minecraft:is_hoe_item_destructible', 'plant', 'crop')",
  shears: "query.any_tag('leaves', 'wool', 'plant', 'minecraft:is_shears_item_destructible')",
  sword: "query.any_tag('minecraft:is_sword_item_destructible', 'plant')",
};
// blocos mineráveis por ferramenta (PETags MINEABLE_WITH_PE_*)
const TOOL_DIGS: Record<ToolKind, string[]> = {
  pickaxe: ["pick"], axe: ["axe"], shovel: ["shovel"], sword: ["sword"], hoe: ["hoe"], shears: ["shears"], hammer: ["pick"],
  katar: ["sword", "axe", "hoe", "shears"], morning_star: ["pick", "shovel", "axe"],
};
const TOOL_TAGS: Record<ToolKind, string[]> = {
  pickaxe: ["minecraft:is_pickaxe"], axe: ["minecraft:is_axe"], shovel: ["minecraft:is_shovel"], sword: ["minecraft:is_sword"], hoe: ["minecraft:is_hoe"],
  shears: [], hammer: ["minecraft:is_pickaxe"], katar: ["minecraft:is_sword", "minecraft:is_axe", "minecraft:is_hoe"], morning_star: ["minecraft:is_pickaxe", "minecraft:is_shovel", "minecraft:is_axe"],
};
const PT_TOOL: Record<ToolKind, string> = {
  pickaxe: "Picareta", axe: "Machado", shovel: "Pá", sword: "Espada", hoe: "Enxada", shears: "Tesoura", hammer: "Martelo", katar: "Katar", morning_star: "Estrela da Manhã",
};
const EN_TOOL: Record<ToolKind, string> = {
  pickaxe: "Pickaxe", axe: "Axe", shovel: "Shovel", sword: "Sword", hoe: "Hoe", shears: "Shears", hammer: "Hammer", katar: "Katar", morning_star: "Morning Star",
};

/** damage = atributo de ataque do ProjectE (base da ferramenta + bônus da matéria); 0 = sem dano extra. */
function tool(mat: "dm" | "rm", kind: ToolKind, damage: number): ItemDef {
  const special = kind === "katar" || kind === "morning_star";
  const speed = kind === "hammer" || kind === "morning_star" ? 100 : mat === "dm" ? 14 : 16; // EnumMatterType.efficiency; martelo/estrela: quase instantâneo
  const components: Record<string, unknown> = {
    "minecraft:hand_equipped": true,
    "minecraft:digger": { use_efficiency: true, destroy_speeds: TOOL_DIGS[kind].map((d) => ({ block: { tags: DIG[d] }, speed })) },
    "minecraft:tags": { tags: [...TOOL_TAGS[kind], "minecraft:diamond_tier", "minecraft:netherite_tier", "minecraft:is_tool"] },
    "minecraft:enchantable": { slot: kind === "sword" || kind === "katar" ? "sword" : kind === "axe" ? "axe" : kind === "shears" ? "shears" : kind === "hoe" ? "hoe" : kind === "shovel" ? "shovel" : "pickaxe", value: 0 },
  };
  if (damage > 0) components["minecraft:damage"] = { value: damage };
  return {
    name: special ? `red_matter_${kind}` : `${mat === "dm" ? "dark" : "red"}_matter_${kind}`,
    en: special ? `Red ${EN_TOOL[kind]}` : `${mat === "dm" ? "Dark" : "Red"} Matter ${EN_TOOL[kind]}`,
    pt: special ? `${PT_TOOL[kind]} Vermelha` : `${PT_TOOL[kind]} de Matéria ${mat === "dm" ? "Escura" : "Vermelha"}`,
    tex: `item/${mat}_tools/${kind}`,
    stack: 1,
    kind: "tool",
    components,
  };
}

function armor(material: ArmorMat, slot: "head" | "chest" | "legs" | "feet"): ItemDef {
  const part = { head: "helmet", chest: "chestplate", legs: "leggings", feet: "boots" }[slot];
  const prot = { head: 3, chest: 8, legs: 6, feet: 3 }[slot]; // PEArmorMaterials.DIAMOND_RESISTANCES
  const en = { head: "Helmet", chest: "Chestplate", legs: "Leggings", feet: "Boots" }[slot];
  const pt = { head: "Capacete", chest: "Peitoral", legs: "Calças", feet: "Botas" }[slot];
  const folder = { dark_matter: "dm_armor", red_matter: "rm_armor", gem_armor: "gem_armor" }[material];
  const prefix = { dark_matter: "dark_matter", red_matter: "red_matter", gem_armor: "gem" }[material];
  const enMat = { dark_matter: "Dark Matter", red_matter: "Red Matter", gem_armor: "Gem" }[material];
  const ptMat = { dark_matter: "de Matéria Escura", red_matter: "de Matéria Vermelha", gem_armor: "de Gema" }[material];
  return {
    name: `${prefix}_${part}`,
    en: `${enMat} ${en}`,
    pt: `${pt} ${ptMat}`,
    tex: `item/${folder}/${slot}`,
    stack: 1,
    kind: "armor",
    armor: { slot, material },
    components: {
      "minecraft:wearable": { slot: `slot.armor.${slot}`, protection: prot },
      "minecraft:enchantable": { slot: `armor_${slot}`, value: 0 },
      "minecraft:tags": { tags: ["minecraft:is_armor"] },
    },
  };
}

const COLORS = ["white", "orange", "magenta", "light_blue", "yellow", "lime", "pink", "gray", "light_gray", "cyan", "purple", "blue", "brown", "green", "red", "black"];
const COLOR_PT: Record<string, string> = {
  white: "Branca", orange: "Laranja", magenta: "Magenta", light_blue: "Azul-clara", yellow: "Amarela", lime: "Verde-lima", pink: "Rosa", gray: "Cinza",
  light_gray: "Cinza-clara", cyan: "Ciano", purple: "Roxa", blue: "Azul", brown: "Marrom", green: "Verde", red: "Vermelha", black: "Preta",
};
const COLOR_EN = (c: string) => c.split("_").map((w) => w[0].toUpperCase() + w.slice(1)).join(" ");
const it = (name: string, en: string, pt: string, tex: string, stack = 64, components?: Record<string, unknown>): ItemDef => ({ name, en, pt, tex, stack, components, kind: "item" });

export const ITEMS: ItemDef[] = [
  it("philosophers_stone", "Philosopher's Stone", "Pedra Filosofal", "item/philosophers_stone", 1),
  it("alchemical_coal", "Alchemical Coal", "Carvão Alquímico", "item/fuels/alchemical_coal", 64, { "minecraft:fuel": { duration: 320 } }),
  it("mobius_fuel", "Mobius Fuel", "Combustível de Möbius", "item/fuels/mobius", 64, { "minecraft:fuel": { duration: 1280 } }),
  it("aeternalis_fuel", "Aeternalis Fuel", "Combustível Aeternalis", "item/fuels/aeternalis", 64, { "minecraft:fuel": { duration: 5120 } }),
  it("low_covalence_dust", "Low Covalence Dust", "Pó de Covalência Baixa", "item/covalence_dust/low"),
  it("medium_covalence_dust", "Medium Covalence Dust", "Pó de Covalência Média", "item/covalence_dust/medium"),
  it("high_covalence_dust", "High Covalence Dust", "Pó de Covalência Alta", "item/covalence_dust/high"),
  it("dark_matter", "Dark Matter", "Matéria Escura", "item/matter/dark"),
  it("red_matter", "Red Matter", "Matéria Vermelha", "item/matter/red"),
  it("iron_band", "Iron Band", "Faixa de Ferro", "item/rings/iron_band", 1),
  it("klein_star_ein", "Klein Star Ein", "Klein Star Ein", "item/stars/klein_star_1", 1),
  it("klein_star_zwei", "Klein Star Zwei", "Klein Star Zwei", "item/stars/klein_star_2", 1),
  it("klein_star_drei", "Klein Star Drei", "Klein Star Drei", "item/stars/klein_star_3", 1),
  it("klein_star_vier", "Klein Star Vier", "Klein Star Vier", "item/stars/klein_star_4", 1),
  it("klein_star_sphere", "Klein Star Sphere", "Klein Star Sphere", "item/stars/klein_star_5", 1),
  it("klein_star_omega", "Klein Star Omega", "Klein Star Omega", "item/stars/klein_star_6", 1),
  it("transmutation_tablet", "Transmutation Tablet", "Tablete de Transmutação", "item/transmutation_tablet", 1),
  it("tome_of_knowledge", "Tome of Knowledge", "Tomo do Conhecimento", "item/tome", 1),
  it("repair_talisman", "Repair Talisman", "Talismã de Reparo", "item/repair_talisman", 1),
  it("black_hole_band", "Black Hole Band", "Faixa do Buraco Negro", "item/rings/black_hole_off", 1),
  it("evertide_amulet", "Evertide Amulet", "Amuleto Maré Eterna", "item/rings/evertide_amulet", 1),
  it("volcanite_amulet", "Volcanite Amulet", "Amuleto Vulcanita", "item/rings/volcanite_amulet", 1),
  it("low_divining_rod", "Divining Rod (low)", "Vara de Adivinhação (baixa)", "item/divining_rod_1", 1),
  it("medium_divining_rod", "Divining Rod (medium)", "Vara de Adivinhação (média)", "item/divining_rod_2", 1),
  it("high_divining_rod", "Divining Rod (high)", "Vara de Adivinhação (alta)", "item/divining_rod_3", 1),
  // anéis e pedras
  it("swiftwolf_rending_gale", "Swiftwolf's Rending Gale", "Vendaval Dilacerante de Swiftwolf", "item/rings/swrg_off", 1),
  it("zero_ring", "Zero Ring", "Anel Zero", "item/rings/zero_off", 1),
  it("ignition_ring", "Ignition Ring", "Anel da Ignição", "item/rings/ignition_off", 1),
  it("harvest_goddess_band", "Harvest Goddess Band", "Faixa da Deusa da Colheita", "item/rings/harvest_god_off", 1),
  it("arcana_ring", "Ring of Arcana", "Anel Arcano", "item/rings/arcana_0", 1),
  it("archangel_smite", "Archangel's Smite", "Golpe do Arcanjo", "item/rings/archangel_smite", 1),
  it("body_stone", "Body Stone", "Pedra do Corpo", "item/rings/body_stone_off", 1),
  it("soul_stone", "Soul Stone", "Pedra da Alma", "item/rings/soul_stone_off", 1),
  it("life_stone", "Life Stone", "Pedra da Vida", "item/rings/life_stone_off", 1),
  it("mind_stone", "Mind Stone", "Pedra da Mente", "item/rings/mind_stone_off", 1),
  it("watch_of_flowing_time", "Watch of Flowing Time", "Relógio do Tempo Fluente", "item/rings/time_watch_off", 1),
  it("void_ring", "Void Ring", "Anel do Vazio", "item/rings/void_off", 1),
  it("gem_of_eternal_density", "Gem of Eternal Density", "Gema da Densidade Eterna", "item/dense_gem_off", 1),
  it("destruction_catalyst", "Destruction Catalyst", "Catalisador da Destruição", "item/destruction_catalyst", 1),
  it("hyperkinetic_lens", "Hyperkinetic Lens", "Lente Hipercinética", "item/hyperkinetic_lens", 1),
  it("catalytic_lens", "Catalytic Lens", "Lente Catalítica", "item/catalytic_lens", 1),
  // bolsas alquímicas (16 cores)
  ...COLORS.map((c) => it(`${c}_alchemical_bag`, `${COLOR_EN(c)} Alchemical Bag`, `Bolsa Alquímica ${COLOR_PT[c]}`, `item/alchemy_bags/${c}`, 1)),
  // ferramentas — dano: DM espada 9+3, machado 5+3, picareta 4+3, pá 2+3, martelo 10+3; RM espada 12+4, machado 5+4, picareta 4+4, pá 2+4, martelo 10+4, katar 19+4, estrela 16+4
  tool("dm", "pickaxe", 7), tool("dm", "axe", 8), tool("dm", "shovel", 5), tool("dm", "sword", 12), tool("dm", "hoe", 0), tool("dm", "shears", 0), tool("dm", "hammer", 13),
  tool("rm", "pickaxe", 8), tool("rm", "axe", 9), tool("rm", "shovel", 6), tool("rm", "sword", 16), tool("rm", "hoe", 0), tool("rm", "shears", 0), tool("rm", "hammer", 14),
  tool("rm", "katar", 23), tool("rm", "morning_star", 20),
  armor("dark_matter", "head"), armor("dark_matter", "chest"), armor("dark_matter", "legs"), armor("dark_matter", "feet"),
  armor("red_matter", "head"), armor("red_matter", "chest"), armor("red_matter", "legs"), armor("red_matter", "feet"),
  armor("gem_armor", "head"), armor("gem_armor", "chest"), armor("gem_armor", "legs"), armor("gem_armor", "feet"),
];

const B = (name: string, en: string, pt: string, kind: BlockKind, tex: BlockDef["tex"], hardness: number, mapColor: string, light?: number): BlockDef => ({ name, en, pt, kind, tex, hardness, mapColor, light });
export const BLOCKS: BlockDef[] = [
  B("transmutation_table", "Transmutation Table", "Mesa de Transmutação", "slab", { top: "block/transmutation_stone/top", side: "block/transmutation_stone/side", bottom: "block/transmutation_stone/bottom" }, 3, "#2c2633"),
  ...[1, 2, 3].map((n) =>
    B(`collector_mk${n}`, `Energy Collector MK${n}`, `Coletor de Energia MK${n}`, "oriented", { front: "block/collectors/front", top: `block/collectors/top_${n}`, side: "block/collectors/other" }, 0.3 * 10, "#e8d27a", 10)
  ),
  ...[1, 2, 3].map((n) =>
    B(`relay_mk${n}`, `Anti-Matter Relay MK${n}`, `Relé Anti-Matéria MK${n}`, "oriented", { front: "block/relays/front", top: `block/relays/top_${n}`, side: "block/relays/other" }, 1, "#26203a")
  ),
  B("condenser", "Energy Condenser", "Condensador de Energia", "chest", { all: "block/condenser_mk1" }, 10, "#1f1f26"),
  B("condenser_mk2", "Energy Condenser MK2", "Condensador de Energia MK2", "chest", { all: "block/condenser_mk2" }, 10, "#8e1515"),
  B("alchemical_chest", "Alchemical Chest", "Baú Alquímico", "chest", { all: "block/alchemical_chest" }, 10, "#3d5bd1"),
  B("dark_matter_block", "Dark Matter Block", "Bloco de Matéria Escura", "cube", { all: "block/dark_matter_block" }, 10, "#2a1f3d"),
  B("red_matter_block", "Red Matter Block", "Bloco de Matéria Vermelha", "cube", { all: "block/red_matter_block" }, 15, "#8e1515"),
  B("alchemical_coal_block", "Alchemical Coal Block", "Bloco de Carvão Alquímico", "cube", { all: "block/alchemical_coal_block" }, 5, "#7a1717"),
  B("mobius_fuel_block", "Mobius Fuel Block", "Bloco de Combustível de Möbius", "cube", { all: "block/mobius_fuel_block" }, 5, "#a34312"),
  B("aeternalis_fuel_block", "Aeternalis Fuel Block", "Bloco de Combustível Aeternalis", "cube", { all: "block/aeternalis_fuel_block" }, 5, "#cfc8ae"),
  B("nova_catalyst", "Nova Catalyst", "Catalisador Nova", "tnt", { top: "block/explosives/top", bottom: "block/explosives/bottom", side: "block/explosives/nova_side" }, 0.1, "#c4162a"),
  B("nova_cataclysm", "Nova Cataclysm", "Cataclismo Nova", "tnt", { top: "block/explosives/top", bottom: "block/explosives/bottom", side: "block/explosives/nova1_side" }, 0.1, "#c4162a"),
  B("interdiction_torch", "Interdiction Torch", "Tocha de Interdição", "torch", { all: "block/interdiction_torch" }, 0.1, "#7ad0ff", 14),
];

// ───────────────────────────────────────────── receitas
/** extra = itens devolvidos junto com o resultado (itens de contêiner do Java: Pedra Filosofal, baldes). */
export type RecipeDef =
  | { kind: "shaped"; id: string; out: string; count?: number; pattern: string[]; key: Record<string, string>; extra?: [string, number][] }
  | { kind: "shapeless"; id: string; out: string; count?: number; ins: [string, number][]; extra?: [string, number][] };

const pe = (n: string) => "projecte:" + n;
const mc = (n: string) => "minecraft:" + n;

export function recipes(): RecipeDef[] {
  const r: RecipeDef[] = [];
  const shaped = (id: string, out: string, pattern: string[], key: Record<string, string>, count = 1, extra?: [string, number][]) =>
    r.push({ kind: "shaped", id, out, pattern, key, count, extra });
  const shapeless = (id: string, out: string, ins: [string, number][], count = 1) => r.push({ kind: "shapeless", id, out, ins, count });

  // Pedra Filosofal (duas variantes)
  shaped("philosophers_stone", pe("philosophers_stone"), ["RGR", "GDG", "RGR"], { R: mc("redstone"), G: mc("glowstone_dust"), D: mc("diamond") });
  shaped("philosophers_stone_alt", pe("philosophers_stone"), ["GRG", "RDR", "GRG"], { R: mc("redstone"), G: mc("glowstone_dust"), D: mc("diamond") });
  // Mesa / Tablete
  shaped("transmutation_table", pe("transmutation_table"), ["OSO", "SPS", "OSO"], { O: mc("obsidian"), S: mc("stone"), P: pe("philosophers_stone") }, 1, [
    [pe("philosophers_stone"), 1],
  ]);
  shaped("transmutation_tablet", pe("transmutation_tablet"), ["DSD", "STS", "DSD"], { D: pe("dark_matter_block"), S: mc("stone"), T: pe("transmutation_table") });
  // Blocos de combustível (9 ↔ 1)
  for (const f of ["alchemical_coal", "mobius_fuel", "aeternalis_fuel"]) {
    shapeless(`${f}_block`, pe(`${f}_block`), [[pe(f), 9]]);
    shapeless(`${f}_block_deconstruct`, pe(f), [[pe(`${f}_block`), 1]], 9);
  }
  // Matéria
  shaped("dark_matter", pe("dark_matter"), ["AAA", "ADA", "AAA"], { A: pe("aeternalis_fuel"), D: mc("diamond_block") });
  shaped("red_matter", pe("red_matter"), ["AAA", "DDD", "AAA"], { A: pe("aeternalis_fuel"), D: pe("dark_matter") });
  shaped("red_matter_alt", pe("red_matter"), ["ADA", "ADA", "ADA"], { A: pe("aeternalis_fuel"), D: pe("dark_matter") });
  for (const m of ["dark_matter", "red_matter"]) {
    shaped(`${m}_block`, pe(`${m}_block`), ["MM", "MM"], { M: pe(m) });
    shapeless(`${m}_block_deconstruct`, pe(m), [[pe(`${m}_block`), 1]], 4);
  }
  // Ferramentas de Matéria Escura
  const D = mc("diamond");
  const dm = pe("dark_matter");
  shaped("dark_matter_helmet", pe("dark_matter_helmet"), ["MMM", "M M"], { M: dm });
  shaped("dark_matter_chestplate", pe("dark_matter_chestplate"), ["M M", "MMM", "MMM"], { M: dm });
  shaped("dark_matter_leggings", pe("dark_matter_leggings"), ["MMM", "M M", "M M"], { M: dm });
  shaped("dark_matter_boots", pe("dark_matter_boots"), ["M M", "M M"], { M: dm });
  shaped("dark_matter_axe", pe("dark_matter_axe"), ["MM", "MD", " D"], { M: dm, D });
  shaped("dark_matter_pickaxe", pe("dark_matter_pickaxe"), ["MMM", " D ", " D "], { M: dm, D });
  shaped("dark_matter_shovel", pe("dark_matter_shovel"), ["M", "D", "D"], { M: dm, D });
  shaped("dark_matter_sword", pe("dark_matter_sword"), ["M", "M", "D"], { M: dm, D });
  shaped("dark_matter_hoe", pe("dark_matter_hoe"), ["MM", " D", " D"], { M: dm, D });
  shaped("dark_matter_shears", pe("dark_matter_shears"), [" M", "D "], { M: dm, D });
  shaped("dark_matter_hammer", pe("dark_matter_hammer"), ["MDM", " D ", " D "], { M: dm, D });
  // Matéria Vermelha
  const rm = pe("red_matter");
  shaped("red_matter_helmet", pe("red_matter_helmet"), ["MMM", "MDM"], { M: rm, D: pe("dark_matter_helmet") });
  shaped("red_matter_chestplate", pe("red_matter_chestplate"), ["MDM", "MMM", "MMM"], { M: rm, D: pe("dark_matter_chestplate") });
  shaped("red_matter_leggings", pe("red_matter_leggings"), ["MMM", "MDM", "M M"], { M: rm, D: pe("dark_matter_leggings") });
  shaped("red_matter_boots", pe("red_matter_boots"), ["MDM", "M M"], { M: rm, D: pe("dark_matter_boots") });
  shaped("red_matter_axe", pe("red_matter_axe"), ["RR", "RA", " M"], { R: rm, M: dm, A: pe("dark_matter_axe") });
  shaped("red_matter_pickaxe", pe("red_matter_pickaxe"), ["RRR", " P ", " M "], { R: rm, M: dm, P: pe("dark_matter_pickaxe") });
  shaped("red_matter_shovel", pe("red_matter_shovel"), ["R", "S", "M"], { R: rm, M: dm, S: pe("dark_matter_shovel") });
  shaped("red_matter_sword", pe("red_matter_sword"), ["R", "R", "S"], { R: rm, S: pe("dark_matter_sword") });
  shaped("red_matter_hoe", pe("red_matter_hoe"), ["RR", " H", " M"], { R: rm, M: dm, H: pe("dark_matter_hoe") });
  shaped("red_matter_shears", pe("red_matter_shears"), [" R", "S "], { R: rm, S: pe("dark_matter_shears") });
  shaped("red_matter_hammer", pe("red_matter_hammer"), ["RMR", " H ", " M "], { R: rm, M: dm, H: pe("dark_matter_hammer") });
  shaped("red_matter_katar", pe("red_matter_katar"), ["ABC", "DRR", "RRR"], { A: pe("red_matter_shears"), B: pe("red_matter_axe"), C: pe("red_matter_sword"), D: pe("red_matter_hoe"), R: rm });
  shaped("red_matter_morning_star", pe("red_matter_morning_star"), ["ABC", "RRR", "RRR"], { A: pe("red_matter_hammer"), B: pe("red_matter_pickaxe"), C: pe("red_matter_shovel"), R: rm });
  // Coletores e relés
  shaped("collector_mk1", pe("collector_mk1"), ["GTG", "GDG", "GFG"], { G: mc("glowstone"), F: mc("furnace"), D: mc("diamond_block"), T: mc("glass") });
  shaped("collector_mk2", pe("collector_mk2"), ["GUG", "GPG", "GGG"], { G: mc("glowstone"), P: pe("collector_mk1"), U: dm });
  shaped("collector_mk3", pe("collector_mk3"), ["GUG", "GPG", "GGG"], { G: mc("glowstone"), P: pe("collector_mk2"), U: rm });
  shaped("relay_mk1", pe("relay_mk1"), ["OSO", "ODO", "OOO"], { S: mc("glass"), O: mc("obsidian"), D: mc("diamond_block") });
  shaped("relay_mk2", pe("relay_mk2"), ["OUO", "OPO", "OOO"], { O: mc("obsidian"), P: pe("relay_mk1"), U: dm });
  shaped("relay_mk3", pe("relay_mk3"), ["OUO", "OPO", "OOO"], { O: mc("obsidian"), P: pe("relay_mk2"), U: rm });
  // Condensador e Baú Alquímico
  shaped("condenser", pe("condenser"), ["ODO", "DCD", "ODO"], { C: pe("alchemical_chest"), O: mc("obsidian"), D });
  shaped("alchemical_chest", pe("alchemical_chest"), ["LMH", "SDS", "ICI"], {
    L: pe("low_covalence_dust"), M: pe("medium_covalence_dust"), H: pe("high_covalence_dust"), S: mc("stone"), I: mc("iron_ingot"), C: mc("chest"), D,
  });
  // Klein Stars
  shaped("klein_star_ein", pe("klein_star_ein"), ["MMM", "MDM", "MMM"], { M: pe("mobius_fuel"), D });
  const tiers = ["ein", "zwei", "drei", "vier", "sphere", "omega"];
  for (let i = 1; i < tiers.length; i++) shapeless(`klein_star_${tiers[i]}`, pe(`klein_star_${tiers[i]}`), [[pe(`klein_star_${tiers[i - 1]}`), 4]]);
  // Anéis e itens
  shaped("iron_band", pe("iron_band"), ["III", "ILI", "III"], { I: mc("iron_ingot"), L: mc("lava_bucket") }, 1, [[mc("bucket"), 1]]);
  shaped("black_hole_band", pe("black_hole_band"), ["SSS", "DID", "SSS"], { S: mc("string"), D: dm, I: pe("iron_band") });
  shaped("evertide_amulet", pe("evertide_amulet"), ["WWW", "DDD", "WWW"], { D: dm, W: mc("water_bucket") }, 1, [[mc("bucket"), 6]]);
  shaped("volcanite_amulet", pe("volcanite_amulet"), ["LLL", "DDD", "LLL"], { D: dm, L: mc("lava_bucket") }, 1, [[mc("bucket"), 6]]);
  shaped("repair_talisman", pe("repair_talisman"), ["LMH", "SPS", "HML"], { P: mc("paper"), S: mc("string"), L: pe("low_covalence_dust"), M: pe("medium_covalence_dust"), H: pe("high_covalence_dust") });
  shaped("repair_talisman_alt", pe("repair_talisman"), ["HML", "SPS", "LMH"], { P: mc("paper"), S: mc("string"), L: pe("low_covalence_dust"), M: pe("medium_covalence_dust"), H: pe("high_covalence_dust") });
  shaped("tome_of_knowledge", pe("tome_of_knowledge"), ["HML", "KBK", "LMH"], { B: mc("book"), K: pe("klein_star_omega"), L: pe("low_covalence_dust"), M: pe("medium_covalence_dust"), H: pe("high_covalence_dust") });
  shaped("tome_of_knowledge_alt", pe("tome_of_knowledge"), ["LMH", "KBK", "HML"], { B: mc("book"), K: pe("klein_star_omega"), L: pe("low_covalence_dust"), M: pe("medium_covalence_dust"), H: pe("high_covalence_dust") });
  // Pós de covalência
  shapeless("low_covalence_dust", pe("low_covalence_dust"), [[mc("charcoal"), 1], [mc("cobblestone"), 8]], 40);
  shapeless("medium_covalence_dust", pe("medium_covalence_dust"), [[mc("iron_ingot"), 1], [mc("redstone"), 1]], 40);
  shapeless("high_covalence_dust", pe("high_covalence_dust"), [[mc("diamond"), 1], [mc("coal"), 1]], 40);
  // Varas de adivinhação
  shaped("low_divining_rod", pe("low_divining_rod"), ["DDD", "DSD", "DDD"], { S: mc("stick"), D: pe("low_covalence_dust") });
  shaped("medium_divining_rod", pe("medium_divining_rod"), ["DDD", "DSD", "DDD"], { S: pe("low_divining_rod"), D: pe("medium_covalence_dust") });
  shaped("high_divining_rod", pe("high_divining_rod"), ["DDD", "DSD", "DDD"], { S: pe("medium_divining_rod"), D: pe("high_covalence_dust") });
  // ── anéis, pedras e itens (PERecipeProvider.addRingRecipes / addMiscToolRecipes / addNovaRecipes / addBagRecipes)
  const ib = pe("iron_band");
  shaped("arcana_ring", pe("arcana_ring"), ["ZIH", "SMM", "MMM"], { Z: pe("zero_ring"), I: pe("ignition_ring"), H: pe("harvest_goddess_band"), S: pe("swiftwolf_rending_gale"), M: rm });
  shaped("archangel_smite", pe("archangel_smite"), ["BFB", "MIM", "BFB"], { B: mc("bow"), F: mc("feather"), I: ib, M: dm });
  shaped("body_stone", pe("body_stone"), ["SSS", "RLR", "SSS"], { R: rm, S: mc("sugar"), L: mc("lapis_lazuli") });
  shaped("harvest_goddess_band", pe("harvest_goddess_band"), ["SFS", "DID", "SFS"], { S: mc("oak_sapling"), D: dm, F: mc("dandelion"), I: ib });
  shaped("ignition_ring", pe("ignition_ring"), ["FMF", "DID", "FMF"], { D: dm, F: mc("flint_and_steel"), I: ib, M: pe("mobius_fuel") });
  shapeless("life_stone", pe("life_stone"), [[pe("body_stone"), 1], [pe("soul_stone"), 1]]);
  shaped("mind_stone", pe("mind_stone"), ["BBB", "RLR", "BBB"], { R: rm, B: mc("book"), L: mc("lapis_lazuli") });
  shaped("soul_stone", pe("soul_stone"), ["GGG", "RLR", "GGG"], { R: rm, G: mc("glowstone_dust"), L: mc("lapis_lazuli") });
  shaped("swiftwolf_rending_gale", pe("swiftwolf_rending_gale"), ["DFD", "FIF", "DFD"], { D: dm, F: mc("feather"), I: ib });
  shapeless("void_ring", pe("void_ring"), [[pe("black_hole_band"), 1], [pe("gem_of_eternal_density"), 1], [rm, 2]]);
  shaped("watch_of_flowing_time", pe("watch_of_flowing_time"), ["DGD", "OCO", "DGD"], { C: mc("clock"), D: dm, G: mc("glowstone"), O: mc("obsidian") });
  shaped("zero_ring", pe("zero_ring"), ["SBS", "MIM", "SBS"], { B: mc("snowball"), S: mc("snow"), I: ib, M: dm });
  shaped("catalytic_lens", pe("catalytic_lens"), ["MMM", "DMH", "MMM"], { D: pe("destruction_catalyst"), H: pe("hyperkinetic_lens"), M: dm });
  shaped("catalytic_lens_alt", pe("catalytic_lens"), ["MMM", "HMD", "MMM"], { D: pe("destruction_catalyst"), H: pe("hyperkinetic_lens"), M: dm });
  shaped("destruction_catalyst", pe("destruction_catalyst"), ["NMN", "MFM", "NMN"], { F: mc("flint_and_steel"), M: pe("mobius_fuel"), N: pe("nova_catalyst") });
  shaped("gem_of_eternal_density", pe("gem_of_eternal_density"), ["DOD", "MDM", "DOD"], { D, M: dm, O: mc("obsidian") });
  shaped("hyperkinetic_lens", pe("hyperkinetic_lens"), ["DDD", "MNM", "DDD"], { D, M: dm, N: pe("nova_catalyst") });
  shapeless("nova_catalyst", pe("nova_catalyst"), [[mc("tnt"), 1], [pe("mobius_fuel"), 1]], 2);
  shapeless("nova_cataclysm", pe("nova_cataclysm"), [[pe("nova_catalyst"), 1], [pe("aeternalis_fuel"), 1]], 2);
  shaped("interdiction_torch", pe("interdiction_torch"), ["RDR", "DPD", "GGG"], { R: mc("redstone_torch"), D, P: pe("philosophers_stone"), G: mc("glowstone_dust") }, 1, [[pe("philosophers_stone"), 1]]);
  shaped("condenser_mk2", pe("condenser_mk2"), ["RDR", "DCD", "RDR"], { R: pe("red_matter_block"), C: pe("condenser"), D: pe("dark_matter_block") });
  for (const c of ["white", "orange", "magenta", "light_blue", "yellow", "lime", "pink", "gray", "light_gray", "cyan", "purple", "blue", "brown", "green", "red", "black"])
    shaped(`${c}_alchemical_bag`, pe(`${c}_alchemical_bag`), ["CCC", "WAW", "WWW"], { A: pe("alchemical_chest"), C: pe("high_covalence_dust"), W: mc(`${c}_wool`) });
  // armadura de gema (PERecipeProvider.gemArmorRecipes — variante que aceita qualquer Klein Star Omega)
  const om = pe("klein_star_omega");
  shapeless("gem_helmet", pe("gem_helmet"), [[pe("red_matter_helmet"), 1], [pe("evertide_amulet"), 1], [pe("soul_stone"), 1], [om, 1]]);
  shapeless("gem_chestplate", pe("gem_chestplate"), [[pe("red_matter_chestplate"), 1], [pe("volcanite_amulet"), 1], [pe("body_stone"), 1], [om, 1]]);
  shapeless("gem_leggings", pe("gem_leggings"), [[pe("red_matter_leggings"), 1], [pe("black_hole_band"), 1], [pe("watch_of_flowing_time"), 1], [om, 1]]);
  shapeless("gem_boots", pe("gem_boots"), [[pe("red_matter_boots"), 1], [pe("swiftwolf_rending_gale"), 2], [om, 1]]);
  return r;
}

/** Converte receitas em entradas para o resolvedor de EMC (inclui as conversões com a Pedra Filosofal). */
export function emcRecipes(defs: RecipeDef[]): Recipe[] {
  const out: Recipe[] = [];
  for (const d of defs) {
    const ins: Record<string, number> = {};
    if (d.kind === "shaped") {
      for (const row of d.pattern) for (const ch of row) if (ch !== " ") ins[d.key[ch]] = (ins[d.key[ch]] ?? 0) + 1;
    } else for (const [id, n] of d.ins) ins[id] = (ins[id] ?? 0) + n;
    // itens devolvidos (contêineres) não entram no custo
    for (const [id, n] of d.extra ?? []) {
      ins[id] = (ins[id] ?? 0) - n;
      if (ins[id] === 0) delete ins[id];
    }
    out.push([d.out, d.count ?? 1, ins]);
  }
  // fuelUpgradeRecipe: Pedra Filosofal + 4 → 1 (a pedra não é consumida)
  out.push([pe("alchemical_coal"), 1, { [mc("coal")]: 4 }]);
  out.push([pe("mobius_fuel"), 1, { [pe("alchemical_coal")]: 4 }]);
  out.push([pe("aeternalis_fuel"), 1, { [pe("mobius_fuel")]: 4 }]);
  return out;
}

/** Fundição filosofal: itens fundíveis (equivalente às receitas de fornalha). */
export function smeltingMap(): Record<string, string> {
  const m: Record<string, string> = {};
  const s = (a: string, b: string) => (m[mc(a)] = mc(b));
  for (const metal of ["iron", "gold", "copper"]) {
    s(`raw_${metal}`, `${metal}_ingot`);
    s(`${metal}_ore`, `${metal}_ingot`);
    s(`deepslate_${metal}_ore`, `${metal}_ingot`);
  }
  s("ancient_debris", "netherite_scrap");
  s("sand", "glass");
  s("red_sand", "glass");
  s("cobblestone", "stone");
  s("stone", "smooth_stone");
  s("cobbled_deepslate", "deepslate");
  s("clay_ball", "brick");
  s("netherrack", "netherbrick");
  s("sandstone", "smooth_sandstone");
  s("quartz_block", "smooth_quartz");
  s("wet_sponge", "sponge");
  s("cactus", "green_dye");
  s("kelp", "dried_kelp");
  s("chorus_fruit", "popped_chorus_fruit");
  s("potato", "baked_potato");
  for (const meat of ["porkchop", "beef", "chicken", "mutton", "rabbit", "cod", "salmon"]) s(meat, `cooked_${meat}`);
  for (const w of ["oak", "spruce", "birch", "jungle", "acacia", "dark_oak", "mangrove", "cherry"]) {
    s(`${w}_log`, "charcoal");
    s(`${w}_wood`, "charcoal");
  }
  return m;
}

export function langFile(lang: "en" | "pt"): string {
  const lines: string[] = [];
  for (const it of ITEMS) lines.push(`item.projecte.${it.name}.name=${lang === "en" ? it.en : it.pt}`);
  for (const b of BLOCKS) lines.push(`tile.projecte:${b.name}.name=${lang === "en" ? b.en : b.pt}`);
  // Interface da mesa (GUITransmutation): título e texto diagonal de "aprendido"/"desaprendido", letra por letra
  lines.push(`pe.gui.transmutation=${lang === "en" ? "Transmutation" : "Transmutação"}`);
  [...(lang === "en" ? "Learned!" : "Aprendeu")].forEach((ch, i) => lines.push(`pe.gui.learned.${i + 1}=${ch}`));
  [...(lang === "en" ? "Unlearned" : "Esquecido")].forEach((ch, i) => lines.push(`pe.gui.unlearned.${i + 1}=${ch}`));
  lines.push(`pack.name=ProjectE (Bedrock)`);
  lines.push(lang === "en" ? "pack.description=Unofficial port of ProjectE: EMC, transmutation and alchemy." : "pack.description=Port não oficial do ProjectE: EMC, transmutação e alquimia.");
  return lines.join("\n") + "\n";
}
