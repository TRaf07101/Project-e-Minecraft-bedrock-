// Valores EMC — portados de ProjectE (MIT) mc1.21.1:
// src/datagen/java/moze_intel/projecte/common/PECustomConversionProvider.java (valores "before")
// Valores derivados são calculados por receitas (como o EMC mapper do ProjectE: o resultado
// recebe a soma dos ingredientes dividida pela quantidade produzida, arredondada para baixo;
// fundição = 1:1; a Pedra Filosofal não é consumida nas receitas de conversão).

const M = (id: string) => (id.includes(":") ? id : "minecraft:" + id);

const WOODS = ["oak", "spruce", "birch", "jungle", "acacia", "dark_oak", "mangrove", "cherry"];
const NETHER_WOODS = ["crimson", "warped"];
const COLORS = ["white", "orange", "magenta", "light_blue", "yellow", "lime", "pink", "gray", "light_gray", "cyan", "purple", "blue", "brown", "green", "red", "black"];
const SMALL_FLOWERS = ["dandelion", "poppy", "blue_orchid", "allium", "azure_bluet", "red_tulip", "orange_tulip", "white_tulip", "pink_tulip", "oxeye_daisy", "cornflower", "lily_of_the_valley", "wither_rose", "torchflower"];
const TALL_FLOWERS = ["sunflower", "lilac", "rose_bush", "peony", "pitcher_plant"];
const CORALS = ["tube", "brain", "bubble", "fire", "horn"];
const DISCS = ["13", "cat", "blocks", "chirp", "far", "mall", "mellohi", "stal", "strad", "ward", "11", "wait"];

/** Valores base (PECustomConversionProvider → ".before(...)") com IDs do Bedrock. */
export function baseValues(): Record<string, number> {
  const v: Record<string, number> = {};
  const set = (ids: string | string[], val: number) => (Array.isArray(ids) ? ids : [ids]).forEach((i) => (v[M(i)] = val));
  set("cobblestone", 1);
  set(["granite", "diorite", "andesite", "pointed_dripstone"], 16);
  set(["end_stone", "netherrack"], 1);
  set(["basalt", "blackstone", "tuff"], 4);
  set("cobbled_deepslate", 2);
  set("calcite", 32);
  set(["dirt", "sand", "red_sand", "snow_layer", "ice", "deadbush"], 1); // Java "snow" = camada de neve (snow_layer no Bedrock)
  set("gravel", 4);
  set(["cactus", "vine"], 8);
  set(["moss_block", "web"], 12);
  set("pink_petals", 4);
  set("waterlily", 16);
  set("small_dripleaf_block", 24);
  set("big_dripleaf", 32);
  set(SMALL_FLOWERS, 16);
  set(TALL_FLOWERS, 32);
  set(["red_mushroom", "brown_mushroom", "sugar_cane", "bamboo"], 32);
  set("soul_sand", 49);
  set("obsidian", 64);
  set("crying_obsidian", 768);
  set("sponge", 128);
  set(["short_grass", "seagrass", "kelp", "tall_grass", "fern", "large_fern", "nether_sprouts", "crimson_roots", "warped_roots"], 1);
  set("sea_pickle", 16);
  set("magma", 128);
  set(["weeping_vines", "twisting_vines", "glow_lichen"], 8);
  set(["crimson_fungus", "warped_fungus"], 32);
  set("spore_blossom", 64);
  CORALS.forEach((c) => {
    set(`${c}_coral_block`, 64);
    set(`dead_${c}_coral_block`, 4);
    set(`${c}_coral_fan`, 16);
    set(`dead_${c}_coral_fan`, 1);
    set(`${c}_coral`, 16);
    set(`dead_${c}_coral`, 1);
  });
  set("chorus_plant", 64);
  set("chorus_flower", 96);
  set("chorus_fruit", 192);
  set("sculk_vein", 4);
  set("sculk_catalyst", 8040);
  set(["wheat_seeds", "beetroot_seeds", "melon_slice", "sweet_berries", "glow_berries"], 16);
  set(["wheat", "nether_wart"], 24);
  set("apple", 128);
  set("pumpkin", 144);
  set("honey_bottle", 48);
  set(["porkchop", "beef", "chicken", "rabbit", "mutton", "cod", "salmon", "tropical_fish", "pufferfish", "carrot", "beetroot", "potato", "poisonous_potato"], 64);
  set("string", 12);
  set(["rotten_flesh", "slime_ball", "egg"], 32);
  set("turtle_scute", 96);
  set("turtle_egg", 192);
  set("feather", 48);
  set("rabbit_hide", 16);
  set(["rabbit_foot", "spider_eye"], 128);
  set(["phantom_membrane", "gunpowder"], 192);
  set(["skeleton_skull", "zombie_head", "creeper_head", "piglin_head"], 256);
  set(["ender_pearl", "nautilus_shell"], 1024);
  set("blaze_rod", 1536);
  set("breeze_rod", 2304);
  set(["shulker_shell", "sniffer_egg"], 2048);
  set("ghast_tear", 4096);
  set("trident", 16398);
  set("heart_of_the_sea", 32768);
  set("heavy_core", 40960);
  set("dragon_egg", 262144);
  set(["saddle", "echo_shard", "name_tag"], 192);
  set(DISCS.map((d) => `music_disc_${d}`), 2048);
  set("music_disc_otherside", 6144);
  set("music_disc_pigstep", 8192);
  set("music_disc_relic", 10176);
  set("music_disc_creator", 40960);
  set("music_disc_creator_music_box", 8192);
  set("music_disc_precipice", 12224);
  set("disc_fragment_5", 192);
  set("flint", 4);
  set("coal", 128);
  set(["quartz", "prismarine_shard"], 256);
  set("prismarine_crystals", 512);
  set("ink_sac", 16);
  set("cocoa_beans", 64);
  set("lapis_lazuli", 864);
  set("emerald", 16384);
  set("nether_star", 139264);
  set("clay_ball", 16);
  set("bone", 144);
  set("snowball", 1);
  set("filled_map", 1472);
  const logs: string[] = [];
  WOODS.forEach((w) => logs.push(`${w}_log`, `stripped_${w}_log`, `${w}_wood`, `stripped_${w}_wood`));
  NETHER_WOODS.forEach((w) => logs.push(`${w}_stem`, `stripped_${w}_stem`, `${w}_hyphae`, `stripped_${w}_hyphae`));
  set(logs, 32);
  set([...WOODS, ...NETHER_WOODS].map((w) => `${w}_planks`).concat(["bamboo_planks"]), 8);
  set(WOODS.filter((w) => w !== "mangrove").map((w) => `${w}_sapling`).concat(["mangrove_propagule"]), 32);
  set("stick", 4);
  set(WOODS.map((w) => `${w}_leaves`).concat(["azalea_leaves", "azalea_leaves_flowered"]), 1);
  set("mangrove_roots", 4);
  set(COLORS.map((c) => `${c}_wool`), 48);
  set("armadillo_scute", 48);
  set("netherite_scrap", 12288);
  set("diamond", 8192);
  set("redstone", 64);
  set("glowstone_dust", 384);
  // grupo "metals": ferro 256; ouro = 8 ferro; cobre = ferro/2; ametista 32
  set("iron_ingot", 256);
  set("amethyst_shard", 32);
  return v;
}

import vanillaRecipeData from "./vanilla_recipes.json";
export type Recipe = [out: string, count: number, inputs: Record<string, number>];

/** Receitas vanilla (Bedrock) usadas para derivar valores. Fundição = 1:1. */
export function vanillaRecipes(): Recipe[] {
  const r: Recipe[] = [];
  const add = (out: string, count: number, inputs: Record<string, number>) => {
    const ins: Record<string, number> = {};
    for (const k of Object.keys(inputs)) ins[M(k)] = inputs[k];
    r.push([M(out), count, ins]);
  };
  // conversões customizadas do ProjectE
  add("gold_ingot", 1, { iron_ingot: 8 });
  add("copper_ingot", 2, { iron_ingot: 1 });
  add("grass_block", 1, { dirt: 2 });
  add("podzol", 1, { dirt: 2 });
  add("mycelium", 1, { dirt: 2 });
  add("crimson_nylium", 1, { netherrack: 2 });
  add("warped_nylium", 1, { netherrack: 2 });
  add("carved_pumpkin", 1, { pumpkin: 1 });
  add("soul_soil", 1, { soul_sand: 1 });
  add("firework_star", 1, { gunpowder: 1 });
  add("firework_rocket", 1, { paper: 1, gunpowder: 1 });
  add("bell", 1, { gold_ingot: 7 });
  add("lava_bucket", 1, { bucket: 1, obsidian: 1 });
  add("water_bucket", 1, { bucket: 1 });
  add("glow_ink_sac", 1, { ink_sac: 1, glowstone_dust: 1 });
  ["helmet", "chestplate", "leggings", "boots"].forEach((p) => add(`chainmail_${p}`, 1, { [`iron_${p}`]: 1 }));
  // fundição
  const smelt: [string, string][] = [
    ["stone", "cobblestone"], ["smooth_stone", "stone"], ["glass", "sand"], ["brick", "clay_ball"], ["netherbrick", "netherrack"],
    ["charcoal", "oak_log"], ["cooked_porkchop", "porkchop"], ["cooked_beef", "beef"], ["cooked_chicken", "chicken"], ["cooked_mutton", "mutton"],
    ["cooked_rabbit", "rabbit"], ["cooked_cod", "cod"], ["cooked_salmon", "salmon"], ["baked_potato", "potato"], ["dried_kelp", "kelp"],
    ["green_dye", "cactus"], ["deepslate", "cobbled_deepslate"], ["popped_chorus_fruit", "chorus_fruit"], ["smooth_sandstone", "sandstone"],
    ["smooth_quartz", "quartz_block"], ["lime_dye", "sea_pickle"],
  ];
  smelt.forEach(([o, i]) => add(o, 1, { [i]: 1 }));
  // blocos de armazenamento e pepitas
  add("iron_block", 1, { iron_ingot: 9 });
  add("gold_block", 1, { gold_ingot: 9 });
  add("diamond_block", 1, { diamond: 9 });
  add("emerald_block", 1, { emerald: 9 });
  add("lapis_block", 1, { lapis_lazuli: 9 });
  add("redstone_block", 1, { redstone: 9 });
  add("coal_block", 1, { coal: 9 });
  add("copper_block", 1, { copper_ingot: 9 });
  add("netherite_ingot", 1, { netherite_scrap: 4, gold_ingot: 4 });
  add("netherite_block", 1, { netherite_ingot: 9 });
  add("gold_nugget", 9, { gold_ingot: 1 });
  add("iron_nugget", 9, { iron_ingot: 1 });
  add("quartz_block", 1, { quartz: 4 });
  add("glowstone", 1, { glowstone_dust: 4 });
  add("amethyst_block", 1, { amethyst_shard: 4 });
  add("bone_meal", 3, { bone: 1 });
  add("bone_block", 1, { bone_meal: 9 });
  add("hay_block", 1, { wheat: 9 });
  add("slime", 1, { slime_ball: 9 });
  add("clay", 1, { clay_ball: 4 });
  add("brick_block", 1, { brick: 4 });
  add("nether_brick", 1, { netherbrick: 4 });
  add("sandstone", 1, { sand: 4 });
  add("red_sandstone", 1, { red_sand: 4 });
  add("stone_bricks", 1, { stone: 4 });
  add("polished_granite", 4, { granite: 4 });
  add("polished_diorite", 4, { diorite: 4 });
  add("polished_andesite", 4, { andesite: 4 });
  add("dried_kelp_block", 1, { dried_kelp: 9 });
  add("melon_block", 1, { melon_slice: 9 });
  add("packed_ice", 1, { ice: 9 });
  add("blue_ice", 1, { packed_ice: 9 });
  add("purpur_block", 4, { popped_chorus_fruit: 4 });
  add("prismarine", 1, { prismarine_shard: 4 });
  add("sea_lantern", 1, { prismarine_shard: 4, prismarine_crystals: 5 });
  // básicos
  add("glass_bottle", 3, { glass: 3 });
  add("bucket", 1, { iron_ingot: 3 });
  add("sugar", 1, { sugar_cane: 1 });
  add("paper", 3, { sugar_cane: 3 });
  add("leather", 1, { rabbit_hide: 4 });
  add("book", 1, { paper: 3, leather: 1 });
  add("bookshelf", 1, { oak_planks: 6, book: 3 });
  add("writable_book", 1, { book: 1, ink_sac: 1, feather: 1 });
  add("torch", 4, { coal: 1, stick: 1 });
  add("crafting_table", 1, { oak_planks: 4 });
  add("chest", 1, { oak_planks: 8 });
  add("barrel", 1, { oak_planks: 6, oak_slab: 2 });
  add("oak_slab", 6, { oak_planks: 3 });
  add("furnace", 1, { cobblestone: 8 });
  add("bread", 1, { wheat: 3 });
  add("pumpkin_pie", 1, { pumpkin: 1, sugar: 1, egg: 1 });
  add("golden_apple", 1, { apple: 1, gold_ingot: 8 });
  add("golden_carrot", 1, { carrot: 1, gold_nugget: 8 });
  add("glistering_melon_slice", 1, { melon_slice: 1, gold_nugget: 8 });
  add("bowl", 4, { oak_planks: 3 });
  add("mushroom_stew", 1, { bowl: 1, red_mushroom: 1, brown_mushroom: 1 });
  // ferramentas e armaduras
  const tools: [string, Record<string, number>][] = [
    ["pickaxe", { M: 3, stick: 2 }], ["axe", { M: 3, stick: 2 }], ["shovel", { M: 1, stick: 2 }], ["sword", { M: 2, stick: 1 }], ["hoe", { M: 2, stick: 2 }],
  ];
  const mats: [string, string][] = [["wooden", "oak_planks"], ["stone", "cobblestone"], ["iron", "iron_ingot"], ["golden", "gold_ingot"], ["diamond", "diamond"]];
  for (const [prefix, mat] of mats)
    for (const [tool, ins] of tools) add(`${prefix}_${tool}`, 1, { [mat]: ins.M, stick: ins.stick });
  for (const [tool] of tools) add(`netherite_${tool}`, 1, { [`diamond_${tool}`]: 1, netherite_ingot: 1, netherite_upgrade_smithing_template: 1 });
  r.push([M("netherite_upgrade_smithing_template"), 1, {}]); // valor base abaixo
  const armor: [string, number][] = [["helmet", 5], ["chestplate", 8], ["leggings", 7], ["boots", 4]];
  const amats: [string, string][] = [["leather", "leather"], ["iron", "iron_ingot"], ["golden", "gold_ingot"], ["diamond", "diamond"]];
  for (const [prefix, mat] of amats) for (const [p, n] of armor) add(`${prefix}_${p}`, 1, { [mat]: n });
  add("shears", 1, { iron_ingot: 2 });
  add("flint_and_steel", 1, { iron_ingot: 1, flint: 1 });
  add("bow", 1, { stick: 3, string: 3 });
  add("arrow", 4, { flint: 1, stick: 1, feather: 1 });
  add("fishing_rod", 1, { stick: 3, string: 2 });
  add("compass", 1, { iron_ingot: 4, redstone: 1 });
  add("clock", 1, { gold_ingot: 4, redstone: 1 });
  add("shield", 1, { oak_planks: 6, iron_ingot: 1 });
  // redstone e utilidades
  add("tnt", 1, { gunpowder: 5, sand: 4 });
  add("redstone_torch", 1, { redstone: 1, stick: 1 });
  add("lever", 1, { stick: 1, cobblestone: 1 });
  add("repeater", 1, { stone: 3, redstone_torch: 2, redstone: 1 });
  add("comparator", 1, { stone: 3, redstone_torch: 3, quartz: 1 });
  add("piston", 1, { oak_planks: 3, cobblestone: 4, iron_ingot: 1, redstone: 1 });
  add("sticky_piston", 1, { piston: 1, slime_ball: 1 });
  add("hopper", 1, { iron_ingot: 5, chest: 1 });
  add("dropper", 1, { cobblestone: 7, redstone: 1 });
  add("dispenser", 1, { cobblestone: 7, bow: 1, redstone: 1 });
  add("observer", 1, { cobblestone: 6, redstone: 2, quartz: 1 });
  add("rail", 16, { iron_ingot: 6, stick: 1 });
  add("minecart", 1, { iron_ingot: 5 });
  add("ladder", 3, { stick: 7 });
  add("iron_bars", 16, { iron_ingot: 6 });
  add("anvil", 1, { iron_block: 3, iron_ingot: 4 });
  add("cauldron", 1, { iron_ingot: 7 });
  add("enchanting_table", 1, { book: 1, diamond: 2, obsidian: 4 });
  add("blaze_powder", 2, { blaze_rod: 1 });
  add("ender_eye", 1, { ender_pearl: 1, blaze_powder: 1 });
  add("ender_chest", 1, { obsidian: 8, ender_eye: 1 });
  add("beacon", 1, { glass: 5, obsidian: 3, nether_star: 1 });
  add("jukebox", 1, { oak_planks: 8, diamond: 1 });
  add("noteblock", 1, { oak_planks: 8, redstone: 1 });
  add("lantern", 1, { torch: 1, iron_nugget: 8 });
  add("item_frame", 1, { stick: 8, leather: 1 });
  add("flower_pot", 1, { brick: 3 });
  add("magma_cream", 1, { blaze_powder: 1, slime_ball: 1 });
  add("fermented_spider_eye", 1, { spider_eye: 1, brown_mushroom: 1, sugar: 1 });
  add("undyed_shulker_box", 1, { shulker_shell: 2, chest: 1 });
  // corantes
  add("white_dye", 1, { bone_meal: 1 });
  add("black_dye", 1, { ink_sac: 1 });
  add("blue_dye", 1, { lapis_lazuli: 1 });
  add("brown_dye", 1, { cocoa_beans: 1 });
  add("red_dye", 1, { poppy: 1 });
  add("yellow_dye", 1, { dandelion: 1 });
  add("orange_dye", 1, { orange_tulip: 1 });
  add("pink_dye", 1, { pink_tulip: 1 });
  add("light_blue_dye", 1, { blue_orchid: 1 });
  add("magenta_dye", 1, { allium: 1 });
  add("light_gray_dye", 1, { azure_bluet: 1 });
  add("lime_dye", 2, { green_dye: 1, white_dye: 1 });
  add("cyan_dye", 2, { blue_dye: 1, green_dye: 1 });
  add("purple_dye", 2, { red_dye: 1, blue_dye: 1 });
  add("gray_dye", 2, { black_dye: 1, white_dye: 1 });
  for (const c of COLORS) {
    add(`${c}_concrete_powder`, 8, { sand: 4, gravel: 4, [`${c}_dye`]: 1 });
    add(`${c}_concrete`, 1, { [`${c}_concrete_powder`]: 1 });
    add(`${c}_carpet`, 3, { [`${c}_wool`]: 2 });
    add(`${c}_stained_glass`, 8, { glass: 8, [`${c}_dye`]: 1 });
  }
  // todas as receitas vanilla do Bedrock (Mojang/bedrock-samples: crafting, fornalha e ferraria), como o mapeador de EMC do ProjectE faz com as receitas do jogo
  for (const rec of vanillaRecipeData as Recipe[]) r.push(rec);
  return r;
}

/** Resolvedor de ponto fixo: menor valor entre todas as receitas conhecidas. */
export function resolveEmc(base: Record<string, number>, recipes: Recipe[], ignore: Set<string>): Record<string, number> {
  const v: Record<string, number> = { ...base };
  v["minecraft:netherite_upgrade_smithing_template"] = 7497;
  for (let pass = 0; pass < 60; pass++) {
    let changed = false;
    for (const [out, count, ins] of recipes) {
      if (base[out] !== undefined) continue; // valores definidos não são sobrescritos
      let sum = 0;
      let ok = Object.keys(ins).length > 0;
      for (const k of Object.keys(ins)) {
        if (ignore.has(k)) continue;
        const val = v[k];
        if (val === undefined || val <= 0) {
          ok = false;
          break;
        }
        sum += val * ins[k];
      }
      if (!ok) continue;
      const val = Math.floor(sum / count);
      if (val <= 0) continue;
      if (v[out] === undefined || val < v[out]) {
        v[out] = val;
        changed = true;
      }
    }
    if (!changed) break;
  }
  return v;
}

// ───────────────────────── Transmutação de mundo (PEWorldTransmutationProvider)
export type WorldTransmutation = [from: string, to: string, alt: string];

export function worldTransmutations(): WorldTransmutation[] {
  const out: WorldTransmutation[] = [];
  const reg = (a: string, b: string, c: string) => out.push([M(a), M(b), M(c)]);
  // registerConsecutivePairs: cada elemento → próximo; agachado → anterior (cíclico)
  const pairs = (...ids: string[]) =>
    ids.forEach((id, i) => out.push([M(id), M(ids[(i + 1) % ids.length]), M(ids[(i - 1 + ids.length) % ids.length])]));
  reg("stone", "cobblestone", "grass_block");
  reg("cobblestone", "stone", "grass_block");
  reg("grass_block", "sand", "cobblestone");
  reg("sand", "grass_block", "cobblestone");
  reg("dirt", "sand", "cobblestone");
  pairs("gravel", "sandstone");
  pairs("ice", "water");
  pairs("obsidian", "lava");
  pairs("melon_block", "pumpkin");
  reg("granite", "diorite", "andesite");
  reg("diorite", "andesite", "granite");
  reg("andesite", "granite", "diorite");
  pairs("soul_sand", "soul_soil");
  pairs("netherrack", "crimson_nylium", "warped_nylium");
  pairs("nether_wart_block", "warped_wart_block");
  pairs("crimson_fungus", "warped_fungus");
  pairs("crimson_roots", "warped_roots");
  const W8 = WOODS;
  const W9 = [...WOODS, "bamboo"];
  pairs(...W8.map((w) => `${w}_log`));
  pairs(...W8.map((w) => `stripped_${w}_log`));
  pairs(...W8.map((w) => `${w}_wood`));
  pairs(...W8.map((w) => `stripped_${w}_wood`));
  pairs(...W8.map((w) => `${w}_leaves`));
  pairs(...W8.map((w) => (w === "mangrove" ? "mangrove_propagule" : `${w}_sapling`)));
  pairs(...W9.map((w) => `${w}_planks`));
  pairs(...W9.map((w) => `${w}_slab`));
  pairs(...W9.map((w) => `${w}_stairs`));
  pairs(...W9.map((w) => `${w}_fence`));
  // No Bedrock, as variantes de carvalho mantêm IDs legados
  pairs(...W9.map((w) => (w === "oak" ? "wooden_pressure_plate" : `${w}_pressure_plate`)));
  pairs(...W9.map((w) => (w === "oak" ? "wooden_button" : `${w}_button`)));
  pairs(...W9.map((w) => (w === "oak" ? "trapdoor" : `${w}_trapdoor`)));
  // Portas foram omitidas de propósito: no Bedrock só a metade clicada mudaria, gerando portas mistas
  // que podem duplicar itens ao serem quebradas.
  pairs("crimson_stem", "warped_stem");
  pairs("stripped_crimson_stem", "stripped_warped_stem");
  pairs("crimson_hyphae", "warped_hyphae");
  pairs("stripped_crimson_hyphae", "stripped_warped_hyphae");
  pairs("crimson_planks", "warped_planks");
  pairs("crimson_slab", "warped_slab");
  pairs("crimson_stairs", "warped_stairs");
  pairs("crimson_fence", "warped_fence");
  pairs("crimson_pressure_plate", "warped_pressure_plate");
  pairs("crimson_button", "warped_button");
  pairs("crimson_trapdoor", "warped_trapdoor");
  for (const suffix of ["concrete", "concrete_powder", "carpet", "wool", "terracotta", "stained_glass", "stained_glass_pane"]) pairs(...COLORS.map((c) => `${c}_${suffix}`));
  // oxidação do cobre (cadeias não enceradas)
  pairs("copper_block", "exposed_copper", "weathered_copper", "oxidized_copper");
  pairs("cut_copper", "exposed_cut_copper", "weathered_cut_copper", "oxidized_cut_copper");
  pairs("cut_copper_stairs", "exposed_cut_copper_stairs", "weathered_cut_copper_stairs", "oxidized_cut_copper_stairs");
  pairs("cut_copper_slab", "exposed_cut_copper_slab", "weathered_cut_copper_slab", "oxidized_cut_copper_slab");
  pairs("copper_trapdoor", "exposed_copper_trapdoor", "weathered_copper_trapdoor", "oxidized_copper_trapdoor");
  pairs("copper_grate", "exposed_copper_grate", "weathered_copper_grate", "oxidized_copper_grate");
  pairs("chiseled_copper", "exposed_chiseled_copper", "weathered_chiseled_copper", "oxidized_chiseled_copper");
  pairs("copper_bulb", "exposed_copper_bulb", "weathered_copper_bulb", "oxidized_copper_bulb");
  return out;
}
