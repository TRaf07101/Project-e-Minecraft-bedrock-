import { useEffect, useRef } from "react";
import * as THREE from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";
import { peTexUrl } from "../addon/textures";
import { ITEMS } from "../addon/content";
import { FUEL_POS, GUI_H, GUI_W, INPUT_POS, MATTER_POS, SEARCH_BOX, invPos } from "../addon/ui";

const loadImg = (url: string) =>
  new Promise<HTMLImageElement>((res, rej) => {
    const i = new Image();
    i.onload = () => res(i);
    i.onerror = rej;
    i.src = url;
  });
const itemTex = (name: string) => ITEMS.find((i) => i.name === name)?.tex ?? "item/philosophers_stone";

/** Modelo 3D da mesa: laje 16×4×16 com as texturas originais (transmutation_stone). */
export function TablePreview() {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const host = ref.current!;
    const w = host.clientWidth;
    const h = 300;
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setPixelRatio(Math.min(2, window.devicePixelRatio));
    renderer.setSize(w, h);
    host.appendChild(renderer.domElement);
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(35, w / h, 0.1, 100);
    camera.position.set(1.6, 1.4, 1.9);
    const loader = new THREE.TextureLoader();
    const tex = (key: string, side = false) => {
      const tx = loader.load(peTexUrl(key));
      tx.magFilter = THREE.NearestFilter;
      tx.minFilter = THREE.NearestFilter;
      tx.colorSpace = THREE.SRGBColorSpace;
      if (side) tx.repeat.set(1, 0.25); // laterais usam as linhas 12–15 (UV automático do modelo do ProjectE)
      return tx;
    };
    const sideMat = new THREE.MeshLambertMaterial({ map: tex("block/transmutation_stone/side", true) });
    const mats = [sideMat, sideMat, new THREE.MeshLambertMaterial({ map: tex("block/transmutation_stone/top") }), new THREE.MeshLambertMaterial({ map: tex("block/transmutation_stone/bottom") }), sideMat, sideMat];
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(1, 0.25, 1), mats);
    mesh.position.y = 0.125;
    scene.add(mesh);
    scene.add(new THREE.AmbientLight(0xffffff, 1.6));
    const sun = new THREE.DirectionalLight(0xffffff, 1.8);
    sun.position.set(2, 4, 3);
    scene.add(sun);
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.target.set(0, 0.1, 0);
    controls.autoRotate = true;
    controls.autoRotateSpeed = 2;
    controls.enableDamping = true;
    let raf = 0;
    const loop = () => {
      controls.update();
      renderer.render(scene, camera);
      raf = requestAnimationFrame(loop);
    };
    loop();
    return () => {
      cancelAnimationFrame(raf);
      controls.dispose();
      renderer.dispose();
      host.removeChild(renderer.domElement);
    };
  }, []);
  return <div ref={ref} style={{ width: "100%", height: 300, cursor: "grab" }} />;
}

/** Imagem da interface: fundo original transmute.png + ícones originais nas posições dos slots. */
export function UiPreview() {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    let alive = true;
    (async () => {
      const S = 3;
      const el = ref.current!;
      el.width = GUI_W * S;
      el.height = GUI_H * S;
      const ctx = el.getContext("2d")!;
      ctx.imageSmoothingEnabled = false;
      const bg = await loadImg(peTexUrl("gui/transmute"));
      if (!alive) return;
      ctx.drawImage(bg, 0, 0, GUI_W, GUI_H, 0, 0, GUI_W * S, GUI_H * S);
      const icon = async (name: string, [x, y]: [number, number]) => {
        const img = await loadImg(peTexUrl(itemTex(name)));
        ctx.imageSmoothingEnabled = false;
        ctx.drawImage(img, x * S, y * S, 16 * S, 16 * S);
      };
      const matter = ["red_matter", "dark_matter", "klein_star_omega", "klein_star_sphere", "klein_star_vier", "klein_star_drei", "klein_star_zwei", "klein_star_ein", "philosophers_stone", "high_covalence_dust", "medium_covalence_dust", "low_covalence_dust"];
      await Promise.all(MATTER_POS.map((p, i) => icon(matter[i], p)));
      await Promise.all(["aeternalis_fuel", "mobius_fuel", "alchemical_coal", "iron_band"].map((n, i) => icon(n, FUEL_POS[i])));
      await icon("klein_star_omega", INPUT_POS[0]);
      await Promise.all(["red_matter_katar", "red_matter_morning_star", "gem_helmet", "gem_boots", "swiftwolf_rending_gale", "transmutation_tablet"].map((n, i) => icon(n, invPos(i))));
      const text = (s: string, x: number, y: number, color: string, shadow = false) => {
        ctx.font = `${8 * S}px "Courier New", monospace`;
        ctx.textBaseline = "top";
        if (shadow) {
          ctx.fillStyle = "#3f3f3f";
          ctx.fillText(s, (x + 1) * S, (y + 1) * S);
        }
        ctx.fillStyle = color;
        ctx.fillText(s, x * S, y * S);
      };
      text("Transmutação", 6, 8, "#404040");
      text("EMC:", 6, 92, "#404040");
      text("51.200.000", 6, 102, "#404040");
      text("Pesquisar...", SEARCH_BOX.x + 2, SEARCH_BOX.y + 1, "#707070");
      const [hx, hy] = MATTER_POS[0];
      ctx.fillStyle = "rgba(255,255,255,0.5)";
      ctx.fillRect(hx * S, hy * S, 16 * S, 16 * S);
      const tx = hx + 16, ty = hy - 2;
      ctx.fillStyle = "rgba(16,0,16,0.94)";
      ctx.fillRect(tx * S, ty * S, 84 * S, 24 * S);
      ctx.strokeStyle = "rgba(80,0,255,0.6)";
      ctx.lineWidth = S;
      ctx.strokeRect((tx + 1.5) * S, (ty + 1.5) * S, 81 * S, 21 * S);
      text("Matéria Vermelha", tx + 4, ty + 4, "#ffffff", true);
      text("EMC: 466.944", tx + 4, ty + 13, "#ffff55", true);
    })();
    return () => {
      alive = false;
    };
  }, []);
  return <canvas ref={ref} style={{ width: "100%", maxWidth: 684, imageRendering: "pixelated", display: "block", margin: "0 auto" }} />;
}

/** Grade com os ícones originais de ferramentas, armaduras e itens do pacote. */
export function ItemsPreview() {
  return (
    <div style={{ display: "flex", flexWrap: "wrap", gap: 6, justifyContent: "center" }}>
      {ITEMS.filter((i) => !i.name.endsWith("_alchemical_bag") || i.name.startsWith("white")).map((i) => (
        <img key={i.name} src={peTexUrl(i.tex)} title={i.pt} alt={i.pt} width={40} height={40} style={{ imageRendering: "pixelated", background: "#c6c6c6", border: "2px solid #555", padding: 2 }} />
      ))}
    </div>
  );
}
