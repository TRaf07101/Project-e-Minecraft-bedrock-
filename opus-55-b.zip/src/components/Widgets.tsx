import { Brain, CalendarCheck, Check, CircleCheck, Flame, Lock, Sparkles, Trophy } from "lucide-react";
import { navigate } from "../lib/router";
import { dayKey, effectiveStreak, type State } from "../lib/store";
import { dailyChallenges, planStats, WEEKDAY_LETTER } from "../lib/engage";
import { Button, ProgressBar, Ring } from "./ui";
import { cn } from "../utils/cn";

export function Widget({ title, icon, action, children, className }: { title: string; icon: React.ReactNode; action?: React.ReactNode; children: React.ReactNode; className?: string }) {
  return (
    <section className={cn("rounded-3xl border border-line bg-white p-4", className)}>
      <div className="mb-3 flex items-center gap-2">
        {icon}
        <h3 className="flex-1 font-extrabold">{title}</h3>
        {action}
      </div>
      {children}
    </section>
  );
}

export function StudyPlanWidget({ s }: { s: State }) {
  const p = planStats(s);
  const goalMet = p.weekGoal > 0 && p.weekMinutes >= p.weekGoal;
  return (
    <Widget
      title="Plano de estudos"
      icon={<CalendarCheck size={18} className="text-brand" />}
      action={
        <button onClick={() => navigate("/plan")} className="text-sm font-bold text-brand hover:underline">
          Editar
        </button>
      }
    >
      <div className="flex items-center gap-3">
        <Ring value={p.weekGoal ? p.weekMinutes / p.weekGoal : 0} size={64} stroke={7} color={goalMet ? "var(--color-ok)" : "var(--color-brand)"}>
          <span className="text-sm font-extrabold">{Math.min(999, p.weekMinutes)}</span>
        </Ring>
        <div className="min-w-0">
          <div className="text-sm font-extrabold">
            {p.weekMinutes} de {p.weekGoal} min nesta semana
          </div>
          <div className="text-xs text-muted">
            Hoje: {p.todayMinutes} min {p.isStudyDay ? `· meta ${s.plan.minutes} min` : "· dia livre"}
          </div>
        </div>
      </div>
      <div className="mt-3 flex justify-between">
        {p.days.map((d) => {
          const k = dayKey(d);
          const planned = s.plan.days.includes(d.getDay());
          const mins = s.days[k]?.minutes ?? 0;
          const met = planned ? mins >= s.plan.minutes : mins > 0;
          const isToday = k === dayKey();
          return (
            <div key={k} className="flex flex-col items-center gap-1">
              <span
                className={cn(
                  "flex h-8 w-8 items-center justify-center rounded-full text-xs font-extrabold",
                  met ? "bg-ok text-white" : planned ? "border-2 border-brand-100 bg-brand-50 text-brand" : "bg-canvas text-muted",
                  isToday && "ring-2 ring-brand ring-offset-1"
                )}
              >
                {met ? <Check size={14} strokeWidth={3} /> : WEEKDAY_LETTER[d.getDay()]}
              </span>
            </div>
          );
        })}
      </div>
      <div className="mt-4 rounded-2xl bg-canvas p-3">
        <div className="flex items-center justify-between text-sm">
          <span className="font-bold">Fluência no curso</span>
          <span className="font-extrabold text-brand">{Math.round(p.fluency * 100)}%</span>
        </div>
        <ProgressBar value={p.fluency} height={6} className="mt-1.5" />
        <div className="mt-2 text-xs text-muted">
          {p.remainingMinutes === 0
            ? "Curso concluído! 🎉"
            : `Previsão para concluir o B1: ${p.eta.toLocaleDateString("pt-BR", { month: "long", year: "numeric" })}`}
        </div>
      </div>
    </Widget>
  );
}

export function ChallengesWidget({ s }: { s: State }) {
  const list = dailyChallenges(s);
  const done = list.filter((c) => c.value >= c.goal).length;
  return (
    <Widget title="Desafios diários" icon={<Trophy size={18} className="text-warn" />} action={<span className="text-xs font-bold text-muted">{done}/3</span>}>
      <div className="space-y-3">
        {list.map((c) => {
          const ok = c.value >= c.goal;
          return (
            <div key={c.id} className="flex items-center gap-3">
              {ok ? <CircleCheck size={22} className="shrink-0 text-ok" /> : <Sparkles size={22} className="shrink-0 text-brand-soft" />}
              <div className="min-w-0 flex-1">
                <div className="flex justify-between gap-2 text-sm">
                  <span className={cn("font-semibold", ok && "text-muted line-through")}>{c.label}</span>
                  <span className="shrink-0 text-xs font-bold text-muted">
                    {Math.min(c.value, c.goal)}/{c.goal}
                  </span>
                </div>
                <ProgressBar value={c.value / c.goal} height={6} color={ok ? "var(--color-ok)" : undefined} className="mt-1" />
              </div>
            </div>
          );
        })}
      </div>
    </Widget>
  );
}

export function StreakWidget({ s }: { s: State }) {
  const streak = effectiveStreak(s);
  const studiedToday = (s.days[dayKey()]?.activities ?? 0) > 0;
  return (
    <Widget title="Sequência" icon={<Flame size={18} className="text-orange-500" />}>
      <div className="flex items-center gap-3">
        <div className={cn("flex h-14 w-14 items-center justify-center rounded-2xl text-white", studiedToday ? "anim-flame bg-gradient-to-b from-orange-400 to-orange-600" : "bg-line")}>
          <Flame size={28} />
        </div>
        <div>
          <div className="text-2xl font-extrabold">
            {streak} {streak === 1 ? "dia" : "dias"}
          </div>
          <div className="text-xs text-muted">{studiedToday ? `Recorde: ${s.streak.best} dias` : "Conclua uma atividade hoje para manter a sequência"}</div>
        </div>
      </div>
    </Widget>
  );
}

export function ReviewWidget({ s }: { s: State }) {
  const now = Date.now();
  const total = Object.keys(s.vocab).length;
  const due = Object.values(s.vocab).filter((v) => v.due <= now).length;
  return (
    <Widget title="Revisão inteligente" icon={<Brain size={18} className="text-purple" />}>
      {total === 0 ? (
        <p className="flex items-center gap-2 text-sm text-muted">
          <Lock size={14} /> Conclua um vocabulário para começar a revisar.
        </p>
      ) : (
        <>
          <p className="text-sm text-muted">{due > 0 ? `${due} ${due === 1 ? "palavra está pronta" : "palavras estão prontas"} para revisão.` : "Tudo em dia. Volte mais tarde!"}</p>
          <Button variant={due > 0 ? "primary" : "secondary"} className="mt-3 min-h-10 w-full py-2" onClick={() => navigate("/review")}>
            {due > 0 ? "Revisar agora" : "Ver vocabulário"}
          </Button>
        </>
      )}
    </Widget>
  );
}

/** Ícone de lição que “enche” com a cor do capítulo à medida que o progresso avança (padrão da navegação plana do Busuu). */
export function LessonIcon({ progress, color, label, locked, size = 56 }: { progress: number; color: string; label: React.ReactNode; locked?: boolean; size?: number }) {
  const done = progress >= 1;
  return (
    <div
      className="relative flex shrink-0 items-center justify-center overflow-hidden rounded-full border-2 font-extrabold"
      style={{
        width: size,
        height: size,
        borderColor: locked ? "var(--color-line)" : color,
        background: locked ? "#eef1f5" : `linear-gradient(to top, ${color}${done ? "" : "55"} ${progress * 100}%, #fff ${progress * 100}%)`,
        color: done ? "#fff" : locked ? "var(--color-muted)" : color,
        transition: "background 0.6s ease",
      }}
    >
      {locked ? <Lock size={size * 0.34} /> : done ? <Check size={size * 0.42} strokeWidth={3} /> : label}
    </div>
  );
}
