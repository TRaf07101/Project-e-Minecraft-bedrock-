import type { ReactNode } from "react";
import { BookOpen, RotateCcw, User, Settings, Flame, Star, CalendarCheck } from "lucide-react";
import { navigate, useRoute } from "../lib/router";
import { effectiveStreak, useAppState } from "../lib/store";
import { Logo } from "./ui";
import { cn } from "../utils/cn";

const NAV = [
  { path: "/", match: ["", "unit", "lesson"], label: "Aprender", icon: BookOpen },
  { path: "/review", match: ["review", "grammar"], label: "Revisar", icon: RotateCcw },
  { path: "/plan", match: ["plan"], label: "Plano", icon: CalendarCheck },
  { path: "/profile", match: ["profile", "certificate"], label: "Perfil", icon: User },
];

export function Shell({ children, wide = false }: { children: ReactNode; wide?: boolean }) {
  const r = useRoute();
  const seg = r[0] ?? "";
  const streak = useAppState(effectiveStreak);
  const xp = useAppState((s) => s.xp);
  const due = useAppState((s) => {
    const now = Date.now();
    return Object.values(s.vocab).filter((v) => v.due <= now).length;
  });
  const items = [...NAV, { path: "/settings", match: ["settings"], label: "Ajustes", icon: Settings }];

  return (
    <div className="min-h-screen">
      {/* Desktop: menu lateral */}
      <aside className="no-print fixed inset-y-0 left-0 z-30 hidden w-60 flex-col border-r border-line bg-white px-3 py-6 md:flex">
        <button onClick={() => navigate("/")} className="px-3 text-left">
          <Logo />
        </button>
        <nav className="mt-8 space-y-1">
          {items.map((n) => {
            const active = n.match.includes(seg);
            return (
              <button
                key={n.path}
                onClick={() => navigate(n.path)}
                className={cn(
                  "relative flex w-full items-center gap-3 rounded-xl px-4 py-3 text-left font-bold transition",
                  active ? "bg-brand-50 text-brand" : "text-muted hover:bg-canvas hover:text-ink"
                )}
              >
                {active && <span className="absolute top-2 bottom-2 left-0 w-1 rounded-r-full bg-brand" />}
                <n.icon size={22} />
                {n.label}
                {n.path === "/review" && due > 0 && <span className="ml-auto rounded-full bg-bad px-2 py-0.5 text-xs font-bold text-white">{due}</span>}
              </button>
            );
          })}
        </nav>
        <div className="mt-auto space-y-2 px-1">
          <div className="flex items-center gap-3 rounded-2xl bg-orange-50 px-3 py-2.5">
            <Flame className="text-orange-500" size={22} />
            <div>
              <div className="font-extrabold leading-tight">{streak}</div>
              <div className="text-xs font-semibold text-muted">dias de sequência</div>
            </div>
          </div>
          <div className="flex items-center gap-3 rounded-2xl bg-amber-50 px-3 py-2.5">
            <Star className="fill-warn text-warn" size={22} />
            <div>
              <div className="font-extrabold leading-tight">{xp}</div>
              <div className="text-xs font-semibold text-muted">estrelas</div>
            </div>
          </div>
        </div>
      </aside>

      {/* Mobile: barra superior */}
      <header className="no-print sticky top-0 z-20 flex items-center justify-between border-b border-line bg-white/95 px-4 py-3 backdrop-blur md:hidden">
        <button onClick={() => navigate("/")}>
          <Logo size={30} />
        </button>
        <div className="flex items-center gap-2 text-sm font-extrabold">
          <span className="flex items-center gap-1 rounded-full bg-orange-50 px-3 py-1 text-orange-600" title="Dias de sequência">
            <Flame size={16} /> {streak}
          </span>
          <span className="flex items-center gap-1 rounded-full bg-amber-50 px-3 py-1 text-amber-600" title="Estrelas">
            <Star size={16} className="fill-warn text-warn" /> {xp}
          </span>
          <button onClick={() => navigate("/settings")} className="rounded-full p-1.5 text-muted hover:bg-canvas" aria-label="Ajustes">
            <Settings size={20} />
          </button>
        </div>
      </header>

      <main className="px-4 pt-5 pb-28 md:ml-60 md:px-8 md:pt-8 md:pb-12">
        <div className={cn("mx-auto", wide ? "max-w-5xl" : "max-w-3xl")}>{children}</div>
      </main>

      {/* Mobile: abas inferiores */}
      <nav className="no-print fixed inset-x-0 bottom-0 z-30 grid grid-cols-4 border-t border-line bg-white pb-[env(safe-area-inset-bottom)] md:hidden">
        {NAV.map((n) => {
          const active = n.match.includes(seg);
          return (
            <button key={n.path} onClick={() => navigate(n.path)} className={cn("relative flex flex-col items-center gap-0.5 py-2.5 text-[0.7rem] font-bold", active ? "text-brand" : "text-muted")}>
              <n.icon size={24} strokeWidth={active ? 2.5 : 2} />
              {n.label}
              {n.path === "/review" && due > 0 && <span className="absolute top-1.5 right-[28%] h-2.5 w-2.5 rounded-full bg-bad ring-2 ring-white" />}
            </button>
          );
        })}
      </nav>
    </div>
  );
}
