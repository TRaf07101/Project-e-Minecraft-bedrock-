import { useEffect, useMemo, useRef, useState } from "react";
import { Check, Mic, MicOff, RotateCw, X } from "lucide-react";
import type { Vocab } from "../course";
import { plain, toHiragana } from "../course/kana";
import { speak } from "../lib/audio";
import { useAppState } from "../lib/store";
import { ActionBar, type StepProps } from "./Exercises";
import { AudioButton, Button, JP } from "./ui";
import { cn } from "../utils/cn";

function Title({ children }: { children: React.ReactNode }) {
  return <h2 className="mb-4 text-lg font-extrabold text-ink sm:text-xl">{children}</h2>;
}

// ───────────────────────────────────── Verdadeiro ou falso
export function TrueFalseView({ v, claim, truth, locked, onSubmit }: { v: Vocab; claim: string; truth: boolean } & StepProps) {
  const [pick, setPick] = useState<boolean | null>(null);
  const answer = (b: boolean) => {
    if (locked || pick !== null) return;
    setPick(b);
    onSubmit({
      correct: b === truth,
      answer: `${plain(v.jp)} = ${v.pt}`,
      audio: v.kana,
      exp: truth ? "A tradução apresentada estava correta." : `A tradução apresentada (“${claim}”) não corresponde a esta palavra.`,
      summary: `${plain(v.jp)} = ${claim}?`,
    });
  };
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if (e.key === "1" || e.key === "ArrowLeft") answer(true);
      if (e.key === "2" || e.key === "ArrowRight") answer(false);
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  });
  const state = (b: boolean) => (pick === null ? "idle" : b === truth ? "correct" : pick === b ? "wrong" : "dim");
  return (
    <div className="anim-slide-in">
      <Title>Verdadeiro ou falso?</Title>
      <div className="mb-6 flex flex-col items-center gap-3 rounded-3xl border border-line bg-white px-4 py-8 text-center">
        <div className="flex items-center gap-3">
          <JP text={v.jp} className="text-3xl font-bold leading-[1.9] sm:text-4xl" />
          <AudioButton text={v.kana} autoPlay />
        </div>
        <div className="text-sm font-bold uppercase tracking-wider text-muted">significa</div>
        <div className="text-2xl font-extrabold">“{claim}”</div>
      </div>
      <div className="grid grid-cols-2 gap-3">
        {[true, false].map((b) => {
          const st = state(b);
          return (
            <button
              key={String(b)}
              disabled={locked}
              onClick={() => answer(b)}
              className={cn(
                "flex min-h-20 flex-col items-center justify-center gap-1 rounded-2xl border-2 border-b-4 text-lg font-extrabold transition active:translate-y-0.5",
                st === "idle" && "border-line bg-white hover:border-brand-100 hover:bg-brand-50/50",
                st === "correct" && "border-ok bg-ok-50 text-ok-dark",
                st === "wrong" && "anim-shake border-bad bg-bad-50 text-bad-dark",
                st === "dim" && "border-line bg-white opacity-50"
              )}
            >
              {b ? <Check size={26} strokeWidth={3} className="text-ok" /> : <X size={26} strokeWidth={3} className="text-bad" />}
              {b ? "Verdadeiro" : "Falso"}
            </button>
          );
        })}
      </div>
      <p className="mt-3 hidden text-center text-xs text-muted sm:block">Atalhos: 1 / ← verdadeiro · 2 / → falso</p>
    </div>
  );
}

// ───────────────────────────────────── Soletrar com kana
export function SpellView({ v, tiles, locked, onSubmit }: { v: Vocab; tiles: string[] } & StepProps) {
  const target = useMemo(() => [...v.kana.replace(/\s/g, "")], [v]);
  const [placed, setPlaced] = useState<number[]>([]);
  const full = placed.length === target.length;
  const submit = () => {
    const ans = placed.map((i) => tiles[i]).join("");
    onSubmit({ correct: ans === target.join(""), answer: v.jp, answerJp: true, audio: v.kana, exp: `Leitura: ${v.kana}`, summary: v.pt });
  };
  return (
    <>
      <div className="anim-slide-in">
        <Title>Soletre a palavra em hiragana</Title>
        <div className="mb-5 flex items-center justify-center gap-3 rounded-3xl border border-line bg-white p-6 text-center">
          <AudioButton text={v.kana} size="lg" autoPlay />
          <div className="text-left">
            <div className="text-2xl font-extrabold">{v.pt}</div>
            <div className="text-sm text-muted">Ouça e monte a leitura</div>
          </div>
        </div>
        <div className="mb-6 flex flex-wrap justify-center gap-2">
          {target.map((_, i) => {
            const idx = placed[i];
            const filled = idx !== undefined;
            return (
              <button
                key={i}
                disabled={locked || !filled}
                onClick={() => setPlaced((p) => p.filter((_, k) => k !== i))}
                className={cn(
                  "jp flex h-14 w-12 items-center justify-center rounded-xl border-b-4 text-2xl font-bold transition",
                  filled ? "border-brand bg-brand-50 text-brand-dark" : "border-line bg-white"
                )}
              >
                {filled ? tiles[idx] : ""}
              </button>
            );
          })}
        </div>
        <div className="flex flex-wrap justify-center gap-2">
          {tiles.map((t, i) => (
            <button
              key={i}
              disabled={locked || placed.includes(i) || full}
              onClick={() => setPlaced((p) => [...p, i])}
              className={cn(
                "jp h-14 w-12 rounded-xl border-2 border-b-4 border-line bg-white text-2xl font-bold transition hover:border-brand-100 active:translate-y-0.5",
                placed.includes(i) && "invisible"
              )}
            >
              {t}
            </button>
          ))}
        </div>
      </div>
      {!locked && (
        <ActionBar>
          <Button onClick={submit} disabled={!full} className="w-full sm:w-auto sm:min-w-48">
            Verificar
          </Button>
          <Button variant="ghost" onClick={() => setPlaced([])} disabled={!placed.length} className="w-full sm:w-auto">
            Limpar
          </Button>
        </ActionBar>
      )}
    </>
  );
}

// ───────────────────────────────────── Pronúncia (reconhecimento de voz)
type SR = {
  lang: string;
  interimResults: boolean;
  maxAlternatives: number;
  start: () => void;
  stop: () => void;
  onresult: (e: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void;
  onerror: (e: { error: string }) => void;
  onend: () => void;
};
const norm = (s: string) => toHiragana(plain(s).replace(/[\s、。！？!?.,・「」]/g, ""));

export function SpeakView({ v, locked, onSubmit }: { v: Vocab } & StepProps) {
  const [listening, setListening] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const recRef = useRef<SR | null>(null);
  const romaji = useAppState((s) => s.settings.romaji);
  useEffect(() => () => recRef.current?.stop(), []);

  const start = () => {
    setError(null);
    const W = window as unknown as { SpeechRecognition?: new () => SR; webkitSpeechRecognition?: new () => SR };
    const Ctor = W.SpeechRecognition ?? W.webkitSpeechRecognition;
    if (!Ctor) return setError("Reconhecimento de voz indisponível neste navegador.");
    const rec = new Ctor();
    rec.lang = "ja-JP";
    rec.interimResults = false;
    rec.maxAlternatives = 5;
    rec.onresult = (e) => {
      const alts = Array.from(e.results[0] ?? []).map((a) => a.transcript);
      const targets = [norm(v.jp), norm(v.kana)];
      const ok = alts.some((a) => {
        const n = norm(a);
        return n.length > 0 && targets.some((t) => n.includes(t) || (t.includes(n) && n.length >= Math.ceil(t.length * 0.7)));
      });
      onSubmit({
        correct: ok ? true : null,
        answer: v.jp,
        answerJp: true,
        audio: v.kana,
        exp: ok ? `Ouvimos: “${alts[0]}”. Ótima pronúncia!` : `Ouvimos: “${alts[0] || "—"}”. Ouça o modelo e tente novamente em outra revisão — esta tentativa não conta como erro.`,
        summary: v.pt,
      });
    };
    rec.onerror = (e) => {
      setListening(false);
      setError(e.error === "not-allowed" ? "Permita o uso do microfone para praticar a pronúncia." : "Não conseguimos ouvir. Tente de novo.");
    };
    rec.onend = () => setListening(false);
    recRef.current = rec;
    setListening(true);
    rec.start();
  };

  return (
    <>
      <div className="anim-slide-in">
        <span className="inline-flex items-center gap-1 rounded-full bg-purple-50 px-3 py-1 text-xs font-extrabold uppercase tracking-wider text-purple">
          <Mic size={14} /> Pronúncia
        </span>
        <h2 className="mt-3 mb-4 text-lg font-extrabold sm:text-xl">Ouça e repita em voz alta</h2>
        <div className="flex flex-col items-center gap-3 rounded-3xl border border-line bg-white px-4 py-8 text-center">
          <JP text={v.jp} className="text-4xl font-bold leading-[1.9]" />
          {romaji && <div className="italic text-muted">{v.romaji}</div>}
          <div className="text-muted">{v.pt}</div>
          <AudioButton text={v.kana} autoPlay />
        </div>
        <div className="mt-8 flex flex-col items-center gap-3">
          <button
            disabled={locked || listening}
            onClick={start}
            aria-label="Gravar"
            className={cn("flex h-24 w-24 items-center justify-center rounded-full bg-brand text-white shadow-lg shadow-brand/30 transition active:scale-95", listening && "anim-pulse bg-bad")}
          >
            {listening ? <MicOff size={40} /> : <Mic size={40} />}
          </button>
          <div className="text-sm font-bold text-muted">{listening ? "Ouvindo… fale agora" : "Toque no microfone e fale"}</div>
          {error && <div className="rounded-xl bg-amber-50 px-3 py-2 text-sm text-amber-900">{error}</div>}
        </div>
      </div>
      {!locked && (
        <ActionBar>
          <Button
            variant="ghost"
            onClick={() => {
              recRef.current?.stop();
              onSubmit({ correct: null, answer: v.jp, answerJp: true, audio: v.kana, exp: "Exercício de fala pulado.", summary: v.pt });
            }}
            className="w-full sm:w-auto"
          >
            Não posso falar agora
          </Button>
        </ActionBar>
      )}
    </>
  );
}

// ───────────────────────────────────── Cartões (revisão)
export function FlashView({ v, locked, onSubmit }: { v: Vocab } & StepProps) {
  const [flipped, setFlipped] = useState(false);
  const graded = useRef(false);
  const romaji = useAppState((s) => s.settings.romaji);
  const grade = (knew: boolean) => {
    if (graded.current || locked) return;
    graded.current = true;
    onSubmit({ correct: knew, answer: v.jp, answerJp: true, summary: v.pt, auto: true });
  };
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if (e.key === " " && !flipped) {
        e.preventDefault();
        setFlipped(true);
      }
      if (flipped && (e.key === "1" || e.key === "ArrowLeft")) grade(false);
      if (flipped && (e.key === "2" || e.key === "ArrowRight")) grade(true);
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  });
  return (
    <>
      <div className="anim-slide-in">
        <Title>Você lembra desta palavra?</Title>
        <button
          onClick={() => {
            if (!flipped) {
              setFlipped(true);
              speak(v.kana);
            }
          }}
          className="flex min-h-72 w-full flex-col items-center justify-center gap-3 rounded-3xl border-2 border-line bg-white p-6 text-center shadow-sm transition hover:border-brand-100"
        >
          <JP text={v.jp} className="text-4xl font-bold leading-[1.9]" furigana={flipped ? undefined : false} />
          {flipped ? (
            <div className="anim-fade-in space-y-2">
              {romaji && <div className="italic text-muted">{v.romaji}</div>}
              <div className="text-2xl font-extrabold text-brand">{v.pt}</div>
              <div className="mx-auto max-w-sm rounded-2xl bg-canvas p-3">
                <JP text={v.ex} className="text-base leading-[2]" />
                <div className="text-sm text-muted">{v.exPt}</div>
              </div>
            </div>
          ) : (
            <span className="inline-flex items-center gap-2 text-sm font-bold text-muted">
              <RotateCw size={16} /> Toque para virar
            </span>
          )}
        </button>
      </div>
      {!locked && flipped && (
        <ActionBar>
          <Button variant="ok" onClick={() => grade(true)} className="w-full sm:w-auto sm:min-w-40">
            Eu sabia
          </Button>
          <Button variant="bad" onClick={() => grade(false)} className="w-full sm:w-auto sm:min-w-40">
            Ainda não
          </Button>
        </ActionBar>
      )}
    </>
  );
}
