import { useEffect, useState, type ReactNode } from "react";
import { Volume2, X, Lock, Check } from "lucide-react";
import { parseFurigana } from "../course/kana";
import { useAppState } from "../lib/store";
import { onSpeaking, speak } from "../lib/audio";
import { cn } from "../utils/cn";

/** Japanese text with optional furigana (ruby). */
export function JP({ text, className, furigana, inherit }: { text: string; className?: string; furigana?: boolean; inherit?: boolean }) {
  const setting = useAppState((s) => s.settings.furigana);
  const show = furigana ?? setting;
  const segs = parseFurigana(text);
  return (
    <span lang={inherit ? undefined : "ja"} className={cn(!inherit && "jp", className)}>
      {segs.map((s, i) =>
        s.r && show ? (
          <ruby key={i}>
            {s.t}
            <rt>{s.r}</rt>
          </ruby>
        ) : (
          <span key={i}>{s.t}</span>
        )
      )}
    </span>
  );
}

function Inline({ text }: { text: string }) {
  const parts = text.split(/\*\*(.+?)\*\*/g);
  return (
    <>
      {parts.map((p, i) =>
        i % 2 === 1 ? (
          <strong key={i} className="font-extrabold text-ink">
            <JP text={p} inherit />
          </strong>
        ) : (
          <JP key={i} text={p} inherit />
        )
      )}
    </>
  );
}

/** Explanation renderer: **bold**, bullets (•), warnings (⚠️) and furigana. */
export function RichText({ text, className }: { text: string; className?: string }) {
  const lines = text.split("\n").filter((l) => l.trim());
  return (
    <div className={cn("space-y-2 leading-relaxed", className)}>
      {lines.map((l, i) => {
        const t = l.trim();
        if (t.startsWith("•"))
          return (
            <div key={i} className="flex gap-2 pl-1">
              <span className="text-brand mt-0.5">•</span>
              <div>
                <Inline text={t.slice(1).trim()} />
              </div>
            </div>
          );
        if (t.startsWith("⚠️"))
          return (
            <div key={i} className="rounded-xl bg-amber-50 border border-amber-200 px-3 py-2 text-amber-900 text-[0.95em]">
              <Inline text={t} />
            </div>
          );
        return (
          <p key={i}>
            <Inline text={t} />
          </p>
        );
      })}
    </div>
  );
}

export function useSpeaking(key: string) {
  const [on, setOn] = useState(false);
  useEffect(() => onSpeaking((k) => setOn(k === key)), [key]);
  return on;
}

export function AudioButton({
  text,
  size = "md",
  autoPlay = false,
  rate,
  label,
  className,
}: {
  text: string;
  size?: "sm" | "md" | "lg" | "xl";
  autoPlay?: boolean;
  rate?: number;
  label?: string;
  className?: string;
}) {
  const key = `${text}@${rate ?? ""}`;
  const speaking = useSpeaking(key);
  const auto = useAppState((s) => s.settings.autoplay);
  useEffect(() => {
    if (autoPlay && auto) {
      const t = setTimeout(() => speak(text, { rate, key }), 250);
      return () => clearTimeout(t);
    }
  }, [autoPlay, auto, text, rate, key]);
  const dims = { sm: "h-8 w-8", md: "h-11 w-11", lg: "h-16 w-16", xl: "h-24 w-24" }[size];
  const icon = { sm: 16, md: 20, lg: 28, xl: 40 }[size];
  return (
    <button
      type="button"
      aria-label={label ?? "Ouvir"}
      title={label ?? "Ouvir"}
      onClick={(e) => {
        e.stopPropagation();
        speak(text, { rate, key });
      }}
      className={cn(
        "inline-flex shrink-0 items-center justify-center rounded-full bg-brand text-white shadow-md shadow-brand/25 transition active:scale-95 hover:bg-brand-dark",
        speaking && "anim-pulse",
        dims,
        className
      )}
    >
      <Volume2 size={icon} />
    </button>
  );
}

export function Button({
  children,
  onClick,
  variant = "primary",
  disabled,
  className,
  type = "button",
}: {
  children: ReactNode;
  onClick?: () => void;
  variant?: "primary" | "secondary" | "ghost" | "ok" | "bad" | "white";
  disabled?: boolean;
  className?: string;
  type?: "button" | "submit";
}) {
  const styles = {
    primary: "bg-brand text-white hover:bg-brand-dark shadow-sm shadow-brand/30",
    secondary: "bg-white text-brand border-2 border-line hover:border-brand-100 hover:bg-brand-50",
    ghost: "bg-transparent text-brand hover:bg-brand-50",
    ok: "bg-ok text-white hover:bg-ok-dark",
    bad: "bg-bad text-white hover:bg-bad-dark",
    white: "bg-white text-ink hover:bg-white/90",
  }[variant];
  return (
    <button
      type={type}
      disabled={disabled}
      onClick={onClick}
      className={cn(
        "inline-flex min-h-12 items-center justify-center gap-2 rounded-full px-6 py-3 font-extrabold tracking-wide transition active:scale-[0.98] disabled:cursor-not-allowed disabled:bg-line disabled:text-muted disabled:shadow-none disabled:border-transparent",
        styles,
        className
      )}
    >
      {children}
    </button>
  );
}

export function ProgressBar({ value, color = "var(--color-brand)", className, height = 8 }: { value: number; color?: string; className?: string; height?: number }) {
  return (
    <div className={cn("w-full overflow-hidden rounded-full bg-line", className)} style={{ height }}>
      <div className="h-full rounded-full transition-all duration-500" style={{ width: `${Math.round(Math.min(1, Math.max(0, value)) * 100)}%`, background: color }} />
    </div>
  );
}

export function Ring({ value, size = 64, stroke = 7, color = "var(--color-brand)", children }: { value: number; size?: number; stroke?: number; color?: string; children?: ReactNode }) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const v = Math.min(1, Math.max(0, value));
  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} stroke="var(--color-line)" strokeWidth={stroke} fill="none" />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          stroke={color}
          strokeWidth={stroke}
          fill="none"
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={c * (1 - v)}
          style={{ transition: "stroke-dashoffset .8s ease" }}
        />
      </svg>
      <div className="absolute inset-0 flex items-center justify-center">{children}</div>
    </div>
  );
}

export function Card({ children, className, onClick }: { children: ReactNode; className?: string; onClick?: () => void }) {
  return (
    <div
      onClick={onClick}
      className={cn("rounded-3xl bg-white p-5 shadow-[0_1px_3px_rgba(16,24,40,0.06),0_1px_2px_rgba(16,24,40,0.04)] border border-line/70", onClick && "cursor-pointer transition hover:shadow-md hover:-translate-y-0.5", className)}
    >
      {children}
    </div>
  );
}

export function StrengthBars({ strength }: { strength: "fraca" | "média" | "forte" }) {
  const n = strength === "forte" ? 3 : strength === "média" ? 2 : 1;
  const color = strength === "forte" ? "bg-ok" : strength === "média" ? "bg-warn" : "bg-bad";
  return (
    <div className="flex items-end gap-0.5" title={`Força: ${strength}`} aria-label={`Força: ${strength}`}>
      {[1, 2, 3].map((i) => (
        <span key={i} className={cn("w-1.5 rounded-sm", i <= n ? color : "bg-line")} style={{ height: 6 + i * 4 }} />
      ))}
    </div>
  );
}

export function Modal({ open, onClose, children }: { open: boolean; onClose: () => void; children: ReactNode }) {
  useEffect(() => {
    if (!open) return;
    const k = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[60] flex items-end justify-center bg-ink/50 p-0 sm:items-center sm:p-4" onClick={onClose}>
      <div className="anim-slide-up w-full max-w-md rounded-t-3xl bg-white p-6 pb-safe sm:rounded-3xl" onClick={(e) => e.stopPropagation()}>
        {children}
      </div>
    </div>
  );
}

export function Confirm({
  open,
  title,
  message,
  confirmLabel,
  cancelLabel = "Cancelar",
  danger,
  onConfirm,
  onCancel,
}: {
  open: boolean;
  title: string;
  message: string;
  confirmLabel: string;
  cancelLabel?: string;
  danger?: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}) {
  return (
    <Modal open={open} onClose={onCancel}>
      <h3 className="text-xl font-black">{title}</h3>
      <p className="mt-2 text-muted">{message}</p>
      <div className="mt-6 flex flex-col gap-2">
        <Button variant={danger ? "bad" : "primary"} onClick={onConfirm}>
          {confirmLabel}
        </Button>
        <Button variant="ghost" onClick={onCancel}>
          {cancelLabel}
        </Button>
      </div>
    </Modal>
  );
}

export function Logo({ size = 36 }: { size?: number }) {
  return (
    <div className="flex items-center gap-2">
      <div className="flex items-center justify-center rounded-xl bg-brand text-white shadow-md shadow-brand/30" style={{ width: size, height: size }}>
        <span className="jp font-bold" style={{ fontSize: size * 0.55 }}>
          言
        </span>
      </div>
      <span className="text-xl font-black tracking-tight text-ink">kotoba</span>
    </div>
  );
}

export function IconClose({ onClick }: { onClick: () => void }) {
  return (
    <button onClick={onClick} aria-label="Fechar" className="rounded-full p-2 text-muted transition hover:bg-canvas hover:text-ink">
      <X size={24} />
    </button>
  );
}

export function StatusIcon({ state }: { state: "done" | "locked" | "open" }) {
  if (state === "done")
    return (
      <span className="flex h-7 w-7 items-center justify-center rounded-full bg-ok text-white">
        <Check size={16} strokeWidth={3} />
      </span>
    );
  if (state === "locked")
    return (
      <span className="flex h-7 w-7 items-center justify-center rounded-full bg-line text-muted">
        <Lock size={14} />
      </span>
    );
  return <span className="h-7 w-7 rounded-full border-2 border-brand-100 bg-brand-50" />;
}

export function Toggle({ checked, onChange, label, desc }: { checked: boolean; onChange: (v: boolean) => void; label: string; desc?: string }) {
  return (
    <label className="flex cursor-pointer items-center justify-between gap-4 py-3">
      <div>
        <div className="font-bold">{label}</div>
        {desc && <div className="text-sm text-muted">{desc}</div>}
      </div>
      <button
        type="button"
        role="switch"
        aria-checked={checked}
        onClick={() => onChange(!checked)}
        className={cn("relative h-7 w-12 shrink-0 rounded-full transition", checked ? "bg-brand" : "bg-line")}
      >
        <span className={cn("absolute top-0.5 h-6 w-6 rounded-full bg-white shadow transition-all", checked ? "left-[22px]" : "left-0.5")} />
      </button>
    </label>
  );
}

export function PageHeader({ title, subtitle, left, right }: { title: string; subtitle?: string; left?: ReactNode; right?: ReactNode }) {
  return (
    <div className="mb-5 flex items-center gap-3">
      {left}
      <div className="min-w-0 flex-1">
        <h1 className="truncate text-2xl font-black tracking-tight sm:text-3xl">{title}</h1>
        {subtitle && <p className="text-muted">{subtitle}</p>}
      </div>
      {right}
    </div>
  );
}

export function Confetti() {
  const colors = ["#116EEE", "#17A865", "#F5A524", "#E8414F", "#7C5CFA"];
  return (
    <div className="pointer-events-none fixed inset-0 z-[70] overflow-hidden">
      {Array.from({ length: 40 }).map((_, i) => (
        <span
          key={i}
          className="absolute top-0 block h-3 w-2 rounded-sm"
          style={{
            left: `${(i * 37) % 100}%`,
            background: colors[i % colors.length],
            animation: `confetti ${1.6 + (i % 5) * 0.35}s ${(i % 7) * 0.08}s ease-in forwards`,
          }}
        />
      ))}
    </div>
  );
}
