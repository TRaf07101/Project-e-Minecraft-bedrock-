import { useCallback, useEffect, useRef, useState, type ReactNode } from "react";
import { CheckCircle2, XCircle, Info, Star, Target, Clock, ChevronDown, Flame, Keyboard, Type, RotateCcw, Trophy, CircleCheck, Sparkles } from "lucide-react";
import { isGraded, isRetryable, type Session, type Step } from "../lib/sessions";
import { dayKey, effectiveStreak, recordGrammar, recordVocab, trackDay, updateSettings, useAppState } from "../lib/store";
import { dailyChallenges, weekDays, WEEKDAY_LETTER } from "../lib/engage";
import { sfx, stopSpeaking } from "../lib/audio";
import { AudioButton, Button, Confetti, Confirm, IconClose, JP, Modal, ProgressBar, Ring, RichText, Toggle } from "./ui";
import { DialogueView, GapView, GrammarCard, KanjiCard, MatchView, McqView, OrderView, TypeView, VocabCard, WriteView, type Feedback } from "./Exercises";
import { FlashView, SpeakView, SpellView, TrueFalseView } from "./ExercisesExtra";
import { cn } from "../utils/cn";

export interface Mistake {
  summary: string;
  answer?: string;
  answerJp?: boolean;
}
export interface SessionResult {
  correct: number;
  total: number;
  score: number;
  seconds: number;
  mistakes: Mistake[];
}

const RETRY = "~retry";

function FeedbackSheet({ fb, retry, onContinue }: { fb: Feedback; retry: boolean; onContinue: () => void }) {
  useEffect(() => {
    (document.activeElement as HTMLElement | null)?.blur?.();
  }, []);
  const tone = fb.correct === true ? "ok" : fb.correct === false ? "bad" : "info";
  const bg = { ok: "bg-ok-50", bad: "bg-bad-50", info: "bg-brand-50" }[tone];
  const text = { ok: "text-ok-dark", bad: "text-bad-dark", info: "text-brand-dark" }[tone];
  const [title] = useState(() =>
    fb.correct === true ? ["Muito bem!", "Correto!", "Excelente!", "Perfeito!", "Isso mesmo!"][Math.floor(Math.random() * 5)] : fb.correct === false ? "Não foi bem assim" : "Confira a resposta"
  );
  return (
    <div className={cn("anim-slide-up fixed inset-x-0 bottom-0 z-40 shadow-[0_-8px_24px_rgba(37,43,47,0.08)]", bg)} role="status" aria-live="polite">
      <div className="mx-auto max-w-2xl px-4 pt-4 pb-safe">
        <div className="flex items-start gap-3">
          <div className={cn("flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-white", text)}>
            {tone === "ok" ? <CheckCircle2 size={28} /> : tone === "bad" ? <XCircle size={28} /> : <Info size={28} />}
          </div>
          <div className="min-w-0 flex-1">
            <div className={cn("text-xl font-extrabold", text)}>{title}</div>
            {fb.answer && (fb.correct !== true || fb.answerJp) && (
              <div className="mt-1 flex items-start gap-3">
                <div className="min-w-0 flex-1">
                  {fb.correct !== true && <div className={cn("text-sm font-bold", text)}>{fb.correct === false ? "Resposta correta:" : "Exemplo:"}</div>}
                  {fb.answerJp ? <JP text={fb.answer} className="text-xl leading-[2] text-ink" /> : <div className="text-lg font-bold text-ink">{fb.answer}</div>}
                </div>
                {fb.audio && <AudioButton text={fb.audio} size="sm" autoPlay={fb.answerJp} />}
              </div>
            )}
            {fb.exp && <RichText text={fb.exp} className="mt-1 text-[0.95rem] text-ink/80" />}
            {fb.extra}
            {retry && (
              <div className="mt-2 inline-flex items-center gap-1.5 rounded-full bg-white/80 px-3 py-1 text-xs font-bold text-bad-dark">
                <RotateCcw size={13} /> Esta questão vai aparecer de novo no fim da atividade
              </div>
            )}
          </div>
        </div>
        <Button variant={tone === "bad" ? "bad" : tone === "ok" ? "ok" : "primary"} onClick={onContinue} className="mt-4 w-full sm:ml-auto sm:flex sm:w-auto sm:min-w-48">
          Continuar
        </Button>
      </div>
    </div>
  );
}

function ScriptMenu({ open, onClose }: { open: boolean; onClose: () => void }) {
  const st = useAppState((s) => s.settings);
  return (
    <Modal open={open} onClose={onClose}>
      <h3 className="text-xl font-extrabold">Exibição do japonês</h3>
      <p className="text-sm text-muted">Vale para todas as lições. Você pode mudar a qualquer momento.</p>
      <div className="mt-3 divide-y divide-line">
        <Toggle checked={st.furigana} onChange={(v) => updateSettings({ furigana: v })} label="Furigana" desc="Leitura em hiragana sobre os kanji" />
        <Toggle checked={st.romaji} onChange={(v) => updateSettings({ romaji: v })} label="Romaji" desc="Transcrição em letras latinas" />
        <Toggle checked={st.autoplay} onChange={(v) => updateSettings({ autoplay: v })} label="Áudio automático" />
        <Toggle checked={st.sfx} onChange={(v) => updateSettings({ sfx: v })} label="Efeitos sonoros" />
      </div>
      <Button className="mt-4 w-full" onClick={onClose}>
        Pronto
      </Button>
    </Modal>
  );
}

function ShortcutsModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const rows: [string, string][] = [
    ["1 – 9", "Escolher alternativa"],
    ["Enter", "Verificar / continuar"],
    ["← / →", "Verdadeiro ou falso · cartões"],
    ["Espaço", "Virar cartão"],
    ["Esc", "Fechar janelas"],
  ];
  return (
    <Modal open={open} onClose={onClose}>
      <h3 className="text-xl font-extrabold">Atalhos de teclado</h3>
      <div className="mt-4 space-y-2">
        {rows.map(([k, d]) => (
          <div key={k} className="flex items-center justify-between rounded-xl bg-canvas px-3 py-2">
            <span className="text-sm">{d}</span>
            <kbd className="rounded-lg border border-line bg-white px-2 py-1 text-xs font-bold shadow-sm">{k}</kbd>
          </div>
        ))}
      </div>
      <Button className="mt-4 w-full" onClick={onClose}>
        Entendi
      </Button>
    </Modal>
  );
}

export function Player({ session, onExit, onFinish }: { session: Session; onExit: () => void; onFinish: (r: SessionResult) => void }) {
  const [queue, setQueue] = useState<Step[]>(session.steps);
  const [idx, setIdx] = useState(0);
  const [fb, setFb] = useState<Feedback | null>(null);
  const [willRetry, setWillRetry] = useState(false);
  const [confirmExit, setConfirmExit] = useState(false);
  const [menu, setMenu] = useState<"script" | "keys" | null>(null);
  const results = useRef<{ correct: boolean; mistake?: Mistake }[]>([]);
  const start = useRef(Date.now());
  const step: Step = queue[idx];
  const isRetry = step.key.endsWith(RETRY);

  const finish = useCallback(() => {
    stopSpeaking();
    const total = results.current.length;
    const correct = results.current.filter((r) => r.correct).length;
    onFinish({
      correct,
      total,
      score: total ? correct / total : 1,
      seconds: Math.round((Date.now() - start.current) / 1000),
      mistakes: results.current.filter((r) => r.mistake).map((r) => r.mistake!),
    });
  }, [onFinish]);

  const queueRef = useRef(queue);
  queueRef.current = queue;
  const doneRef = useRef(false);
  const next = useCallback(() => {
    stopSpeaking();
    setFb(null);
    setWillRetry(false);
    if (idx + 1 >= queueRef.current.length) {
      if (!doneRef.current) {
        doneRef.current = true;
        finish();
      }
    } else setIdx((i) => i + 1);
    window.scrollTo({ top: 0 });
  }, [idx, finish]);

  const submit = (f: Feedback) => {
    if (f.correct === true) sfx("correct");
    else if (f.correct === false) sfx("wrong");
    if (f.correct !== null) {
      // aprendizado (SRS) registra todas as tentativas
      if (step.t === "mcq") {
        if (step.vocabId) recordVocab(step.vocabId, f.correct);
        if (step.grammarId) recordGrammar(step.grammarId, f.correct);
      } else if (step.t === "type" || step.t === "tf" || step.t === "spell" || step.t === "flash") recordVocab(step.v.id, f.correct);
      else if (step.t === "match") step.pairs.forEach((p) => p.vocabId && recordVocab(p.vocabId, f.correct!));
      else if (step.t === "gap" || step.t === "order") recordGrammar(step.grammarId, f.correct);
      trackDay({ correct: f.correct ? 1 : 0, reviewed: session.kind === "review" ? 1 : 0 });
      // pontuação conta só a primeira tentativa
      if (!isRetry) {
        results.current.push({
          correct: f.correct,
          mistake: f.correct ? undefined : { summary: f.summary ?? "", answer: f.answer, answerJp: f.answerJp },
        });
      }
      if (!f.correct && !isRetry && isRetryable(step)) {
        const copy = { ...step, key: step.key + RETRY } as Step;
        queueRef.current = [...queueRef.current, copy];
        setQueue(queueRef.current);
        setWillRetry(true);
      }
    }
    if (f.auto) {
      setTimeout(next, 120);
      return;
    }
    setFb(f);
  };

  useEffect(() => {
    if (!fb) return;
    const h = (e: KeyboardEvent) => {
      if (e.key === "Enter") {
        e.preventDefault();
        next();
      }
    };
    const t = setTimeout(() => window.addEventListener("keydown", h), 150);
    return () => {
      clearTimeout(t);
      window.removeEventListener("keydown", h);
    };
  }, [fb, next]);

  useEffect(() => () => stopSpeaking(), []);

  const progress = (idx + (fb ? 1 : 0)) / queue.length;
  const locked = !!fb;
  const props = { locked, onSubmit: submit, onNext: next };
  let view: ReactNode = null;
  switch (step.t) {
    case "vocabCard":
      view = <VocabCard v={step.v} onNext={next} />;
      break;
    case "kanjiCard":
      view = <KanjiCard k={step.k} onNext={next} />;
      break;
    case "grammarCard":
      view = <GrammarCard g={step.g} onNext={next} />;
      break;
    case "dialogue":
      view = <DialogueView d={step.d} onNext={next} />;
      break;
    case "mcq":
      view = <McqView step={step} {...props} />;
      break;
    case "match":
      view = <MatchView pairs={step.pairs} {...props} />;
      break;
    case "type":
      view = <TypeView v={step.v} {...props} />;
      break;
    case "gap":
      view = <GapView ex={step.ex} {...props} />;
      break;
    case "order":
      view = <OrderView ex={step.ex} {...props} />;
      break;
    case "write":
      view = <WriteView w={step.w} {...props} />;
      break;
    case "tf":
      view = <TrueFalseView v={step.v} claim={step.claim} truth={step.truth} {...props} />;
      break;
    case "spell":
      view = <SpellView v={step.v} tiles={step.tiles} {...props} />;
      break;
    case "speak":
      view = <SpeakView v={step.v} {...props} />;
      break;
    case "flash":
      view = <FlashView v={step.v} {...props} />;
      break;
  }
  const graded = queue.filter(isGraded).length;

  return (
    <div className="min-h-screen bg-white">
      <header className="sticky top-0 z-20 bg-white/95 backdrop-blur">
        <div className="mx-auto flex max-w-2xl items-center gap-2 px-3 pt-3 pb-1">
          <IconClose onClick={() => setConfirmExit(true)} />
          <ProgressBar value={progress} height={10} />
          <button onClick={() => setMenu("script")} aria-label="Exibição do japonês" title="Exibição do japonês" className="rounded-full p-2 text-muted transition hover:bg-canvas hover:text-ink">
            <Type size={22} />
          </button>
          <button onClick={() => setMenu("keys")} aria-label="Atalhos de teclado" title="Atalhos de teclado" className="hidden rounded-full p-2 text-muted transition hover:bg-canvas hover:text-ink sm:block">
            <Keyboard size={22} />
          </button>
        </div>
        <div className="mx-auto flex max-w-2xl items-center justify-between px-5 pb-2 text-xs font-bold text-muted">
          <span className="truncate">
            {session.title} · {session.subtitle}
          </span>
          {isRetry ? (
            <span className="inline-flex shrink-0 items-center gap-1 text-bad-dark">
              <RotateCcw size={12} /> Repetindo erro
            </span>
          ) : (
            graded > 0 && <span className="shrink-0">{results.current.length} respondidas</span>
          )}
        </div>
      </header>
      <main className="mx-auto max-w-2xl px-4 pt-4 pb-56" key={idx + step.key}>
        {view}
      </main>
      {fb && <FeedbackSheet fb={fb} retry={willRetry} onContinue={next} />}
      <ScriptMenu open={menu === "script"} onClose={() => setMenu(null)} />
      <ShortcutsModal open={menu === "keys"} onClose={() => setMenu(null)} />
      <Confirm
        open={confirmExit}
        title="Quer mesmo sair?"
        message="O progresso desta atividade não será salvo. Tudo o que você já concluiu antes continua salvo."
        confirmLabel="Sair da atividade"
        cancelLabel="Continuar estudando"
        danger
        onConfirm={() => {
          stopSpeaking();
          onExit();
        }}
        onCancel={() => setConfirmExit(false)}
      />
    </div>
  );
}

function StreakPanel() {
  const s = useAppState((x) => x);
  const streak = effectiveStreak(s);
  const today = dayKey();
  return (
    <div className="flex items-center gap-4 rounded-3xl border border-orange-100 bg-orange-50 p-4 text-left">
      <div className="anim-flame flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-b from-orange-400 to-orange-600 text-white">
        <Flame size={30} />
      </div>
      <div className="min-w-0 flex-1">
        <div className="text-lg font-extrabold">
          {streak} {streak === 1 ? "dia" : "dias"} de sequência!
        </div>
        <div className="mt-2 flex gap-1.5">
          {weekDays().map((d) => {
            const k = dayKey(d);
            const done = (s.days[k]?.activities ?? 0) > 0;
            return (
              <div key={k} className="flex flex-col items-center gap-0.5">
                <span className={cn("flex h-7 w-7 items-center justify-center rounded-full text-[0.65rem] font-extrabold", done ? "bg-orange-500 text-white" : "bg-white text-muted", k === today && "ring-2 ring-orange-300")}>
                  {done ? <Flame size={13} /> : WEEKDAY_LETTER[d.getDay()]}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function ChallengesPanel() {
  const s = useAppState((x) => x);
  const list = dailyChallenges(s);
  return (
    <div className="rounded-3xl border border-line p-4 text-left">
      <div className="mb-2 flex items-center gap-2 text-sm font-extrabold">
        <Trophy size={16} className="text-warn" /> Desafios diários
      </div>
      <div className="space-y-2.5">
        {list.map((c) => {
          const done = c.value >= c.goal;
          return (
            <div key={c.id} className="flex items-center gap-3">
              {done ? <CircleCheck size={20} className="shrink-0 text-ok" /> : <Sparkles size={20} className="shrink-0 text-brand-soft" />}
              <div className="min-w-0 flex-1">
                <div className="flex justify-between text-sm">
                  <span className={cn("font-semibold", done && "text-muted line-through")}>{c.label}</span>
                  <span className="text-xs font-bold text-muted">
                    {Math.min(c.value, c.goal)}/{c.goal}
                  </span>
                </div>
                <ProgressBar value={c.value / c.goal} height={6} color={done ? "var(--color-ok)" : undefined} className="mt-1" />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export function ResultsView({
  result,
  title,
  message,
  xp,
  passed,
  primary,
  secondary,
  tertiary,
}: {
  result: SessionResult;
  title: string;
  message: string;
  xp: number;
  passed?: boolean;
  primary: { label: string; onClick: () => void };
  secondary?: { label: string; onClick: () => void };
  tertiary?: { label: string; onClick: () => void };
}) {
  const [open, setOpen] = useState(false);
  const pct = Math.round(result.score * 100);
  const good = passed ?? result.score >= 0.7;
  useEffect(() => {
    sfx(good ? "complete" : "wrong");
  }, [good]);
  const color = good ? "var(--color-ok)" : "var(--color-warn)";
  const mins = Math.floor(result.seconds / 60);
  const secs = result.seconds % 60;
  return (
    <div className="min-h-screen bg-white">
      {good && <Confetti />}
      <main className="mx-auto flex max-w-xl flex-col items-center px-4 pt-10 pb-60 text-center">
        <div className="anim-pop">
          <Ring value={result.score} size={156} stroke={13} color={color}>
            <div>
              <div className="text-4xl font-extrabold">{pct}%</div>
              <div className="text-xs font-bold uppercase text-muted">acertos</div>
            </div>
          </Ring>
        </div>
        <h1 className="mt-5 text-3xl font-extrabold">{title}</h1>
        <p className="mt-2 max-w-md text-muted">{message}</p>
        <div className="mt-6 grid w-full grid-cols-3 gap-3">
          <div className="rounded-2xl bg-amber-50 p-3">
            <Star className="mx-auto fill-warn text-warn" size={22} />
            <div className="mt-1 text-xl font-extrabold">+{xp}</div>
            <div className="text-xs font-bold text-muted">estrelas</div>
          </div>
          <div className="rounded-2xl bg-ok-50 p-3">
            <Target className="mx-auto text-ok" size={22} />
            <div className="mt-1 text-xl font-extrabold">
              {result.correct}/{result.total}
            </div>
            <div className="text-xs font-bold text-muted">corretas</div>
          </div>
          <div className="rounded-2xl bg-brand-50 p-3">
            <Clock className="mx-auto text-brand" size={22} />
            <div className="mt-1 text-xl font-extrabold">
              {mins}:{String(secs).padStart(2, "0")}
            </div>
            <div className="text-xs font-bold text-muted">tempo</div>
          </div>
        </div>
        <div className="mt-4 w-full space-y-3">
          <StreakPanel />
          <ChallengesPanel />
        </div>
        {result.mistakes.length > 0 && (
          <div className="mt-4 w-full rounded-3xl border border-line text-left">
            <button onClick={() => setOpen((v) => !v)} className="flex w-full items-center justify-between p-4 font-extrabold">
              Revise seus erros ({result.mistakes.length})
              <ChevronDown className={cn("transition", open && "rotate-180")} size={20} />
            </button>
            {open && (
              <div className="divide-y divide-line border-t border-line">
                {result.mistakes.map((m, i) => (
                  <div key={i} className="p-4">
                    <div className="jp text-sm text-muted">{m.summary}</div>
                    {m.answer && (m.answerJp ? <JP text={m.answer} className="text-lg leading-[2]" /> : <div className="font-bold">{m.answer}</div>)}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </main>
      <div className="fixed inset-x-0 bottom-0 border-t border-line bg-white">
        <div className="mx-auto flex max-w-xl flex-col gap-2 px-4 pt-3 pb-safe">
          <Button onClick={primary.onClick} className="w-full">
            {primary.label}
          </Button>
          {secondary && (
            <Button onClick={secondary.onClick} variant="secondary" className="w-full">
              {secondary.label}
            </Button>
          )}
          {tertiary && (
            <Button onClick={tertiary.onClick} variant="ghost" className="w-full">
              {tertiary.label}
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}
