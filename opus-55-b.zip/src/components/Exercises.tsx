import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { Languages, Lightbulb, MessageSquare, Play, Square, Sparkles, Eye, EyeOff } from "lucide-react";
import type { Dialogue, GapEx, Grammar, Kanji, OrderEx, Vocab, Writing } from "../course";
import { checkTyped, hasJapanese, plain, reading, toRomaji } from "../course/kana";
import type { McqStep } from "../lib/sessions";
import { shuffle } from "../lib/sessions";
import { speak, stopSpeaking } from "../lib/audio";
import { useAppState } from "../lib/store";
import { AudioButton, Button, JP, RichText } from "./ui";
import { cn } from "../utils/cn";

export interface Feedback {
  correct: boolean | null; // null = not graded (skipped)
  answer?: string; // correct answer (may contain furigana)
  answerJp?: boolean;
  audio?: string;
  exp?: string;
  extra?: ReactNode;
  summary?: string; // short prompt summary for the mistakes list
  auto?: boolean; // advance immediately without the feedback panel (flashcards)
}

export interface StepProps {
  locked: boolean;
  onSubmit: (f: Feedback) => void;
  onNext: () => void;
}

export function ActionBar({ children }: { children: ReactNode }) {
  const ref = useRef<HTMLDivElement>(null);
  // Enter aciona a ação principal (Verificar / Continuar) — atalho de teclado da versão web
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if (e.key !== "Enter" || e.defaultPrevented || e.repeat) return;
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA") return;
      const b = ref.current?.querySelector("button:not(:disabled)") as HTMLButtonElement | null;
      if (b) {
        e.preventDefault();
        b.click();
      }
    };
    const t = setTimeout(() => window.addEventListener("keydown", h), 200);
    return () => {
      clearTimeout(t);
      window.removeEventListener("keydown", h);
    };
  }, []);
  return (
    <div className="fixed inset-x-0 bottom-0 z-30 border-t border-line bg-white/95 backdrop-blur">
      <div ref={ref} className="mx-auto flex max-w-2xl flex-col gap-2 px-4 pt-3 pb-safe sm:flex-row-reverse sm:items-center">
        {children}
        <span className="mr-auto hidden text-xs font-semibold text-muted sm:block">Enter ↵</span>
      </div>
    </div>
  );
}

function Instruction({ children }: { children: ReactNode }) {
  return <h2 className="mb-4 text-lg font-extrabold text-ink sm:text-xl">{children}</h2>;
}

function OptionButton({
  children,
  state,
  onClick,
  disabled,
  index,
}: {
  children: ReactNode;
  state: "idle" | "selected" | "correct" | "wrong" | "dim";
  onClick: () => void;
  disabled?: boolean;
  index?: number;
}) {
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={onClick}
      className={cn(
        "flex w-full items-center gap-3 rounded-2xl border-2 px-4 py-3.5 text-left text-[1.05rem] font-bold transition active:scale-[0.99]",
        state === "idle" && "border-line bg-white hover:border-brand-100 hover:bg-brand-50/50",
        state === "selected" && "border-brand bg-brand-50 text-brand-dark",
        state === "correct" && "border-ok bg-ok-50 text-ok-dark",
        state === "wrong" && "anim-shake border-bad bg-bad-50 text-bad-dark",
        state === "dim" && "border-line bg-white opacity-50"
      )}
    >
      {index !== undefined && (
        <span className={cn("hidden h-7 w-7 shrink-0 items-center justify-center rounded-lg border text-xs sm:flex", state === "selected" ? "border-brand text-brand" : "border-line text-muted")}>
          {index + 1}
        </span>
      )}
      <span className="flex-1">{children}</span>
    </button>
  );
}

/** keyboard 1-9 to pick options */
function useNumberKeys(n: number, enabled: boolean, pick: (i: number) => void) {
  useEffect(() => {
    if (!enabled) return;
    const h = (e: KeyboardEvent) => {
      if ((e.target as HTMLElement)?.tagName === "INPUT" || (e.target as HTMLElement)?.tagName === "TEXTAREA") return;
      const k = parseInt(e.key);
      if (k >= 1 && k <= n) pick(k - 1);
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [n, enabled, pick]);
}

// ───────────────────────────────────── Cards
export function VocabCard({ v, onNext }: { v: Vocab; onNext: () => void }) {
  const romaji = useAppState((s) => s.settings.romaji);
  const furi = useAppState((s) => s.settings.furigana);
  return (
    <>
      <div className="anim-fade-in">
        <span className="inline-flex items-center gap-1 rounded-full bg-brand-50 px-3 py-1 text-xs font-extrabold uppercase tracking-wider text-brand">
          <Sparkles size={14} /> Nova palavra
        </span>
        <div className="mt-6 flex flex-col items-center text-center">
          <JP text={v.jp} className="text-4xl font-bold leading-[1.9] sm:text-5xl" />
          {(!furi || romaji) && (
            <div className="mt-1 text-muted">
              {!furi && <span className="jp mr-2">{v.kana}</span>}
              {romaji && <span className="italic">{v.romaji}</span>}
            </div>
          )}
          <AudioButton text={v.kana} size="lg" autoPlay className="mt-5" />
          <div className="mt-5 text-2xl font-extrabold text-ink">{v.pt}</div>
        </div>
        <div className="mt-8 rounded-3xl border border-line bg-canvas/60 p-4">
          <div className="mb-2 text-xs font-extrabold uppercase tracking-wider text-muted">Exemplo</div>
          <div className="flex items-start gap-3">
            <AudioButton text={v.ex} size="sm" />
            <div>
              <JP text={v.ex} className="text-lg leading-[2]" />
              <div className="text-muted">{v.exPt}</div>
            </div>
          </div>
        </div>
      </div>
      <ActionBar>
        <Button onClick={onNext} className="w-full sm:w-auto sm:min-w-48">
          Continuar
        </Button>
      </ActionBar>
    </>
  );
}

export function KanjiCard({ k, onNext }: { k: Kanji; onNext: () => void }) {
  return (
    <>
      <div className="anim-fade-in">
        <span className="inline-flex items-center gap-1 rounded-full bg-violet-50 px-3 py-1 text-xs font-extrabold uppercase tracking-wider text-violet-600">
          漢字 · Novo kanji
        </span>
        <div className="mt-6 flex flex-col items-center">
          <div className="jp flex h-40 w-40 items-center justify-center rounded-[2rem] border-2 border-line bg-white text-[6.5rem] leading-none shadow-sm">{k.char}</div>
          <div className="mt-4 text-2xl font-extrabold">{k.pt}</div>
          <div className="mt-4 grid w-full max-w-sm grid-cols-2 gap-3 text-center">
            <div className="rounded-2xl bg-canvas p-3">
              <div className="text-xs font-extrabold uppercase text-muted">On'yomi</div>
              <div className="jp mt-1 text-lg">{k.on}</div>
            </div>
            <div className="rounded-2xl bg-canvas p-3">
              <div className="text-xs font-extrabold uppercase text-muted">Kun'yomi</div>
              <div className="jp mt-1 text-lg">{k.kun}</div>
            </div>
          </div>
        </div>
        <div className="mt-6 space-y-2">
          {k.words.map((w) => (
            <div key={w.jp} className="flex items-center gap-3 rounded-2xl border border-line bg-white p-3">
              <AudioButton text={reading(w.jp)} size="sm" />
              <JP text={w.jp} className="text-xl leading-[2]" furigana />
              <span className="ml-auto text-right text-muted">{w.pt}</span>
            </div>
          ))}
        </div>
      </div>
      <ActionBar>
        <Button onClick={onNext} className="w-full sm:w-auto sm:min-w-48">
          Continuar
        </Button>
      </ActionBar>
    </>
  );
}

export function GrammarCard({ g, onNext }: { g: Grammar; onNext: () => void }) {
  return (
    <>
      <div className="anim-fade-in">
        <span className="inline-flex items-center gap-1 rounded-full bg-amber-50 px-3 py-1 text-xs font-extrabold uppercase tracking-wider text-amber-700">
          <Lightbulb size={14} /> Dica de gramática
        </span>
        <h2 className="mt-4 text-2xl font-black leading-tight">
          <JP text={g.title} />
        </h2>
        <div className="mt-4 rounded-3xl border border-line bg-white p-5 text-[1.02rem]">
          <RichText text={g.explanation} />
        </div>
        <h3 className="mt-6 mb-2 text-sm font-extrabold uppercase tracking-wider text-muted">Exemplos</h3>
        <div className="space-y-2">
          {g.examples.map((x) => (
            <div key={x.jp} className="flex items-start gap-3 rounded-2xl bg-canvas/70 p-3">
              <AudioButton text={x.jp} size="sm" />
              <div>
                <JP text={x.jp} className="text-lg leading-[2]" />
                <div className="text-muted">{x.pt}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
      <ActionBar>
        <Button onClick={onNext} className="w-full sm:w-auto sm:min-w-48">
          Entendi, vamos praticar
        </Button>
      </ActionBar>
    </>
  );
}

const SPEAKER_COLORS = ["#116EEE", "#E85D9E", "#17A865", "#F5A524", "#7C5CFA", "#0FA3B1"];

export function DialogueView({ d, onNext }: { d: Dialogue; onNext: () => void }) {
  const [showPt, setShowPt] = useState(false);
  const [playing, setPlaying] = useState<number | null>(null);
  const [heard, setHeard] = useState(false);
  const stopRef = useRef(false);
  const speakers = useMemo(() => Array.from(new Set(d.lines.map((l) => l.speaker))), [d]);
  const rightSpeaker = speakers.includes("Ana") ? "Ana" : speakers[0];

  useEffect(
    () => () => {
      stopRef.current = true;
      stopSpeaking();
    },
    []
  );

  async function playAll() {
    if (playing !== null) {
      stopRef.current = true;
      stopSpeaking();
      setPlaying(null);
      return;
    }
    stopRef.current = false;
    for (let i = 0; i < d.lines.length; i++) {
      if (stopRef.current) break;
      setPlaying(i);
      await speak(d.lines[i].jp, { key: `dlg-${i}` });
      await new Promise((r) => setTimeout(r, 250));
    }
    setPlaying(null);
    setHeard(true);
  }

  return (
    <>
      <div className="anim-fade-in">
        <span className="inline-flex items-center gap-1 rounded-full bg-teal-50 px-3 py-1 text-xs font-extrabold uppercase tracking-wider text-teal-700">
          <MessageSquare size={14} /> Diálogo
        </span>
        <h2 className="mt-3 text-2xl font-black">{d.title}</h2>
        <p className="text-muted">Ouça o diálogo e leia com atenção. Toque em uma fala para ouvi-la.</p>
        <div className="mt-4 flex flex-wrap gap-2">
          <Button onClick={playAll} variant={playing !== null ? "secondary" : "primary"} className="min-h-10 py-2">
            {playing !== null ? <Square size={16} /> : <Play size={16} />} {playing !== null ? "Parar" : heard ? "Ouvir de novo" : "Ouvir diálogo"}
          </Button>
          <Button onClick={() => setShowPt((v) => !v)} variant="secondary" className="min-h-10 py-2">
            <Languages size={16} /> {showPt ? "Ocultar tradução" : "Mostrar tradução"}
          </Button>
        </div>
        <div className="mt-5 space-y-3">
          {d.lines.map((ln, i) => {
            const right = ln.speaker === rightSpeaker;
            const color = SPEAKER_COLORS[speakers.indexOf(ln.speaker) % SPEAKER_COLORS.length];
            return (
              <div key={i} className={cn("flex items-end gap-2", right && "flex-row-reverse")}>
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-sm font-black text-white" style={{ background: color }} title={ln.speaker}>
                  {ln.speaker.slice(0, 1)}
                </div>
                <button
                  type="button"
                  onClick={() => speak(ln.jp, { key: `dlg-${i}` })}
                  className={cn(
                    "max-w-[82%] rounded-3xl px-4 py-2.5 text-left transition",
                    right ? "rounded-br-md bg-brand text-white" : "rounded-bl-md border border-line bg-white",
                    playing === i && "ring-4 ring-warn/60"
                  )}
                >
                  <div className={cn("text-xs font-extrabold", right ? "text-white/80" : "text-muted")}>{ln.speaker}</div>
                  <JP text={ln.jp} className={cn("text-[1.08rem] leading-[2]", right && "[&_rt]:text-white/75")} />
                  {showPt && <div className={cn("mt-1 text-sm", right ? "text-white/85" : "text-muted")}>{ln.pt}</div>}
                </button>
              </div>
            );
          })}
        </div>
      </div>
      <ActionBar>
        <Button
          onClick={() => {
            stopRef.current = true;
            stopSpeaking();
            onNext();
          }}
          className="w-full sm:w-auto sm:min-w-48"
        >
          Responder perguntas
        </Button>
      </ActionBar>
    </>
  );
}

// ───────────────────────────────────── Multiple choice
export function McqView({ step, locked, onSubmit }: { step: McqStep } & StepProps) {
  const [sel, setSel] = useState<number | null>(null);
  useNumberKeys(step.options.length, !locked, setSel);
  const submit = () => {
    if (sel === null) return;
    onSubmit({
      correct: sel === step.answer,
      answer: step.options[step.answer],
      answerJp: step.optionsJp,
      audio: step.optionsJp ? step.options[step.answer] : step.audio,
      exp: step.exp,
      summary: step.promptJp ? plain(step.promptJp) : step.promptPt ?? step.instruction,
    });
  };
  return (
    <>
      <div className="anim-fade-in">
        <Instruction>{step.instruction}</Instruction>
        <div className="mb-6 flex flex-col items-center gap-3 rounded-3xl border border-line bg-white px-4 py-6 text-center">
          {step.listening && step.audio && (
            <div className="flex items-center gap-4">
              <AudioButton text={step.audio} size="xl" autoPlay />
              <AudioButton text={step.audio} size="md" rate={0.6} label="Ouvir devagar" className="bg-brand-50 text-brand shadow-none hover:bg-brand-100" />
            </div>
          )}
          {!step.listening && step.promptJp && (
            <div className="flex items-center gap-3">
              <JP text={step.promptJp} className="text-3xl font-bold leading-[1.9] sm:text-4xl" />
              {step.audio && <AudioButton text={step.audio} size="md" autoPlay />}
            </div>
          )}
          {!step.listening && step.promptPt && <div className="text-2xl font-extrabold">{step.promptPt}</div>}
          {step.context && <div className="text-sm font-semibold text-muted">{step.context}</div>}
          {step.listening && <div className="text-sm text-muted">Toque no caracol para ouvir mais devagar</div>}
        </div>
        <div className="grid gap-2.5">
          {step.options.map((op, i) => {
            const state = locked ? (i === step.answer ? "correct" : i === sel ? "wrong" : "dim") : sel === i ? "selected" : "idle";
            return (
              <OptionButton key={i} index={i} state={state} disabled={locked} onClick={() => setSel(i)}>
                {step.optionsJp ? <JP text={op} className="text-xl leading-[2]" /> : op}
              </OptionButton>
            );
          })}
        </div>
      </div>
      {!locked && (
        <ActionBar>
          <Button onClick={submit} disabled={sel === null} className="w-full sm:w-auto sm:min-w-48">
            Verificar
          </Button>
        </ActionBar>
      )}
    </>
  );
}

// ───────────────────────────────────── Match pairs
export function MatchView({ pairs, locked, onSubmit }: { pairs: { id: string; left: string; right: string }[] } & StepProps) {
  const left = useMemo(() => shuffle(pairs), [pairs]);
  const right = useMemo(() => shuffle(pairs), [pairs]);
  const [selL, setSelL] = useState<string | null>(null);
  const [selR, setSelR] = useState<string | null>(null);
  const [matched, setMatched] = useState<Set<string>>(new Set());
  const [wrong, setWrong] = useState<[string, string] | null>(null);
  const [mistakes, setMistakes] = useState(0);
  const [missed, setMissed] = useState<Set<string>>(new Set());

  useEffect(() => {
    if (!selL || !selR) return;
    if (selL === selR) {
      const m = new Set(matched);
      m.add(selL);
      setMatched(m);
      setSelL(null);
      setSelR(null);
      if (m.size === pairs.length) {
        setTimeout(
          () =>
            onSubmit({
              correct: mistakes === 0,
              answer: mistakes === 0 ? undefined : `Você errou ${mistakes} ${mistakes === 1 ? "par" : "pares"}. Revise: ${pairs
                .filter((p) => missed.has(p.id))
                .map((p) => `${plain(p.left)} = ${p.right}`)
                .join(" · ")}`,
              summary: "Relacione os pares",
            }),
          350
        );
      }
    } else {
      setWrong([selL, selR]);
      setMistakes((n) => n + 1);
      setMissed((s) => new Set(s).add(selL));
      const t = setTimeout(() => {
        setWrong(null);
        setSelL(null);
        setSelR(null);
      }, 550);
      return () => clearTimeout(t);
    }
  }, [selL, selR]); // eslint-disable-line react-hooks/exhaustive-deps

  const cls = (side: "l" | "r", id: string) => {
    if (matched.has(id)) return "border-ok bg-ok-50 text-ok-dark opacity-70";
    if (wrong && ((side === "l" && wrong[0] === id) || (side === "r" && wrong[1] === id))) return "anim-shake border-bad bg-bad-50 text-bad-dark";
    if ((side === "l" ? selL : selR) === id) return "border-brand bg-brand-50 text-brand-dark";
    return "border-line bg-white hover:border-brand-100";
  };

  return (
    <div className="anim-fade-in">
      <Instruction>Relacione os pares</Instruction>
      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-2.5">
          {left.map((p) => (
            <button
              key={p.id}
              type="button"
              disabled={locked || matched.has(p.id) || !!wrong}
              onClick={() => {
                setSelL(p.id);
                speak(p.left);
              }}
              className={cn("flex min-h-16 w-full items-center justify-center rounded-2xl border-2 px-2 py-2 text-center font-bold transition", cls("l", p.id))}
            >
              <JP text={p.left} className="text-lg leading-[1.9]" />
            </button>
          ))}
        </div>
        <div className="space-y-2.5">
          {right.map((p) => (
            <button
              key={p.id}
              type="button"
              disabled={locked || matched.has(p.id) || !!wrong}
              onClick={() => setSelR(p.id)}
              className={cn("flex min-h-16 w-full items-center justify-center rounded-2xl border-2 px-2 py-2 text-center text-[0.95rem] font-bold transition", cls("r", p.id))}
            >
              {p.right}
            </button>
          ))}
        </div>
      </div>
      <p className="mt-4 text-center text-sm text-muted">
        {matched.size}/{pairs.length} pares · {mistakes} {mistakes === 1 ? "erro" : "erros"}
      </p>
    </div>
  );
}

// ───────────────────────────────────── Typing
export function TypeView({ v, locked, onSubmit }: { v: Vocab } & StepProps) {
  const [val, setVal] = useState("");
  const [hint, setHint] = useState(0);
  const ref = useRef<HTMLInputElement>(null);
  useEffect(() => {
    const t = setTimeout(() => ref.current?.focus(), 100);
    return () => clearTimeout(t);
  }, []);
  const submit = () => {
    if (!val.trim()) return;
    onSubmit({
      correct: checkTyped(val, v.jp, v.kana),
      answer: v.jp,
      answerJp: true,
      audio: v.kana,
      exp: `Leitura: ${v.kana} (${v.romaji}). Você pode digitar em kana, kanji ou romaji.`,
      summary: v.pt,
    });
  };
  return (
    <>
      <form
        className="anim-fade-in"
        onSubmit={(e) => {
          e.preventDefault();
          if (!locked) submit();
        }}
      >
        <Instruction>Escreva em japonês</Instruction>
        <div className="mb-5 rounded-3xl border border-line bg-white p-6 text-center">
          <div className="text-2xl font-extrabold">{v.pt}</div>
          <div className="mt-2 text-sm text-muted">Digite em hiragana, katakana, kanji ou romaji</div>
        </div>
        <input
          ref={ref}
          value={val}
          disabled={locked}
          onChange={(e) => setVal(e.target.value)}
          lang="ja"
          autoCapitalize="off"
          autoComplete="off"
          autoCorrect="off"
          spellCheck={false}
          placeholder="Sua resposta…"
          className="jp w-full rounded-2xl border-2 border-line bg-white px-4 py-4 text-xl outline-none transition focus:border-brand"
        />
        <div className="mt-3 flex items-center justify-between">
          <button type="button" disabled={locked || hint >= v.kana.length} onClick={() => setHint((h) => h + 1)} className="inline-flex items-center gap-1 text-sm font-bold text-brand disabled:text-muted">
            <Lightbulb size={16} /> Dica
          </button>
          {hint > 0 && (
            <span className="jp text-muted">
              {v.kana.slice(0, hint)}
              {"・".repeat(Math.max(0, v.kana.length - hint))}
            </span>
          )}
        </div>
      </form>
      {!locked && (
        <ActionBar>
          <Button onClick={submit} disabled={!val.trim()} className="w-full sm:w-auto sm:min-w-48">
            Verificar
          </Button>
        </ActionBar>
      )}
    </>
  );
}

// ───────────────────────────────────── Gap fill
export function GapView({ ex, locked, onSubmit }: { ex: GapEx } & StepProps) {
  const [sel, setSel] = useState<number | null>(null);
  useNumberKeys(ex.options.length, !locked, setSel);
  const parts = ex.jp.split("＿＿");
  const full = parts.join(plain(ex.options[ex.answer]));
  const submit = () => {
    if (sel === null) return;
    onSubmit({
      correct: sel === ex.answer,
      answer: parts.join(ex.options[ex.answer]),
      answerJp: true,
      audio: full,
      exp: ex.exp,
      summary: plain(ex.jp),
    });
  };
  return (
    <>
      <div className="anim-fade-in">
        <Instruction>Complete a frase</Instruction>
        <div className="mb-6 rounded-3xl border border-line bg-white p-5">
          <div className="text-xl leading-[2.3] sm:text-2xl">
            {parts.map((p, i) => (
              <span key={i}>
                <JP text={p} />
                {i < parts.length - 1 && (
                  <span
                    className={cn(
                      "mx-1 inline-block min-w-16 rounded-lg border-b-4 px-2 text-center align-baseline",
                      sel === null ? "border-brand-100 bg-brand-50/60 text-transparent" : locked ? (sel === ex.answer ? "border-ok bg-ok-50" : "border-bad bg-bad-50") : "border-brand bg-brand-50"
                    )}
                  >
                    {sel === null ? "＿＿" : <JP text={ex.options[sel]} />}
                  </span>
                )}
              </span>
            ))}
          </div>
          <div className="mt-3 border-t border-line pt-3 text-muted">{ex.pt}</div>
        </div>
        <div className="flex flex-wrap justify-center gap-2.5">
          {ex.options.map((op, i) => (
            <button
              key={i}
              type="button"
              disabled={locked}
              onClick={() => setSel(i)}
              className={cn(
                "rounded-2xl border-2 border-b-4 px-4 py-2.5 text-xl font-bold transition active:translate-y-0.5",
                locked
                  ? i === ex.answer
                    ? "border-ok bg-ok-50 text-ok-dark"
                    : i === sel
                      ? "anim-shake border-bad bg-bad-50 text-bad-dark"
                      : "border-line opacity-50"
                  : sel === i
                    ? "border-brand bg-brand-50 text-brand-dark"
                    : "border-line bg-white hover:border-brand-100"
              )}
            >
              <JP text={op} className="leading-[2]" />
            </button>
          ))}
        </div>
      </div>
      {!locked && (
        <ActionBar>
          <Button onClick={submit} disabled={sel === null} className="w-full sm:w-auto sm:min-w-48">
            Verificar
          </Button>
        </ActionBar>
      )}
    </>
  );
}

// ───────────────────────────────────── Word order
export function OrderView({ ex, locked, onSubmit }: { ex: OrderEx } & StepProps) {
  const bankInit = useMemo(() => {
    let s = shuffle(ex.tiles.map((t, i) => ({ t, i })));
    // avoid presenting the solution already in order
    if (s.every((x, k) => x.i === k)) s = [...s.slice(1), s[0]];
    return s;
  }, [ex]);
  const [placed, setPlaced] = useState<{ t: string; i: number }[]>([]);
  const bank = bankInit.filter((b) => !placed.some((p) => p.i === b.i));
  const sentence = ex.tiles.join("");
  const submit = () => {
    const ans = placed.map((p) => p.t).join("");
    const ok = ans === sentence || ex.alts.some((a) => a.join("") === ans);
    onSubmit({ correct: ok, answer: sentence + "。", answerJp: true, audio: sentence, summary: ex.pt });
  };
  return (
    <>
      <div className="anim-fade-in">
        <Instruction>Coloque as palavras na ordem certa</Instruction>
        <div className="mb-4 rounded-3xl border border-line bg-white p-4 text-lg font-bold">{ex.pt}</div>
        <div
          className={cn(
            "mb-6 flex min-h-24 flex-wrap content-start gap-2 rounded-3xl border-2 border-dashed p-3",
            locked ? "border-transparent bg-canvas" : "border-brand-100 bg-brand-50/40"
          )}
        >
          {placed.length === 0 && <span className="m-auto text-sm text-muted">Toque nas palavras abaixo</span>}
          {placed.map((p) => (
            <button
              key={p.i}
              type="button"
              disabled={locked}
              onClick={() => setPlaced((x) => x.filter((y) => y.i !== p.i))}
              className="anim-pop rounded-xl border-2 border-b-4 border-line bg-white px-3 py-1.5 text-lg font-bold"
            >
              <JP text={p.t} className="leading-[2]" />
            </button>
          ))}
        </div>
        <div className="flex flex-wrap justify-center gap-2">
          {bank.map((b) => (
            <button
              key={b.i}
              type="button"
              disabled={locked}
              onClick={() => setPlaced((x) => [...x, b])}
              className="rounded-xl border-2 border-b-4 border-line bg-white px-3 py-1.5 text-lg font-bold transition hover:border-brand-100 active:translate-y-0.5"
            >
              <JP text={b.t} className="leading-[2]" />
            </button>
          ))}
        </div>
      </div>
      {!locked && (
        <ActionBar>
          <Button onClick={submit} disabled={bank.length > 0} className="w-full sm:w-auto sm:min-w-48">
            Verificar
          </Button>
        </ActionBar>
      )}
    </>
  );
}

// ───────────────────────────────────── Writing
export function WriteView({ w, locked, onSubmit }: { w: Writing } & StepProps) {
  const [val, setVal] = useState("");
  const [showModel, setShowModel] = useState(false);
  const norm = (s: string) => s.replace(/[\s　]/g, "");
  const results = w.checks.map((c) => ({ label: c.label, ok: c.any.some((a) => norm(val).includes(a)) }));
  const isJp = hasJapanese(val);
  const submit = (skip = false) => {
    const ok = isJp && results.every((r) => r.ok);
    onSubmit({
      correct: skip ? null : ok,
      answer: w.model,
      answerJp: true,
      audio: w.model,
      summary: w.prompt,
      exp: skip
        ? "Atividade pulada — compare com a resposta modelo."
        : ok
          ? "Sua frase contém todos os elementos pedidos. Compare com o modelo para ver outra forma natural de dizer."
          : !isJp
            ? "Escreva usando caracteres japoneses (hiragana, katakana ou kanji). Ative um teclado japonês no seu dispositivo."
            : `Faltou: ${results
                .filter((r) => !r.ok)
                .map((r) => r.label)
                .join(", ")}.`,
      extra: !skip && val.trim() ? (
        <div className="mt-2 rounded-xl bg-white/70 p-2 text-sm">
          <div className="font-bold text-muted">Sua resposta:</div>
          <div className="jp text-base">{val}</div>
        </div>
      ) : undefined,
    });
  };
  return (
    <>
      <div className="anim-fade-in">
        <span className="inline-flex items-center gap-1 rounded-full bg-rose-50 px-3 py-1 text-xs font-extrabold uppercase tracking-wider text-rose-600">✍️ Escrita</span>
        <h2 className="mt-3 text-xl font-extrabold">{w.prompt}</h2>
        <div className="mt-3 flex flex-wrap gap-2">
          {results.map((r) => (
            <span key={r.label} className={cn("rounded-full border px-3 py-1 text-sm font-bold", r.ok ? "border-ok bg-ok-50 text-ok-dark" : "border-line bg-white text-muted")}>
              {r.ok ? "✓ " : ""}Use: <span className="jp">{r.label}</span>
            </span>
          ))}
        </div>
        <textarea
          value={val}
          disabled={locked}
          onChange={(e) => setVal(e.target.value)}
          lang="ja"
          rows={4}
          placeholder="Escreva sua frase em japonês…"
          className="jp mt-4 w-full resize-none rounded-2xl border-2 border-line bg-white p-4 text-lg outline-none focus:border-brand"
        />
        {!locked && (
          <button type="button" onClick={() => setShowModel((v) => !v)} className="mt-2 inline-flex items-center gap-1 text-sm font-bold text-brand">
            {showModel ? <EyeOff size={16} /> : <Eye size={16} />} {showModel ? "Ocultar exemplo" : "Ver um exemplo de resposta"}
          </button>
        )}
        {showModel && !locked && (
          <div className="mt-2 rounded-2xl bg-canvas p-3">
            <JP text={w.model} className="text-lg leading-[2]" />
          </div>
        )}
      </div>
      {!locked && (
        <ActionBar>
          <Button onClick={() => submit(false)} disabled={!val.trim()} className="w-full sm:w-auto sm:min-w-48">
            Verificar
          </Button>
          <Button onClick={() => submit(true)} variant="ghost" className="w-full sm:w-auto">
            Não consigo digitar em japonês
          </Button>
        </ActionBar>
      )}
    </>
  );
}

export { toRomaji };
