import { CalendarPlus, Check, Clock, Target, TrendingUp } from "lucide-react";
import { LEVEL_INFO } from "../course";
import { dayKey, updatePlan, updateSettings, useAppState } from "../lib/store";
import { planStats, WEEKDAY_SHORT } from "../lib/engage";
import { levelProgress } from "../lib/progress";
import { Button, Card, ProgressBar, Ring } from "../components/ui";
import { cn } from "../utils/cn";

const MINUTES = [5, 10, 15, 20, 30, 45];
const ICS_DAYS = ["SU", "MO", "TU", "WE", "TH", "FR", "SA"];
const GOALS = [
  { xp: 20, label: "Casual" },
  { xp: 30, label: "Regular" },
  { xp: 50, label: "Sério" },
  { xp: 80, label: "Intenso" },
];

function downloadIcs(days: number[], time: string, minutes: number) {
  const [hh, mm] = time.split(":").map((x) => parseInt(x, 10));
  const start = new Date();
  start.setHours(hh, mm, 0, 0);
  const pad = (n: number) => String(n).padStart(2, "0");
  const local = (d: Date) => `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}T${pad(d.getHours())}${pad(d.getMinutes())}00`;
  const utc = new Date().toISOString().replace(/[-:]/g, "").split(".")[0] + "Z";
  const ics = [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "PRODID:-//Kotoba//Plano de estudos//PT",
    "BEGIN:VEVENT",
    `UID:kotoba-plano-${Date.now()}@kotoba`,
    `DTSTAMP:${utc}`,
    `DTSTART:${local(start)}`,
    `DURATION:PT${minutes}M`,
    `RRULE:FREQ=WEEKLY;BYDAY=${[...days].sort().map((d) => ICS_DAYS[d]).join(",")}`,
    "SUMMARY:Estudar japonês — Kotoba",
    `DESCRIPTION:Sessão de ${minutes} minutos do curso de japonês A2–B1.`,
    "BEGIN:VALARM",
    "TRIGGER:-PT5M",
    "ACTION:DISPLAY",
    "DESCRIPTION:Hora de estudar japonês!",
    "END:VALARM",
    "END:VEVENT",
    "END:VCALENDAR",
  ].join("\r\n");
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([ics], { type: "text/calendar" }));
  a.download = "plano-de-estudos-japones.ics";
  a.click();
  URL.revokeObjectURL(a.href);
}

export function Plan() {
  const s = useAppState((x) => x);
  const p = planStats(s);
  const toggleDay = (d: number) => {
    const has = s.plan.days.includes(d);
    if (has && s.plan.days.length === 1) return; // pelo menos um dia
    updatePlan({ days: has ? s.plan.days.filter((x) => x !== d) : [...s.plan.days, d].sort() });
  };
  const order = [1, 2, 3, 4, 5, 6, 0];

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-3xl font-extrabold tracking-tight">Plano de estudos</h1>
        <p className="text-muted">Meta: concluir o nível B1 — {LEVEL_INFO.B1.name}</p>
      </div>

      <Card className="p-5">
        <div className="flex flex-wrap items-center gap-5">
          <Ring value={p.fluency} size={110} stroke={11}>
            <div className="text-center">
              <div className="text-2xl font-extrabold">{Math.round(p.fluency * 100)}%</div>
              <div className="text-[0.65rem] font-bold uppercase text-muted">fluência</div>
            </div>
          </Ring>
          <div className="min-w-0 flex-1 space-y-2">
            <div>
              <div className="flex justify-between text-sm font-bold">
                <span>A2 · {LEVEL_INFO.A2.name}</span>
                <span>{Math.round(levelProgress(s, "A2") * 100)}%</span>
              </div>
              <ProgressBar value={levelProgress(s, "A2")} height={6} className="mt-1" />
            </div>
            <div>
              <div className="flex justify-between text-sm font-bold">
                <span>B1 · {LEVEL_INFO.B1.name}</span>
                <span>{Math.round(levelProgress(s, "B1") * 100)}%</span>
              </div>
              <ProgressBar value={levelProgress(s, "B1")} height={6} className="mt-1" />
            </div>
            <div className="flex items-center gap-2 rounded-2xl bg-brand-50 px-3 py-2 text-sm text-brand-dark">
              <TrendingUp size={16} />
              {p.remainingMinutes === 0 ? (
                <span className="font-bold">Curso concluído!</span>
              ) : (
                <span>
                  Previsão de conclusão: <strong>{p.eta.toLocaleDateString("pt-BR", { day: "2-digit", month: "long", year: "numeric" })}</strong> (~{Math.round(p.remainingMinutes / 60)} h restantes)
                </span>
              )}
            </div>
          </div>
        </div>
      </Card>

      <Card className="p-5">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-extrabold">Esta semana</h2>
          <span className="text-sm font-bold text-muted">
            {p.weekMinutes}/{p.weekGoal} min
          </span>
        </div>
        <ProgressBar value={p.weekGoal ? p.weekMinutes / p.weekGoal : 0} className="mt-2" color={p.weekMinutes >= p.weekGoal ? "var(--color-ok)" : undefined} />
        <div className="mt-4 grid grid-cols-7 gap-1.5">
          {p.days.map((d) => {
            const k = dayKey(d);
            const mins = s.days[k]?.minutes ?? 0;
            const planned = s.plan.days.includes(d.getDay());
            const met = planned ? mins >= s.plan.minutes : mins > 0;
            const today = k === dayKey();
            return (
              <div key={k} className={cn("flex flex-col items-center gap-1 rounded-2xl py-2", today && "bg-brand-50")}>
                <span className="text-xs font-bold text-muted">{WEEKDAY_SHORT[d.getDay()]}</span>
                <span className={cn("flex h-9 w-9 items-center justify-center rounded-full text-xs font-extrabold", met ? "bg-ok text-white" : planned ? "border-2 border-brand-100 text-brand" : "bg-canvas text-muted")}>
                  {met ? <Check size={15} strokeWidth={3} /> : d.getDate()}
                </span>
                <span className="text-[0.65rem] font-bold text-muted">{mins} min</span>
              </div>
            );
          })}
        </div>
      </Card>

      <Card className="p-5">
        <h2 className="text-lg font-extrabold">Editar plano</h2>
        <div className="mt-4">
          <div className="mb-2 flex items-center gap-2 text-sm font-bold">
            <Target size={16} className="text-brand" /> Dias de estudo
          </div>
          <div className="grid grid-cols-7 gap-1.5">
            {order.map((d) => {
              const on = s.plan.days.includes(d);
              return (
                <button
                  key={d}
                  onClick={() => toggleDay(d)}
                  aria-pressed={on}
                  className={cn("rounded-2xl border-2 py-2.5 text-sm font-extrabold transition", on ? "border-brand bg-brand text-white" : "border-line bg-white text-muted hover:border-brand-100")}
                >
                  {WEEKDAY_SHORT[d]}
                </button>
              );
            })}
          </div>
        </div>
        <div className="mt-5">
          <div className="mb-2 flex items-center gap-2 text-sm font-bold">
            <Clock size={16} className="text-brand" /> Minutos por dia
          </div>
          <div className="grid grid-cols-3 gap-2 sm:grid-cols-6">
            {MINUTES.map((m) => (
              <button
                key={m}
                onClick={() => updatePlan({ minutes: m })}
                className={cn("rounded-2xl border-2 py-2.5 font-extrabold transition", s.plan.minutes === m ? "border-brand bg-brand-50 text-brand" : "border-line bg-white hover:border-brand-100")}
              >
                {m} min
              </button>
            ))}
          </div>
        </div>
        <div className="mt-5 flex flex-wrap items-end gap-3">
          <label className="flex-1">
            <span className="mb-2 block text-sm font-bold">Horário preferido</span>
            <input
              type="time"
              value={s.plan.time}
              onChange={(e) => e.target.value && updatePlan({ time: e.target.value })}
              className="w-full rounded-2xl border-2 border-line bg-white px-4 py-2.5 font-bold outline-none focus:border-brand"
            />
          </label>
          <Button variant="secondary" onClick={() => downloadIcs(s.plan.days, s.plan.time, s.plan.minutes)}>
            <CalendarPlus size={18} /> Adicionar ao calendário
          </Button>
        </div>
        <p className="mt-2 text-xs text-muted">O arquivo .ics cria um evento semanal com lembrete 5 minutos antes, compatível com Google Agenda, Apple Calendário e Outlook.</p>
        <div className="mt-5">
          <div className="mb-2 text-sm font-bold">Meta diária de estrelas</div>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            {GOALS.map((g) => (
              <button
                key={g.xp}
                onClick={() => updateSettings({ dailyGoal: g.xp })}
                className={cn("rounded-2xl border-2 p-2.5 text-left transition", s.settings.dailyGoal === g.xp ? "border-brand bg-brand-50" : "border-line hover:border-brand-100")}
              >
                <div className="font-extrabold">{g.label}</div>
                <div className="text-xs text-muted">{g.xp} estrelas/dia</div>
              </button>
            ))}
          </div>
        </div>
      </Card>
    </div>
  );
}
