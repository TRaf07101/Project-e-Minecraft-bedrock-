import { useState } from "react";
import { ArrowLeft, Award, BookOpen, CheckCircle2, Flame, Lock, Pencil, Printer, Star, Languages, Settings as Gear, CalendarCheck } from "lucide-react";
import { LEVEL_INFO, LEVELS, ALL_KANJI, unitsOf, type Level } from "../course";
import { navigate } from "../lib/router";
import { dayKey, effectiveStreak, setState, useAppState } from "../lib/store";
import { isActivityDone, isCheckpointPassed, isLevelComplete, lessonsCompleted, levelProgress, wordsLearned } from "../lib/progress";
import { Button, Card, Logo, ProgressBar } from "../components/ui";
import { cn } from "../utils/cn";

const WEEKDAYS = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];

export function Profile() {
  const s = useAppState((x) => x);
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState(s.name);
  const streak = effectiveStreak(s);
  const kanjiLearned = ALL_KANJI.filter((k) => isActivityDone(s, k.lessonId, "kanji")).length;
  const days = Array.from({ length: 7 }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - (6 - i));
    const k = dayKey(d);
    return { label: WEEKDAYS[d.getDay()], xp: s.days[k]?.xp ?? 0, min: s.days[k]?.minutes ?? 0, today: i === 6 };
  });
  const max = Math.max(s.settings.dailyGoal, ...days.map((d) => d.xp));
  const weekXp = days.reduce((n, d) => n + d.xp, 0);
  const weekMin = days.reduce((n, d) => n + d.min, 0);
  const initials = (s.name || "?").trim().slice(0, 1).toUpperCase();

  const stats = [
    { icon: Flame, color: "text-orange-500 bg-orange-50", value: streak, label: `dias seguidos (recorde ${s.streak.best})` },
    { icon: Star, color: "text-amber-500 bg-amber-50", value: s.xp, label: "estrelas no total" },
    { icon: BookOpen, color: "text-brand bg-brand-50", value: wordsLearned(s), label: "palavras aprendidas" },
    { icon: CheckCircle2, color: "text-ok bg-ok-50", value: lessonsCompleted(s), label: "lições concluídas" },
    { icon: Languages, color: "text-violet-600 bg-violet-50", value: kanjiLearned, label: "kanji estudados" },
    { icon: Award, color: "text-rose-500 bg-rose-50", value: Object.keys(s.checkpoints).filter((k) => s.checkpoints[k].passed).length, label: "checkpoints aprovados" },
  ];

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-black tracking-tight">Perfil</h1>
        <button onClick={() => navigate("/settings")} className="rounded-full bg-white p-2.5 shadow-sm ring-1 ring-line md:hidden" aria-label="Ajustes">
          <Gear size={20} />
        </button>
      </div>
      <Card className="flex items-center gap-4">
        <div className="flex h-20 w-20 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-brand to-indigo-500 text-3xl font-black text-white">{initials}</div>
        <div className="min-w-0 flex-1">
          {editing ? (
            <form
              className="flex gap-2"
              onSubmit={(e) => {
                e.preventDefault();
                if (!name.trim()) return;
                setState((x) => ({ ...x, name: name.trim() }));
                setEditing(false);
              }}
            >
              <input autoFocus value={name} onChange={(e) => setName(e.target.value)} maxLength={30} className="min-w-0 flex-1 rounded-xl border-2 border-line px-3 py-2 font-bold outline-none focus:border-brand" />
              <Button type="submit" className="min-h-10 px-4 py-2">
                Salvar
              </Button>
            </form>
          ) : (
            <div className="flex items-center gap-2">
              <div className="truncate text-2xl font-black">{s.name || "Estudante"}</div>
              <button onClick={() => setEditing(true)} className="rounded-full p-1.5 text-muted hover:bg-canvas" aria-label="Editar nome">
                <Pencil size={16} />
              </button>
            </div>
          )}
          <div className="text-muted">Estudando japonês desde {new Date(s.createdAt).toLocaleDateString("pt-BR", { month: "long", year: "numeric" })}</div>
          <div className="mt-1 inline-flex rounded-full bg-brand-50 px-3 py-0.5 text-sm font-black text-brand">
            Nível atual: {isLevelComplete(s, "A2") || s.testedOut.A2 ? "B1" : "A2"}
          </div>
        </div>
      </Card>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
        {stats.map((st) => (
          <Card key={st.label} className="p-4">
            <div className={cn("inline-flex rounded-xl p-2", st.color)}>
              <st.icon size={20} />
            </div>
            <div className="mt-2 text-2xl font-black">{st.value}</div>
            <div className="text-sm text-muted">{st.label}</div>
          </Card>
        ))}
      </div>

      <Card>
        <div className="flex items-end justify-between">
          <div>
            <div className="text-xs font-extrabold uppercase tracking-wider text-muted">Últimos 7 dias</div>
            <div className="text-xl font-extrabold">{weekXp} estrelas</div>
          </div>
          <div className="text-sm text-muted">{weekMin} min estudados</div>
        </div>
        <div className="relative mt-4 flex h-36 items-end gap-2">
          <div className="absolute inset-x-0 border-t-2 border-dashed border-ok/50" style={{ bottom: `${(s.settings.dailyGoal / max) * 100}%` }} title="Meta diária" />
          {days.map((d) => (
            <div key={d.label + d.today} className="flex flex-1 flex-col items-center justify-end gap-1" style={{ height: "100%" }}>
              <div className="text-[0.7rem] font-bold text-muted">{d.xp || ""}</div>
              <div
                className={cn("w-full max-w-10 rounded-t-lg transition-all", d.xp >= s.settings.dailyGoal ? "bg-ok" : d.xp > 0 ? "bg-brand" : "bg-line")}
                style={{ height: `${Math.max(4, (d.xp / max) * 100)}%` }}
              />
              <div className={cn("text-xs font-bold", d.today ? "text-brand" : "text-muted")}>{d.label}</div>
            </div>
          ))}
        </div>
        <div className="mt-2 text-xs text-muted">Linha tracejada: meta diária de {s.settings.dailyGoal} estrelas</div>
      </Card>

      <Card onClick={() => navigate("/plan")} className="flex items-center gap-4">
        <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-brand-50 text-brand">
          <CalendarCheck size={24} />
        </div>
        <div className="min-w-0 flex-1">
          <div className="font-extrabold">Plano de estudos</div>
          <div className="text-sm text-muted">
            {s.plan.days.length} dias por semana · {s.plan.minutes} min por dia · às {s.plan.time}
          </div>
        </div>
        <span className="text-sm font-bold text-brand">Editar</span>
      </Card>

      <div>
        <h2 className="mb-3 text-xl font-black">Níveis e certificados</h2>
        <div className="space-y-3">
          {LEVELS.map((l) => {
            const cert = s.certificates[l];
            const passed = unitsOf(l).filter((u) => isCheckpointPassed(s, u.id)).length;
            return (
              <Card key={l} className="flex items-center gap-4">
                <div className={cn("flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl", cert ? "bg-amber-100 text-amber-600" : "bg-line text-muted")}>
                  {cert ? <Award size={30} /> : <Lock size={24} />}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="font-black">
                    {l} · {LEVEL_INFO[l].name}
                  </div>
                  <ProgressBar value={levelProgress(s, l)} className="mt-2" height={6} color={cert ? "var(--color-ok)" : undefined} />
                  <div className="mt-1 text-sm text-muted">
                    {passed}/{unitsOf(l).length} checkpoints · {Math.round(levelProgress(s, l) * 100)}%
                  </div>
                </div>
                <Button variant={cert ? "primary" : "secondary"} disabled={!cert} className="shrink-0 px-4" onClick={() => navigate(`/certificate/${l}`)}>
                  {cert ? "Ver" : "Bloqueado"}
                </Button>
              </Card>
            );
          })}
        </div>
        {s.placement && (
          <p className="mt-3 text-sm text-muted">
            Teste de nivelamento: {Math.round(s.placement.score * 100)}% em {new Date(s.placement.at).toLocaleDateString("pt-BR")}
            {s.placement.passed ? " · A2 validado" : ""}
          </p>
        )}
      </div>
    </div>
  );
}

export function Certificate({ level }: { level: string }) {
  const s = useAppState((x) => x);
  const lv = level as Level;
  const cert = LEVELS.includes(lv) ? s.certificates[lv] : undefined;
  if (!cert)
    return (
      <div className="py-16 text-center">
        <Lock className="mx-auto text-muted" size={40} />
        <h1 className="mt-4 text-2xl font-black">Certificado ainda não disponível</h1>
        <p className="mt-2 text-muted">Passe em todos os checkpoints do nível {LEVELS.includes(lv) ? lv : ""} para receber seu certificado.</p>
        <Button className="mt-6" onClick={() => navigate("/profile")}>
          Voltar ao perfil
        </Button>
      </div>
    );
  return (
    <div className="space-y-5">
      <div className="no-print flex items-center justify-between">
        <button onClick={() => navigate("/profile")} aria-label="Voltar" className="rounded-full bg-white p-2.5 shadow-sm ring-1 ring-line">
          <ArrowLeft size={20} />
        </button>
        <Button onClick={() => window.print()}>
          <Printer size={18} /> Imprimir / salvar PDF
        </Button>
      </div>
      <div className="relative overflow-hidden rounded-3xl border-[10px] border-double border-amber-300 bg-white p-8 text-center shadow-xl sm:p-12">
        <div className="absolute -top-10 -left-10 h-40 w-40 rounded-full bg-brand-50" />
        <div className="absolute -right-12 -bottom-12 h-48 w-48 rounded-full bg-amber-50" />
        <div className="relative">
          <div className="flex justify-center">
            <Logo size={44} />
          </div>
          <div className="mt-6 text-sm font-extrabold uppercase tracking-[0.3em] text-muted">Certificado de conclusão</div>
          <div className="mt-6 text-muted">Certificamos que</div>
          <div className="mt-2 text-4xl font-black text-ink">{s.name || "Estudante"}</div>
          <div className="mx-auto mt-4 max-w-md text-lg text-ink/80">
            concluiu o nível <strong>{lv} — {LEVEL_INFO[lv].name}</strong> do curso de japonês, com aprovação em todos os {unitsOf(lv).length} checkpoints.
          </div>
          <div className="jp mt-6 text-5xl text-brand">修了証</div>
          <div className="mt-6 flex flex-wrap justify-center gap-8 text-sm">
            <div>
              <div className="font-black text-ink">{new Date(cert.at).toLocaleDateString("pt-BR", { day: "2-digit", month: "long", year: "numeric" })}</div>
              <div className="text-muted">Data</div>
            </div>
            <div>
              <div className="font-black text-ink">{Math.round(cert.score * 100)}%</div>
              <div className="text-muted">Média nos checkpoints</div>
            </div>
          </div>
          <ul className="mx-auto mt-6 max-w-md space-y-1 text-left text-sm text-muted">
            {LEVEL_INFO[lv].can.map((c) => (
              <li key={c}>✓ {c}</li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}
