import { useMemo, useRef, useState } from "react";
import { Lock } from "lucide-react";
import { ACTIVITY_LABEL, ACTIVITY_TYPES, grammarById, lessonById, unitById, unitsOf, vocabById, type ActivityType } from "../course";
import { navigate } from "../lib/router";
import { addXP, awardCertificate, completeActivity, ensureVocab, getState, recordCheckpoint, recordPlacement } from "../lib/store";
import {
  isActivityUnlocked,
  isCheckpointPassed,
  isCheckpointUnlocked,
  isLevelComplete,
  stepAfter,
  pathFor,
  PASS_CHECKPOINT,
  PASS_PLACEMENT,
  isActivityDone,
} from "../lib/progress";
import { buildActivity, buildCheckpoint, buildGrammarReview, buildPlacement, buildVocabReview, dueVocabIds, favoriteVocabIds, shuffle, weakVocabIds, type Session } from "../lib/sessions";
import { Player, ResultsView, type SessionResult } from "../components/Player";
import { Button } from "../components/ui";
import { NotFound } from "./Learn";

function Blocked({ title, message, back }: { title: string; message: string; back: string }) {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-white px-6 text-center">
      <div className="flex h-20 w-20 items-center justify-center rounded-full bg-line text-muted">
        <Lock size={36} />
      </div>
      <h1 className="mt-5 text-2xl font-black">{title}</h1>
      <p className="mt-2 max-w-sm text-muted">{message}</p>
      <Button className="mt-6" onClick={() => navigate(back)}>
        Voltar
      </Button>
    </div>
  );
}

const minutes = (sec: number) => Math.max(1, Math.round(sec / 60));

export function ActivityPlay({ lessonId, type }: { lessonId: string; type: string }) {
  const lesson = lessonById.get(lessonId);
  const valid = lesson && (ACTIVITY_TYPES as readonly string[]).includes(type);
  const [allowed] = useState(() => (valid ? isActivityUnlocked(getState(), lesson!, type as ActivityType) : false));
  const [nonce, setNonce] = useState(0);
  const [result, setResult] = useState<(SessionResult & { xp: number }) | null>(null);
  const session = useMemo(() => (valid ? buildActivity(lesson!, type as ActivityType) : null), [valid, lesson, type, nonce]); // eslint-disable-line react-hooks/exhaustive-deps

  if (!valid || !session) return <NotFound what="Atividade" />;
  const t = type as ActivityType;
  if (!allowed) return <Blocked title="Atividade bloqueada" message="Conclua as atividades anteriores desta lição para continuar." back={`/lesson/${lesson.id}`} />;

  if (result) {
    const n = stepAfter(getState(), lesson, t);
    const sameLesson = n.kind === "activity" && n.lesson.id === lesson.id;
    const nextLabel =
      n.kind === "activity" ? (sameLesson ? `Próxima: ${ACTIVITY_LABEL[n.type]}` : `Próxima lição: ${n.lesson.title}`) : n.kind === "checkpoint" ? "Ir para o checkpoint" : "Voltar ao início";
    const lessonDone = ACTIVITY_TYPES.every((x) => isActivityDone(getState(), lesson.id, x));
    return (
      <ResultsView
        result={result}
        xp={result.xp}
        passed
        title={lessonDone && t === "practice" ? "Lição concluída! 🎉" : `${ACTIVITY_LABEL[t]} concluído!`}
        message={
          t === "vocab"
            ? `As ${lesson.vocab.length} palavras desta lição foram adicionadas à sua Revisão.`
            : result.score >= 0.8
              ? "Ótimo desempenho! Continue para a próxima atividade."
              : "Atividade concluída. Revise os erros abaixo para fixar melhor o conteúdo."
        }
        primary={{ label: nextLabel, onClick: () => navigate(pathFor(n), true) }}
        secondary={{ label: "Voltar à lição", onClick: () => navigate(`/lesson/${lesson.id}`, true) }}
        tertiary={{
          label: "Refazer atividade",
          onClick: () => {
            setResult(null);
            setNonce((x) => x + 1);
          },
        }}
      />
    );
  }

  return (
    <Player
      key={nonce}
      session={session}
      onExit={() => navigate(`/lesson/${lesson.id}`, true)}
      onFinish={(r) => {
        completeActivity(lesson.id, t, r.score);
        if (t === "vocab") ensureVocab(lesson.vocab.map((v) => v.id));
        const xp = 10 + Math.round(r.score * 10);
        addXP(xp, minutes(r.seconds));
        setResult({ ...r, xp });
      }}
    />
  );
}

export function CheckpointPlay({ unitId }: { unitId: string }) {
  const unit = unitById.get(unitId);
  const [allowed] = useState(() => (unit ? isCheckpointUnlocked(getState(), unit) : false));
  const [nonce, setNonce] = useState(0);
  const [result, setResult] = useState<(SessionResult & { xp: number; passed: boolean; levelDone: boolean }) | null>(null);
  const session = useMemo(() => (unit ? buildCheckpoint(unit) : null), [unit, nonce]); // eslint-disable-line react-hooks/exhaustive-deps
  if (!unit || !session) return <NotFound what="Checkpoint" />;
  if (!allowed) return <Blocked title="Checkpoint bloqueado" message="Conclua as 3 lições do capítulo para fazer o checkpoint." back={`/unit/${unit.id}`} />;

  if (result) {
    const units = unitsOf(unit.level);
    const nextUnit = units[unit.levelIndex] ?? (unit.level === "A2" ? unitsOf("B1")[0] : undefined);
    return (
      <ResultsView
        result={result}
        xp={result.xp}
        passed={result.passed}
        title={result.passed ? (result.levelDone ? `Nível ${unit.level} concluído! 🏆` : "Checkpoint aprovado!") : "Quase lá!"}
        message={
          result.passed
            ? result.levelDone
              ? `Parabéns! Você concluiu todos os capítulos do ${unit.level} e ganhou um certificado.`
              : nextUnit
                ? `Capítulo “${nextUnit.title}” desbloqueado.`
                : "Você concluiu este capítulo."
            : `Você precisa de ${Math.round(PASS_CHECKPOINT * 100)}% para passar. Revise as lições e tente novamente.`
        }
        primary={
          result.passed
            ? result.levelDone
              ? { label: "Ver meu certificado", onClick: () => navigate(`/certificate/${unit.level}`, true) }
              : nextUnit
                ? { label: `Ir para: ${nextUnit.title}`, onClick: () => navigate(`/unit/${nextUnit.id}`, true) }
                : { label: "Voltar ao início", onClick: () => navigate("/", true) }
            : {
                label: "Tentar novamente",
                onClick: () => {
                  setResult(null);
                  setNonce((x) => x + 1);
                },
              }
        }
        secondary={{ label: "Voltar ao capítulo", onClick: () => navigate(`/unit/${unit.id}`, true) }}
      />
    );
  }

  return (
    <Player
      key={nonce}
      session={session}
      onExit={() => navigate(`/unit/${unit.id}`, true)}
      onFinish={(r) => {
        const passed = r.score >= PASS_CHECKPOINT;
        const wasPassed = isCheckpointPassed(getState(), unit.id);
        recordCheckpoint(unit.id, r.score, passed);
        let levelDone = false;
        if (passed && isLevelComplete(getState(), unit.level)) {
          const s = getState();
          const avg = unitsOf(unit.level).reduce((n, u) => n + (s.checkpoints[u.id]?.best ?? 0), 0) / unitsOf(unit.level).length;
          levelDone = !wasPassed || !s.certificates[unit.level];
          awardCertificate(unit.level, avg);
        }
        const xp = passed ? 30 + Math.round(r.score * 20) : 10;
        addXP(xp, minutes(r.seconds));
        setResult({ ...r, xp, passed, levelDone });
      }}
    />
  );
}

export function PlacementPlay() {
  const [nonce, setNonce] = useState(0);
  const [result, setResult] = useState<(SessionResult & { xp: number; passed: boolean }) | null>(null);
  const session = useMemo(() => buildPlacement(), [nonce]); // eslint-disable-line react-hooks/exhaustive-deps
  if (result)
    return (
      <ResultsView
        result={result}
        xp={result.xp}
        passed={result.passed}
        title={result.passed ? "Você já domina o A2!" : "Recomendamos começar pelo A2"}
        message={
          result.passed
            ? "Todos os capítulos do A2 foram desbloqueados e você já pode começar o B1. Você também pode fazer os checkpoints do A2 para ganhar o certificado."
            : `Você acertou ${Math.round(result.score * 100)}%. São necessários ${Math.round(PASS_PLACEMENT * 100)}% para pular o A2. O curso A2 vai consolidar sua base.`
        }
        primary={result.passed ? { label: "Começar o B1", onClick: () => navigate("/?level=B1", true) } : { label: "Começar pelo A2", onClick: () => navigate("/?level=A2", true) }}
        secondary={{
          label: "Refazer o teste",
          onClick: () => {
            setResult(null);
            setNonce((x) => x + 1);
          },
        }}
      />
    );
  return (
    <Player
      key={nonce}
      session={session}
      onExit={() => navigate("/", true)}
      onFinish={(r) => {
        const passed = r.score >= PASS_PLACEMENT;
        recordPlacement(r.score, passed);
        const xp = 10 + Math.round(r.score * 20);
        addXP(xp, minutes(r.seconds));
        setResult({ ...r, xp, passed });
      }}
    />
  );
}

export function ReviewPlay({ mode }: { mode: string }) {
  const built = useRef<Session | null | undefined>(undefined);
  const [nonce, setNonce] = useState(0);
  const [result, setResult] = useState<(SessionResult & { xp: number }) | null>(null);
  const session = useMemo(() => {
    const s = getState();
    const flash = mode.endsWith("-flash");
    const base = flash ? mode.slice(0, -6) : mode;
    const fmt = flash ? "flash" : "writing";
    if (base === "smart") {
      const ids = dueVocabIds(12);
      let list = ids.length ? ids : weakVocabIds(12);
      if (!list.length) list = shuffle(Object.keys(s.vocab).filter((id) => vocabById.has(id))).slice(0, 12);
      return list.length ? buildVocabReview(list, ids.length ? "Revisão inteligente" : "Prática extra", fmt) : null;
    }
    if (base === "weak") {
      const ids = weakVocabIds(12);
      return ids.length ? buildVocabReview(ids, "Fortalecer palavras", fmt) : null;
    }
    if (base === "fav") {
      const ids = favoriteVocabIds(15).filter((id) => s.vocab[id]);
      return ids.length >= 5 ? buildVocabReview(ids, "Favoritas", fmt) : null;
    }
    if (mode === "grammar") {
      const learned = Object.keys(s.grammar).filter((g) => grammarById.has(g));
      if (!learned.length) return null;
      const scored = learned
        .map((g) => {
          const r = s.grammar[g];
          const avg = r.recent.length ? r.recent.reduce((a, b) => a + b, 0) / r.recent.length : 0;
          return { g, avg };
        })
        .sort((a, b) => a.avg - b.avg)
        .slice(0, 4)
        .map((x) => x.g);
      return buildGrammarReview(scored);
    }
    if (mode.startsWith("g-")) {
      const gid = mode.slice(2);
      const g = grammarById.get(gid);
      if (!g) return null;
      const lesson = lessonById.get(g.lessonId)!;
      if (!isActivityDone(s, lesson.id, "grammar") && !isActivityUnlocked(s, lesson, "grammar")) return null;
      return buildGrammarReview([gid], "Praticar gramática");
    }
    return null;
  }, [mode, nonce]);
  built.current = session;
  const backTo = mode === "grammar" || mode.startsWith("g-") ? (mode.startsWith("g-") ? `/grammar/${mode.slice(2)}` : "/review?tab=grammar") : "/review";

  if (!session)
    return (
      <div className="flex min-h-screen flex-col items-center justify-center bg-white px-6 text-center">
        <div className="text-6xl">📭</div>
        <h1 className="mt-4 text-2xl font-black">Nada para revisar ainda</h1>
        <p className="mt-2 max-w-sm text-muted">Conclua atividades de vocabulário e gramática nas lições. Elas entram automaticamente na sua revisão.</p>
        <Button className="mt-6" onClick={() => navigate(backTo, true)}>
          Voltar
        </Button>
      </div>
    );

  if (result)
    return (
      <ResultsView
        result={result}
        xp={result.xp}
        title="Revisão concluída!"
        message="A força de cada item foi atualizada. Itens que você errou vão aparecer de novo em breve."
        primary={{ label: "Voltar à Revisão", onClick: () => navigate(backTo, true) }}
        secondary={{
          label: "Revisar mais",
          onClick: () => {
            setResult(null);
            setNonce((x) => x + 1);
          },
        }}
      />
    );

  return (
    <Player
      key={nonce}
      session={session}
      onExit={() => navigate(backTo, true)}
      onFinish={(r) => {
        const xp = 5 + Math.round(r.score * 10);
        addXP(xp, minutes(r.seconds));
        setResult({ ...r, xp });
      }}
    />
  );
}
