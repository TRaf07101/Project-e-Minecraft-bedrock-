import { useState } from "react";
import { ArrowLeft, BookOpen, GraduationCap, Headphones, Brain, Award } from "lucide-react";
import { setState, updateSettings } from "../lib/store";
import { navigate } from "../lib/router";
import { COURSE_STATS } from "../course";
import { Button, Logo } from "../components/ui";
import { speak } from "../lib/audio";
import { cn } from "../utils/cn";

const GOALS = [
  { xp: 20, label: "Casual", desc: "5 minutos por dia" },
  { xp: 30, label: "Regular", desc: "10 minutos por dia" },
  { xp: 50, label: "Sério", desc: "15 minutos por dia" },
  { xp: 80, label: "Intenso", desc: "25 minutos por dia" },
];

export function Onboarding() {
  const [step, setStep] = useState(0);
  const [name, setName] = useState("");
  const [goal, setGoal] = useState(30);

  const finish = (placement: boolean) => {
    updateSettings({ dailyGoal: goal });
    setState((s) => ({ ...s, name: name.trim() || "Estudante", onboarded: true, createdAt: Date.now() }));
    navigate(placement ? "/placement" : "/", true);
  };

  return (
    <div className="flex min-h-screen flex-col bg-white">
      <header className="mx-auto flex w-full max-w-xl items-center gap-3 px-4 py-4">
        {step > 0 ? (
          <button onClick={() => setStep(step - 1)} className="rounded-full p-2 hover:bg-canvas" aria-label="Voltar">
            <ArrowLeft />
          </button>
        ) : (
          <div className="w-10" />
        )}
        <div className="flex flex-1 gap-1.5">
          {[0, 1, 2, 3].map((i) => (
            <span key={i} className={cn("h-2 flex-1 rounded-full transition", i <= step ? "bg-brand" : "bg-line")} />
          ))}
        </div>
        <div className="w-10" />
      </header>

      <main className="mx-auto w-full max-w-xl flex-1 px-5 pb-40">
        {step === 0 && (
          <div className="anim-fade-in pt-6 text-center">
            <div className="flex justify-center">
              <Logo size={56} />
            </div>
            <h1 className="mt-8 text-3xl leading-tight font-black sm:text-4xl">
              Japonês de verdade,
              <br />
              do A2 ao B1.
            </h1>
            <p className="mx-auto mt-3 max-w-sm text-muted">
              {COURSE_STATS.units} capítulos, {COURSE_STATS.lessons} lições, {COURSE_STATS.vocab} palavras e {COURSE_STATS.kanji} kanji — com áudio, revisão inteligente e certificados.
            </p>
            <div className="mt-8 grid grid-cols-2 gap-3 text-left">
              {[
                { icon: BookOpen, t: "Lições curtas", d: "Vocabulário, kanji, gramática e diálogos" },
                { icon: Headphones, t: "Áudio em japonês", d: "Ouça cada palavra e frase" },
                { icon: Brain, t: "Revisão inteligente", d: "Repetição espaçada para não esquecer" },
                { icon: Award, t: "Certificados", d: "Ao concluir cada nível" },
              ].map((f) => (
                <div key={f.t} className="rounded-2xl bg-canvas p-4">
                  <f.icon className="text-brand" size={24} />
                  <div className="mt-2 font-black">{f.t}</div>
                  <div className="text-sm text-muted">{f.d}</div>
                </div>
              ))}
            </div>
          </div>
        )}
        {step === 1 && (
          <div className="anim-fade-in pt-6">
            <h1 className="text-3xl font-black">Como podemos te chamar?</h1>
            <p className="mt-2 text-muted">Seu nome aparece no perfil e nos certificados.</p>
            <input
              autoFocus
              value={name}
              onChange={(e) => setName(e.target.value)}
              maxLength={30}
              placeholder="Seu nome"
              onKeyDown={(e) => e.key === "Enter" && name.trim() && setStep(2)}
              className="mt-6 w-full rounded-2xl border-2 border-line px-4 py-4 text-xl font-bold outline-none focus:border-brand"
            />
          </div>
        )}
        {step === 2 && (
          <div className="anim-fade-in pt-6">
            <h1 className="text-3xl font-black">Qual é a sua meta diária?</h1>
            <p className="mt-2 text-muted">Você pode mudar isso depois em Ajustes.</p>
            <div className="mt-6 space-y-3">
              {GOALS.map((g) => (
                <button
                  key={g.xp}
                  onClick={() => setGoal(g.xp)}
                  className={cn("flex w-full items-center justify-between rounded-2xl border-2 p-4 text-left transition", goal === g.xp ? "border-brand bg-brand-50" : "border-line")}
                >
                  <div>
                    <div className="text-lg font-black">{g.label}</div>
                    <div className="text-muted">{g.desc}</div>
                  </div>
                  <div className="font-extrabold text-brand">{g.xp} ★</div>
                </button>
              ))}
            </div>
          </div>
        )}
        {step === 3 && (
          <div className="anim-fade-in pt-6">
            <h1 className="text-3xl font-black">Por onde você quer começar?</h1>
            <p className="mt-2 text-muted">Este curso pressupõe que você já lê hiragana e katakana e conhece o básico (nível A1 / N5).</p>
            <div className="mt-6 space-y-3">
              <button onClick={() => finish(false)} className="flex w-full items-center gap-4 rounded-3xl border-2 border-line p-5 text-left transition hover:border-brand">
                <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-brand-50 text-2xl font-black text-brand">A2</div>
                <div className="flex-1">
                  <div className="text-lg font-black">Começar do A2</div>
                  <div className="text-muted">Rotina, compras, saúde, planos, cidade e trabalho.</div>
                </div>
              </button>
              <button onClick={() => finish(true)} className="flex w-full items-center gap-4 rounded-3xl border-2 border-line p-5 text-left transition hover:border-brand">
                <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-amber-50 text-amber-600">
                  <GraduationCap size={28} />
                </div>
                <div className="flex-1">
                  <div className="text-lg font-black">Fazer o teste de nivelamento</div>
                  <div className="text-muted">20 questões. Com 75% ou mais, você desbloqueia o A2 e começa o B1.</div>
                </div>
              </button>
            </div>
          </div>
        )}
      </main>

      {step < 3 && (
        <div className="fixed inset-x-0 bottom-0 border-t border-line bg-white">
          <div className="mx-auto max-w-xl px-5 pt-3 pb-safe">
            <Button
              className="w-full"
              disabled={step === 1 && !name.trim()}
              onClick={() => {
                if (step === 0) speak("ようこそ！"); // unlocks audio on iOS with a user gesture
                setStep(step + 1);
              }}
            >
              {step === 0 ? "Começar" : "Continuar"}
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
