import { useMemo, useRef, useState } from "react";
import { Download, Upload, Trash2, Volume2, ShieldCheck, AlertTriangle } from "lucide-react";
import { COURSE_STATS, validateCourse } from "../course";
import { exportState, importState, resetAll, updateSettings, useAppState } from "../lib/store";
import { japaneseVoiceAvailable, speak, ttsAvailable, voiceName, sfx } from "../lib/audio";
import { Button, Card, Confirm, Toggle } from "../components/ui";
import { cn } from "../utils/cn";
import { navigate } from "../lib/router";
import { auditSessions, simulateProgression } from "../lib/selftest";

const GOALS = [
  { xp: 20, label: "Casual", desc: "~5 min/dia" },
  { xp: 30, label: "Regular", desc: "~10 min/dia" },
  { xp: 50, label: "Sério", desc: "~15 min/dia" },
  { xp: 80, label: "Intenso", desc: "~25 min/dia" },
];

export function Settings() {
  const st = useAppState((s) => s.settings);
  const [confirmReset, setConfirmReset] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const [showIssues, setShowIssues] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const audit = useMemo(() => {
    const content = validateCourse();
    const sess = auditSessions();
    const sim = simulateProgression();
    return { content, sess, sim, all: [...content, ...sess.issues, ...sim.issues] };
  }, []);
  const issues = audit.all;
  const hasVoice = japaneseVoiceAvailable();

  const flash = (m: string) => {
    setMsg(m);
    setTimeout(() => setMsg(null), 3500);
  };

  return (
    <div className="space-y-5">
      <h1 className="text-3xl font-black tracking-tight">Ajustes</h1>
      {msg && <div className="anim-fade-in rounded-2xl bg-ok-50 px-4 py-3 font-bold text-ok-dark">{msg}</div>}

      <Card>
        <h2 className="text-lg font-black">Plano de estudos</h2>
        <p className="text-sm text-muted">
          Escolha sua meta diária de estrelas. Dias, minutos e horário ficam no{" "}
          <button className="font-bold text-brand underline" onClick={() => navigate("/plan")}>
            Plano de estudos
          </button>
          .
        </p>
        <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4">
          {GOALS.map((g) => (
            <button
              key={g.xp}
              onClick={() => updateSettings({ dailyGoal: g.xp })}
              className={cn("rounded-2xl border-2 p-3 text-left transition", st.dailyGoal === g.xp ? "border-brand bg-brand-50" : "border-line hover:border-brand-100")}
            >
              <div className="font-black">{g.label}</div>
              <div className="text-sm text-muted">
                {g.xp} ★ · {g.desc}
              </div>
            </button>
          ))}
        </div>
      </Card>

      <Card>
        <h2 className="text-lg font-black">Áudio</h2>
        {!ttsAvailable() ? (
          <div className="mt-2 flex items-start gap-2 rounded-xl bg-amber-50 p-3 text-sm text-amber-900">
            <AlertTriangle size={18} className="shrink-0" /> Seu navegador não oferece síntese de voz. Use Chrome, Edge ou Safari para ouvir os áudios.
          </div>
        ) : !hasVoice ? (
          <div className="mt-2 flex items-start gap-2 rounded-xl bg-amber-50 p-3 text-sm text-amber-900">
            <AlertTriangle size={18} className="shrink-0" /> Nenhuma voz japonesa foi encontrada. Instale a voz “Japonês” nas configurações de idioma/fala do seu sistema para melhor pronúncia.
          </div>
        ) : (
          <div className="mt-1 text-sm text-muted">Voz: {voiceName()}</div>
        )}
        <div className="divide-y divide-line">
          <Toggle checked={st.autoplay} onChange={(v) => updateSettings({ autoplay: v })} label="Reproduzir áudio automaticamente" desc="Toca palavras e frases ao aparecerem" />
          <Toggle
            checked={st.sfx}
            onChange={(v) => {
              updateSettings({ sfx: v });
              if (v) setTimeout(() => sfx("correct"), 50);
            }}
            label="Efeitos sonoros"
            desc="Sons de acerto, erro e conclusão"
          />
          <div className="py-3">
            <div className="flex items-center justify-between">
              <div className="font-bold">Velocidade da fala</div>
              <span className="text-sm font-bold text-muted">{st.rate.toFixed(2)}×</span>
            </div>
            <input type="range" min={0.5} max={1.2} step={0.05} value={st.rate} onChange={(e) => updateSettings({ rate: parseFloat(e.target.value) })} className="mt-2 w-full" />
            <Button variant="secondary" className="mt-2 min-h-10 py-2" onClick={() => speak("こんにちは。日本語[にほんご]の勉強[べんきょう]を頑張[がんば]りましょう。")}>
              <Volume2 size={16} /> Testar voz
            </Button>
          </div>
        </div>
      </Card>

      <Card>
        <h2 className="text-lg font-black">Exibição</h2>
        <div className="divide-y divide-line">
          <Toggle checked={st.furigana} onChange={(v) => updateSettings({ furigana: v })} label="Mostrar furigana" desc="Leitura em hiragana sobre os kanji" />
          <Toggle checked={st.romaji} onChange={(v) => updateSettings({ romaji: v })} label="Mostrar romaji" desc="Transcrição em letras latinas no vocabulário" />
        </div>
      </Card>

      <Card>
        <h2 className="text-lg font-black">Seus dados</h2>
        <p className="text-sm text-muted">Seu progresso é salvo automaticamente neste dispositivo.</p>
        <div className="mt-3 flex flex-wrap gap-2">
          <Button
            variant="secondary"
            onClick={() => {
              const blob = new Blob([exportState()], { type: "application/json" });
              const a = document.createElement("a");
              a.href = URL.createObjectURL(blob);
              a.download = `kotoba-progresso-${new Date().toISOString().slice(0, 10)}.json`;
              a.click();
              URL.revokeObjectURL(a.href);
              flash("Arquivo de progresso exportado.");
            }}
          >
            <Download size={18} /> Exportar progresso
          </Button>
          <Button variant="secondary" onClick={() => fileRef.current?.click()}>
            <Upload size={18} /> Importar progresso
          </Button>
          <input
            ref={fileRef}
            type="file"
            accept="application/json,.json"
            className="hidden"
            onChange={async (e) => {
              const f = e.target.files?.[0];
              if (!f) return;
              const ok = importState(await f.text());
              flash(ok ? "Progresso importado com sucesso." : "Arquivo inválido. Nada foi alterado.");
              e.target.value = "";
            }}
          />
          <Button variant="ghost" className="text-bad hover:bg-bad-50" onClick={() => setConfirmReset(true)}>
            <Trash2 size={18} /> Apagar todo o progresso
          </Button>
        </div>
      </Card>

      <Card>
        <h2 className="text-lg font-black">Sobre o curso</h2>
        <div className="mt-3 grid grid-cols-2 gap-2 text-sm sm:grid-cols-4">
          {[
            ["Capítulos", COURSE_STATS.units],
            ["Lições", COURSE_STATS.lessons],
            ["Palavras", COURSE_STATS.vocab],
            ["Kanji", COURSE_STATS.kanji],
            ["Tópicos de gramática", COURSE_STATS.grammar],
            ["Exercícios de gramática", COURSE_STATS.exercises],
            ["Diálogos", COURSE_STATS.dialogues],
            ["Perguntas de diálogo", COURSE_STATS.questions],
          ].map(([k, v]) => (
            <div key={k} className="rounded-xl bg-canvas p-3">
              <div className="text-xl font-black">{v}</div>
              <div className="text-muted">{k}</div>
            </div>
          ))}
        </div>
        <button onClick={() => setShowIssues((v) => !v)} className={cn("mt-3 flex w-full items-center gap-2 rounded-xl p-3 text-left text-sm font-bold", issues.length ? "bg-amber-50 text-amber-900" : "bg-ok-50 text-ok-dark")}>
          {issues.length ? <AlertTriangle size={18} /> : <ShieldCheck size={18} />}
          Verificação automática: {issues.length === 0 ? "nenhum problema encontrado" : `${issues.length} aviso(s)`}
        </button>
        <div className="mt-2 grid gap-1 text-xs text-muted sm:grid-cols-3">
          <div className="rounded-lg bg-canvas px-2 py-1.5">Conteúdo: {audit.content.length === 0 ? "✓ íntegro" : `${audit.content.length} aviso(s)`}</div>
          <div className="rounded-lg bg-canvas px-2 py-1.5">
            Sessões: {audit.sess.sessions} montadas, {audit.sess.steps} etapas {audit.sess.issues.length === 0 ? "✓" : `· ${audit.sess.issues.length} aviso(s)`}
          </div>
          <div className="rounded-lg bg-canvas px-2 py-1.5">
            Desbloqueios: {audit.sim.steps} etapas simuladas {audit.sim.issues.length === 0 ? "✓" : `· ${audit.sim.issues.length} aviso(s)`}
          </div>
        </div>
        {showIssues && issues.length > 0 && (
          <ul className="mt-2 max-h-60 space-y-1 overflow-auto text-xs text-muted">
            {issues.map((i, k) => (
              <li key={k}>
                <span className="font-bold">{i.where}</span>: {i.msg}
              </li>
            ))}
          </ul>
        )}
        <p className="mt-3 text-xs text-muted">Conteúdo original, inspirado na estrutura do QECR (A2–B1) e nos níveis JLPT N4–N3. Interface própria inspirada em aplicativos de idiomas; sem afiliação com marcas de terceiros.</p>
      </Card>

      <Confirm
        open={confirmReset}
        title="Apagar todo o progresso?"
        message="Isso remove lições concluídas, checkpoints, palavras da revisão, favoritas, estrelas, sequência, plano de estudos e certificados. Não é possível desfazer."
        confirmLabel="Apagar tudo"
        danger
        onConfirm={() => {
          resetAll();
          setConfirmReset(false);
          navigate("/", true);
        }}
        onCancel={() => setConfirmReset(false)}
      />
    </div>
  );
}
