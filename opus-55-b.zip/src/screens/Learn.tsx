import { useEffect, useRef, useState } from "react";
import {
  ArrowLeft,
  BookOpen,
  ChevronDown,
  ChevronRight,
  Lock,
  MessageCircle,
  PenLine,
  Puzzle,
  Trophy,
  Award,
  Languages,
  GraduationCap,
  Check,
  Play,
  Info,
} from "lucide-react";
import { ACTIVITY_DESC, ACTIVITY_LABEL, ACTIVITY_TYPES, LEVEL_INFO, LEVELS, lessonById, unitById, unitsOf, type ActivityType, type Lesson, type Level, type Unit } from "../course";
import { navigate } from "../lib/router";
import { activityKey, useAppState, type State } from "../lib/store";
import {
  isActivityDone,
  isActivityUnlocked,
  isCheckpointPassed,
  isCheckpointUnlocked,
  isLessonComplete,
  isLessonUnlocked,
  isLevelComplete,
  isLevelUnlocked,
  isUnitUnlocked,
  lessonDoneCount,
  levelProgress,
  nextStep,
  pathFor,
  unitProgress,
  PASS_CHECKPOINT,
} from "../lib/progress";
import { Button, Card, JP, ProgressBar, StatusIcon } from "../components/ui";
import { ChallengesWidget, LessonIcon, ReviewWidget, StreakWidget, StudyPlanWidget } from "../components/Widgets";
import { cn } from "../utils/cn";

export const ACTIVITY_ICON: Record<ActivityType, typeof BookOpen> = {
  vocab: BookOpen,
  kanji: Languages,
  grammar: Puzzle,
  dialogue: MessageCircle,
  practice: PenLine,
};

// ───────────────────────────────────────── Linha do tempo do curso
function ActivityIcons({ s, l, nextType }: { s: State; l: Lesson; nextType?: ActivityType }) {
  return (
    <div className="grid grid-cols-5 gap-1 sm:gap-2">
      {ACTIVITY_TYPES.map((t) => {
        const Icon = ACTIVITY_ICON[t];
        const done = isActivityDone(s, l.id, t);
        const open = isActivityUnlocked(s, l, t);
        const current = t === nextType;
        return (
          <button
            key={t}
            disabled={!open}
            onClick={() => navigate(`/play/${l.id}/${t}`)}
            title={open ? ACTIVITY_LABEL[t] : `${ACTIVITY_LABEL[t]} (bloqueada)`}
            className="group flex flex-col items-center gap-1.5 rounded-2xl py-2 transition hover:bg-canvas disabled:cursor-not-allowed disabled:hover:bg-transparent"
          >
            <span
              className={cn(
                "relative flex h-12 w-12 items-center justify-center rounded-full transition group-enabled:group-hover:scale-105",
                done ? "bg-ok-50 text-ok" : current ? "anim-pulse bg-brand text-white" : open ? "border-2 border-brand-100 bg-white text-brand" : "bg-canvas text-muted/60"
              )}
            >
              <Icon size={22} />
              {done && (
                <span className="absolute -right-0.5 -bottom-0.5 flex h-5 w-5 items-center justify-center rounded-full bg-ok text-white ring-2 ring-white">
                  <Check size={11} strokeWidth={3.5} />
                </span>
              )}
              {!open && (
                <span className="absolute -right-0.5 -bottom-0.5 flex h-5 w-5 items-center justify-center rounded-full bg-line text-muted ring-2 ring-white">
                  <Lock size={10} />
                </span>
              )}
            </span>
            <span className={cn("text-[0.68rem] font-bold leading-tight sm:text-xs", current ? "text-brand" : done ? "text-ok-dark" : "text-muted")}>{ACTIVITY_LABEL[t]}</span>
          </button>
        );
      })}
    </div>
  );
}

function LessonRow({ s, l, u, expanded, onToggle }: { s: State; l: Lesson; u: Unit; expanded: boolean; onToggle: () => void }) {
  const unlocked = isLessonUnlocked(s, l);
  const count = lessonDoneCount(s, l);
  const prog = count / ACTIVITY_TYPES.length;
  const nextType = ACTIVITY_TYPES.find((t) => !isActivityDone(s, l.id, t) && isActivityUnlocked(s, l, t));
  return (
    <div id={`lesson-${l.id}`} className="relative pl-[72px] sm:pl-20">
      <div className="absolute top-3 left-[6px] sm:left-2">
        <LessonIcon progress={prog} color={u.color} locked={!unlocked} label={<span className="text-lg">{l.index + 1}</span>} />
      </div>
      <div className={cn("rounded-3xl border bg-white transition", expanded ? "border-brand-100 shadow-md shadow-brand/5" : "border-line hover:border-brand-100")}>
        <button onClick={onToggle} aria-expanded={expanded} className="flex w-full items-center gap-3 p-4 text-left">
          <div className="min-w-0 flex-1">
            <div className="text-xs font-bold text-muted">
              Lição {l.index + 1} · {count}/{ACTIVITY_TYPES.length} atividades
            </div>
            <div className="truncate text-[1.05rem] font-extrabold">{l.title}</div>
            <div className="truncate text-sm text-muted">
              <JP text={l.desc} furigana={false} />
            </div>
          </div>
          {count > 0 && count < ACTIVITY_TYPES.length && <span className="rounded-full bg-brand-50 px-2 py-0.5 text-xs font-extrabold text-brand">{Math.round(prog * 100)}%</span>}
          <ChevronDown size={20} className={cn("shrink-0 text-muted transition", expanded && "rotate-180")} />
        </button>
        {expanded && (
          <div className="anim-expand border-t border-line px-3 pt-3 pb-4 sm:px-4">
            {!unlocked && (
              <div className="mb-3 flex items-center gap-2 rounded-2xl bg-amber-50 px-3 py-2 text-sm text-amber-900">
                <Lock size={16} /> {l.index === 0 ? "Passe no checkpoint do capítulo anterior para desbloquear." : "Conclua a lição anterior para desbloquear."}
              </div>
            )}
            <ActivityIcons s={s} l={l} nextType={nextType} />
            <div className="mt-3 flex flex-wrap gap-2">
              {nextType ? (
                <Button className="min-h-11 flex-1 py-2" onClick={() => navigate(`/play/${l.id}/${nextType}`)}>
                  <Play size={16} className="fill-current" /> {count === 0 ? "Começar lição" : `Continuar: ${ACTIVITY_LABEL[nextType]}`}
                </Button>
              ) : (
                isLessonComplete(s, l) && (
                  <div className="flex flex-1 items-center gap-2 rounded-full bg-ok-50 px-4 py-2 text-sm font-bold text-ok-dark">
                    <Check size={16} strokeWidth={3} /> Lição concluída — toque numa atividade para refazê-la
                  </div>
                )
              )}
              <Button variant="secondary" className="min-h-11 py-2" onClick={() => navigate(`/lesson/${l.id}`)}>
                <Info size={16} /> Detalhes
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function CheckpointRow({ s, u }: { s: State; u: Unit }) {
  const cp = s.checkpoints[u.id];
  const open = isCheckpointUnlocked(s, u);
  return (
    <div className="relative pl-[72px] sm:pl-20">
      <div className="absolute top-3 left-[6px] sm:left-2">
        <div className={cn("flex h-14 w-14 items-center justify-center rounded-2xl border-2", cp?.passed ? "border-ok bg-ok text-white" : open ? "border-warn bg-amber-50 text-amber-600" : "border-line bg-canvas text-muted")}>
          <Trophy size={26} />
        </div>
      </div>
      <div className={cn("rounded-3xl border bg-white p-4", cp?.passed ? "border-ok/40" : open ? "border-warn/50" : "border-line")}>
        <div className="flex flex-wrap items-center gap-3">
          <div className="min-w-0 flex-1">
            <div className="text-xs font-bold text-muted">Fim do capítulo {u.levelIndex}</div>
            <div className="text-[1.05rem] font-extrabold">Checkpoint</div>
            <div className="text-sm text-muted">
              {cp ? (
                <span className={cn("font-bold", cp.passed ? "text-ok-dark" : "text-bad-dark")}>
                  Melhor resultado: {Math.round(cp.best * 100)}% {cp.passed ? "· aprovado" : `· precisa de ${Math.round(PASS_CHECKPOINT * 100)}%`}
                </span>
              ) : (
                `Teste rápido das 3 lições · aprovação com ${Math.round(PASS_CHECKPOINT * 100)}%`
              )}
            </div>
          </div>
          <Button disabled={!open} variant={cp?.passed ? "secondary" : "primary"} className="min-h-11 py-2" onClick={() => navigate(`/checkpoint/${u.id}`)}>
            {!open ? (
              <>
                <Lock size={15} /> Bloqueado
              </>
            ) : cp?.passed ? (
              "Refazer"
            ) : cp ? (
              "Tentar de novo"
            ) : (
              "Começar"
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}

function ChapterSection({ s, u, expanded, setExpanded }: { s: State; u: Unit; expanded: string | null; setExpanded: (id: string | null) => void }) {
  const unlocked = isUnitUnlocked(s, u);
  const prog = unitProgress(s, u);
  const passed = isCheckpointPassed(s, u.id);
  return (
    <section className="relative">
      <button onClick={() => navigate(`/unit/${u.id}`)} className="mb-3 flex w-full items-center gap-3 text-left">
        <div className={cn("flex h-[68px] w-[68px] shrink-0 items-center justify-center rounded-2xl text-3xl sm:h-[76px] sm:w-[76px]", !unlocked && "grayscale")} style={{ background: unlocked ? u.color + "1f" : "#eef1f5" }}>
          {u.icon}
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-muted">
            Capítulo {u.levelIndex}
            {passed && (
              <span className="inline-flex items-center gap-0.5 rounded-full bg-ok-50 px-2 py-0.5 text-[0.65rem] text-ok-dark normal-case">
                <Check size={11} strokeWidth={3} /> concluído
              </span>
            )}
            {!unlocked && <Lock size={13} />}
          </div>
          <div className="truncate text-xl font-extrabold">{u.title}</div>
          <div className="flex items-center gap-2">
            <ProgressBar value={prog} height={6} color={passed ? "var(--color-ok)" : u.color} className="max-w-40" />
            <span className="text-xs font-bold text-muted">{Math.round(prog * 100)}%</span>
          </div>
        </div>
        <ChevronRight className="text-muted" size={20} />
      </button>
      <div className="relative space-y-3">
        <div className="absolute top-6 bottom-8 left-[33px] w-0.5 bg-line sm:left-[37px]" aria-hidden />
        {u.lessons.map((l) => (
          <LessonRow key={l.id} s={s} l={l} u={u} expanded={expanded === l.id} onToggle={() => setExpanded(expanded === l.id ? null : l.id)} />
        ))}
        <CheckpointRow s={s} u={u} />
      </div>
    </section>
  );
}

function LevelDivider({ s, level }: { s: State; level: Level }) {
  const unlocked = isLevelUnlocked(s, level);
  const done = isLevelComplete(s, level);
  const p = levelProgress(s, level);
  return (
    <div id={`level-${level}`} className="sticky top-[57px] z-10 -mx-4 bg-canvas/95 px-4 py-3 backdrop-blur md:top-0 md:-mx-8 md:px-8">
      <div className="flex items-center gap-3 rounded-2xl bg-white px-4 py-3 shadow-sm ring-1 ring-line">
        <span className={cn("flex h-10 w-12 items-center justify-center rounded-xl text-base font-extrabold", unlocked ? "bg-brand text-white" : "bg-line text-muted")}>{level}</span>
        <div className="min-w-0 flex-1">
          <div className="font-extrabold">
            {LEVEL_INFO[level].name} {!unlocked && <Lock size={14} className="inline text-muted" />}
          </div>
          <ProgressBar value={p} height={5} className="mt-1 max-w-56" color={done ? "var(--color-ok)" : undefined} />
        </div>
        {done ? (
          <Button variant="secondary" className="min-h-9 px-3 py-1.5 text-sm" onClick={() => navigate(`/certificate/${level}`)}>
            <Award size={16} /> Certificado
          </Button>
        ) : (
          <span className="text-sm font-extrabold text-muted">{Math.round(p * 100)}%</span>
        )}
      </div>
    </div>
  );
}

function ContinueBanner({ s }: { s: State }) {
  const n = nextStep(s);
  if (n.kind === "done")
    return (
      <div className="rounded-3xl bg-gradient-to-br from-ok to-emerald-700 p-5 text-white">
        <div className="flex items-center gap-3">
          <Award size={36} />
          <div>
            <div className="text-lg font-extrabold">Curso A2–B1 concluído!</div>
            <div className="text-white/85">Você passou em todos os checkpoints. Continue revisando para não esquecer.</div>
          </div>
        </div>
      </div>
    );
  const started = Object.keys(s.activities).length > 0;
  const u = n.unit;
  return (
    <div className="relative overflow-hidden rounded-3xl bg-brand p-5 text-white shadow-lg shadow-brand/20">
      <div className="absolute -top-8 -right-6 text-[7.5rem] opacity-20 select-none">{u.icon}</div>
      <div className="relative">
        <div className="text-xs font-bold uppercase tracking-wider text-white/80">
          {u.level} · Capítulo {u.levelIndex} · {u.title}
        </div>
        <div className="mt-1 text-2xl font-extrabold leading-tight">{n.kind === "activity" ? n.lesson.title : "Checkpoint do capítulo"}</div>
        <div className="text-white/90">{n.kind === "activity" ? `Próxima atividade: ${ACTIVITY_LABEL[n.type]}` : "Teste o que você aprendeu"}</div>
        <div className="mt-4 flex flex-wrap gap-2">
          <Button variant="white" className="text-brand" onClick={() => navigate(pathFor(n))}>
            <Play size={16} className="fill-current" /> {started ? "Continuar aprendendo" : "Começar a primeira lição"}
          </Button>
          {n.kind === "activity" && (
            <Button
              variant="secondary"
              className="border-white/30 bg-white/10 text-white hover:border-white/50 hover:bg-white/20"
              onClick={() => document.getElementById(`lesson-${n.lesson.id}`)?.scrollIntoView({ behavior: "smooth", block: "center" })}
            >
              Ver no curso
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}

export function Learn() {
  const s = useAppState((x) => x);
  const n = nextStep(s);
  const [expanded, setExpanded] = useState<string | null>(n.kind === "activity" ? n.lesson.id : null);
  const scrolled = useRef(false);

  // como no Busuu, abre o curso no ponto onde você parou (ou no nível pedido via ?level=)
  useEffect(() => {
    if (scrolled.current) return;
    scrolled.current = true;
    const q = new URLSearchParams(window.location.hash.split("?")[1] ?? "").get("level") as Level | null;
    const t = setTimeout(() => {
      if (q && LEVELS.includes(q)) document.getElementById(`level-${q}`)?.scrollIntoView({ behavior: "smooth", block: "start" });
      else if (n.kind === "activity" && Object.keys(s.activities).length > 0)
        document.getElementById(`lesson-${n.lesson.id}`)?.scrollIntoView({ behavior: "smooth", block: "center" });
    }, 250);
    return () => clearTimeout(t);
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const showPlacement = !s.testedOut.A2 && !isLevelComplete(s, "A2");

  return (
    <div className="lg:grid lg:grid-cols-[minmax(0,1fr)_300px] lg:gap-8">
      <div className="min-w-0 space-y-5">
        <div>
          <p className="font-semibold text-muted">Olá, {s.name || "estudante"}! 👋</p>
          <h1 className="text-3xl font-extrabold tracking-tight">Japonês · A2–B1</h1>
        </div>
        <ContinueBanner s={s} />

        {/* widgets compactos no celular */}
        <div className="grid gap-3 sm:grid-cols-2 lg:hidden">
          <StudyPlanWidget s={s} />
          <ChallengesWidget s={s} />
        </div>

        {showPlacement && (
          <Card className="flex flex-wrap items-center gap-4 border-dashed border-brand-100 bg-brand-50/60">
            <GraduationCap className="shrink-0 text-brand" size={32} />
            <div className="min-w-48 flex-1">
              <div className="font-extrabold">Já domina o A2?</div>
              <div className="text-sm text-muted">Faça o teste de nivelamento (20 questões) para desbloquear todo o A2 e começar o B1.</div>
            </div>
            <Button variant="secondary" className="shrink-0" onClick={() => navigate("/placement")}>
              Fazer o teste
            </Button>
          </Card>
        )}

        {LEVELS.map((level) => (
          <div key={level} className="space-y-6">
            <LevelDivider s={s} level={level} />
            <p className="-mt-2 text-sm text-muted">{LEVEL_INFO[level].desc}</p>
            {unitsOf(level).map((u) => (
              <ChapterSection key={u.id} s={s} u={u} expanded={expanded} setExpanded={setExpanded} />
            ))}
          </div>
        ))}
      </div>

      <aside className="hidden space-y-4 self-start lg:sticky lg:top-8 lg:block">
        <StudyPlanWidget s={s} />
        <ChallengesWidget s={s} />
        <StreakWidget s={s} />
        <ReviewWidget s={s} />
      </aside>
    </div>
  );
}

export function NotFound({ what = "Página" }: { what?: string }) {
  return (
    <div className="py-20 text-center">
      <div className="text-5xl">🗾</div>
      <h1 className="mt-4 text-2xl font-extrabold">{what} não encontrada</h1>
      <Button className="mt-6" onClick={() => navigate("/")}>
        Voltar ao início
      </Button>
    </div>
  );
}

function BackButton({ to }: { to: string }) {
  return (
    <button onClick={() => navigate(to)} aria-label="Voltar" className="rounded-full bg-white p-2.5 shadow-sm ring-1 ring-line transition hover:bg-canvas">
      <ArrowLeft size={20} />
    </button>
  );
}

// ───────────────────────────────────────── Página do capítulo
export function UnitScreen({ id }: { id: string }) {
  const s = useAppState((x) => x);
  const [expanded, setExpanded] = useState<string | null>(null);
  const u = unitById.get(id);
  if (!u) return <NotFound what="Capítulo" />;
  const unlocked = isUnitUnlocked(s, u);
  return (
    <div className="space-y-5">
      <div className="flex items-center gap-3">
        <BackButton to={`/?level=${u.level}`} />
        <span className="text-sm font-bold uppercase tracking-wider text-muted">
          {u.level} · Capítulo {u.levelIndex}
        </span>
      </div>
      <div className="relative overflow-hidden rounded-3xl p-6 text-white" style={{ background: `linear-gradient(135deg, ${u.color}, ${u.color}cc)` }}>
        <div className="absolute -right-2 -bottom-6 text-[8rem] opacity-25">{u.icon}</div>
        <h1 className="relative text-3xl font-extrabold">{u.title}</h1>
        <p className="relative mt-1 text-white/90">{u.desc}</p>
        <div className="relative mt-4 max-w-xs">
          <ProgressBar value={unitProgress(s, u)} color="#fff" className="bg-white/30" />
          <div className="mt-1 text-sm font-bold text-white/90">{Math.round(unitProgress(s, u) * 100)}% concluído</div>
        </div>
      </div>
      {!unlocked && (
        <Card className="flex items-center gap-3 border-amber-200 bg-amber-50">
          <Lock className="text-amber-600" />
          <p className="text-sm text-amber-900">Passe no checkpoint do capítulo anterior para desbloquear este capítulo.</p>
        </Card>
      )}
      <div className="relative space-y-3">
        <div className="absolute top-6 bottom-8 left-[33px] w-0.5 bg-line sm:left-[37px]" aria-hidden />
        {u.lessons.map((l) => (
          <LessonRow key={l.id} s={s} l={l} u={u} expanded={expanded === l.id} onToggle={() => setExpanded(expanded === l.id ? null : l.id)} />
        ))}
        <CheckpointRow s={s} u={u} />
      </div>
    </div>
  );
}

// ───────────────────────────────────────── Página da lição
export function LessonScreen({ id }: { id: string }) {
  const s = useAppState((x) => x);
  const l = lessonById.get(id);
  if (!l) return <NotFound what="Lição" />;
  const u = unitById.get(l.unitId)!;
  const lu = isLessonUnlocked(s, l);
  const next = ACTIVITY_TYPES.find((t) => !isActivityDone(s, l.id, t) && isActivityUnlocked(s, l, t));
  return (
    <div className="space-y-5">
      <div className="flex items-center gap-3">
        <BackButton to={`/unit/${u.id}`} />
        <span className="truncate text-sm font-bold uppercase tracking-wider text-muted">
          {u.level} · Cap. {u.levelIndex} · Lição {l.index + 1}
        </span>
      </div>
      <div className="flex items-center gap-4">
        <LessonIcon progress={lessonDoneCount(s, l) / ACTIVITY_TYPES.length} color={u.color} locked={!lu} label={<span className="text-2xl">{u.icon}</span>} size={72} />
        <div className="min-w-0">
          <h1 className="text-3xl font-extrabold tracking-tight">{l.title}</h1>
          <p className="text-muted">
            <JP text={l.desc} furigana={false} />
          </p>
        </div>
      </div>
      {!lu && (
        <Card className="flex items-center gap-3 border-amber-200 bg-amber-50">
          <Lock className="text-amber-600" />
          <p className="text-sm text-amber-900">Conclua a lição anterior para desbloquear esta lição.</p>
        </Card>
      )}
      <Card>
        <div className="text-xs font-bold uppercase tracking-wider text-muted">Nesta lição</div>
        <div className="mt-2 flex items-center gap-2 font-extrabold">
          <Puzzle size={18} className="text-purple" /> <JP text={l.grammar.title} furigana={false} />
        </div>
        <div className="mt-3 flex flex-wrap gap-2">
          {l.vocab.map((v) => (
            <span key={v.id} className="rounded-full bg-canvas px-3 py-1 text-sm">
              <JP text={v.jp} furigana={false} /> <span className="text-muted">· {v.pt}</span>
            </span>
          ))}
        </div>
        <div className="mt-3 flex gap-2">
          {l.kanji.map((k) => (
            <span key={k.id} className="jp flex h-11 w-11 items-center justify-center rounded-xl border border-line text-2xl" title={k.pt}>
              {k.char}
            </span>
          ))}
        </div>
      </Card>
      <div className="space-y-2.5">
        {ACTIVITY_TYPES.map((t, i) => {
          const Icon = ACTIVITY_ICON[t];
          const done = isActivityDone(s, l.id, t);
          const open = isActivityUnlocked(s, l, t);
          const rec = s.activities[activityKey(l.id, t)];
          const isNext = t === next;
          return (
            <button
              key={t}
              disabled={!open}
              onClick={() => navigate(`/play/${l.id}/${t}`)}
              className={cn(
                "flex w-full items-center gap-4 rounded-3xl border-2 bg-white p-4 text-left transition",
                isNext ? "border-brand shadow-md shadow-brand/10" : "border-line",
                open ? "hover:-translate-y-0.5 hover:shadow-md" : "cursor-not-allowed opacity-60"
              )}
            >
              <div className={cn("flex h-12 w-12 shrink-0 items-center justify-center rounded-full", done ? "bg-ok-50 text-ok" : isNext ? "bg-brand text-white" : "bg-canvas text-muted")}>
                <Icon size={24} />
              </div>
              <div className="min-w-0 flex-1">
                <div className="text-xs font-bold uppercase tracking-wider text-muted">Atividade {i + 1}</div>
                <div className="font-extrabold">{ACTIVITY_LABEL[t]}</div>
                <div className="truncate text-sm text-muted">{ACTIVITY_DESC[t]}</div>
              </div>
              {done ? (
                <div className="text-right">
                  <StatusIcon state="done" />
                  <div className="mt-1 text-xs font-bold text-muted">{Math.round((rec?.best ?? 0) * 100)}%</div>
                </div>
              ) : open ? (
                <span className={cn("rounded-full px-4 py-2 text-sm font-extrabold", isNext ? "bg-brand text-white" : "bg-brand-50 text-brand")}>Começar</span>
              ) : (
                <StatusIcon state="locked" />
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}
