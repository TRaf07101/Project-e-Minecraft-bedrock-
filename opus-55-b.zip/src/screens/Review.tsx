import { useMemo, useState } from "react";
import { ArrowLeft, Brain, ChevronRight, Lock, Search, Sparkles, Dumbbell, Star, Info, Layers, PenLine, BookOpen, Lightbulb } from "lucide-react";
import { grammarById, lessonById, unitById, vocabById, ALL_GRAMMAR, LEVELS, unitsOf, type Vocab } from "../course";
import { navigate } from "../lib/router";
import { grammarMastery, MASTERY_COLOR, MASTERY_LABEL, toggleFavorite, useAppState, vocabStrength, type Mastery, type Strength } from "../lib/store";
import { isActivityDone, isActivityUnlocked } from "../lib/progress";
import { AudioButton, Button, Card, JP, Modal, RichText, StrengthBars } from "../components/ui";
import { NotFound } from "./Learn";
import { cn } from "../utils/cn";

const STRENGTH_COLOR: Record<Strength, string> = { fraca: "#E5484D", média: "#F5A623", forte: "#1E9E62" };
const STRENGTH_LABEL: Record<Strength, string> = { fraca: "Fracas", média: "Médias", forte: "Fortes" };

function ModeChooser({ open, onClose, base }: { open: boolean; onClose: () => void; base: string }) {
  return (
    <Modal open={open} onClose={onClose}>
      <h3 className="text-xl font-extrabold">Como você quer revisar?</h3>
      <p className="text-sm text-muted">Escolha o formato desta revisão.</p>
      <div className="mt-4 space-y-3">
        <button onClick={() => navigate(`/review/play/${base}-flash`)} className="flex w-full items-center gap-4 rounded-2xl border-2 border-line p-4 text-left transition hover:border-brand">
          <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-brand-50 text-brand">
            <Layers size={24} />
          </span>
          <div>
            <div className="font-extrabold">Cartões</div>
            <div className="text-sm text-muted">Vire o cartão e diga se você sabia</div>
          </div>
        </button>
        <button onClick={() => navigate(`/review/play/${base}`)} className="flex w-full items-center gap-4 rounded-2xl border-2 border-line p-4 text-left transition hover:border-brand">
          <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-purple-50 text-purple">
            <PenLine size={24} />
          </span>
          <div>
            <div className="font-extrabold">Escrita e exercícios</div>
            <div className="text-sm text-muted">Múltipla escolha, áudio, verdadeiro ou falso e digitação</div>
          </div>
        </button>
      </div>
      <Button variant="ghost" className="mt-3 w-full" onClick={onClose}>
        Cancelar
      </Button>
    </Modal>
  );
}

function WordModal({ v, onClose }: { v: Vocab | null; onClose: () => void }) {
  const s = useAppState((x) => x);
  if (!v) return null;
  const l = lessonById.get(v.lessonId)!;
  const u = unitById.get(l.unitId)!;
  const fav = s.favorites.includes(v.id);
  const r = s.vocab[v.id];
  const st = vocabStrength(r);
  return (
    <Modal open onClose={onClose}>
      <div className="flex items-start justify-between gap-3">
        <div>
          <JP text={v.jp} className="text-3xl font-bold leading-[1.9]" />
          <div className="text-muted">
            <span className="jp">{v.kana}</span> · <span className="italic">{v.romaji}</span>
          </div>
        </div>
        <AudioButton text={v.kana} />
      </div>
      <div className="mt-2 text-xl font-extrabold">{v.pt}</div>
      <div className="mt-4 rounded-2xl bg-canvas p-3">
        <div className="mb-1 flex items-center gap-2 text-xs font-bold uppercase text-muted">
          Exemplo <AudioButton text={v.ex} size="sm" />
        </div>
        <JP text={v.ex} className="text-lg leading-[2]" />
        <div className="text-sm text-muted">{v.exPt}</div>
      </div>
      <div className="mt-4 flex items-center justify-between text-sm">
        <span className="flex items-center gap-2">
          <StrengthBars strength={st} /> <span className="font-bold capitalize">{st}</span>
        </span>
        <span className="text-muted">
          {u.level} · Cap. {u.levelIndex} · {l.title}
        </span>
      </div>
      {r && (
        <div className="mt-1 text-xs text-muted">
          {r.correct} acertos · {r.wrong} erros · próxima revisão {r.due <= Date.now() ? "agora" : new Date(r.due).toLocaleDateString("pt-BR")}
        </div>
      )}
      <div className="mt-5 flex gap-2">
        <Button variant={fav ? "primary" : "secondary"} className="flex-1" onClick={() => toggleFavorite(v.id)}>
          <Star size={18} className={cn(fav && "fill-current")} /> {fav ? "Favorita" : "Favoritar"}
        </Button>
        <Button variant="ghost" onClick={onClose}>
          Fechar
        </Button>
      </div>
    </Modal>
  );
}

function VocabTab() {
  const s = useAppState((x) => x);
  const [list, setList] = useState<"todas" | "favoritas">("todas");
  const [filter, setFilter] = useState<Strength | null>(null);
  const [q, setQ] = useState("");
  const [chooser, setChooser] = useState<string | null>(null);
  const [info, setInfo] = useState<Vocab | null>(null);
  const now = Date.now();

  const words = useMemo(
    () =>
      Object.entries(s.vocab)
        .filter(([id]) => vocabById.has(id))
        .map(([id, r]) => ({ v: vocabById.get(id)!, r, st: vocabStrength(r) })),
    [s.vocab]
  );
  const due = words.filter((w) => w.r.due <= now).length;
  const counts: Record<Strength, number> = { fraca: 0, média: 0, forte: 0 };
  words.forEach((w) => counts[w.st]++);
  const favCount = s.favorites.filter((id) => s.vocab[id]).length;
  const query = q.trim().toLowerCase();
  const shown = words
    .filter((w) => list === "todas" || s.favorites.includes(w.v.id))
    .filter((w) => !filter || w.st === filter)
    .filter((w) => !query || w.v.pt.toLowerCase().includes(query) || w.v.kana.includes(query) || w.v.romaji.includes(query) || w.v.jp.includes(query))
    .sort((a, b) => a.r.box - b.r.box || a.v.id.localeCompare(b.v.id));

  if (words.length === 0)
    return (
      <Card className="py-10 text-center">
        <Brain className="mx-auto text-brand-soft" size={48} />
        <h2 className="mt-3 text-xl font-extrabold">Seu vocabulário aparece aqui</h2>
        <p className="mx-auto mt-1 max-w-sm text-muted">Toda palavra que você estudar na atividade de Vocabulário entra automaticamente na sua revisão.</p>
        <Button className="mt-5" onClick={() => navigate("/")}>
          Ir para as lições
        </Button>
      </Card>
    );

  return (
    <div className="space-y-4">
      <Card className="p-5">
        <div className="flex flex-wrap items-center gap-4">
          <div className="min-w-0 flex-1">
            <div className="text-xs font-bold uppercase tracking-wider text-muted">Seu vocabulário</div>
            <div className="text-2xl font-extrabold">{words.length} palavras</div>
            <div className="text-sm text-muted">{due > 0 ? `${due} prontas para revisão agora` : "Nenhuma revisão pendente — pratique quando quiser"}</div>
          </div>
          <Button onClick={() => setChooser("smart")}>
            <Sparkles size={18} /> Revisar agora
          </Button>
        </div>
        <div className="mt-4 flex h-3 overflow-hidden rounded-full bg-line">
          {(["fraca", "média", "forte"] as Strength[]).map((k) => (
            <div key={k} style={{ width: `${(counts[k] / words.length) * 100}%`, background: STRENGTH_COLOR[k] }} className="transition-all" />
          ))}
        </div>
        <div className="mt-3 grid grid-cols-3 gap-2">
          {(["fraca", "média", "forte"] as Strength[]).map((k) => (
            <button
              key={k}
              onClick={() => setFilter(filter === k ? null : k)}
              className={cn("flex items-center gap-2 rounded-2xl border-2 px-3 py-2 text-left transition", filter === k ? "border-brand bg-brand-50" : "border-transparent bg-canvas")}
            >
              <StrengthBars strength={k} />
              <div>
                <div className="font-extrabold leading-tight">{counts[k]}</div>
                <div className="text-xs font-semibold text-muted">{STRENGTH_LABEL[k]}</div>
              </div>
            </button>
          ))}
        </div>
        <div className="mt-3 flex flex-wrap gap-2">
          <Button variant="secondary" className="min-h-10 py-2" disabled={counts.fraca + counts.média === 0} onClick={() => setChooser("weak")}>
            <Dumbbell size={16} /> Fortalecer palavras
          </Button>
          <Button variant="secondary" className="min-h-10 py-2" disabled={favCount < 5} onClick={() => setChooser("fav")} >
            <Star size={16} /> Testar favoritas {favCount < 5 && <span className="text-xs font-semibold">(mín. 5)</span>}
          </Button>
        </div>
      </Card>

      <div className="flex flex-wrap items-center gap-2">
        <div className="flex rounded-full bg-white p-1 ring-1 ring-line">
          {(["todas", "favoritas"] as const).map((k) => (
            <button key={k} onClick={() => setList(k)} className={cn("rounded-full px-4 py-1.5 text-sm font-bold capitalize transition", list === k ? "bg-ink text-white" : "text-muted")}>
              {k === "todas" ? "Todas" : `Favoritas (${favCount})`}
            </button>
          ))}
        </div>
        <div className="relative min-w-48 flex-1">
          <Search className="absolute top-1/2 left-3.5 -translate-y-1/2 text-muted" size={17} />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Buscar palavra"
            className="w-full rounded-full border-2 border-line bg-white py-2 pr-4 pl-10 text-sm outline-none focus:border-brand"
          />
        </div>
      </div>

      <Card className="divide-y divide-line p-0">
        {shown.length === 0 && <div className="p-6 text-center text-muted">{list === "favoritas" ? "Toque na estrela de uma palavra para salvá-la nas favoritas." : "Nenhuma palavra encontrada."}</div>}
        {shown.map(({ v, st }) => {
          const fav = s.favorites.includes(v.id);
          return (
            <div key={v.id} className="flex items-center gap-3 px-3 py-2.5 sm:px-4">
              <AudioButton text={v.kana} size="sm" />
              <button onClick={() => setInfo(v)} className="min-w-0 flex-1 text-left">
                <JP text={v.jp} className="text-lg leading-[2]" />
                <div className="truncate text-sm text-muted">
                  {s.settings.romaji && <span className="italic">{v.romaji} · </span>}
                  {v.pt}
                </div>
              </button>
              <StrengthBars strength={st} />
              <button onClick={() => toggleFavorite(v.id)} aria-label={fav ? "Remover das favoritas" : "Favoritar"} className="rounded-full p-2 hover:bg-canvas">
                <Star size={20} className={fav ? "fill-warn text-warn" : "text-muted"} />
              </button>
              <button onClick={() => setInfo(v)} aria-label="Ver detalhes" className="hidden rounded-full p-2 text-muted hover:bg-canvas sm:block">
                <Info size={20} />
              </button>
            </div>
          );
        })}
      </Card>
      <ModeChooser open={!!chooser} onClose={() => setChooser(null)} base={chooser ?? "smart"} />
      <WordModal v={info} onClose={() => setInfo(null)} />
    </div>
  );
}

function MasteryPill({ m, learned }: { m: Mastery; learned: boolean }) {
  if (!learned) return <span className="shrink-0 rounded-full bg-canvas px-2.5 py-1 text-xs font-bold text-muted">Não estudado</span>;
  return (
    <span className="inline-flex shrink-0 items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-bold" style={{ background: MASTERY_COLOR[m] + "1a", color: MASTERY_COLOR[m] }}>
      <span className="h-2 w-2 rounded-full" style={{ background: MASTERY_COLOR[m] }} /> {MASTERY_LABEL[m]}
    </span>
  );
}

function GrammarTab() {
  const s = useAppState((x) => x);
  const learned = ALL_GRAMMAR.filter((g) => isActivityDone(s, g.lessonId, "grammar"));
  const counts: Record<Mastery, number> = { needs: 0, improving: 0, strong: 0, mastered: 0 };
  learned.forEach((g) => counts[grammarMastery(s.grammar[g.id])]++);
  const order: Mastery[] = ["needs", "improving", "strong", "mastered"];
  return (
    <div className="space-y-4">
      <Card className="p-5">
        <div className="flex flex-wrap items-center gap-4">
          <div className="min-w-0 flex-1">
            <div className="text-xs font-bold uppercase tracking-wider text-muted">Revisão de gramática</div>
            <div className="text-2xl font-extrabold">
              {learned.length} de {ALL_GRAMMAR.length} tópicos estudados
            </div>
            <div className="text-sm text-muted">A prática personalizada escolhe os tópicos que mais precisam de atenção.</div>
          </div>
          <Button disabled={!learned.length} onClick={() => navigate("/review/play/grammar")}>
            <Sparkles size={18} /> Praticar agora
          </Button>
        </div>
        <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
          {order.map((m) => (
            <div key={m} className="rounded-2xl bg-canvas p-3">
              <div className="h-1.5 w-8 rounded-full" style={{ background: MASTERY_COLOR[m] }} />
              <div className="mt-2 text-2xl font-extrabold">{counts[m]}</div>
              <div className="text-xs font-semibold text-muted">{MASTERY_LABEL[m]}</div>
            </div>
          ))}
        </div>
      </Card>
      {LEVELS.map((lv) => (
        <div key={lv}>
          <h2 className="mb-2 text-lg font-extrabold">Nível {lv}</h2>
          <Card className="divide-y divide-line p-0">
            {unitsOf(lv).flatMap((u) =>
              u.lessons.map((l) => {
                const g = l.grammar;
                const isLearned = isActivityDone(s, l.id, "grammar");
                return (
                  <button key={g.id} onClick={() => navigate(`/grammar/${g.id}`)} className="flex w-full items-center gap-3 px-4 py-3 text-left hover:bg-canvas/60">
                    <span className={cn("flex h-9 w-9 shrink-0 items-center justify-center rounded-xl", isLearned ? "bg-purple-50 text-purple" : "bg-canvas text-muted")}>
                      {isLearned ? <Lightbulb size={18} /> : <Lock size={15} />}
                    </span>
                    <div className="min-w-0 flex-1">
                      <div className="truncate font-bold">
                        <JP text={g.title} furigana={false} />
                      </div>
                      <div className="truncate text-xs text-muted">
                        Cap. {u.levelIndex} · {u.title} · {l.title}
                      </div>
                    </div>
                    <MasteryPill m={grammarMastery(s.grammar[g.id])} learned={isLearned} />
                    <ChevronRight className="hidden shrink-0 text-muted sm:block" size={18} />
                  </button>
                );
              })
            )}
          </Card>
        </div>
      ))}
    </div>
  );
}

export function Review() {
  const [tab, setTab] = useState<"vocab" | "grammar">(() => (window.location.hash.includes("tab=grammar") ? "grammar" : "vocab"));
  return (
    <div className="space-y-5">
      <h1 className="text-3xl font-extrabold tracking-tight">Revisar</h1>
      <div className="flex rounded-full bg-white p-1 shadow-sm ring-1 ring-line">
        {(
          [
            ["vocab", "Vocabulário", BookOpen],
            ["grammar", "Gramática", Lightbulb],
          ] as const
        ).map(([k, label, Icon]) => (
          <button
            key={k}
            onClick={() => {
              setTab(k);
              window.history.replaceState(null, "", k === "grammar" ? "#/review?tab=grammar" : "#/review");
            }}
            className={cn("flex flex-1 items-center justify-center gap-2 rounded-full py-2.5 font-bold transition", tab === k ? "bg-brand text-white shadow" : "text-muted")}
          >
            <Icon size={18} /> {label}
          </button>
        ))}
      </div>
      {tab === "vocab" ? <VocabTab /> : <GrammarTab />}
    </div>
  );
}

export function GrammarDetail({ id }: { id: string }) {
  const s = useAppState((x) => x);
  const g = grammarById.get(id);
  if (!g) return <NotFound what="Tópico" />;
  const l = lessonById.get(g.lessonId)!;
  const u = unitById.get(l.unitId)!;
  const learned = isActivityDone(s, l.id, "grammar");
  const canPractice = learned || isActivityUnlocked(s, l, "grammar");
  const m = grammarMastery(s.grammar[g.id]);
  const r = s.grammar[g.id];
  return (
    <div className="space-y-5">
      <div className="flex items-center gap-3">
        <button onClick={() => navigate("/review?tab=grammar")} aria-label="Voltar" className="rounded-full bg-white p-2.5 shadow-sm ring-1 ring-line">
          <ArrowLeft size={20} />
        </button>
        <span className="truncate text-sm font-bold uppercase tracking-wider text-muted">
          {u.level} · Cap. {u.levelIndex} · {l.title}
        </span>
      </div>
      <h1 className="text-3xl font-extrabold leading-tight">
        <JP text={g.title} />
      </h1>
      <Card className="flex flex-wrap items-center gap-3">
        <div className="min-w-0 flex-1">
          <div className="text-xs font-bold uppercase tracking-wider text-muted">Seu domínio</div>
          <div className="mt-1 flex gap-1.5">
            {(["needs", "improving", "strong", "mastered"] as Mastery[]).map((k, i, arr) => (
              <span key={k} className="h-2 flex-1 rounded-full" style={{ background: learned && arr.indexOf(m) >= i ? MASTERY_COLOR[m] : "var(--color-line)" }} />
            ))}
          </div>
          <div className="mt-1 text-sm font-bold" style={{ color: learned ? MASTERY_COLOR[m] : undefined }}>
            {learned ? MASTERY_LABEL[m] : "Ainda não estudado"}
            {r && <span className="font-medium text-muted"> · {r.correct} acertos, {r.wrong} erros</span>}
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button disabled={!canPractice} onClick={() => navigate(`/review/play/g-${g.id}`)} className="min-h-11 py-2">
            {canPractice ? "Praticar agora" : (
              <>
                <Lock size={15} /> Praticar
              </>
            )}
          </Button>
          <Button variant="secondary" onClick={() => navigate(`/lesson/${l.id}`)} className="min-h-11 py-2">
            Ir para a lição
          </Button>
        </div>
      </Card>
      <div>
        <h2 className="mb-2 flex items-center gap-2 text-sm font-bold uppercase tracking-wider text-muted">
          <Lightbulb size={16} className="text-purple" /> Dicas
        </h2>
        <Card className="text-[1.02rem]">
          <RichText text={g.explanation} />
        </Card>
      </div>
      <h2 className="text-sm font-bold uppercase tracking-wider text-muted">Exemplos</h2>
      <div className="space-y-2">
        {g.examples.map((x) => (
          <Card key={x.jp} className="flex items-start gap-3 p-4">
            <AudioButton text={x.jp} size="sm" />
            <div>
              <JP text={x.jp} className="text-lg leading-[2]" />
              <div className="text-muted">{x.pt}</div>
            </div>
          </Card>
        ))}
      </div>
      {!canPractice && <p className="text-sm text-muted">A prática deste tópico é liberada quando você chega à lição “{l.title}”. As dicas podem ser lidas a qualquer momento.</p>}
    </div>
  );
}
