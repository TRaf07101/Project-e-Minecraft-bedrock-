import { useState } from "react";
import { buildMcaddon } from "./addon/build";
import { ItemsPreview, TablePreview, UiPreview } from "./site/Previews";

export default function App() {
  const [status, setStatus] = useState("");
  const [busy, setBusy] = useState(false);

  async function download() {
    setBusy(true);
    setStatus("Gerando o addon…");
    try {
      const blob = await buildMcaddon(setStatus);
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "ProjectE.mcaddon";
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 60_000);
      setStatus("");
    } catch (e) {
      setStatus("Erro ao gerar o arquivo: " + String(e));
    } finally {
      setBusy(false);
    }
  }

  return (
    <main style={{ maxWidth: 720, margin: "6vh auto", padding: 24, fontFamily: "system-ui, sans-serif", textAlign: "center" }}>
      <h1 style={{ fontSize: 40, margin: 0 }}>ProjectE</h1>
      <p style={{ color: "#444", lineHeight: 1.5 }}>
        Port não oficial do mod ProjectE (EMC, transmutação, Pedra Filosofal, Klein Stars, coletores, relés, condensador e itens de matéria) para
        Minecraft Bedrock 1.21.90 ou mais recente.
      </p>
      <button
        onClick={download}
        disabled={busy}
        style={{ fontSize: 18, padding: "12px 28px", borderRadius: 8, border: "none", background: busy ? "#999" : "#c4162a", color: "#fff", cursor: busy ? "default" : "pointer" }}
      >
        Baixar addon
      </button>
      {status && <p style={{ color: "#666" }}>{status}</p>}

      <h2 style={{ marginTop: 40, fontSize: 20 }}>Mesa de Transmutação</h2>
      <TablePreview />
      <p style={{ color: "#777", fontSize: 13 }}>Modelo 3D (laje 16×4×16, como no mod). Arraste para girar.</p>

      <h2 style={{ marginTop: 32, fontSize: 20 }}>Ferramentas, armaduras e itens</h2>
      <ItemsPreview />
      <p style={{ color: "#777", fontSize: 13 }}>Ícones originais do ProjectE (MIT). Passe o mouse para ver o nome.</p>

      <h2 style={{ marginTop: 32, fontSize: 20 }}>Nova interface</h2>
      <UiPreview />
      <p style={{ color: "#777", fontSize: 13 }}>
        Prévia montada no navegador com a textura original da interface (transmute.png) e os ícones do pacote. Não é uma captura de tela do jogo; no Minecraft, os itens vanilla usam os ícones do próprio
        jogo.
      </p>
    </main>
  );
}
